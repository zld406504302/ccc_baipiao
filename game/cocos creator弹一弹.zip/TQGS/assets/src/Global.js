cc.Class({
    statics: {
        screenStartTime: 0,
        openAds: !0,
        sceneA: !1,
        boomScale: 1,
        InitData: function() {}
    }
});