cc.Class({
    extends: cc.Component,
    properties: {},
    EndFlash: function() {
        this.node.active = !1
    }
})