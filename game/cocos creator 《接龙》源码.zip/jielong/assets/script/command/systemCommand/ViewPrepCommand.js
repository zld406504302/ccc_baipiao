cc.Class({
    extends: puremvc.SimpleCommand,

    properties: {
        
    },

    execute(notification){

    }
});
