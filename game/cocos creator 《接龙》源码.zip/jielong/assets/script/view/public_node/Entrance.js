var NodeCtlMediator = require("NodeCtlMediator");
var LoadingNodeMediator = require("LoadingNodeMediator");
var StartupCommand = require("StartupCommand");
var UserProxy = require("UserProxy");
var upltv = require("UPLTV").upltv;
cc.bridgeInterface = require("UPLTV").bridgeInterface;

cc.Class({
    extends: cc.Component,

    properties: {
        layerContent:cc.Node,
        nodeContent:cc.Node,
        popContent:cc.Node,
        toastContent:cc.Node,
        loadingNode:cc.Node,
        loadingLogoNode:cc.Node,
        loadingLogoCircle:cc.Node,
        loadingProgressBar:cc.ProgressBar,
        progressLabel:cc.Label,

    },
    //如果在ctor new mediator,可能造成mediator初始化node的数据出问题
    onLoad(){

        puremvc.Facade.registerCommand(appNotice.START_UP,StartupCommand);
        puremvc.Facade.sendNotification(appNotice.START_UP);
        puremvc.Facade.registerMediator(new LoadingNodeMediator(LoadingNodeMediator.NAME,this));
        puremvc.Facade.registerMediator(new NodeCtlMediator(NodeCtlMediator.NAME,this));


        //必须加载的资源，否则无法启动整套UI框架
        preloadTool.preload(["prefab_ToastNode"],false,function(){
            puremvc.Facade.sendNotification(appNotice.CHANGE_LAYER, {name: "MainNode", loading: true});
        });

        if (cc.sys.isNative && cc.sys.os === cc.sys.OS_ANDROID) {
            upltv.intSdk(2);
            console.log("初始化广告sdk完成");
        }
        
        console.log("imei:",this.getIMEI());
        var data = {
            imei: this.getIMEI(),
            channel: "a_01"
        }
        var http = require("http");
        http.sendRequest("/getchannel", data);

        this.setLanguage();
    },

    getIMEI: function() {
        if (cc.sys.isNative && cc.sys.os === cc.sys.OS_ANDROID) {
            return jsb.reflection.callStaticMethod('org/cocos2dx/javascript/GameAPI', 'getIMEI',"()Ljava/lang/String;");
        }else{
            return "web";
        }
    },

    setLanguage: function () {
        var language = "en-CN";
        if (cc.sys.isNative && cc.sys.os === cc.sys.OS_ANDROID) {
            language = jsb.reflection.callStaticMethod('org/cocos2dx/javascript/GameAPI', 'getLanguage',"()Ljava/lang/String;");
            window.sysLanguage = language;
        }else if(cc.sys.isBrowser){
            language = (navigator.language || navigator.browserLanguage).toLowerCase();
            window.sysLanguage = language;
        }
        if(language.indexOf("en") != -1){
            window.language = window.enumLanguage.English;
        }else if(language.indexOf("zh-TW") != -1){ 
            window.language = window.enumLanguage.ChineseTraditional;
        }else if(language.indexOf("zh") != -1){
            window.language = window.enumLanguage.Chinese;
        }else if(language.indexOf("nl") != -1){
            window.language = window.enumLanguage.Dutch;
        }else if(language.indexOf("fr") != -1){
            window.language = window.enumLanguage.French;
        }else if(language.indexOf("de") != -1){
            window.language = window.enumLanguage.German;
        }else if(language.indexOf("it") != -1){ 
            window.language = window.enumLanguage.Italian;
        }else if(language.indexOf("ja") != -1){ 
            window.language = window.enumLanguage.Japanese;
        }else if(language.indexOf("ru") != -1){ 
            window.language = window.enumLanguage.Russian;
        }else if(language.indexOf("es") != -1){ 
            window.language = window.enumLanguage.Spanish;
        }else if(language.indexOf("pt") != -1){ 
            window.language = window.enumLanguage.Portuguese;
        }else if(language.indexOf("tr") != -1){ 
            window.language = window.enumLanguage.Turkish;
        }else{
            window.language = window.enumLanguage.English;
        }
    },

    onDestroy(){
        puremvc.Facade.removeMediator(NodeCtlMediator.NAME);
        puremvc.Facade.removeMediator(LoadingNodeMediator.NAME);
    },
});
