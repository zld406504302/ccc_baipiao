var BaseCmpt = require("BaseCmpt")
var HelpNodeMediator =require("HelpNodeMediator")
var Localization = require("Localization");

cc.Class({
    extends: BaseCmpt,
    mediatorName:HelpNodeMediator,
    properties: {

    },

    onLoad () {
        this._super();
        
        var closebtn = this.node.getChildByName("content").getChildByName("closebtn");
        closebtn.on('click', ()=>{
            this.hideNode("HelpNode");
        }, this);
        
        // this.node.getChildByName("bg").on('click', ()=>{
        //     this.hideNode("HelpNode");
        // }, this);

        
        this.node.getChildByName("content").getChildByName("title").getComponent("cc.Label").string = Localization["HowToPlay"][window.language];

        this._pageIndex = 0;
        this._pageView = this.node.getChildByName("content").getChildByName("pageView");

        this._pageback = this.node.getChildByName("content").getChildByName("pageback");
        this._pageback.getChildByName("New Label").getComponent("cc.Label").string = Localization["Tip_Help_prev"][window.language];
        this._pagefoward = this.node.getChildByName("content").getChildByName("pagefoward");
        this._pagefoward.getChildByName("New Label").getComponent("cc.Label").string = Localization["Tip_Help_next"][window.language];

        this._pageback.getComponent("cc.Button").interactable = false;

        var content = this.node.getChildByName("content").getChildByName("pageView").getChildByName("view").getChildByName("content");
        for(var i = 0; i < content.children.length; ++i){
            content.children[i].getChildByName("New Label").getComponent("cc.Label").string = Localization["Tip_Help_" + (i+1)][window.language];
        }

        actionLib.backIn(this.node.getChildByName("content"));
    },

    onPageBack(){
        this._pageIndex--;
        this._pageView.getComponent("cc.PageView").setCurrentPageIndex(this._pageIndex);
        // this._pagefoward.getComponent("cc.Button").interactable = true;
        this._pagefoward.getChildByName("New Label").getComponent("cc.Label").string = Localization["Tip_Help_next"][window.language];
        if(this._pageIndex <= 0){
            this._pageback.getComponent("cc.Button").interactable = false;
        }
    },

    onPageFoward(){
        this._pageIndex++;
        this._pageView.getComponent("cc.PageView").setCurrentPageIndex(this._pageIndex);
        this._pageback.getComponent("cc.Button").interactable = true;
        if(this._pageIndex == 5){
            // this._pagefoward.getComponent("cc.Button").interactable = false;
            this._pagefoward.getChildByName("New Label").getComponent("cc.Label").string = Localization["StartGame"][window.language];
        }else if(this._pageIndex > 5){
            this._pageIndex = 5;
            this.dispatchEvent("CLICK_NEW_GAME_BTN");
        }
    },

    onDestroy:function(){
        this._super();
        actionLib.backOut(this.node.getChildByName("content"));
    }
});
