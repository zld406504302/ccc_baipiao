var BaseMediator = require("BaseMediator")
cc.Class({
    extends:BaseMediator,

    properties: {

    },


    didRegister(){
        this.bind("CLICK_CLOSE_BTN", (data)=>{
            this.facade.sendNotification(appNotice.HIDE_NODE,{name:"HelpNode"});
        }, this);

        this.bind("CLICK_NEW_GAME_BTN", (data)=>{
            this.facade.sendNotification(appNotice.HIDE_NODE,{name:"HelpNode"});
            this.facade.sendNotification(appNotice.RESET_MATCH);
        }, this);
        
    },

    listNotificationInterests(){
        return [
            
        ];
    },

    handleNotification(notification){
        var data = notification.getBody();
        var view = this.viewComponent;
        var name = notification.getName();
        console.log("handleNotification data : " + name + ":" + JSON.stringify(data));
        switch(name){
            
        }
    },

});
