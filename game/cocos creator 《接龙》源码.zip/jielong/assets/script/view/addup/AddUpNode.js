var BaseCmpt = require("BaseCmpt")
var AddUpNodeMediator =require("AddUpNodeMediator")
var Localization = require("Localization");

cc.Class({
    extends: BaseCmpt,
    mediatorName:AddUpNodeMediator,
    properties: {
 
    },

    onLoad () {
        this._super();
        var closebtn = this.node.getChildByName("content").getChildByName("closebtn");
        closebtn.on('click', ()=>{
            // this.hideNode("AddUpNode");
            this.dispatchEvent("CLICK_CLOSE_BTN");
        }, this);

        this.node.getChildByName("bg").on('click', ()=>{
            // this.hideNode("AddUpNode");
            this.dispatchEvent("CLICK_CLOSE_BTN");
        }, this);

        this.index = 0;

        var content = this.node.getChildByName("content");

        content.getChildByName("title").getComponent("cc.Label").string = Localization["Stats"][window.language];

        this.ocardbtn = content.getChildByName("groupnode").getChildByName("ocardbtn");
        this.ocardbtn.getChildByName("New Label").getComponent("cc.Label").string = Localization["OneCard"][window.language];
        this.itembg1 = this.ocardbtn.getChildByName("itembg_1");
        this.ocardbtn.on('click', ()=>{
            this.selectGroupBtn(0);
        }, this);
        this.tcardbtn = content.getChildByName("groupnode").getChildByName("tcardbtn");
        this.tcardbtn.getChildByName("New Label").getComponent("cc.Label").string = Localization["ThreeCard"][window.language];
        this.itembg2 = this.tcardbtn.getChildByName("itembg_1");
        this.tcardbtn.on('click', ()=>{
            this.selectGroupBtn(1);
        }, this);
        this.wjsbtn = content.getChildByName("groupnode").getChildByName("wjsbtn");
        this.wjsbtn.getChildByName("New Label").getComponent("cc.Label").string = Localization["VegasGame"][window.language];
        this.itembg3 = this.wjsbtn.getChildByName("itembg_1");
        this.wjsbtn.on('click', ()=>{
            this.selectGroupBtn(2);
        }, this);

        this.yzplayout = content.getChildByName("yzplayout");
        this.yzplayout.active = true;
        this.yzpNumList = [];
        for(var i = 0; i < this.yzplayout.children.length; ++i){
            var num = this.yzplayout.children[i].getChildByName("num");
            this.yzpNumList.push(num);
            var nameLabel = this.yzplayout.children[i].getChildByName("name").getComponent("cc.Label");
            if(i == 0){
                nameLabel.string = Localization["GamesPlayed"][window.language];
            }else if(i == 1){
                nameLabel.string = Localization["GamesWon"][window.language];
            }else if(i == 2){
                nameLabel.string = Localization["BestScore"][window.language];
            }else if(i == 3){
                nameLabel.string = Localization["LeastMoves"][window.language];
            }else if(i == 4){
                nameLabel.string = Localization["BestTime"][window.language];
            }else if(i == 5){
                nameLabel.string = Localization["TotalTime"][window.language];
            }
        }

        this.szplayout = content.getChildByName("szplayout");
        this.szplayout.active = false;
        this.szpNumList = [];
        for(var i = 0; i < this.szplayout.children.length; ++i){
            var num = this.szplayout.children[i].getChildByName("num");
            this.szpNumList.push(num);

            var nameLabel = this.szplayout.children[i].getChildByName("name").getComponent("cc.Label");
            if(i == 0){
                nameLabel.string = Localization["GamesPlayed"][window.language];
            }else if(i == 1){
                nameLabel.string = Localization["GamesWon"][window.language];
            }else if(i == 2){
                nameLabel.string = Localization["BestScore"][window.language];
            }else if(i == 3){
                nameLabel.string = Localization["LeastMoves"][window.language];
            }else if(i == 4){
                nameLabel.string = Localization["BestTime"][window.language];
            }else if(i == 5){
                nameLabel.string = Localization["TotalTime"][window.language];
            }
        }

        this.wjslayout = content.getChildByName("wjslayout");
        this.wjslayout.active = false;
        this.wjsNumList = [];
        for(var i = 0; i < this.wjslayout.children.length; ++i){
            var num = this.wjslayout.children[i].getChildByName("num");
            this.wjsNumList.push(num);

            var nameLabel = this.wjslayout.children[i].getChildByName("name").getComponent("cc.Label");
            if(i == 0){
                nameLabel.string = Localization["GamesPlayed"][window.language];
            }else if(i == 1){
                nameLabel.string = Localization["GamesWon"][window.language];
            }else if(i == 2){
                nameLabel.string = Localization["TotalMoneyCost"][window.language];
            }else if(i == 3){
                nameLabel.string = Localization["TotalMoneyWonBack"][window.language];
            }else if(i == 4){
                nameLabel.string = Localization["CumulativeHighestScore"][window.language];
            }
        }

        var resetbtn = content.getChildByName("resetbtn");
        resetbtn.getChildByName("New Label").getComponent("cc.Label").string = Localization["Reset"][window.language];
        resetbtn.on('click', ()=>{
            this.resetDataIndex();
        }, this);

        actionLib.backIn(this.node.getChildByName("content"));
    },

    initData(){
        var num = 0;
        for(var i = 0; i < this.yzpNumList.length; ++i){
            if(i == 0){
                num = parseInt(cc.sys.localStorage.getItem("one_totalJuShu")) || 0;
            }else if(i == 1){
                var one_totalJuShu = parseInt(cc.sys.localStorage.getItem("one_totalJuShu")) || 0;
                var one_successNum = parseInt(cc.sys.localStorage.getItem("one_successNum")) || 0;
                if(one_totalJuShu == 0){
                    num = "0(0.00%)";
                }else{
                    num = one_successNum.toString() + "(" + (one_successNum/one_totalJuShu * 100).toFixed(2) + "%)";
                }
            }else if(i == 2){
                num = parseInt(cc.sys.localStorage.getItem("one_bestScore")) || 0;
            }else if(i == 3){
                num = parseInt(cc.sys.localStorage.getItem("one_minMoveStep")) || 0;
            }else if(i == 4){
                num = parseInt(cc.sys.localStorage.getItem("one_minTime")) || 0;
            }else if(i == 5){
                num = parseInt(cc.sys.localStorage.getItem("one_totalTime")) || 0;
            }
            this.yzpNumList[i].getComponent("cc.Label").string = num;
        }

        for(var i = 0; i < this.szpNumList.length; ++i){
            if(i == 0){
                num = parseInt(cc.sys.localStorage.getItem("three_totalJuShu")) || 0;
            }else if(i == 1){
                var three_totalJuShu = parseInt(cc.sys.localStorage.getItem("three_totalJuShu")) || 0;
                var three_successNum = parseInt(cc.sys.localStorage.getItem("three_successNum")) || 0;
                if(three_totalJuShu == 0){
                    num = "0(0.00%)";
                }else{
                    num = three_successNum.toString() + "(" + (three_successNum/three_totalJuShu * 100).toFixed(2) + "%)";
                }
            }else if(i == 2){
                num = parseInt(cc.sys.localStorage.getItem("three_bestScore")) || 0;
            }else if(i == 3){
                num = parseInt(cc.sys.localStorage.getItem("three_minMoveStep")) || 0;
            }else if(i == 4){
                num = parseInt(cc.sys.localStorage.getItem("three_minTime")) || 0;
            }else if(i == 5){
                num = parseInt(cc.sys.localStorage.getItem("three_totalTime")) || 0;
            }
            this.szpNumList[i].getComponent("cc.Label").string = num;
        }

        for(var i = 0; i < this.wjsNumList.length; ++i){
            if(i == 0){
                num = parseInt(cc.sys.localStorage.getItem("wjs_totalJuShu")) || 0;
            }else if(i == 1){
                var wjs_totalJuShu = parseInt(cc.sys.localStorage.getItem("wjs_totalJuShu")) || 0;
                var wjs_successNum = parseInt(cc.sys.localStorage.getItem("wjs_successNum")) || 0;
                if(wjs_totalJuShu == 0){
                    num = "0(0.00%)";
                }else{
                    num = wjs_successNum.toString() + "(" + (wjs_successNum/wjs_totalJuShu * 100).toFixed(2) + "%)";
                }
            }else if(i == 2){
                num = "$" + (parseInt(cc.sys.localStorage.getItem("wjs_totalJuShu")) || 0) * 52 ;
            }else if(i == 3){
                num = "$" + (parseInt(cc.sys.localStorage.getItem("wjs_totalIncome")) || 0);
            }else if(i == 4){
                num = "$" + (parseInt(cc.sys.localStorage.getItem("wjs_maxCash")) || 0);
            }
            this.wjsNumList[i].getComponent("cc.Label").string = num;
        }
    },

    selectGroupBtn:function(index){
        if(this.index != index){
            this.index = index;
            this.itembg1.active = false;
            this.itembg2.active = false;
            this.itembg3.active = false;
            this.yzplayout.active = false;
            this.szplayout.active = false;
            this.wjslayout.active = false;
            if(index == 0){
                this.itembg1.active = true;
                this.yzplayout.active = true;
            }else if(index == 1){
                this.itembg2.active = true;
                this.szplayout.active = true;
            }else if(index == 2){
                this.itembg3.active = true;
                this.wjslayout.active = true;
            }
        }
    },

    resetDataIndex(){
        
        if(this.index == 0){
            for(var i = 0; i < this.yzpNumList.length; ++i){
                if(i == 1){
                    this.yzpNumList[i].getComponent("cc.Label").string = "0(0.00%)";
                }else{
                    this.yzpNumList[i].getComponent("cc.Label").string = 0;
                }
            }

            cc.sys.localStorage.removeItem("one_totalJuShu");
            cc.sys.localStorage.removeItem("one_successNum");
            cc.sys.localStorage.removeItem("one_bestScore");
            cc.sys.localStorage.removeItem("one_minMoveStep");
            cc.sys.localStorage.removeItem("one_minTime");
            cc.sys.localStorage.removeItem("one_totalTime");

        }else if(this.index == 1){
            for(var i = 0; i < this.szpNumList.length; ++i){
                if(i == 1){
                    this.szpNumList[i].getComponent("cc.Label").string = "0(0.00%)";
                }else{
                    this.szpNumList[i].getComponent("cc.Label").string = 0;
                }
            }

            cc.sys.localStorage.removeItem("three_totalJuShu");
            cc.sys.localStorage.removeItem("three_successNum");
            cc.sys.localStorage.removeItem("three_bestScore");
            cc.sys.localStorage.removeItem("three_minMoveStep");
            cc.sys.localStorage.removeItem("three_minTime");
            cc.sys.localStorage.removeItem("three_totalTime");
        }else if(this.index == 2){
            for(var i = 0; i < this.wjsNumList.length; ++i){
                if(i == 1){
                    this.wjsNumList[i].getComponent("cc.Label").string = "0(0.00%)";
                }else{
                    this.wjsNumList[i].getComponent("cc.Label").string = 0;
                }
            }

            cc.sys.localStorage.removeItem("wjs_totalJuShu");
            cc.sys.localStorage.removeItem("wjs_successNum");
            cc.sys.localStorage.removeItem("wjs_totalIncome");
            cc.sys.localStorage.removeItem("wjs_maxCash");
        }
        
    },

    onDestroy:function(){
        this._super();
        actionLib.backOut(this.node.getChildByName("content"));
    }
});
