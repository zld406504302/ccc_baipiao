var BaseMediator = require("BaseMediator")
cc.Class({
    extends:BaseMediator,

    properties: {

    },


    didRegister(){
        this.bind("CLICK_CLOSE_BTN", (data)=>{
            this.facade.sendNotification(appNotice.HIDE_NODE,{name:"AddUpNode"});
            if(this._data){
                this.facade.sendNotification(appNotice.SHOW_NODE, {name:this._data.history, initData:this._data.data});
            }
        }, this);
    },

    listNotificationInterests(){
        return [
            
        ];
    },

    initData:function(data){
        this._data = data;
        this.viewComponent.initData();
    },

    handleNotification(notification){
        var data = notification.getBody();
        var view = this.viewComponent;
        var name = notification.getName();
        console.log("handleNotification data : " + name + ":" + JSON.stringify(data));
        switch(name){
            
        }
    },

});
