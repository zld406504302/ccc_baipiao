var BaseCmpt = require("BaseCmpt")
var PrivacyNodeMediator =require("PrivacyNodeMediator")

cc.Class({
    extends: BaseCmpt,
    mediatorName:PrivacyNodeMediator,
    properties: {

    },

    onLoad () {
        this._super();
        
        var closebtn = this.node.getChildByName("closebtn");
        closebtn.on('click', ()=>{
            this.hideNode("PrivacyNode");
        }, this);
    
    },
});
