var BaseCmpt = require("BaseCmpt")
var HandsNodeMediator =require("HandsNodeMediator")
var Localization = require("Localization");

cc.Class({
    extends: BaseCmpt,
    mediatorName:HandsNodeMediator,
    properties: {

    },

    onLoad () {
        this._super();
        var closebtn = this.node.getChildByName("content").getChildByName("closebtn");
        closebtn.on('click', ()=>{
            // this.hideNode("HandsNode");
            this.dispatchEvent("CLICK_CLOSE_BTN");
        }, this);

        this.node.getChildByName("bg").on('click', ()=>{
            // this.hideNode("HandsNode");
            this.dispatchEvent("CLICK_CLOSE_BTN");
        }, this);

        this.initBtnEvents();
        actionLib.backIn(this.node.getChildByName("content"));
    },

    initBtnEvents:function(){
        var layout = this.node.getChildByName("content").getChildByName("layout");

        var randomHandbtn = layout.getChildByName("randomHandbtn");
        randomHandbtn.getChildByName("label").getComponent("cc.Label").string = Localization["RandomGame"][window.language];
        randomHandbtn.on('click', ()=>{
            this.dispatchEvent("CLICK_RANDOMHAND_BTN");
            this.hideNode("HandsNode");
        }, this);

        var liveHandbtn = layout.getChildByName("liveHandbtn");
        liveHandbtn.getChildByName("label").getComponent("cc.Label").string = Localization["WinningGame"][window.language];
        liveHandbtn.on('click', ()=>{
            this.dispatchEvent("CLICK_LIVEHAND_BTN");
            this.hideNode("HandsNode");
        }, this);

        var wjsHandbtn = layout.getChildByName("wjsHandbtn");
        wjsHandbtn.getChildByName("label").getComponent("cc.Label").string = Localization["VegasGame"][window.language];
        wjsHandbtn.on('click', ()=>{
            this.dispatchEvent("CLICK_WJSHAND_BTN");
            this.hideNode("HandsNode");
        }, this);

        var restartbtn = layout.getChildByName("restartbtn");
        restartbtn.getChildByName("label").getComponent("cc.Label").string = Localization["ReplayGame"][window.language];
        restartbtn.on('click', ()=>{
            this.dispatchEvent("CLICK_RESTART_BTN");
            this.hideNode("HandsNode");
        }, this);

         var tjinfobtn = layout.getChildByName("tjinfobtn");
         tjinfobtn.getChildByName("label").getComponent("cc.Label").string = Localization["Stats"][window.language];
        tjinfobtn.on('click', ()=>{
            this.dispatchEvent("CLICK_TJINFO_BTN");
        }, this);
    },

    onDestroy:function(){
        this._super();
        actionLib.backOut(this.node.getChildByName("content"));
    }
});
