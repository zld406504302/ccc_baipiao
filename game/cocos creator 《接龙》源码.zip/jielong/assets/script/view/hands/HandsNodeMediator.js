var BaseMediator = require("BaseMediator")
cc.Class({
    extends:BaseMediator,

    properties: {

    },


    didRegister(){
        this.bind("CLICK_CLOSE_BTN", (data)=>{
            this.facade.sendNotification(appNotice.HIDE_NODE,{name:"HandsNode"});
            if(this._data == 1){
                this.facade.sendNotification(appNotice.RESET_MATCH);
            }
        }, this);

        this.bind("CLICK_RANDOMHAND_BTN", (data)=>{
            this.facade.sendNotification(appNotice.RESET_MATCH);
        }, this);
        this.bind("CLICK_LIVEHAND_BTN", (data)=>{
            this.facade.sendNotification(appNotice.RESET_MATCH, 1);
        }, this);
        this.bind("CLICK_WJSHAND_BTN", (data)=>{
            this.facade.sendNotification(appNotice.RESET_MATCH, 2);
        }, this);
        this.bind("CLICK_RESTART_BTN", (data)=>{
            this.facade.sendNotification(appNotice.RESET_MATCH, 3);
        }, this);
        this.bind("CLICK_TJINFO_BTN", (data)=>{
            if(this._data){
                this.facade.sendNotification(appNotice.SHOW_NODE,{name:"AddUpNode", initData:{history:"HandsNode", data:this._data}});
            }else{
                this.facade.sendNotification(appNotice.SHOW_NODE,{name:"AddUpNode"});
            }
        }, this);
    },

    listNotificationInterests(){
        return [
            
        ];
    },

    initData:function(data){
        this._data = data;
    },

    handleNotification(notification){
        var data = notification.getBody();
        var view = this.viewComponent;
        var name = notification.getName();
        console.log("handleNotification data : " + name + ":" + JSON.stringify(data));
        switch(name){
            
        }
    },

});
