var BaseCmpt = require("BaseCmpt")
var SignNodeMediator =require("SignNodeMediator")
var Localization = require("Localization");

cc.Class({
    extends: BaseCmpt,
    mediatorName:SignNodeMediator,
    properties: {

    },

    onLoad () {
        this._super();
        var closebtn = this.node.getChildByName("content").getChildByName("closebtn");
        closebtn.on('click', ()=>{
            this.dispatchEvent("CLICK_CLOSE_BTN");
        }, this);

        this.node.getChildByName("bg").on('click', ()=>{
            this.dispatchEvent("CLICK_CLOSE_BTN");
        }, this);

        var content = this.node.getChildByName("content");
        content.getChildByName("title").getComponent("cc.Label").string = Localization["DailyChallenge"][window.language];

        var bottombg = content.getChildByName("bottombg");
        this.stateicon = bottombg.getChildByName("stateicon");
        this.statelabel = bottombg.getChildByName("statelabel");

        //历史累计
        this.ht_num = bottombg.getChildByName("htLayout").getChildByName("ht_num");
        var num = cc.sys.localStorage.getItem("dayily_total_num") || 0;
        this.ht_num.getComponent("cc.Label").string = Localization["LifetimeEarned"][window.language] + num;

        var date = new Date()
        this.currentyear = date.getFullYear();
        this.currentmonth = date.getMonth();
        this.realmonth = date.getMonth();
        this.currentday = date.getDate();

        this.startgamebtn = bottombg.getChildByName("startgamebtn");
        this.startgamebtn.getChildByName("label").getComponent("cc.Label").string = Localization["START"][window.language];
        this.startgamebtn.on('click', ()=>{
            this.dispatchEvent("CLICK_START_BTN", {month:this.currentmonth, day:this.dayIndex});
        }, this);

        this.datelabel = bottombg.getChildByName("datelabel");
        this.datelabel.getComponent("cc.Label").string = this.currentday + "/" + this.currentmonth + "/" + this.currentyear;

        var progressnode = content.getChildByName("progressnode");
        this.progress = progressnode.getChildByName("progress").getComponent("cc.ProgressBar");
        this.day3 = progressnode.getChildByName("day3");
        
        //-----------------------------------------------------------------------------------------
        var calendar = content.getChildByName("calendar");

        var xqtitle = calendar.getChildByName("xqtitle");
        for(var i = 1; i <= 7; ++i){
            xqtitle.getChildByName("item" + i).getComponent("cc.Label").string = Localization["Week" + i][window.language];
        }

        this.star = calendar.getChildByName("data").getChildByName("star");
        this.monthLabel = calendar.getChildByName("data").getChildByName("month").getComponent("cc.Label");
        this.forwardbtn = calendar.getChildByName("data").getChildByName("forwardbtn");
        this.forwardbtn.active = false;
        this.forwardbtn.on('click', ()=>{
            this.backwardbtn.active = true;
            this.currentmonth = this.currentmonth + 1;
            if(this.currentmonth >= this.realmonth){
                this.forwardbtn.active = false;
            }
            this.setMonth(this.currentyear, this.currentmonth);
        }, this);
        this.backwardbtn = calendar.getChildByName("data").getChildByName("backwardbtn");
        this.backwardbtn.on('click', ()=>{
            this.forwardbtn.active = true;
            this.currentmonth = this.currentmonth - 1;
            if(this.currentmonth < this.realmonth - 3){
                this.backwardbtn.active = false;
            }
            this.setMonth(this.currentyear, this.currentmonth);
        }, this);

        //-----------------------------------------------------------------------------------------

        this._listContent = calendar.getChildByName("listview").getChildByName("view").getChildByName("content");
        this._viewitemTemp = this._listContent.children[0];
        this._listContent.removeChild(this._viewitemTemp);

        this.setMonth(this.currentyear, this.currentmonth, this.currentday);

        this.setDayState(this.currentmonth, this.currentday);

        actionLib.backIn(this.node.getChildByName("content"));
    },

    setMonth:function(year, month, day){
        // 获取当月第一天星期几
        var firstDay = this.getMonthFirst(year, month);
        // 获取这月有多少天
        var currentDay = this.getMonthsDay(year, month);

        day = day || currentDay;

        var lastMonth = (month - 1) >= 0 ? (month - 1) : 12;
        var lastDay = this.getMonthsDay(year, lastMonth);
        var newlastDay = lastDay;
        for(var i = 0; i < 42; ++i){
            var item = this.getViewItem(i);
            item.dayIndex = -1;
            if(i < firstDay){
                item.getChildByName("riqi").active = false;
                item.getChildByName("icon1").active = false;
                item.getChildByName("icon2").active = false;
                item.getChildByName("icon3").active = false;
                item.getChildByName("riqi").getComponent("cc.Label").string = newlastDay - firstDay + i;
            }else if(i < currentDay + firstDay){
                item.getChildByName("riqi").active = true;
                item.getChildByName("riqi").getComponent("cc.Label").string = i + 1 - firstDay;
                item.dayIndex = i + 1 - firstDay;

                item.getChildByName("icon1").active = false;
                item.getChildByName("icon2").active = false;
                item.getChildByName("icon3").active = false;
                if(i + 1 - firstDay < day){
                    if(cc.sys.localStorage.getItem("dayily_" + month + "_" + (i + 1 - firstDay)) == 1){
                        item.getChildByName("icon3").active = true;
                    }else{
                        item.getChildByName("icon1").active = true;
                    }
                }else if(i + 1 - firstDay == day){
                    if(cc.sys.localStorage.getItem("dayily_" + month + "_" + (i + 1 - firstDay)) == 1){
                        item.getChildByName("icon3").active = true;
                        item.getChildByName("riqi").active = false;
                    }else{
                        item.getChildByName("icon2").active = true && this.realmonth == month;
                        item.getChildByName("icon1").active = this.realmonth != month;
                    }
                }
            }else{
                item.getChildByName("riqi").active = false;
                item.getChildByName("icon1").active = false;
                item.getChildByName("icon2").active = false;
                item.getChildByName("icon3").active = false;
                item.getChildByName("riqi").getComponent("cc.Label").string = i + 1 - currentDay - firstDay;
            }
        }

        this.day3.getComponent("cc.Label").string = currentDay;

        this.setMonthState(month, day);
    },

    setDayState:function(month, day){
        if(cc.sys.localStorage.getItem("dayily_" + month + "_" + day) == 1){
            this.startgamebtn.getChildByName("label").getComponent("cc.Label").string = Localization["ReplayGame"][window.language];
            this.statelabel.getComponent("cc.Label").string = Localization["Solved"][window.language];
        }else{
            this.startgamebtn.getChildByName("label").getComponent("cc.Label").string = Localization["START"][window.language];
            this.statelabel.getComponent("cc.Label").string = Localization["Unsolved"][window.language];
        }

        this.dayIndex = day;
    },

    setMonthState:function(month, day){
        var num = 0;
        for(var i = 1; i <= day; ++i){
            num = num + parseInt(cc.sys.localStorage.getItem("dayily_" + month + "_" + i)) || 0;
        }
        this.progress.progress = (num / day) * 1.0.toFixed(3);

        this.monthLabel.string = (month + 1) + "月";
    },

    getViewItem:function(index){
        if(this._listContent.childrenCount > index){
            return this._listContent.children[index];
        }
        var node = cc.instantiate(this._viewitemTemp);
        this._listContent.addChild(node);
        return node;
    },

    onItemClick:function(event){
        var dayIndex = event.target.dayIndex;

        if(dayIndex != -1){
            this.setDayState(this.currentmonth, dayIndex);
        }
    },

    // 获取那年那月有多少天
    getMonthsDay(year, month) {
        var year = year;
        var month = month;
        if (arguments.length == 0) {
            var date = new Date();
            year = date.getFullYear();
            month = data.getMonth();
        }

        if (arguments.length == 1) {
            var date = new Date();
            month = data.getMonth();
        }
        
        var monthDays = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];

        if ((year % 4 == 0) && (year % 100 != 0) || (year % 400 == 0)) {
            monthDays[1] = 29;
        }
        return monthDays[month];
    },

    // 获取这个月第一天星期几 
    getMonthFirst(year, month) {
        var year = year;
        var month = month;
        if (arguments.length == 0) {
            var date = new Date();
            year = date.getFullYear();
            month = data.getMonth();
        }

        if (arguments.length == 1) {
            var date = new Date();
            month = data.getMonth();
        }
        
        var newDate = new Date(year, month, 1);
        return newDate.getDay();
    },

    onDestroy:function(){
        this._super();
        actionLib.backOut(this.node.getChildByName("content"));
    }
});
