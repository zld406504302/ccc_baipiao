var BaseCmpt = require("BaseCmpt")
var MainNodeMediator = require("MainNodeMediator");
var UserProxy = require("UserProxy");
var DailyChallengeConfig = require("DailyChallengeConfig");
var SolutionConfig = require("SolutionConfig");
var Localization = require("Localization");
var upltv = require("UPLTV").upltv;

var cardArray = [
    0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12,
    13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25,
    26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38,
    39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51
];

var cardWidth = 100;
var cardHight = 150;
cc.Class({
    extends: BaseCmpt,
    //mediator名字定义
    mediatorName: MainNodeMediator,

    properties: {

        cardItem: cc.Prefab,
        promptNode: cc.Node,
        cardsPanel: cc.Node,
        shoupaiBtn: cc.Node,
    },

    onLoad() {
        this._super();

        this.touchlayer = this.node.getChildByName("touchlayer");
        this.touchlayer.active = true;

        var mainBg = this.node.getChildByName("mainBg");

        this.toplayout = mainBg.getChildByName("toplayout");
        //时间
        this.timeLabel = this.toplayout.getChildByName("timenode").getChildByName("time").getComponent("cc.Label");
        //得分
        this.scoreLabel = this.toplayout.getChildByName("score").getComponent("cc.Label");
        //移动
        this.moveLabel = this.toplayout.getChildByName("move").getComponent("cc.Label");

        //牌局描述
        this.paijudesc = mainBg.getChildByName("bottombg").getChildByName("paijudesc");

        var bottomlayout = mainBg.getChildByName("bottombg").getChildByName("bottomlayout");

        this.undobtn = bottomlayout.getChildByName("undobtn");
        this.undobtn.getChildByName("label").getComponent("cc.Label").string = Localization["UI_undo"][window.language];
        this.tipsbtn = bottomlayout.getChildByName("tipsbtn");
        this.tipsbtn.getChildByName("label").getComponent("cc.Label").string = Localization["UI_hint"][window.language];
        this.handbtn = bottomlayout.getChildByName("handbtn");
        this.handbtn.getChildByName("label").getComponent("cc.Label").string = Localization["UI_game"][window.language];
        this.dailybtn = bottomlayout.getChildByName("dailybtn");
        this.dailybtn.getChildByName("label").getComponent("cc.Label").string = Localization["DailyChallenge"][window.language];
        this.settingbtn = bottomlayout.getChildByName("settingbtn");
        this.settingbtn.getChildByName("label").getComponent("cc.Label").string = Localization["UI_setting"][window.language];

        //牌区域
        var cardspanel = mainBg.getChildByName("cardspanel");
        this.cardspanel = cardspanel;

        this.factorylayout = cardspanel.getChildByName("factorylayout");
        this.factorybtn = this.factorylayout.getChildByName("factorybtn");
        this.pool = this.factorylayout.getChildByName('pool');
        this.factorybtn.on("click", () => {
            console.log("fa pai chu lai");

            this.playSound("cardon.wav");
            if (this.status == 2) {
                if (this.pool.children.length > 0) {
                    this.setMoveStep(1);
                    this.fapaichulai();
                } else {
                    console.log("wjs fan pai wan bi");
                }
            } else {
                this.setMoveStep(1);
                this.fapaichulai();
            }
        });
        this.tipkuang = this.factorylayout.getChildByName("tipkuang");
        this.playTipKuang(false);

        this.fcardlayout = cardspanel.getChildByName("fcardlayout");

        this.scardlayout = cardspanel.getChildByName("scardlayout");
        this.shoucardList = [];
        for (var i = 0; i < 4; ++i) {
            var shoucard = this.scardlayout.getChildByName("shoucard" + i);
            this.shoucardList.push(shoucard);
        }

        this.cardlayout = cardspanel.getChildByName("cardlayout");
        this.asList = [];
        this.cardlayoutList = [];
        for (var i = 0; i < 7; ++i) {
            var cardlayoutItem = this.cardlayout.getChildByName("cardlayout" + i);
            this.cardlayoutList.push(cardlayoutItem);
            this.asList.push(this.cardlayout.getChildByName("as" + (i + 1)));
        }

        this.movecardlayout = cardspanel.getChildByName("movecardlayout");

        this.undobtn.on("click", () => {
            this.revert();
            console.log("撤销");

            this.stopAllPromptNode();
            if (this.lastAutoMoveTimeout) {
                clearTimeout(this.lastAutoMoveTimeout);
            }
            this.playTipKuang(false);
            this.lastAutoMoveTimeout = setTimeout(this.onAutoTishi.bind(this), 5000);
        });
        this.tipsbtn.on("click", () => {
            this.playSound("hint.wav");
            this.onTishi();
        });
        this.handbtn.on("click", () => {
            this.dispatchEvent("HAND_BTN");
        });
        this.dailybtn.on("click", () => {
            this.dispatchEvent("DAILY_BTN");
        });
        this.settingbtn.on("click", () => {
            this.dispatchEvent("SETTING_BTN");
        });

        if (cc.sys.isNative && cc.sys.os === cc.sys.OS_ANDROID) {
            // upltv.showBannerAdAtTop("bannertop");
            // console.log("展示顶部广告位");

            // console.log('language:', this.getLanguage(), null);
        }
    },

    start() {

        // upltv.showInterstitialDebugUI();
        var cardIndex = cc.sys.localStorage.getItem("CardBgIndex") || 1;
        var mainBgIndex = cc.sys.localStorage.getItem("MainBgIndex") || 1;
        //-----------------取设置等数据处-----------------------// 
        this.preFaNum = cc.sys.localStorage.getItem("is3Card") == 1 ? 3 : 1;  //每次发牌的数量   1或3
        this.leftRightMode = cc.sys.localStorage.getItem("leftRightMode") || 0;
        this.timeMode = cc.sys.localStorage.getItem("timeMode") || 0;
        this.soundTag = cc.sys.localStorage.getItem("soundTag") || 0;

        this.settingLeftRight(this.leftRightMode);
        this.settingTimeMode(this.timeMode);
        //-----------------取设置等数据处-----------------------// 

        this.initData();
        this.updateMainBg(mainBgIndex);
        this.updateCardBg(cardIndex);
        this.shuffle();
        this.shoupaiBtn.active = false;

        this.touchlayer.active = true;
        setTimeout(() => {
            //start后widget
            this.bottomBg = this.node.getChildByName("mainBg").getChildByName("bottombg");
            this.bottomBgPos = this.bottomBg.getPosition();

            this.onFaCards();
        }, 500);
    },

    startTimer() {
        this.stopTimer();
        this.gameTime = 0;
        this.timeLabel.string = "00:00";
        let callback = function () {
            this.gameTime = this.gameTime + 1;
            if (this.gameTime > 3600) {
                this.stopTimer();
            } else {
                if (this.gameTime % 60 == 0) {
                    if (this.status != 2) {
                        this.setScore(-5);  //每过一分钟-5分
                    }
                }
                this.timeLabel.string = utils.GetDateTime(this.gameTime);
            }
        }.bind(this);
        this.intervalId = setInterval(callback, 1000);
    },

    onBgHit: function () {
        if (cc.sys.isNative && cc.sys.os === cc.sys.OS_ANDROID) {
            this.bottomBg.stopAllActions();
            if (this.bottomBg.y == this.bottomBgPos.y) {
                this.bottomBg.runAction(cc.sequence(cc.moveTo(0.2, cc.v2(this.bottomBgPos.x, this.bottomBgPos.y - 300)),
                    cc.callFunc(() => {
                        upltv.showBannerAdAtBottom("jielongAAAA002");
                    })));
            } else {
                upltv.hideBannerAdAtBottom();
                this.bottomBg.runAction(cc.moveTo(0.2, cc.v2(this.bottomBgPos.x, this.bottomBgPos.y)));
            }
        }
    },

    stopTimer: function () {
        clearInterval(this.intervalId);
        this.intervalId = null;
    },

    onTishi: function () {
        var moveQueue = this.getMoveQueue();

        if (this.pool.children.length > 0) {
            var card = this.pool.children[this.pool.children.length - 1];
            var pos = card.parent.convertToWorldSpaceAR(card.position);
            pos = this.cardspanel.convertToNodeSpaceAR(pos);
            if (this.leftRightMode == 0) {
                pos.x -= 100;
            } else if (this.leftRightMode == 1) {
                pos.x += 100;
            }
            pos.y += 70;
            moveQueue.push({ cards: [card], end: pos });
            console.log(1);
        }

        for (var i = 0; i < moveQueue.length; i++) {
            var list = [];
            for (var j = 0; j < moveQueue[i].cards.length; j++) {
                var cardInfo = this.getCardInfo(moveQueue[i].cards[j]);
                list.push(cardInfo);
            }
            console.log('提示结果', list, moveQueue[i].end);
        }

        this.stopAllPromptNode();
        if (this.lastAutoMoveTimeout) {
            clearTimeout(this.lastAutoMoveTimeout);
        }
        this.playTishi(moveQueue);
    },

    onAutoTishi: function () {
        if (this.playingAutoTishi) {
            console.log("自动提示正在播放中");
            return;
        }

        if (this.shoupaiBtn.active == true || this.isGameOver == true) {
            this.shoupaiBtn.active = false;
            this.playTipKuang(false);
            this.stopAllPromptNode();
            if (this.lastAutoMoveTimeout) {
                clearTimeout(this.lastAutoMoveTimeout);
            }
        }

        var moveQueue = this.getMoveQueue();
        if (moveQueue.length == 0) {
            if (this.pool.children.length > 0) {
                var card = this.pool.children[this.pool.children.length - 1];
                var pos = card.parent.convertToWorldSpaceAR(card.position);
                pos = this.cardspanel.convertToNodeSpaceAR(pos);
                if (this.leftRightMode == 0) {
                    pos.x -= 100;
                } else if (this.leftRightMode == 1) {
                    pos.x += 100;
                }
                pos.y += 70;
                moveQueue.push({ cards: [card], end: pos });
                console.log(1);
            } else {
                this.playTipKuang(true);
            }
        }
        // if (this.moveQueue) {
        //     this.moveQueue.splice(0, this.moveQueue.length);
        // }
        this.promptNode.stopAllActions();
        // this.moveQueue = moveQueue;
        this.promptNode.active = true;
        var move = moveQueue[0];
        if (move == null) {
            this.promptNode.active = false;
            return;
        }
        this.promptNode.getChildByName("cards").opacity = 1;
        this.promptNode.getChildByName("cards").removeAllChildren(true);
        var startPos = null;
        var offPos = null;
        for (var i = 0; i < move.cards.length; i++) {
            if (startPos == null) {
                startPos = move.cards[i].parent.convertToWorldSpaceAR(move.cards[i]);
                startPos = this.cardspanel.convertToNodeSpaceAR(startPos);
            }
            var card = cc.instantiate(move.cards[i]);
            card.parent = this.promptNode.getChildByName("cards");
            card.x = 0;
            card.y = 0;
            this.promptNode.getChildByName("cards").getComponent(cc.Layout).updateLayout();
            if (offPos == null) {
                offPos = card.parent.convertToWorldSpaceAR(card);
                offPos = this.cardspanel.convertToNodeSpaceAR(offPos);
                offPos.x = offPos.x - startPos.x;
                offPos.y = offPos.y - startPos.y;
            }
        }

        var offY = (this.promptNode.height - 140) / 2;
        this.promptNode.x -= offPos.x;
        this.promptNode.y -= offPos.y;
        var ani = this.promptNode.getComponent(cc.Animation);
        ani.play();
        this.playingAutoTishi = true;

        if (this.status != 2) {
            this.setScore(-5);  //自动提示减5分
        }
    },

    stopAllPromptNode: function () {
        var ani = this.promptNode.getComponent(cc.Animation);
        this.playingAutoTishi = false;
        ani.stop();
        this.promptNode.stopAllActions();
        this.promptNode.opacity = 255;
        this.promptNode.active = false;
    },

    getMoveQueue: function () {
        var moveQueue = []

        // 检查横向牌
        for (var i = 0; i < this.cardlayoutList.length; i++) {
            var showNode = this.cardlayoutList[i].getChildByName('show');
            if (showNode.children.length == 0) {
                continue;
            }
            var hideNode = this.cardlayoutList[i].getChildByName('hide');
            var firstCard = showNode.children[0];
            var firstInfo = this.getCardInfo(firstCard);
            // if (firstInfo.value == 13 && hideNode.children.length == 0) {
            //     continue;
            // }

            var lastCard = showNode.children[showNode.children.length - 1];
            var cardInfo = this.getCardInfo(lastCard);

            // 顶部
            for (var j = 0; j < this.shoucardList.length; j++) {
                var pos = this.shoucardList[j].parent.convertToWorldSpaceAR(this.shoucardList[j].position);
                pos = this.cardspanel.convertToNodeSpaceAR(pos);
                pos.y += 70;
                if (cardInfo.value == 1) {
                    if (this.shoucardList[j].children.length == 0) {
                        moveQueue.push({ cards: [lastCard], end: pos, endTarget: this.shoucardList[j] });
                        break;
                    }
                } else {
                    if (this.shoucardList[j].children.length > 0) {
                        var tempCard = this.shoucardList[j].children[this.shoucardList[j].children.length - 1];
                        var tempCardInfo = this.getCardInfo(tempCard);
                        if (tempCardInfo.type == cardInfo.type && tempCardInfo.value + 1 == cardInfo.value) {
                            moveQueue.push({ cards: [lastCard], end: pos, endTarget: this.shoucardList[j] });
                        }
                    }
                }
            }

            if (cardInfo.value != 1) {
                // 横向
                var firstCard = showNode.children[0];
                cardInfo = this.getCardInfo(firstCard);
                for (var j = 0; j < this.cardlayoutList.length; j++) {
                    var tempShowNode = this.cardlayoutList[j].getChildByName('show');
                    var tempHideNode = this.cardlayoutList[j].getChildByName('hide');
                    if (tempShowNode.children.length == 0) {
                        if (cardInfo.value == 13 && hideNode.children.length != 0) {
                            var pos = tempShowNode.parent.convertToWorldSpaceAR(tempShowNode.position);
                            pos = this.cardspanel.convertToNodeSpaceAR(pos);
                            pos.y += 20;
                            moveQueue.push({ cards: showNode.children, end: pos, endTarget: tempShowNode });
                        }
                    } else {
                        var tempCard = tempShowNode.children[tempShowNode.children.length - 1];
                        var tempCardInfo = this.getCardInfo(tempCard);
                        if (tempCardInfo.type % 2 != cardInfo.type % 2 && tempCardInfo.value - 1 == cardInfo.value) {
                            var pos = tempCard.parent.convertToWorldSpaceAR(tempCard.position);
                            pos = this.cardspanel.convertToNodeSpaceAR(pos);
                            pos.y += 20;
                            moveQueue.push({ cards: showNode.children, end: pos, endTarget: tempShowNode });
                        } else if (tempCardInfo.type % 2 == cardInfo.type % 2 && tempCardInfo.value - 2 == cardInfo.value) {
                            // 从顶部插牌下来
                            for (var k = 0; k < this.shoucardList.length; k++) {
                                if (this.shoucardList[k].children.length > 0) {
                                    var tempShowCard = this.shoucardList[k].children[this.shoucardList[k].children.length - 1];
                                    var tempShowCardInfo = this.getCardInfo(tempShowCard);
                                    if (tempShowCardInfo.type % 2 != tempCardInfo.type % 2 && tempCardInfo.value - 1 == tempShowCardInfo.value) {
                                        var pos = tempCard.parent.convertToWorldSpaceAR(tempCard.position);
                                        pos = this.cardspanel.convertToNodeSpaceAR(pos);
                                        pos.y += 20;
                                        moveQueue.push({ cards: [tempShowCard], end: pos, endTarget: tempShowNode });
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // 检查左顶部牌
        if (this.fcardlayout.children.length > 0) {
            var lastCard = this.fcardlayout.children[this.fcardlayout.children.length - 1];
            var cardInfo = this.getCardInfo(lastCard);

            // 顶部
            for (var j = 0; j < this.shoucardList.length; j++) {
                var pos = this.shoucardList[j].parent.convertToWorldSpaceAR(this.shoucardList[j].position);
                pos = this.cardspanel.convertToNodeSpaceAR(pos);
                pos.y += 70;
                if (cardInfo.value == 1) {
                    if (this.shoucardList[j].children.length == 0) {
                        moveQueue.push({ cards: [lastCard], end: pos, endTarget: this.shoucardList[j] });
                        break;
                    }
                } else {
                    if (this.shoucardList[j].children.length > 0) {
                        var tempCard = this.shoucardList[j].children[this.shoucardList[j].children.length - 1];
                        var tempCardInfo = this.getCardInfo(tempCard);
                        if (tempCardInfo.type == cardInfo.type && tempCardInfo.value + 1 == cardInfo.value) {
                            moveQueue.push({ cards: [lastCard], end: pos, endTarget: this.shoucardList[j] });
                        }
                    }
                }
            }

            if (cardInfo.value != 1) {
                // 横向
                for (var j = 0; j < this.cardlayoutList.length; j++) {
                    var tempShowNode = this.cardlayoutList[j].getChildByName('show');
                    if (tempShowNode.children.length == 0) {
                        if (cardInfo.value == 13) {
                            var pos = tempShowNode.parent.convertToWorldSpaceAR(tempShowNode.position);
                            pos = this.cardspanel.convertToNodeSpaceAR(pos);
                            pos.y += 20;
                            moveQueue.push({ cards: [lastCard], end: pos, endTarget: tempShowNode });
                        }
                    } else {
                        var tempCard = tempShowNode.children[tempShowNode.children.length - 1];
                        var tempCardInfo = this.getCardInfo(tempCard);
                        if (tempCardInfo.type % 2 != cardInfo.type % 2 && tempCardInfo.value - 1 == cardInfo.value) {
                            var pos = tempCard.parent.convertToWorldSpaceAR(tempCard.position);
                            pos = this.cardspanel.convertToNodeSpaceAR(pos);
                            pos.y += 20;
                            moveQueue.push({ cards: [lastCard], end: pos, endTarget: tempShowNode });
                        }
                    }
                }
            }
        }

        // 检查收牌部分 
        for (var i = 0; i < this.shoucardList.length; i++) {
            if (this.shoucardList[i].children.length == 0) {
                continue;
            }
            var lastCard = this.shoucardList[i].children[this.shoucardList[i].children.length - 1];
            var cardInfo = this.getCardInfo(lastCard);

            // 检查可以收到顶的牌
            for (var j = 0; j < this.cardlayoutList.length; j++) {
                var tempShowNode = this.cardlayoutList[j].getChildByName('show');
                var tempList = [];
                for (var k = 0; k < tempShowNode.children.length; k++) {
                    var tempCard = tempShowNode.children[tempShowNode.children.length - 1 - k];
                    if (k > 0) {
                        var tempCardInfo = this.getCardInfo(tempCard);
                        if (tempCardInfo.type == cardInfo.type && tempCardInfo.value - 1 == cardInfo.value) {
                            var moveCard = tempList[tempList.length - 1];
                            var moveCardInfo = this.getCardInfo(moveCard);

                            for (var t = 0; t < this.cardlayoutList.length; t++) {
                                var targetShow = this.cardlayoutList[t].getChildByName('show');
                                if (targetShow.children.length == 0) {
                                    continue;
                                }
                                var lastTempCard = targetShow.children[targetShow.children.length - 1];
                                var lastTempCardInfo = this.getCardInfo(lastTempCard);
                                if (lastTempCardInfo.type % 2 != moveCardInfo.type % 2 && lastTempCardInfo.value - 1 == moveCardInfo.value) {
                                    var pos = lastTempCard.parent.convertToWorldSpaceAR(lastTempCard.position);
                                    pos = this.cardspanel.convertToNodeSpaceAR(pos);
                                    pos.y += 20;
                                    var cards = [];
                                    for (var m = tempList.length - 1; m >= 0; m--) {
                                        cards.push(tempList[m]);
                                    }
                                    moveQueue.push({ cards: cards, end: pos, endTarget: targetShow });
                                }
                            }
                        }
                    }
                    tempList.push(tempCard);
                }

            }
        }
        return moveQueue;
    },

    playTishi: function (moveQueue) {
        if (moveQueue.length == 0) {
            return;
        }
        if (this.moveQueue) {
            this.moveQueue.splice(0, this.moveQueue.length);
        }
        this.promptNode.stopAllActions();
        this.moveQueue = moveQueue;
        this.promptNode.active = true;
        this.promptNode.getChildByName("cards").opacity = 255;
        var play = () => {
            var move = this.moveQueue[0];

            if (this.moveQueue.length <= 0) {
                this.promptNode.active = false;
                this.playTipKuang(false);
                return;
            } else if (this.moveQueue.length <= 1) {
                this.playTipKuang(true);
            }

            this.promptNode.getChildByName("cards").removeAllChildren(true);
            var startPos = null;
            var offPos = null;
            for (var i = 0; i < move.cards.length; i++) {
                if (startPos == null) {
                    startPos = move.cards[i].parent.convertToWorldSpaceAR(move.cards[i]);
                    startPos = this.cardspanel.convertToNodeSpaceAR(startPos);
                }
                var card = cc.instantiate(move.cards[i]);
                card.parent = this.promptNode.getChildByName("cards");
                card.x = 0;
                card.y = 0;
                this.promptNode.getChildByName("cards").getComponent(cc.Layout).updateLayout();
                if (offPos == null) {
                    offPos = card.parent.convertToWorldSpaceAR(card);
                    offPos = this.cardspanel.convertToNodeSpaceAR(offPos);
                    offPos.x = offPos.x - startPos.x;
                    offPos.y = offPos.y - startPos.y;
                }
            }

            var offY = (this.promptNode.height - 140) / 2;
            this.promptNode.x -= offPos.x;
            this.promptNode.y -= offPos.y;

            console.log(this.promptNode.x, this.promptNode.y, move.end);
            this.promptNode.runAction(cc.sequence(cc.moveTo(0.5, cc.v2(move.end.x, move.end.y)), cc.callFunc(() => {
                this.moveQueue.splice(0, 1);
                play();
            })));
        }
        play();
    },

    getCardInfo: function (cardNode) {
        var script = cardNode.getComponent('CardItem');
        var value = script.getRealValue();
        var type = script.getCardType();
        return { type: type, value: value };
    },

    clickCard: function (d) {
        const data = d;
        console.log('点击牌面');
        var srcX = data.x;
        var srcY = data.y;

        var angle = parseInt(Math.random() * 360);
        var y = Math.sin(angle) * 10;
        var x = Math.cos(angle) * 10;
        console.log(x, y);

        var moveQueue = this.getMoveQueue();
        var move = null;
        for (var i = 0; i < moveQueue.length; i++) {
            if (moveQueue[i].cards[0] == data) {
                move = moveQueue[i];
                break;
            }
        }

        if (this.moving) {
            return;
        }

        if (move) {
            this.moving = true;
            const clickList = [];
            for (var i = 0; i < this.cardItemList.length; i++) {
                if (this.cardItemList[i].getComponent("CardItem").isCanClick2()) {
                    this.cardItemList[i].getComponent("CardItem").setCanClick(false);
                    clickList.push(this.cardItemList[i].getComponent("CardItem"));
                }
            }
            this.startMoveCard(data);
            var end = this.cardspanel.convertToWorldSpaceAR(move.end);
            end = this.movecardlayout.convertToNodeSpaceAR(end);
            data.parent.runAction(cc.sequence(cc.moveTo(0.2, cc.v2(end.x, end.y - 70)), cc.callFunc(() => {
                this.endMoveCard(data.parent);
                this.moving = false;
                for (var i = 0; i < clickList.length; i++) {
                    clickList[i].setCanClick(true);
                }
            })));
        } else {
            data.stopAllActions();
            data.x = srcX;
            data.y = srcY;
            data.runAction(cc.sequence(
                cc.moveTo(0.05, cc.v2(srcX + x, srcY + y)),
                cc.moveTo(0.07, cc.v2(srcX - x, srcY - y)),
                cc.moveTo(0.05, cc.v2(srcX, srcY))
            ));
        }
    },

    initData() {
        this.fcardlayout.removeAllChildren();

        for (var i = 0; i < 4; ++i) {
            this.shoucardList[i].removeAllChildren();
        }

        this.cardItemList = [];
        for (var i = 0; i < this.cardlayoutList.length; i++) {
            this.cardlayoutList[i].getChildByName('hide').removeAllChildren(true);
            this.cardlayoutList[i].getChildByName('show').removeAllChildren(true);
        }
        this.pool.removeAllChildren(true);
        this.fcardlayout.removeAllChildren(true);
        for (var i = 0; i < this.shoucardList.length; i++) {
            this.shoucardList[i].removeAllChildren(true);
        }

        this.startTimer();

        this.history = [];
    },

    revert: function () {
        if (this.history.length == 0) {
            console.log("历史记录为空，无法撤销");
            return;
        }
        var history = this.history.splice(this.history.length - 1, 1)[0];

        console.log(history);
        var cardItemList = [];
        if (history.item instanceof Array) {
            cardItemList = history.item;
        } else {
            cardItemList.push(history.item);
        }

        this.setMoveStep(1);

        var moveAniQueue = [];
        for (var i = 0; i < cardItemList.length; i++) {
            const card = cardItemList[i];

            var srcPos = card.parent.convertToWorldSpaceAR(card.position);
            srcPos = this.movecardlayout.convertToNodeSpaceAR(srcPos);

            card.x = 0;
            card.y = 0;
            card.parent = history.fromParent;
            var layout = card.parent.getComponent(cc.Layout);
            if (layout) {
                layout.updateLayout();
            }

            var targetPos = card.parent.convertToWorldSpaceAR(card.position);
            targetPos = this.movecardlayout.convertToNodeSpaceAR(targetPos);

            moveAniQueue.push({ card: card, srcPos: srcPos, targetPos: targetPos });
        }

        for (var i = 0; i < moveAniQueue.length; i++) {
            const card = moveAniQueue[i].card;
            const srcPos = moveAniQueue[i].srcPos;
            const targetPos = moveAniQueue[i].targetPos;

            card.parent = this.movecardlayout;
            card.x = srcPos.x;
            card.y = srcPos.y;

            if (i == 0) {
                card.runAction(cc.sequence(cc.moveTo(0.2, cc.v2(targetPos.x, targetPos.y)), cc.callFunc(() => {
                    card.x = 0;
                    card.y = 0;
                    card.parent = history.fromParent;
                }), cc.callFunc(() => {
                    if (history.showCard) {
                        history.showCard.getComponent("CardItem").setCardBg();
                        var hideNode = history.showCard.parent.parent.getChildByName('hide');
                        history.showCard.parent = hideNode;
                    }
                    if (history.faCard) {
                        for (var j = 0; j < history.faCard.length; j++) {
                            history.faCard[j].getComponent("CardItem").setCardBg();
                            // var hideNode = history.faCard[j].parent.parent.getChildByName('hide');
                            history.faCard[j].parent = this.pool;
                        }
                    }
                    this.updateFapaiAni();

                    this.calculSocre();
                })));
            } else {
                card.runAction(cc.sequence(cc.moveTo(0.2, cc.v2(targetPos.x, targetPos.y)), cc.callFunc(() => {
                    card.x = 0;
                    card.y = 0;
                    card.parent = history.fromParent;

                    this.calculSocre();
                })));
            }
        }

    },

    addHistory: function (item, fromParent, toParent) {
        if (fromParent == toParent) {
            return;
        }
        var data = {};
        data.fromParent = fromParent;
        data.toParent = toParent;
        if (item instanceof Array || item.getComponent("CardItem") != null) {
            data.item = item;
        } else {
            var cardList = [];
            for (var i = 0; i < item.children.length; i++) {
                cardList.push(item.children[i]);
            }
            data.item = cardList;
        }
        this.history.push(data);
        console.log("添加历史记录");
    },

    resetData: function () {
        this.moveStep = 0;
        this.moveLabel.string = Localization["Moves"][window.language] + "0";
        this.score = 0;
        this.scoreLabel.string = Localization["Score_format"][window.language] + "0";

        this.piaoNum = -1;
        this.a_num = 0;
        this.b_num = 24;
        this.c_num = 7;
    },

    shuffle: function (status) {
        this.resetData();
        this.isGameOver = false;

        if (status == 1) {  //活局
            this.status = 1;
            var index = parseInt(Math.random() * (DailyChallengeConfig.datas.length - 1));
            this.cardArray = DailyChallengeConfig.datas[index].cards;
            this.paijudesc.getComponent("cc.Label").string = Localization["WinningGame"][window.language];
        } else if (status == 2) {   //维加斯
            this.status = 2;
            var index = parseInt(Math.random() * (SolutionConfig.datas.length - 1));
            this.cardArray = SolutionConfig.datas[index].cards;
            this.paijudesc.getComponent("cc.Label").string = Localization["VegasGame"][window.language];

            var wjs_totalJuShu = parseInt(cc.sys.localStorage.getItem("wjs_totalJuShu")) || 0;
            cc.sys.localStorage.setItem("wjs_totalJuShu", wjs_totalJuShu + 1);

            var wjs_totalIncome = parseInt(cc.sys.localStorage.getItem("wjs_totalIncome")) || 0;
            var scoreNum = wjs_totalIncome - (wjs_totalJuShu * 52) - 52;
            this.setScore(scoreNum);
        } else if (status == 3) {//重玩本局
            if (this.status == 1) {
                this.paijudesc.getComponent("cc.Label").string = Localization["WinningGame"][window.language];
            } else if (this.status == 2) {
                this.paijudesc.getComponent("cc.Label").string = Localization["VegasGame"][window.language];
            } else if (this.status == 0) {
                this.paijudesc.getComponent("cc.Label").string = Localization["RandomGame"][window.language];
            }
        } else if (status == 4) { //每日牌局
            this.status = 4;
            var index = parseInt(Math.random() * (DailyChallengeConfig.datas.length - 1));
            this.cardArray = DailyChallengeConfig.datas[index].cards;
            this.paijudesc.getComponent("cc.Label").string = Localization["DailyChallenge"][window.language];
        } else {   //随机牌局
            this.status = 0;
            this.cardArray = cardArray.shuffle();
            this.paijudesc.getComponent("cc.Label").string = Localization["RandomGame"][window.language];
        }

        // this.cardArray = [
        //     0, 1, 13, 3, 2, 26, 6, 5, 4, 39, 11, 10, 9, 8, 7, 12,
        //     14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25,
        //     27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38,
        //     40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51
        // ];

        if (this.preFaNum == 1) {
            var jushu = parseInt(cc.sys.localStorage.getItem("one_totalJuShu")) || 0;
            cc.sys.localStorage.setItem("one_totalJuShu", jushu + 1);
        } else if (this.preFaNum == 3) {
            var jushu = parseInt(cc.sys.localStorage.getItem("three_totalJuShu")) || 0;
            cc.sys.localStorage.setItem("three_totalJuShu", jushu + 1);
        }

        this.cardItemList = this.cardItemList || [];
        for (var i = 0; i < this.cardArray.length; i++) {
            var item = this.cardItemList[i];
            if (!item) {
                item = cc.instantiate(this.cardItem);
                this.cardItemList.push(item);
            }
            item.x = 0;
            item.y = 0;
            item.parent = this.pool;

            item.getComponent("CardItem").setCardValue(this.cardArray[i]);
            item.getComponent("CardItem").setCardBg();
            item.getComponent("CardItem").resetTouchListener();
        }
    },

    onFaCards() {
        this.touchlayer.active = true;
        this.playSound("deal.wav");

        var num = Math.floor(Math.random() * 3);
        if (num == 0) {
            this.onFaCards_one();
        } else if (num == 1) {
            this.onFaCards_two();
        } else {
            this.onFaCards_three();
        }

        if (this.lastAutoMoveTimeout) {
            clearTimeout(this.lastAutoMoveTimeout);
        }
        this.lastAutoMoveTimeout = setTimeout(this.onAutoTishi.bind(this), 5000);
        this.shoupaiBtn.active = false;
    },

    onFaCards_one: function () {
        var startPos = this.factorylayout.getPosition();
        var cardlayoutY = this.cardlayout.getPosition().y
        for (var i = 0; i < 28; ++i) {
            var cardItem = this.cardItemList[i];
            if (i < 1) {
                var targetPos = this.cardlayoutList[0].getPosition();
                var posX = targetPos.x - startPos.x;
                var posY = targetPos.y - (cardlayoutY + 72.5);

                var action1 = cc.delayTime(0.1);
                var action2 = cc.moveTo(0.2, cc.v2(posX, posY));
                var action3 = cc.callFunc((tcardItem) => {
                    this.insertCardLayout(tcardItem, 0, true);
                    tcardItem.getComponent("CardItem").setFanPaiMv();
                })
                cardItem.runAction(cc.sequence(action1, action2, action3));
            } else if (i < 3) {
                var targetPos = this.cardlayoutList[1].getPosition();
                var posX = targetPos.x - startPos.x;
                var posY = targetPos.y - (cardlayoutY + 72.5);

                var action1 = cc.delayTime(0.2);
                var action2 = cc.moveTo(0.2, cc.v2(posX, posY));
                if (i == 2) {
                    var action3 = cc.callFunc((tcardItem) => {
                        this.insertCardLayout(tcardItem, 1, true);
                        tcardItem.getComponent("CardItem").setFanPaiMv();
                    });
                    cardItem.runAction(cc.sequence(action1, action2, action3));
                } else {
                    var action3 = cc.callFunc((tcardItem) => {
                        this.insertCardLayout(tcardItem, 1);
                    });
                    cardItem.runAction(cc.sequence(action1, action2, action3));
                }
            } else if (i < 6) {
                var targetPos = this.cardlayoutList[2].getPosition();
                var posX = targetPos.x - startPos.x;
                var posY = targetPos.y - (cardlayoutY + 72.5);
                var action1 = cc.delayTime(0.3);
                var action2 = cc.moveTo(0.2, cc.v2(posX, posY));
                if (i == 5) {
                    var action3 = cc.callFunc((tcardItem) => {
                        this.insertCardLayout(tcardItem, 2, true);
                        tcardItem.getComponent("CardItem").setFanPaiMv();
                    });
                    cardItem.runAction(cc.sequence(action1, action2, action3));
                } else {
                    var action3 = cc.callFunc((tcardItem) => {
                        this.insertCardLayout(tcardItem, 2);
                    });
                    cardItem.runAction(cc.sequence(action1, action2, action3));
                }
            } else if (i < 10) {
                var targetPos = this.cardlayoutList[3].getPosition();
                var posX = targetPos.x - startPos.x;
                var posY = targetPos.y - (cardlayoutY + 72.5);
                var action1 = cc.delayTime(0.4);
                var action2 = cc.moveTo(0.2, cc.v2(posX, posY));

                if (i == 9) {
                    var action3 = cc.callFunc((tcardItem) => {
                        this.insertCardLayout(tcardItem, 3, true);
                        tcardItem.getComponent("CardItem").setFanPaiMv();
                    });
                    cardItem.runAction(cc.sequence(action1, action2, action3));
                } else {
                    var action3 = cc.callFunc((tcardItem) => {
                        this.insertCardLayout(tcardItem, 3);
                    });
                    cardItem.runAction(cc.sequence(action1, action2, action3));
                }
            } else if (i < 15) {
                var targetPos = this.cardlayoutList[4].getPosition();
                var posX = targetPos.x - startPos.x;
                var posY = targetPos.y - (cardlayoutY + 72.5);
                var action1 = cc.delayTime(0.5);
                var action2 = cc.moveTo(0.2, cc.v2(posX, posY));
                if (i == 14) {
                    var action3 = cc.callFunc((tcardItem) => {
                        this.insertCardLayout(tcardItem, 4, true);
                        tcardItem.getComponent("CardItem").setFanPaiMv();
                    });
                    cardItem.runAction(cc.sequence(action1, action2, action3));
                } else {
                    var action3 = cc.callFunc((tcardItem) => {
                        this.insertCardLayout(tcardItem, 4);
                    });
                    cardItem.runAction(cc.sequence(action1, action2, action3));
                }
            } else if (i < 21) {
                var targetPos = this.cardlayoutList[5].getPosition();
                var posX = targetPos.x - startPos.x;
                var posY = targetPos.y - (cardlayoutY + 72.5);
                var action1 = cc.delayTime(0.6);
                var action2 = cc.moveTo(0.2, cc.v2(posX, posY));
                if (i == 20) {
                    var action3 = cc.callFunc((tcardItem) => {
                        this.insertCardLayout(tcardItem, 5, true);
                        tcardItem.getComponent("CardItem").setFanPaiMv();
                    });
                    cardItem.runAction(cc.sequence(action1, action2, action3));
                } else {
                    var action3 = cc.callFunc((tcardItem) => {
                        this.insertCardLayout(tcardItem, 5);
                    });
                    cardItem.runAction(cc.sequence(action1, action2, action3));
                }
            } else if (i < 28) {
                var targetPos = this.cardlayoutList[6].getPosition();
                var posX = targetPos.x - startPos.x;
                var posY = targetPos.y - (cardlayoutY + 72.5);
                var action1 = cc.delayTime(0.7);
                var action2 = cc.moveTo(0.2, cc.v2(posX, posY));
                if (i == 27) {
                    var action3 = cc.callFunc((tcardItem) => {
                        this.insertCardLayout(tcardItem, 6, true);
                        tcardItem.x = 0;
                        tcardItem.getComponent("CardItem").setFanPaiMv();

                        this.touchlayer.active = false;
                    });
                    cardItem.runAction(cc.sequence(action1, action2, action3));
                } else {
                    var action3 = cc.callFunc((tcardItem) => {
                        this.insertCardLayout(tcardItem, 6);
                    });
                    cardItem.runAction(cc.sequence(action1, action2, action3));
                }
            }
        }
    },

    onFaCards_two: function () {
        var startPos = this.factorylayout.getPosition();
        var cardlayoutY = this.cardlayout.getPosition().y
        for (var i = 0; i < 28; ++i) {
            var cardItem = this.cardItemList[i];
            if (i < 1) {
                var targetPos = this.cardlayoutList[0].getPosition();
                var posX = targetPos.x - startPos.x;
                var posY = targetPos.y - (cardlayoutY + 72.5);

                var action1 = cc.delayTime(0.7);
                var action2 = cc.moveTo(0.2, cc.v2(posX, posY));
                var action3 = cc.callFunc((tcardItem) => {
                    this.insertCardLayout(tcardItem, 0, true);
                    tcardItem.getComponent("CardItem").setFanPaiMv();
                })
                cardItem.runAction(cc.sequence(action1, action2, action3));
            } else if (i < 3) {
                var targetPos = this.cardlayoutList[1].getPosition();
                var posX = targetPos.x - startPos.x;
                var posY = targetPos.y - (cardlayoutY + 72.5);

                var action1 = cc.delayTime(0.6);
                var action2 = cc.moveTo(0.2, cc.v2(posX, posY));
                if (i == 2) {
                    var action3 = cc.callFunc((tcardItem) => {
                        this.insertCardLayout(tcardItem, 1, true);
                        tcardItem.getComponent("CardItem").setFanPaiMv();
                    });
                    cardItem.runAction(cc.sequence(action1, action2, action3));
                } else {
                    var action3 = cc.callFunc((tcardItem) => {
                        this.insertCardLayout(tcardItem, 1);
                    });
                    cardItem.runAction(cc.sequence(action1, action2, action3));
                }
            } else if (i < 6) {
                var targetPos = this.cardlayoutList[2].getPosition();
                var posX = targetPos.x - startPos.x;
                var posY = targetPos.y - (cardlayoutY + 72.5);
                var action1 = cc.delayTime(0.5);
                var action2 = cc.moveTo(0.2, cc.v2(posX, posY));
                if (i == 5) {
                    var action3 = cc.callFunc((tcardItem) => {
                        this.insertCardLayout(tcardItem, 2, true);
                        tcardItem.getComponent("CardItem").setFanPaiMv();
                    });
                    cardItem.runAction(cc.sequence(action1, action2, action3));
                } else {
                    var action3 = cc.callFunc((tcardItem) => {
                        this.insertCardLayout(tcardItem, 2);
                    });
                    cardItem.runAction(cc.sequence(action1, action2, action3));
                }
            } else if (i < 10) {
                var targetPos = this.cardlayoutList[3].getPosition();
                var posX = targetPos.x - startPos.x;
                var posY = targetPos.y - (cardlayoutY + 72.5);
                var action1 = cc.delayTime(0.4);
                var action2 = cc.moveTo(0.2, cc.v2(posX, posY));

                if (i == 9) {
                    var action3 = cc.callFunc((tcardItem) => {
                        this.insertCardLayout(tcardItem, 3, true);
                        tcardItem.getComponent("CardItem").setFanPaiMv();
                    });
                    cardItem.runAction(cc.sequence(action1, action2, action3));
                } else {
                    var action3 = cc.callFunc((tcardItem) => {
                        this.insertCardLayout(tcardItem, 3);
                    });
                    cardItem.runAction(cc.sequence(action1, action2, action3));
                }
            } else if (i < 15) {
                var targetPos = this.cardlayoutList[4].getPosition();
                var posX = targetPos.x - startPos.x;
                var posY = targetPos.y - (cardlayoutY + 72.5);
                var action1 = cc.delayTime(0.3);
                var action2 = cc.moveTo(0.2, cc.v2(posX, posY));
                if (i == 14) {
                    var action3 = cc.callFunc((tcardItem) => {
                        this.insertCardLayout(tcardItem, 4, true);
                        tcardItem.getComponent("CardItem").setFanPaiMv();
                    });
                    cardItem.runAction(cc.sequence(action1, action2, action3));
                } else {
                    var action3 = cc.callFunc((tcardItem) => {
                        this.insertCardLayout(tcardItem, 4);
                    });
                    cardItem.runAction(cc.sequence(action1, action2, action3));
                }
            } else if (i < 21) {
                var targetPos = this.cardlayoutList[5].getPosition();
                var posX = targetPos.x - startPos.x;
                var posY = targetPos.y - (cardlayoutY + 72.5);
                var action1 = cc.delayTime(0.2);
                var action2 = cc.moveTo(0.2, cc.v2(posX, posY));
                if (i == 20) {
                    var action3 = cc.callFunc((tcardItem) => {
                        this.insertCardLayout(tcardItem, 5, true);
                        tcardItem.getComponent("CardItem").setFanPaiMv();
                    });
                    cardItem.runAction(cc.sequence(action1, action2, action3));
                } else {
                    var action3 = cc.callFunc((tcardItem) => {
                        this.insertCardLayout(tcardItem, 5);
                    });
                    cardItem.runAction(cc.sequence(action1, action2, action3));
                }
            } else if (i < 28) {
                var targetPos = this.cardlayoutList[6].getPosition();
                var posX = targetPos.x - startPos.x;
                var posY = targetPos.y - (cardlayoutY + 72.5);
                var action1 = cc.delayTime(0.1);
                var action2 = cc.moveTo(0.2, cc.v2(posX, posY));
                if (i == 27) {
                    var action3 = cc.callFunc((tcardItem) => {
                        this.insertCardLayout(tcardItem, 6, true);
                        tcardItem.x = 0;
                        tcardItem.getComponent("CardItem").setFanPaiMv();

                        this.touchlayer.active = false;
                    });
                    cardItem.runAction(cc.sequence(action1, action2, action3));
                } else {
                    var action3 = cc.callFunc((tcardItem) => {
                        this.insertCardLayout(tcardItem, 6);
                    });
                    cardItem.runAction(cc.sequence(action1, action2, action3));
                }
            }
        }
    },

    onFaCards_three: function () {
        var startPos = this.factorylayout.getPosition();
        var cardlayoutY = this.cardlayout.getPosition().y
        for (var i = 0; i < 28; ++i) {
            var cardItem = this.cardItemList[i];
            if (i < 1) {
                var targetPos = this.cardlayoutList[0].getPosition();
                var posX = targetPos.x - startPos.x;
                var posY = targetPos.y - (cardlayoutY + 12.5);

                var action1 = cc.delayTime(0.1);
                var action2 = cc.moveTo(0.2, cc.v2(posX, posY));
                var action3 = cc.callFunc((tcardItem) => {
                    tcardItem.getComponent("CardItem").setFanPaiMv();
                })
                cardItem.runAction(cc.sequence(action1, action2, action3));
            } else if (i < 3) {
                var targetPos = this.cardlayoutList[1].getPosition();
                var posX = targetPos.x - startPos.x;
                var posY = targetPos.y - (cardlayoutY + 12.5);

                var action1 = cc.delayTime(0.2);
                var action2 = cc.moveTo(0.2, cc.v2(posX, posY));

                if (i == 2) {
                    var action3 = cc.callFunc((tcardItem) => {
                        tcardItem.getComponent("CardItem").setFanPaiMv();
                    });
                    cardItem.runAction(cc.sequence(action1, action2, action3));
                } else {
                    cardItem.runAction(cc.sequence(action1, action2));
                }
            } else if (i < 6) {
                var targetPos = this.cardlayoutList[2].getPosition();
                var posX = targetPos.x - startPos.x;
                var posY = targetPos.y - (cardlayoutY + 12.5);
                var action1 = cc.delayTime(0.3);
                var action2 = cc.moveTo(0.2, cc.v2(posX, posY));

                if (i == 5) {
                    var action3 = cc.callFunc((tcardItem) => {
                        tcardItem.getComponent("CardItem").setFanPaiMv();
                    });
                    cardItem.runAction(cc.sequence(action1, action2, action3));
                } else {
                    cardItem.runAction(cc.sequence(action1, action2));
                }
            } else if (i < 10) {
                var targetPos = this.cardlayoutList[3].getPosition();
                var posX = targetPos.x - startPos.x;
                var posY = targetPos.y - (cardlayoutY + 12.5);
                var action1 = cc.delayTime(0.4);
                var action2 = cc.moveTo(0.2, cc.v2(posX, posY));

                if (i == 9) {
                    var action3 = cc.callFunc((tcardItem) => {
                        tcardItem.getComponent("CardItem").setFanPaiMv();
                    });
                    cardItem.runAction(cc.sequence(action1, action2, action3));
                } else {
                    cardItem.runAction(cc.sequence(action1, action2));
                }
            } else if (i < 15) {
                var targetPos = this.cardlayoutList[4].getPosition();
                var posX = targetPos.x - startPos.x;
                var posY = targetPos.y - (cardlayoutY + 12.5);
                var action1 = cc.delayTime(0.5);
                var action2 = cc.moveTo(0.2, cc.v2(posX, posY));

                if (i == 14) {
                    var action3 = cc.callFunc((tcardItem) => {
                        tcardItem.getComponent("CardItem").setFanPaiMv();
                    });
                    cardItem.runAction(cc.sequence(action1, action2, action3));
                } else {
                    cardItem.runAction(cc.sequence(action1, action2));
                }
            } else if (i < 21) {
                var targetPos = this.cardlayoutList[5].getPosition();
                var posX = targetPos.x - startPos.x;
                var posY = targetPos.y - (cardlayoutY + 12.5);
                var action1 = cc.delayTime(0.6);
                var action2 = cc.moveTo(0.2, cc.v2(posX, posY));

                if (i == 20) {
                    var action3 = cc.callFunc((tcardItem) => {
                        tcardItem.getComponent("CardItem").setFanPaiMv();
                    });
                    cardItem.runAction(cc.sequence(action1, action2, action3));
                } else {
                    cardItem.runAction(cc.sequence(action1, action2));
                }
            } else if (i < 28) {
                var targetPos = this.cardlayoutList[6].getPosition();
                var posX = targetPos.x - startPos.x;
                var posY = targetPos.y - (cardlayoutY + 12.5);
                var action1 = cc.delayTime(0.7);
                var action2 = cc.moveTo(0.2, cc.v2(posX, posY));

                if (i == 27) {
                    var action3 = cc.callFunc((tcardItem) => {
                        tcardItem.getComponent("CardItem").setFanPaiMv();
                    });
                    cardItem.runAction(cc.sequence(action1, action2, action3));
                } else {
                    cardItem.runAction(cc.sequence(action1, action2));
                }
            }
        }

        setTimeout(() => {
            for (var i = 0; i < 28; ++i) {
                var cardItem = this.cardItemList[i];

                var action1 = null;
                var action2 = null;
                if (i == 0) {
                    this.insertCardLayout(cardItem, 0, true);
                } else if (i == 1) {
                    this.insertCardLayout(cardItem, 1);
                } else if (i < 3) {
                    action1 = cc.delayTime(0.1 + (i - 1) * 0.05);
                    if (i == 2) {
                        action2 = cc.callFunc((tcardItem) => {
                            this.insertCardLayout(tcardItem, 1, true);
                        });
                    } else {
                        action2 = cc.callFunc((tcardItem) => {
                            this.insertCardLayout(tcardItem, 1);
                        });
                    }
                    cardItem.runAction(cc.sequence(action1, action2));
                } else if (i < 6) {
                    action1 = cc.delayTime(0.1 + (i - 3) * 0.05);
                    if (i == 5) {
                        action2 = cc.callFunc((tcardItem) => {
                            this.insertCardLayout(tcardItem, 2, true);
                        });
                    } else {
                        action2 = cc.callFunc((tcardItem) => {
                            this.insertCardLayout(tcardItem, 2);
                        });
                    }
                    cardItem.runAction(cc.sequence(action1, action2));
                } else if (i < 10) {
                    action1 = cc.delayTime(0.1 + (i - 6) * 0.05);
                    if (i == 9) {
                        action2 = cc.callFunc((tcardItem) => {
                            this.insertCardLayout(tcardItem, 3, true);
                        });
                    } else {
                        action2 = cc.callFunc((tcardItem) => {
                            this.insertCardLayout(tcardItem, 3);
                        });
                    }
                    cardItem.runAction(cc.sequence(action1, action2));
                } else if (i < 15) {
                    action1 = cc.delayTime(0.1 + (i - 10) * 0.05);
                    if (i == 14) {
                        action2 = cc.callFunc((tcardItem) => {
                            this.insertCardLayout(tcardItem, 4, true);
                        });
                    } else {
                        action2 = cc.callFunc((tcardItem) => {
                            this.insertCardLayout(tcardItem, 4);
                        });
                    }
                    cardItem.runAction(cc.sequence(action1, action2));
                } else if (i < 21) {
                    action1 = cc.delayTime(0.1 + (i - 15) * 0.05);
                    if (i == 20) {
                        action2 = cc.callFunc((tcardItem) => {
                            this.insertCardLayout(tcardItem, 5, true);
                        });
                    } else {
                        action2 = cc.callFunc((tcardItem) => {
                            this.insertCardLayout(tcardItem, 5);
                        });
                    }
                    cardItem.runAction(cc.sequence(action1, action2));
                } else if (i < 28) {
                    action1 = cc.delayTime(0.1 + (i - 21) * 0.05);
                    if (i == 27) {
                        action2 = cc.callFunc((tcardItem) => {
                            this.insertCardLayout(tcardItem, 6, true);
                            this.touchlayer.active = false;
                        });
                    } else {
                        action2 = cc.callFunc((tcardItem) => {
                            this.insertCardLayout(tcardItem, 6);
                        });
                    }
                    cardItem.runAction(cc.sequence(action1, action2));
                }
            }
        }, 1000);

    },

    tuipaihuiqu: function () {
        this.updateFapaiAni();
    },

    updateFapaiAni: function () {
        for (var i = this.fcardlayout.children.length - 1, j = 0; i >= 0 && i >= this.fcardlayout.children.length - 3; i-- , j++) {
            this.fcardlayout.children[i].getComponent("CardItem").setShowValue();
            this.fcardlayout.children[i].getComponent("CardItem").offTouchListener();
            this.fcardlayout.children[i].runAction(cc.moveTo(0.2, cc.v2(130 - j * 40, 0)));
        }

        for (var i = this.fcardlayout.children.length - 4; i >= 0; i--) {
            this.fcardlayout.children[i].getComponent("CardItem").offTouchListener();
            if (this.fcardlayout.children[i].x != 50) {
                this.fcardlayout.children[i].runAction(cc.moveTo(0.2, cc.v2(50, 0)));
            }
        }

        if (this.fcardlayout.children.length > 0) {
            this.fcardlayout.children[this.fcardlayout.children.length - 1].getComponent("CardItem").onTouchListener();
        }

    },

    fapaichulai: function () {
        this.stopAllPromptNode();
        if (this.lastAutoMoveTimeout) {
            clearTimeout(this.lastAutoMoveTimeout);
        }
        this.playTipKuang(false);
        this.lastAutoMoveTimeout = setTimeout(this.onAutoTishi.bind(this), 5000);

        var target = [];
        if (this.pool.children.length > 0) {
            for (var i = 1; i <= this.preFaNum; ++i) {
                if (this.pool.children.length - i >= 0) {
                    target.push(this.pool.children[this.pool.children.length - i]);
                }
            }
        }
        if (target.length > 0) {
            this.addHistory(target, this.pool, this.fcardlayout);
            this.history[this.history.length - 1].faCard = target;

            if (this.leftRightMode == 0) {
                for (var i = 0; i < target.length; ++i) {
                    target[i].parent = this.fcardlayout;
                    target[i].x = 230;
                }
            } else if (this.leftRightMode == 1) {
                for (var i = 0; i < target.length; ++i) {
                    target[i].parent = this.fcardlayout;
                    target[i].x = 0;
                }
            }

            this.updateFapaiAni();

            if (this.pool.children.length <= 0 && this.status != 2) {
                this.playTipKuang(true);
            }
            // for (var i = this.fcardlayout.children.length - 1, j = 0; i >= 0 && i >= this.fcardlayout.children.length - 3; i-- , j++) {
            //     this.fcardlayout.children[i].getComponent("CardItem").setShowValue();
            //     this.fcardlayout.children[i].getComponent("CardItem").offTouchListener();
            //     this.fcardlayout.children[i].runAction(cc.moveTo(0.2, cc.v2(130 - j * 40, 0)));
            // }
            // target.getComponent("CardItem").onTouchListener();
        } else {
            this.playTipKuang(false);

            if (this.fcardlayout.children.length > 0) {
                var all = [];
                for (var i = 0; i < this.fcardlayout.children.length; i++) {
                    all.push(this.fcardlayout.children[i]);
                }
                this.fcardlayout.removeAllChildren();

                for (var i = all.length - 1; i >= 0; i--) {
                    all[i].x = 0;
                    all[i].y = 0;
                    console.log('设置牌背,', i);
                    all[i].getComponent('CardItem').setCardBg();
                    this.pool.addChild(all[i]);
                }

                this.fapaichulai();
            }
        }
    },

    insertCardLayout: function (cardItem, index, isShow) {
        if (cardItem && this.cardlayoutList[index]) {
            if (cardItem.parent) {
                var parent = cardItem.parent;
                parent.removeChild(cardItem);
            }
            if (isShow) {
                this.cardlayoutList[index].getChildByName('show').addChild(cardItem);
            } else {
                this.cardlayoutList[index].getChildByName('hide').addChild(cardItem);
            }
            cardItem.x = 0;
            cardItem.getComponent("CardItem").resetTouchListener();

            this.playSound("cardoff.wav");
        }
    },

    insertCardLayoutToOther: function (cardLayoutShow, index) {
        if (cardLayoutShow && this.cardlayoutList[index]) {
            if (cardLayoutShow.srcParent.getParent().name != this.cardlayoutList[index].name) {
                this.addHistory(cardLayoutShow, cardLayoutShow.srcParent, this.cardlayoutList[index].getChildByName('show'));
                this.setMoveStep(1);
            }
            var cardList = [];
            for (var i = 0; i < cardLayoutShow.children.length; i++) {
                cardList.push(cardLayoutShow.children[i]);
            }
            cardLayoutShow.removeAllChildren(true);
            for (var i = 0; i < cardList.length; i++) {
                this.cardlayoutList[index].getChildByName('show').addChild(cardList[i]);
                cardList[i].getComponent("CardItem").resetTouchListener();
            }

            this.playSound("cardoff.wav");

            this.piaoNum = -1;
        }
    },

    insertsCardLayout: function (cardItem, index) {
        if (cardItem && this.shoucardList[index]) {
            cardItem.parent = this.shoucardList[index];
            cardItem.x = 0;
            cardItem.y = 0;
            cardItem.posIndex = null;
            if (cardItem.oldParent.name != this.shoucardList[index].name) {
                this.addHistory(cardItem, cardItem.oldParent, this.shoucardList[index]);
                this.setMoveStep(1);
                // cardItem.scale = 1;
                cardItem.parent = this.shoucardList[index];
                cardItem.x = 0;
                cardItem.y = 0;

                this.piaoNum = this.piaoNum + 1;
                if (this.piaoNum > 9) {
                    this.piaoNum = 0;
                }
                console.log("piaoNum:", this.piaoNum);
                this.playSound("piano_" + this.piaoNum + ".wav");
            }
        }
    },

    startMoveCard: function (cardLayoutShow) {
        console.log("开始挪动");
        if (this.lastAutoMoveTimeout) {
            clearTimeout(this.lastAutoMoveTimeout);
        }

        // if(this.startMoving) {
        //     return;
        // }
        this.stopAllPromptNode();
        if (cardLayoutShow) {
            if (cardLayoutShow.getComponent("CardItem") != null) {
                var pos = cardLayoutShow.parent.convertToWorldSpaceAR(cardLayoutShow.position);
                var newNode = new cc.Node();
                cardLayoutShow.x = 0;
                cardLayoutShow.y = 0;
                cardLayoutShow.oldParent = cardLayoutShow.parent;

                var afterCards = [];
                if (cardLayoutShow.oldParent.name == 'show') {
                    var begin = false;
                    for (var i = 0; i < cardLayoutShow.oldParent.children.length; i++) {
                        if (begin) {
                            afterCards.push(cardLayoutShow.oldParent.children[i]);
                        }
                        if (cardLayoutShow.oldParent.children[i] == cardLayoutShow) {
                            begin = true;;
                        }
                    }
                }
                newNode.srcParent = cardLayoutShow.oldParent;
                cardLayoutShow.parent = newNode;
                for (var i = 0; i < afterCards.length; i++) {
                    afterCards[i].x = 0;
                    afterCards[i].y = (-1 - i) * 50;
                    afterCards[i].oldParent = afterCards[i].parent;
                    afterCards[i].parent = newNode;
                }

                cardLayoutShow = newNode;
                cardLayoutShow.parent = this.movecardlayout;
                pos = this.movecardlayout.convertToNodeSpaceAR(pos);
                cardLayoutShow.x = pos.x;
                cardLayoutShow.y = pos.y;
                // newNode.scale = 1.1;
            } else {
                cardLayoutShow.oldParent = cardLayoutShow.parent;
                // cardLayoutShow.scale = 1.1;
                var pos1 = cardLayoutShow.getParent() ? cardLayoutShow.getParent().getPosition() : { x: 0, y: 0 };
                var pos2 = cardLayoutShow.getPosition();

                cardLayoutShow.parent = this.movecardlayout;
                cardLayoutShow.x = pos1.x + pos2.x;
                cardLayoutShow.y = pos1.y + pos2.y;
            }
        }
        this.startMoving = true;;
    },

    endMoveCard: function (cardLayoutShow) {
        // if(!this.startMoving) {
        //     return;
        // }
        this.lastAutoMoveTimeout = setTimeout(this.onAutoTishi.bind(this), 5000);
        if (cardLayoutShow) {
            var isSuccess = false;
            if (cardLayoutShow.y < 0) {
                for (var i = 0; i < this.cardlayoutList.length; ++i) {
                    console.log(this.cardlayoutList[i].x);
                    if (cardLayoutShow.x < this.cardlayoutList[i].x + cardWidth / 2) {
                        var showNode = this.cardlayoutList[i].getChildByName('show');
                        // 放在原位
                        if (showNode == null) {
                            console.log("shownode为空，放在原位");
                            isSuccess = false;
                            break;
                        }
                        var length = showNode.children.length;
                        length += this.cardlayoutList[i].getChildByName('hide').children.length;
                        if (length == 0) {
                            var cardItem = cardLayoutShow.children[0];
                            if (cardItem.getComponent("CardItem").getCardValue() == 12 || cardItem.getComponent("CardItem").getCardValue() == 25 || cardItem.getComponent("CardItem").getCardValue() == 38 || cardItem.getComponent("CardItem").getCardValue() == 51) {
                                this.insertCardLayoutToOther(cardLayoutShow, i);
                                isSuccess = true;
                            }
                        } else {
                            var last = showNode.children[showNode.children.length - 1];
                            var first = cardLayoutShow.children[0];
                            if (this.getDiffColor(last, first) == 1) {
                                this.insertCardLayoutToOther(cardLayoutShow, i);
                                isSuccess = true;
                            }
                        }
                        break;
                    }
                }
            } else if (cardLayoutShow.children.length == 1) {
                var cardItem = cardLayoutShow.children[0];
                var pos = cardLayoutShow.convertToWorldSpaceAR(cardItem.position);
                for (var i = 0; i < this.shoucardList.length; ++i) {
                    var targetPos = this.scardlayout.convertToWorldSpaceAR(this.shoucardList[i].position);
                    if (pos.x > targetPos.x - 50 && pos.x < targetPos.x + 50 && pos.y > targetPos.y - 70 && pos.y < targetPos.y + 70) {
                        if (this.shoucardList[i].children == 0) {
                            if (cardItem.getComponent("CardItem").getCardValue() == 0 || cardItem.getComponent("CardItem").getCardValue() == 13 || cardItem.getComponent("CardItem").getCardValue() == 26 || cardItem.getComponent("CardItem").getCardValue() == 39) {
                                this.insertsCardLayout(cardItem, i);
                                isSuccess = true;
                            }
                        } else if (this.getDiffColor(this.shoucardList[i].children[this.shoucardList[i].children.length - 1], cardItem) == 2) {
                            this.insertsCardLayout(cardItem, i);
                            isSuccess = true;
                        }
                        break;
                    }
                }
            }

            //无效移动
            // cardLayoutShow.scale = 1;

            // if(cardItem.posIndex >= 0 && cardItem.posIndex < 7){
            //     this.insertCardLayout(cardItem, cardItem.posIndex);
            // }

            cardLayoutShow.parent = cardLayoutShow.oldParent;
            if (cardLayoutShow.parent) {
                cardLayoutShow.x = 0;
                var layout = cardLayoutShow.parent.getComponent(cc.Layout);
                if (layout) {
                    layout.updateLayout();
                }
            } else if (!isSuccess) {
                var cardItems = [];
                for (var i = 0; i < cardLayoutShow.children.length; i++) {
                    cardItems.push(cardLayoutShow.children[i]);
                }
                for (var i = 0; i < cardItems.length; i++) {
                    var cardItem = cardItems[i];
                    if (cardItem.parent) {
                        cardItem.parent.removeChild(cardItem);
                    }
                    console.log('value:', cardItem.getComponent("CardItem").getRealValue());
                    cardItem.oldParent.addChild(cardItem);
                    // cardItem.parent = cardItem.oldParent;
                    if (cardItem.oldParent.name == 'fcardlayout') {
                        cardItem.x = 130;
                    } else {
                        cardItem.x = 0;
                    }
                    cardItem.y = 0;
                    cardItem.getComponent("CardItem").resetTouchListener();
                }
            }

            // 翻牌
            for (var i = 0; i < this.cardlayoutList.length; ++i) {
                var hideNode = this.cardlayoutList[i].getChildByName('hide');
                var showNode = this.cardlayoutList[i].getChildByName('show');
                console.log(i, hideNode.children.length, showNode.children.length);
                if (hideNode.children.length > 0 && showNode.children.length == 0) {
                    const lastNode = hideNode.children[hideNode.children.length - 1];
                    this.insertCardLayout(lastNode, i, true);
                    lastNode.getComponent("CardItem").offTouchListener();
                    lastNode.getComponent("CardItem").setFanPaiMv(() => {
                        lastNode.getComponent("CardItem").onTouchListener();
                    });
                    if (this.history.length > 0) {
                        this.history[this.history.length - 1].showCard = lastNode;
                    }
                    hideNode.height = 120;
                    var layout = this.cardlayoutList[i].getComponent(cc.Layout);
                    layout.updateLayout();
                }
            }
            this.tuipaihuiqu();
            if (isSuccess) {
                this.calculSocre();
                var isClear = true;
                for (var i = 0; i < this.cardlayoutList.length; ++i) {
                    var hideNode = this.cardlayoutList[i].getChildByName('hide');
                    if (hideNode.children.length != 0) {
                        isClear = false;
                        break;
                    }
                }

                if (this.fcardlayout.children.length > 0) {
                    // isClear = false;
                }

                if (isClear) {
                    this.shoupaiBtn.active = true;
                    this.playTipKuang(false);
                    this.stopAllPromptNode();
                    if (this.lastAutoMoveTimeout) {
                        clearTimeout(this.lastAutoMoveTimeout);
                    }

                    console.log('牌局结束');
                }
            }
        }
        this.startMoving = false;
    },

    calculSocre: function () {
        if (this.status == 2) {
            var aNum = 0;
            for (var i = 0; i < this.shoucardList.length; ++i) {
                aNum = aNum + this.shoucardList[i].children.length;
            }
            this.setScore(5 * (aNum - this.a_num));

            var wjs_totalIncome = parseInt(cc.sys.localStorage.getItem("wjs_totalIncome")) || 0;
            wjs_totalIncome = wjs_totalIncome + 5 * (aNum - this.a_num);
            if (wjs_totalIncome < 0) {
                wjs_totalIncome = 0;
            }
            cc.sys.localStorage.setItem("wjs_totalIncome", wjs_totalIncome);

            this.a_num = aNum;
        } else {
            var aNum = 0;
            for (var i = 0; i < this.shoucardList.length; ++i) {
                aNum = aNum + this.shoucardList[i].children.length;
            }
            if (aNum > this.a_num) {
                this.setScore(10);
            } else if (aNum < this.a_num) {
                this.setScore(-20);
            }
            this.a_num = aNum;

            var cNum = 0;
            for (var i = 0; i < this.cardlayoutList.length; ++i) {
                cNum = cNum + this.cardlayoutList[i].getChildByName('show').children.length;
            }

            this.setScore(5 * (cNum - this.c_num));
            this.c_num = cNum;

            var bNum = this.pool.children.length + this.fcardlayout.children.length;
            if (bNum < this.b_num) {
                this.setScore(5);
            }
            this.b_num = bNum;
        }
    },

    // 自动收牌
    onAutoShoupai: function () {
        this.shoupaiBtn.active = false;

        var checkOver = () => {
            var lastCard = null;
            var isFindA = false;
            var shouCard = null;

            for (var i = 0; i < this.shoucardList.length; i++) {
                if (this.shoucardList[i].children.length == 0) {
                    shouCard = this.shoucardList[i];
                    isFindA = true;
                    break;
                } else if (this.shoucardList[i].children.length == 13) {
                    continue;
                } else {
                    var card = this.shoucardList[i].children[this.shoucardList[i].children.length - 1];
                    if (lastCard == null) {
                        lastCard = card;
                        shouCard = this.shoucardList[i];
                    }
                    var lastInfo = this.getCardInfo(lastCard);
                    var curInfo = this.getCardInfo(card);
                    if (curInfo.value < lastInfo.value) {
                        lastCard = card;
                        shouCard = this.shoucardList[i];
                    }
                }
            }
            if (lastCard == null && !isFindA) {
                console.log('游戏结束');
                this.playWin();
                return;
            } else {
                var moveTarget = null;
                for (var i = 0; i < this.cardItemList.length; i++) {
                    if (this.cardItemList[i].parent.parent == this.scardlayout) {
                        continue;
                    }
                    var curInfo = this.getCardInfo(this.cardItemList[i]);
                    if (isFindA) {
                        if (curInfo.value == 1) {
                            moveTarget = this.cardItemList[i];
                            break;
                        }
                    } else {
                        var lastInfo = this.getCardInfo(lastCard);
                        if (lastInfo.value + 1 == curInfo.value) {
                            moveTarget = this.cardItemList[i];
                            break;
                        }
                    }
                }
                var pos = moveTarget.parent.convertToWorldSpaceAR(moveTarget.position);
                moveTarget.getComponent("CardItem").setShowValue(false);
                pos = shouCard.convertToNodeSpaceAR(pos);
                moveTarget.parent = shouCard;

                this.piaoNum = this.piaoNum + 1;
                if (this.piaoNum > 9) {
                    this.piaoNum = 0;
                }

                console.log("piaoNum:", this.piaoNum);
                this.playSound("piano_" + this.piaoNum + ".wav");
                this.calculSocre();
                moveTarget.x = pos.x;
                moveTarget.y = pos.y;
                moveTarget.runAction(cc.sequence(cc.moveTo(0.1, cc.v2(0, 0)), cc.callFunc(() => {
                    setTimeout(checkOver, 0.1);
                })));
            }

        }
        checkOver();
    },

    getDiffColor(cardItem1, cardItem2) {
        if (cardItem1 && cardItem2 && cardItem1.getComponent("CardItem").isCanClick()) {
            if (cardItem1.getComponent("CardItem").getRealValue() - cardItem2.getComponent("CardItem").getRealValue() == 1
                && (Math.abs(cardItem1.getComponent("CardItem").getCardType() - cardItem2.getComponent("CardItem").getCardType()) == 1
                    || Math.abs(cardItem1.getComponent("CardItem").getCardType() - cardItem2.getComponent("CardItem").getCardType()) == 3)) {
                return 1;   //987654321
            } else if (cardItem2.getComponent("CardItem").getRealValue() - cardItem1.getComponent("CardItem").getRealValue() == 1 && cardItem1.getComponent("CardItem").getCardType() == cardItem2.getComponent("CardItem").getCardType()) {
                return 2;   //123456789
            }
            return -1;
        }
        return -1;
    },

    resetMatch(status) {
        var reset = () => {
            this.initData();
            this.stopAllPromptNode();
            if (this.lastAutoMoveTimeout) {
                clearTimeout(this.lastAutoMoveTimeout);
            }
            this.shuffle(status);
            this.onFaCards();
        }
        if (cc.sys.isNative && cc.sys.os === cc.sys.OS_ANDROID && (this.lastWatch == null || Date.now() - this.lastWatch > 60000)) {
            if (upltv.isRewardReady()) {
                // upltv.setRewardVideoShowCallback(function (type, cpid) {
                //     var event = "unkown";
                //     if (type == upltv.AdEventType.VIDEO_EVENT_DID_SHOW) {
                //         event = "Did_Show";
                //     }
                //     else if (type == upltv.AdEventType.VIDEO_EVENT_DID_CLICK) {
                //         event = "Did_Click";
                //     }
                //     else if (type == upltv.AdEventType.VIDEO_EVENT_DID_CLOSE) {
                //         event = "Did_Close";
                //         reset();
                //     } else if (type == upltv.AdEventType.VIDEO_EVENT_DID_GIVEN_REWARD) {
                //         event = "Did_Given_Reward";
                //     } else if (type == upltv.AdEventType.VIDEO_EVENT_DID_ABANDON_REWARD) {
                //         event = "Did_Abandon_Reward";
                //     }
                //     cc.log("===> js RewardVideo Show Callback, event: %s, at: %s", event, cpid);
                // });
                upltv.showInterstitialAd('jielong003');
                console.log("展示激励视屏");
                this.lastWatch = Date.now();
            } else {
                reset();
            }
        } else {
            reset();
        }


    },

    dayilyMatch(data) {
        this.initData();
        this.stopAllPromptNode();
        if (this.lastAutoMoveTimeout) {
            clearTimeout(this.lastAutoMoveTimeout);
        }
        this.dayilyMatchData = data;
        this.shuffle(4);
        this.onFaCards();
    },

    settingLeftRight(isOpen) {
        this.leftRightMode = isOpen;
        if (isOpen == 0) {
            this.undobtn.x = 310;
            this.tipsbtn.x = 155;
            this.handbtn.x = 0;
            this.dailybtn.x = -155;
            this.settingbtn.x = -310;

            this.factorylayout.x = 315;
            this.fcardlayout.x = 55;
            this.scardlayout.x = -370;
        } else if (isOpen == 1) {
            this.undobtn.x = -310;
            this.tipsbtn.x = -155;
            this.handbtn.x = 0;
            this.dailybtn.x = 155;
            this.settingbtn.x = 310;
            this.factorylayout.x = -320;
            this.fcardlayout.x = -254;
            this.scardlayout.x = -45;
        }
        this.stopAllPromptNode();
        if (this.lastAutoMoveTimeout) {
            clearTimeout(this.lastAutoMoveTimeout);
        }
        this.playTipKuang(false);
        this.lastAutoMoveTimeout = setTimeout(this.onAutoTishi.bind(this), 5000);

    },

    settingTimeMode(isOpen) {
        if (isOpen == 0) {
            this.toplayout.active = false;
        } else if (isOpen == 1) {
            this.toplayout.active = true;
        }
    },

    settingThreeCard(data) {
        this.preFaNum = data == 1 ? 3 : 1;
    },

    settintSound(isOpen) {
        this.soundTag = isOpen;
    },

    playSound(path) {
        if (this.soundTag == 1) {
            cc.audioEngine.play(cc.url.raw("resources/sound/" + path));
        }
    },

    testshoupai() {
        for (var i = 0; i < this.cardItemList.length; ++i) {
            if (i < 13) {
                this.cardItemList[i].parent = this.shoucardList[0];
            } else if (i < 26) {
                this.cardItemList[i].parent = this.shoucardList[1];
            } else if (i < 39) {
                this.cardItemList[i].parent = this.shoucardList[2];
            } else {
                this.cardItemList[i].parent = this.shoucardList[3];
            }
            this.cardItemList[i].getComponent("CardItem").setShowValue();
            this.cardItemList[i].x = 0;
            this.cardItemList[i].y = 0;
        }
    },

    //游戏结束调用这个
    playWin() {
        this.touchlayer.active = true;
        this.stopTimer();
        this.isGameOver = true;
        this.shoupaiBtn.active = false;
        this.playTipKuang(false);
        this.stopAllPromptNode();
        if (this.lastAutoMoveTimeout) {
            clearTimeout(this.lastAutoMoveTimeout);
        }

        var timeout = 0;
        var num = Math.floor(Math.random() * 4);
        if (num == 0) {
            this.playWin_sjsl();
            timeout = 7000;
        } else if (num == 1) {
            this.playWin_zfx();
            timeout = 11000;
        } else if (num == 2) {
            this.playWin_yx();
            timeout = 11000;
        } else {
            this.playWin_bl();
            timeout = 11000;
        }


        setTimeout(function () {
            this.touchlayer.active = false;
            this.dispatchEvent("PLAY_WIN", { moveStep: this.moveStep, score: this.score, time: this.gameTime });
        }.bind(this), timeout);

        if (this.status == 4) {
            if (this.dayilyMatchData) {
                if (cc.sys.localStorage.getItem("dayily_" + this.dayilyMatchData.month + "_" + this.dayilyMatchData.day) != 1) {
                    var num = parseInt(cc.sys.localStorage.getItem("dayily_total_num")) || 0;
                    cc.sys.localStorage.setItem("dayily_total_num", num + 1);
                }
                cc.sys.localStorage.setItem("dayily_" + this.dayilyMatchData.month + "_" + this.dayilyMatchData.day, 1);
            }
        } else if (this.status == 2) {
            var num = parseInt(cc.sys.localStorage.getItem("wjs_successNum")) || 0;
            cc.sys.localStorage.setItem("wjs_successNum", num + 1);

            var wjs_maxCash = parseInt(cc.sys.localStorage.getItem("wjs_maxCash")) || 0;
            if (this.score > wjs_maxCash) {
                cc.sys.localStorage.setItem("wjs_maxCash", this.score);
            }
        }

        if (this.preFaNum == 1) {
            var num = parseInt(cc.sys.localStorage.getItem("one_successNum")) || 0;
            cc.sys.localStorage.setItem("one_successNum", num + 1);

            var score = parseInt(cc.sys.localStorage.getItem("one_bestScore")) || 0;
            if (this.score > score) {
                cc.sys.localStorage.setItem("one_bestScore", this.score);
            }

            var moveStep = parseInt(cc.sys.localStorage.getItem("one_minMoveStep")) || 0;
            if (this.moveStep < moveStep || moveStep == 0) {
                cc.sys.localStorage.setItem("one_minMoveStep", this.moveStep);
            }

            var time = parseInt(cc.sys.localStorage.getItem("one_minTime")) || 0;
            if (this.gameTime < time || time == 0) {
                cc.sys.localStorage.setItem("one_minTime", this.gameTime);
            }

            var time = parseInt(cc.sys.localStorage.getItem("one_totalTime")) || 0;
            cc.sys.localStorage.setItem("one_totalTime", time + this.gameTime);
        } else if (this.preFaNum == 3) {
            var num = parseInt(cc.sys.localStorage.getItem("three_successNum")) || 0;
            cc.sys.localStorage.setItem("three_successNum", num + 1);

            var score = parseInt(cc.sys.localStorage.getItem("three_bestScore")) || 0;
            if (this.score > score) {
                cc.sys.localStorage.setItem("three_bestScore", this.score);
            }

            var moveStep = parseInt(cc.sys.localStorage.getItem("three_minMoveStep")) || 0;
            if (this.moveStep < moveStep || moveStep == 0) {
                cc.sys.localStorage.setItem("three_minMoveStep", this.moveStep);
            }

            var time = parseInt(cc.sys.localStorage.getItem("three_minTime")) || 0;
            if (this.gameTime < time || time == 0) {
                cc.sys.localStorage.setItem("three_minTime", this.gameTime);
            }

            var time = parseInt(cc.sys.localStorage.getItem("three_totalTime")) || 0;
            cc.sys.localStorage.setItem("three_totalTime", time + this.gameTime);
        }
    },

    //随机散列
    playWin_sjsl() {
        this.playSound("win.wav");

        var pos0 = this.shoucardList[0].convertToNodeSpaceAR(cc.v2(cc.winSize.width / 2, cc.winSize.height / 2));
        var pos1 = this.shoucardList[1].convertToNodeSpaceAR(cc.v2(cc.winSize.width / 2, cc.winSize.height / 2));
        var pos2 = this.shoucardList[2].convertToNodeSpaceAR(cc.v2(cc.winSize.width / 2, cc.winSize.height / 2));
        var pos3 = this.shoucardList[3].convertToNodeSpaceAR(cc.v2(cc.winSize.width / 2, cc.winSize.height / 2));

        for (var i = this.shoucardList[0].children.length - 1; i >= 0; --i) {
            var cardItem = this.shoucardList[0].children[i];
            cardItem.runAction(cc.sequence(cc.delayTime(i * 0.1), cc.moveTo(0.2, pos0).easing(cc.easeSineInOut())));
        }

        for (var i = this.shoucardList[1].children.length - 1; i >= 0; --i) {
            var cardItem = this.shoucardList[1].children[i];
            cardItem.runAction(cc.sequence(cc.delayTime(0.15 + i * 0.1), cc.moveTo(0.2, pos1).easing(cc.easeSineInOut())));
        }

        for (var i = this.shoucardList[2].children.length - 1; i >= 0; --i) {
            var cardItem = this.shoucardList[2].children[i];
            cardItem.runAction(cc.sequence(cc.delayTime(0.3 + i * 0.1), cc.moveTo(0.2, pos2).easing(cc.easeSineInOut())));
        }

        for (var i = this.shoucardList[3].children.length - 1; i >= 0; --i) {
            var cardItem = this.shoucardList[3].children[i];
            cardItem.runAction(cc.sequence(cc.delayTime(0.45 + i * 0.1), cc.moveTo(0.2, pos3).easing(cc.easeSineInOut())));
        }

        var randomPosList = [];
        for (var i = 0; i < this.cardItemList.length; ++i) {
            var cardItem = this.cardItemList[i];
            var randomX = Math.random() * 600 - 300;
            var randomY = Math.random() * 600 - 300;
            var randomRotate = Math.random() * 360;
            randomPosList.push({ "x": randomX, "y": randomY });
            cardItem.runAction(cc.sequence(cc.delayTime(2), cc.spawn(cc.rotateTo(0.1, randomRotate), cc.moveBy(0.1, cc.v2(randomX, randomY)).easing(cc.easeSineInOut()))));
        }

        setTimeout(function () {
            var poolpos = this.pool.convertToNodeSpaceAR(cc.v2(cc.winSize.width / 2, cc.winSize.height / 2));
            for (var i = 0; i < this.cardItemList.length; ++i) {
                var cardItem = this.cardItemList[i];

                cardItem.parent = this.pool;
                cardItem.x = poolpos.x + randomPosList[i].x
                cardItem.y = poolpos.y + randomPosList[i].y;
                cardItem.runAction(cc.sequence(cc.delayTime((this.cardItemList.length - 1 - i) * 0.05), cc.spawn(cc.rotateTo(0.1, 0), cc.moveTo(0.1, cc.v2(0, 0)).easing(cc.easeSineInOut()))));
            }
        }.bind(this), 3000);
    },

    //正方形
    playWin_zfx() {
        this.playSound("win.wav");

        var radius = 240;
        var offestX = this.scardlayout.getPosition().x - this.factorylayout.getPosition().x;
        var poolpos = this.pool.convertToNodeSpaceAR(cc.v2(cc.winSize.width / 2, cc.winSize.height / 2));
        for (var i = 0; i < this.cardItemList.length; ++i) {
            var cardItem = this.cardItemList[i];
            var srcPosX = offestX + cardItem.parent.getPosition().x;
            var srcPosY = 0;
            cardItem.parent = this.pool;
            cardItem.x = srcPosX;
            cardItem.y = srcPosY;
            if (i < 13) {
                var targetX = poolpos.x + (i - 6) * 40;
                var targetY = poolpos.y + radius;
                cardItem.runAction(cc.sequence(cc.delayTime(0.1 + i * 0.03), cc.moveTo(0.2, cc.v2(targetX, targetY)).easing(cc.easeSineInOut())));
            } else if (i < 26) {
                var targetX = poolpos.x + radius;
                var targetY = poolpos.y + (19 - i) * 40;
                cardItem.runAction(cc.sequence(cc.delayTime(0.1 + i * 0.03), cc.moveTo(0.2, cc.v2(targetX, targetY)).easing(cc.easeSineInOut())));
            } else if (i < 39) {
                var targetX = poolpos.x + (32 - i) * 40;
                var targetY = poolpos.y - radius;
                cardItem.runAction(cc.sequence(cc.delayTime(0.1 + i * 0.03), cc.moveTo(0.2, cc.v2(targetX, targetY)).easing(cc.easeSineInOut())));
            } else {
                var targetX = poolpos.x - radius;
                var targetY = poolpos.y + (i - 45) * 40;
                cardItem.runAction(cc.sequence(cc.delayTime(0.1 + i * 0.03), cc.moveTo(0.2, cc.v2(targetX, targetY)).easing(cc.easeSineInOut())));
            }

            var action1 = cc.delayTime(2 + i * 0.05);
            var action2 = cc.callFunc((tcardItem) => {
                tcardItem.getComponent("CardItem").setCardBg(true);
            });
            var action3 = cc.delayTime(5 + i * 0.05);
            var action4 = cc.callFunc((tcardItem) => {
                tcardItem.getComponent("CardItem").setShowValue(true);
            });
            cardItem.runAction(cc.sequence(action1, action2));
            cardItem.runAction(cc.sequence(action3, action4));

            cardItem.runAction(cc.sequence(cc.delayTime(8 + i * 0.04), cc.spawn(cc.rotateTo(0.1, 0), cc.moveTo(0.1, cc.v2(0, 0)).easing(cc.easeSineInOut()))));
        }
    },

    //圆形
    playWin_yx() {
        this.playSound("win.wav");
        var radius = 240;
        var offestX = this.scardlayout.getPosition().x - this.factorylayout.getPosition().x;
        var poolpos = this.pool.convertToNodeSpaceAR(cc.v2(cc.winSize.width / 2, cc.winSize.height / 2));
        for (var i = 0; i < this.cardItemList.length; ++i) {
            var cardItem = this.cardItemList[i];
            var srcPosX = offestX + cardItem.parent.getPosition().x;
            var srcPosY = 0;
            cardItem.parent = this.pool;
            cardItem.x = srcPosX;
            cardItem.y = srcPosY;
            var targetX = poolpos.x + radius * Math.cos((i * 7) * 3.14 / 180);
            var targetY = poolpos.y + radius * Math.sin((i * 7) * 3.14 / 180);
            cardItem.runAction(cc.sequence(cc.delayTime(0.1 + i * 0.03), cc.moveTo(0.2, cc.v2(targetX, targetY)).easing(cc.easeSineInOut())));

            var action1 = cc.delayTime(2 + i * 0.05);
            var action2 = cc.callFunc((tcardItem) => {
                tcardItem.getComponent("CardItem").setCardBg(true);
            });
            var action3 = cc.delayTime(5 + i * 0.05);
            var action4 = cc.callFunc((tcardItem) => {
                tcardItem.getComponent("CardItem").setShowValue(true);
            });
            cardItem.runAction(cc.sequence(action1, action2));
            cardItem.runAction(cc.sequence(action3, action4));

            cardItem.runAction(cc.sequence(cc.delayTime(8 + i * 0.04), cc.spawn(cc.rotateTo(0.1, 0), cc.moveTo(0.1, cc.v2(0, 0)).easing(cc.easeSineInOut()))));
        }
    },

    //波浪
    playWin_bl() {
        this.playSound("win.wav");

        var radius = 360;
        var offestX = this.scardlayout.getPosition().x - this.factorylayout.getPosition().x;
        var poolpos = this.pool.convertToNodeSpaceAR(cc.v2(cc.winSize.width / 2, cc.winSize.height / 2));
        for (var i = 0; i < this.cardItemList.length; ++i) {
            var cardItem = this.cardItemList[i];
            var srcPosX = offestX + cardItem.parent.getPosition().x;
            var srcPosY = 0;
            cardItem.parent = this.pool;
            cardItem.x = srcPosX;
            cardItem.y = srcPosY;
            if (i < 13) {
                var targetX = poolpos.x - radius + i * 15;
                var targetY = poolpos.y + i * 15;
                cardItem.runAction(cc.sequence(cc.delayTime(0.1 + i * 0.03), cc.moveTo(0.2, cc.v2(targetX, targetY)).easing(cc.easeSineInOut())));
            } else if (i < 26) {
                var targetX = poolpos.x - radius + i * 15;
                var targetY = poolpos.y + (26 - i) * 15;
                cardItem.runAction(cc.sequence(cc.delayTime(0.1 + i * 0.03), cc.moveTo(0.2, cc.v2(targetX, targetY)).easing(cc.easeSineInOut())));
            } else if (i < 39) {
                var targetX = poolpos.x + (i - 26) * 15;
                var targetY = poolpos.y + (i - 26) * 15;
                cardItem.runAction(cc.sequence(cc.delayTime(0.1 + i * 0.03), cc.moveTo(0.2, cc.v2(targetX, targetY)).easing(cc.easeSineInOut())));
            } else {
                var targetX = poolpos.x + (i - 26) * 15;
                var targetY = poolpos.y + (52 - i) * 15
                cardItem.runAction(cc.sequence(cc.delayTime(0.1 + i * 0.03), cc.moveTo(0.2, cc.v2(targetX, targetY)).easing(cc.easeSineInOut())));
            }

            var action1 = cc.delayTime(2 + i * 0.05);
            var action2 = cc.callFunc((tcardItem) => {
                tcardItem.getComponent("CardItem").setCardBg(true);
            });
            var action3 = cc.delayTime(5 + i * 0.05);
            var action4 = cc.callFunc((tcardItem) => {
                tcardItem.getComponent("CardItem").setShowValue(true);
            });
            cardItem.runAction(cc.sequence(action1, action2));
            cardItem.runAction(cc.sequence(action3, action4));

            cardItem.runAction(cc.sequence(cc.delayTime(8 + i * 0.04), cc.spawn(cc.rotateTo(0.1, 0), cc.moveTo(0.1, cc.v2(0, 0)).easing(cc.easeSineInOut()))));
        }
    },

    //移动步数
    setMoveStep(step) {
        this.moveStep = this.moveStep + step;
        if (this.moveStep <= 0) {
            this.moveStep = 0;
        }
        this.moveLabel.string = Localization["Moves"][window.language] + this.moveStep;
    },

    //得分
    setScore(score) {
        this.score = this.score + score;
        if (this.status == 2) {
            if (this.score > 0) {
                this.scoreLabel.string = Localization["Score_format"][window.language] + "$" + this.score;
            } else {
                this.scoreLabel.string = Localization["Score_format"][window.language] + "-$" + (this.score * -1);
            }
        } else {
            if (this.score <= 0) {
                this.score = 0;
            }
            this.scoreLabel.string = Localization["Score_format"][window.language] + this.score;
        }
    },

    updateMainBg: function (index) {
        if (index) {
            if (index < 5) {
                utils.restSpriteFrame(this.node.getChildByName("bg"), "texture/bg" + index + ".png");

                utils.restSpriteFrame(this.factorylayout, "texture/sx" + index + ".png");

                for (var i = 0; i < this.shoucardList.length; ++i) {
                    utils.restSpriteFrame(this.shoucardList[i], "texture/kp" + index + ".png");
                }

                for (var i = 0; i < this.asList.length; ++i) {
                    utils.restSpriteFrame(this.asList[i], "texture/kp" + index + ".png");
                }
            } else {
                const bgNode = this.node.getChildByName("bg");
                const width = bgNode.width;
                const height = bgNode.height;
                var jsonStr = cc.sys.localStorage.getItem("GAME_BG") || "[]";
                var bgList = JSON.parse(jsonStr);

                cc.loader.load(bgList[index - 5], function (err, tex) {
                    bgNode.getComponent(cc.Sprite).spriteFrame = new cc.SpriteFrame(tex);
                    bgNode.width = width;
                    bgNode.height = height;
                    console.log("刷新选择的相册背景完成");
                });
            }
        }
    },

    updateCardBg: function (index) {
        if (index) {
            if (index < 6) {
                window.poksersBgType = index;
                for (var i = 0; i < this.cardItemList.length; ++i) {
                    if (this.cardItemList[i].getComponent("CardItem").getZFM() == false) {
                        this.cardItemList[i].getComponent("CardItem").updateBg();
                    }
                }
                console.log("刷新选择的牌背景完成",index);
            } else {
                window.poksersBgType = index;
                var jsonStr = cc.sys.localStorage.getItem("GAME_CARD") || "[]";
                var bgList = JSON.parse(jsonStr);
                cc.loader.load(bgList[index - 6], (err, tex) => {
                    window.cardBgSpriteFrame = new cc.SpriteFrame(tex);
                    for (var i = 0; i < this.cardItemList.length; ++i) {
                        if (this.cardItemList[i].getComponent("CardItem").getZFM() == false) {
                            this.cardItemList[i].getComponent("CardItem").updateBg();
                        }
                    }
                    console.log("刷新选择的牌背景完成");
                });
            }
        }
    },

    updateCard: function (index) {
        if (index) {
            window.poksersType = index;
            for (var i = 0; i < this.cardItemList.length; ++i) {
                if (this.cardItemList[i].getComponent("CardItem").getZFM() == true) {
                    this.cardItemList[i].getComponent("CardItem").updateCard();
                }
            }
        }
    },

    playTipKuang: function (isVisible) {
        if (isVisible) {
            if (this.fcardlayout.children.length > 0) {
                this.tipkuang.active = true;
                this.tipkuang.getComponent("cc.Animation").play("tipkuang");
            } else {
                this.tipkuang.active = false;
            }
        } else {
            this.tipkuang.active = false;
        }
    },

    onDestroy() {
        this._super();
    }
});

