window.poksersType = 1;
cc.Class({
    extends: cc.Component,

    properties: {
        poksers1: {
            default: null,
            type: cc.SpriteAtlas,
        },
        poksers2: {
            default: null,
            type: cc.SpriteAtlas,
        },
        poksers3: {
            default: null,
            type: cc.SpriteAtlas,
        },
        poksers4: {
            default: null,
            type: cc.SpriteAtlas,
        },
        poksers5: {
            default: null,
            type: cc.SpriteAtlas,
        },
    },

    onLoad() {
        // console.log("加载节点完成");
        this._zfmian = false;   //正反面
    },

    offTouchListener: function () {
        this.node.off(cc.Node.EventType.TOUCH_START);
        this.node.off(cc.Node.EventType.TOUCH_MOVE);
        this.node.off(cc.Node.EventType.TOUCH_END);
        this.node.off(cc.Node.EventType.TOUCH_CANCEL);
    },

    onTouchListener: function () {
        this.node.on(cc.Node.EventType.TOUCH_START,  (event) => {
            if (!this.canClick || cc.cardtouching) {
                return;
            }
            cc.cardtouching = true;
            event.bubbles = false;
            console.log("cc.Node.EventType.TOUCH_START:");
            this.node.moveModel = false;
            puremvc.Facade.sendNotification(appNotice.CARD_MOVE_BEGIN, this.node);
        });

        this.node.on(cc.Node.EventType.TOUCH_MOVE,  (event) => {
            if (!this.canClick || !cc.cardtouching) {
                return;
            }
            event.bubbles = false;
            var cur = event.getLocation();
            var src = this.node.parent.convertToWorldSpaceAR(this.node.position);
            if (Math.abs(cur.x - src.x) > 50 || Math.abs(cur.y - src.y) > 70) {
                this.node.moveModel = true;
            }

            if (this.node.moveModel) {
                var delta = event.getDelta();
                // console.log(delta);
                this.node.parent.x += delta.x;
                this.node.parent.y += delta.y;
            }
        });

        this.node.on(cc.Node.EventType.TOUCH_END,  (event) => {
            if (!this.canClick || !cc.cardtouching) {
                return;
            }
            cc.cardtouching = false;
            event.bubbles = false;
            console.log("cc.Node.EventType.TOUCH_END:");
            puremvc.Facade.sendNotification(appNotice.CARD_MOVE_END, this.node.parent);
            if (!this.node.moveModel) {
                puremvc.Facade.sendNotification(appNotice.CARD_CLICK, this.node);
            }
        });

        this.node.on(cc.Node.EventType.TOUCH_CANCEL,  (event) => {
            if (!this.canClick || !cc.cardtouching) {
                return;
            }
            cc.cardtouching = false;
            event.bubbles = false;
            console.log("**************************TOUCH_CANCEL");
            puremvc.Facade.sendNotification(appNotice.CARD_MOVE_END, this.node.parent);
            if (!this.node.moveModel) {
                puremvc.Facade.sendNotification(appNotice.CARD_CLICK, this.node.parent);
            }
        });
    },

    resetTouchListener: function () {
        this.offTouchListener();
        this.onTouchListener();
    },

    setCardValue(cardValue) {
        if (cardValue != null && cardValue >= 0 && cardValue < 53) {
            this._cardValue = cardValue;
            this.node.getComponent("cc.Sprite").spriteFrame = this.getSpriteFrame(cardValue);
            this.setCanClick(true);
        }
    },


    setShowValue(isPlay) {
        if (isPlay == true) {
            var action1 = cc.scaleTo(0.05, 0, 1);
            var action2 = cc.callFunc(() => {
                this.node.getComponent("cc.Sprite").spriteFrame = this.getSpriteFrame(this._cardValue);
            });
            var action3 = cc.scaleTo(0.05, 1, 1);
            this.node.runAction(cc.sequence(action1, action2, action3));
            console.log('正面-翻牌完成');
        } else {
            this.node.getComponent("cc.Sprite").spriteFrame = this.getSpriteFrame(this._cardValue);
        }
        this.setCanClick(true);
    },

    //设置为背面
    setCardBg(isPlay) {
        if (isPlay == true) {
            var action1 = cc.scaleTo(0.05, 0, 1);
            var action2 = cc.callFunc(() => {
                var width = this.node.width;
                var height = this.node.height;
                this.node.getComponent("cc.Sprite").spriteFrame = this.getBgSpriteFrame();
                this.node.width = width;
                this.node.height = height;
            });
            var action3 = cc.scaleTo(0.05, 1, 1);
            this.node.runAction(cc.sequence(action1, action2, action3));
            console.log('背面-翻牌完成');
        } else {
            var width = this.node.width;
            var height = this.node.height;
            this.node.getComponent("cc.Sprite").spriteFrame = this.getBgSpriteFrame();
            this.node.width = width;
            this.node.height = height;
        }
        this.setCanClick(false);
    },

    setCanClick(iscanclick) {
        // this.node.getComponent("cc.Button").interactable = iscanclick;
        this.canClick = iscanclick;
    },

    setFanPaiMv(callback) {
        console.log('翻牌', this._cardValue)
        if (this._cardValue >= 0 && this._cardValue < 53) {
            this.node.stopAllActions();

            var action1 = cc.scaleTo(0.1, 0, 1);
            var action2 = cc.callFunc(() => {
                this.node.getComponent("cc.Sprite").spriteFrame = this.getSpriteFrame(this._cardValue);
                this.setCanClick(true);
            });
            var action3 = cc.scaleTo(0.1, 1, 1);
            this.node.runAction(cc.sequence(action1, action2, action3, cc.callFunc(callback)));
            console.log('翻牌完成');
        }
    },

    isCanClick() {
        return true;
    },

    isCanClick2() {
        return this.canClick;
    },

    getCardValue() {
        return this._cardValue;
    },

    getRealValue() {
        return this._cardValue % 13 + 1;
    },

    getCardType() {
        //方块-梅花-红桃-黑桃
        if (this._cardValue >= 0) {
            if (this._cardValue < 13) {
                return 0;
            } else if (this._cardValue < 26) {
                return 1;
            } else if (this._cardValue < 39) {
                return 2;
            } else if (this._cardValue < 52) {
                return 3;
            }
            return -1;
        }
        return -1;
    },


    getSpriteFrame: function (cardValue) {
        this._zfmian = true;
        if (window.poksersType == 1) {
            return this.poksers1.getSpriteFrame(cardValue);
        } else if (window.poksersType == 2) {
            return this.poksers2.getSpriteFrame(cardValue);
        } else if (window.poksersType == 3) {
            return this.poksers3.getSpriteFrame(cardValue);
        } else if (window.poksersType == 4) {
            return this.poksers4.getSpriteFrame(cardValue);
        } else if (window.poksersType == 5) {
            return this.poksers5.getSpriteFrame(cardValue);
        } else {
            return this.poksers1.getSpriteFrame(cardValue);
        }
    },

    getBgSpriteFrame: function () {
        this._zfmian = false;
        if (window.poksersBgType == 1) {
            return this.poksers1.getSpriteFrame("bg");
        } else if (window.poksersBgType == 2) {
            return this.poksers2.getSpriteFrame("bg");
        } else if (window.poksersBgType == 3) {
            return this.poksers3.getSpriteFrame("bg");
        } else if (window.poksersBgType == 4) {
            return this.poksers4.getSpriteFrame("bg");
        } else if (window.poksersBgType == 5) {
            return this.poksers5.getSpriteFrame("bg");
        } else if (window.poksersBgType >= 6) {
            return window.cardBgSpriteFrame;
        } else {
            return this.poksers1.getSpriteFrame("bg");
        }
    },

    updateBg: function () {
        var width = this.node.width;
        var height = this.node.height;
        this.node.getComponent("cc.Sprite").spriteFrame = this.getBgSpriteFrame();
        this.node.width = width;
        this.node.height = height;
    },

    updateCard: function () {
        this.node.getComponent("cc.Sprite").spriteFrame = this.getSpriteFrame(this._cardValue)
    },

    getZFM: function () {
        return this._zfmian;
    },

    onDestroy() {

    },
});
