var UserProxy = require("UserProxy");
var BaseMediator = require("BaseMediator");

cc.Class({
    extends:BaseMediator,
    properties: {
        middlePositionX : 0,
    },

    statics:{
        NAME:"MAINNODEMEDIATOR"
    },

    didRegister(){
        this.bind("UNDO_BTN", (data)=>{
           this.tipsEventBtnClicked();
        }, this);
        this.bind("TIPS_BTN", (data)=>{
            this.tipsEventBtnClicked();
        }, this);
        this.bind("HAND_BTN", (data)=>{
            this.facade.sendNotification(appNotice.SHOW_NODE, {name:"HandsNode"});
        }, this);
        this.bind("DAILY_BTN", (data)=>{
            this.facade.sendNotification(appNotice.SHOW_NODE, {name:"SignNode"});
        }, this);

        this.bind("SETTING_BTN", (data)=>{
            this.facade.sendNotification(appNotice.SHOW_NODE, {name:"SettingNode"});
        }, this);

        this.bind("PLAY_WIN", (data)=>{
            this.facade.sendNotification(appNotice.SHOW_NODE, {name:"ResultNode", initData:data});
        }, this);

        var newuser = cc.sys.localStorage.getItem("newuser");
        if(!newuser){
            cc.sys.localStorage.setItem("newuser", 1);
            this.facade.sendNotification(appNotice.SHOW_NODE, {name:"HelpNode"});

            //新用户设置默认状态
            cc.sys.localStorage.setItem("soundTag", 1);
            cc.sys.localStorage.setItem("timeMode", 1);
            cc.sys.localStorage.setItem("pushTag", 1);
            cc.sys.localStorage.setItem("autoTips", 1);
        }
    },

    listNotificationInterests(){
        return [
            appNotice.CARD_MOVE_BEGIN,
            appNotice.CARD_MOVE_END,
            appNotice.CARD_CLICK,
            appNotice.RESET_MATCH,
            appNotice.SETTINT_LEFT_RIGHT,
            appNotice.SETTINT_TIME_MODE,
            appNotice.SETTINT_THREED_CARD,
            appNotice.SETTINT_SOUND,
            appNotice.UPDATE_MAINBG_MODEL,
            appNotice.UPDATE_CARDBG_MODEL,
            appNotice.UPDATE_CARD_MODEL,
            appNotice.DAYILY_MATCH,
        ];
    },

    handleNotification(notification){
        var data = notification.getBody();
        console.log("handleNotification data : " , notification.getName());
        var view = this.viewComponent;
        var name = notification.getName();
        
        switch(name){
            case appNotice.CARD_CLICK:
                this.viewComponent.clickCard(data);
                break;
            case appNotice.CARD_MOVE_BEGIN:{
                this.viewComponent.startMoveCard(data);
            }break;
            case appNotice.CARD_MOVE_END:{
                this.viewComponent.endMoveCard(data);
            }break;  
            case appNotice.RESET_MATCH:{
                this.viewComponent.resetMatch(data);
            }break;
            case appNotice.SETTINT_LEFT_RIGHT:{
                this.viewComponent.settingLeftRight(data);
            }break;
            case appNotice.SETTINT_TIME_MODE:{
                this.viewComponent.settingTimeMode(data);
            }break;   
            case appNotice.SETTINT_THREED_CARD:{
                this.viewComponent.settingThreeCard(data);
            }break; 
            case appNotice.SETTINT_SOUND:{
                this.viewComponent.settintSound(data);
            }break;  
            case appNotice.UPDATE_MAINBG_MODEL:{
                this.viewComponent.updateMainBg(data);
            }break;
            case appNotice.UPDATE_CARDBG_MODEL:{
                this.viewComponent.updateCardBg(data);
            }break;
            case appNotice.UPDATE_CARD_MODEL:{
                this.viewComponent.updateCard(data);
            }break;
            case appNotice.DAYILY_MATCH:{
                this.viewComponent.dayilyMatch(data);
            }
        }
    },

    tipsEventBtnClicked(eventTouch){
        var data = {
            title:"",
            content:"此功能尚未开放",
            btnArr:[
                {name:"确定"},
            ]
        };

        this.facade.sendNotification(appNotice.SHOW_POP,{name:"AlertPopNode",initData:data});
    },

});
