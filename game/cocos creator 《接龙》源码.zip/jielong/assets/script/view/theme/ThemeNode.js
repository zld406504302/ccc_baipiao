var BaseCmpt = require("BaseCmpt")
var ThemeNodeMediator = require("ThemeNodeMediator")
var Localization = require("Localization");

cc.Class({
    extends: BaseCmpt,
    mediatorName: ThemeNodeMediator,
    properties: {

    },

    onLoad() {
        this._super();
        var closebtn = this.node.getChildByName("content").getChildByName("closebtn");
        closebtn.on('click', () => {
            this.hideNode("ThemeNode");
        }, this);

        this.node.getChildByName("bg").on('click', () => {
            this.hideNode("ThemeNode");
        }, this);

        this.index = 1;

        var content = this.node.getChildByName("content");

        content.getChildByName("title").getComponent("cc.Label").string = Localization["Theme"][window.language];

        this.ocardbtn = content.getChildByName("groupnode").getChildByName("ocardbtn");
        this.ocardbtn.getChildByName("New Label").getComponent("cc.Label").string = Localization["CardFace"][window.language];
        this.itembg1 = this.ocardbtn.getChildByName("itembg_1");
        this.ocardbtn.on('click', () => {
            this.selectGroupBtn(1);
        }, this);
        this.tcardbtn = content.getChildByName("groupnode").getChildByName("tcardbtn");
        this.tcardbtn.getChildByName("New Label").getComponent("cc.Label").string = Localization["Background"][window.language];
        this.itembg2 = this.tcardbtn.getChildByName("itembg_1");
        this.tcardbtn.on('click', () => {
            this.selectGroupBtn(2);
        }, this);
        this.wjsbtn = content.getChildByName("groupnode").getChildByName("wjsbtn");
        this.wjsbtn.getChildByName("New Label").getComponent("cc.Label").string = Localization["CardBack"][window.language];
        this.itembg3 = this.wjsbtn.getChildByName("itembg_1");
        this.wjsbtn.on('click', () => {
            this.selectGroupBtn(3);
        }, this);

        this.listview1 = content.getChildByName("listview1");
        this.listview2 = content.getChildByName("listview2");
        this.listview3 = content.getChildByName("listview3");
        this.listview1.active = true;
        this.listview2.active = false;
        this.listview3.active = false;

        this._listContent1 = content.getChildByName("listview1").getChildByName("view").getChildByName("content");

        this._listContent2 = content.getChildByName("listview2").getChildByName("view").getChildByName("content");
        this._viewitemTemp2 = this._listContent2.children[0];
        this._listContent2.removeChild(this._viewitemTemp2);

        this._listContent3 = content.getChildByName("listview3").getChildByName("view").getChildByName("content");
        this._viewitemTemp3 = this._listContent3.children[0];
        this._listContent3.removeChild(this._viewitemTemp3);

        this.initData();

        actionLib.backIn(this.node.getChildByName("content"));

        cc.director.on('ADD_IMAGE_BG', (data) => {
            console.log("ADD_IMAGE_BG:", data);
            var bgList = this.getGameBGList();
            if(bgList.indexOf(data) >= 0) {
                console.log("图片已存在");
                return;
            }
            bgList = [];
            bgList.push(data);
            cc.sys.localStorage.setItem("GAME_BG", JSON.stringify(bgList));
            this.initData();
            this.selectmainbgModel0(5);
            // cc.loader.load(data, function (err,txt) {
            //     // Use texture to create sprite frame
            //     console.log(err);
            //     console.log("加载图片完成， txt:", txt);
            // });
        });

        cc.director.on('ADD_IMAGE_CARD', (data) => {
            console.log("ADD_IMAGE_CARD:", data);
            var bgList = this.getGameCardList();
            if(bgList.indexOf(data) >= 0) {
                console.log("图片已存在");
                return;
            }
            bgList = [];
            bgList.push(data);
            cc.sys.localStorage.setItem("GAME_CARD", JSON.stringify(bgList));
            this.initData();
            this.selectcardbgModel0(6);
        });
    },

    getGameBGList: function () {
        var jsonStr = cc.sys.localStorage.getItem("GAME_BG") || "[]";
        var bgList = JSON.parse(jsonStr);
        return bgList;
    },

    getGameCardList: function () {
        var jsonStr = cc.sys.localStorage.getItem("GAME_CARD") || "[]";
        var bgList = JSON.parse(jsonStr);
        return bgList;
    },

    onDestroy: function () {
        cc.director.off('ADD_IMAGE_BG');
        cc.director.off('ADD_IMAGE_CARD');
    },

    getViewItem2: function (index) {
        if (this._listContent2.childrenCount > index) {
            return this._listContent2.children[index];
        }
        var node = cc.instantiate(this._viewitemTemp2);
        this._listContent2.addChild(node);
        return node;
    },

    getViewItem3: function (index) {
        if (this._listContent3.childrenCount > index) {
            return this._listContent3.children[index];
        }
        var node = cc.instantiate(this._viewitemTemp3);
        this._listContent3.addChild(node);
        return node;
    },

    initData: function () {
        this.cardIndex = cc.sys.localStorage.getItem("CardIndex") || 1;

        for (var i = 0; i < this._listContent1.children.length; ++i) {
            this._listContent1.children[i].getChildByName("gou").active = false;
            if (i == this.cardIndex - 1) {
                this._listContent1.children[i].getChildByName("gou").active = true;
            }
        }

        this.mainBgIndex = cc.sys.localStorage.getItem("MainBgIndex") || 1;
        for (var i = 0; i < 5; ++i) {
            var item = this.getViewItem2(i);
            item.getChildByName("gou").active = false;
            if (i != 0) {
                utils.restSpriteFrame(item, "texture/theme/bg" + i + ".png");
                if (i == this.mainBgIndex) {
                    item.getChildByName("gou").active = true;
                }
            }
            item.index = i;
        }

        var gameBgList = this.getGameBGList();
        for (var j = 0; j < gameBgList.length; j++) {
            const item = this.getViewItem2(j + 5);
            item.getChildByName("gou").active = false;
            item.index = j+5;
            cc.loader.load(gameBgList[j], function (err, tex) {
                item.getComponent(cc.Sprite).spriteFrame = new cc.SpriteFrame(tex);
                item.width = 162;
                item.height = 222;
                console.log("加载相册背景完成");
            });

            if (this.mainBgIndex == j + 5) {
                item.getChildByName("gou").active = true;
            }
        }

        this.cardBgIndex = cc.sys.localStorage.getItem("CardBgIndex") || 1;
        for (var i = 0; i < 6; ++i) {
            var item = this.getViewItem3(i);
            item.getChildByName("gou").active = false;
            if (i != 0) {
                utils.restSpriteFrame(item, "texture/theme/pb" + i + ".png");
                if (i == this.cardBgIndex) {
                    item.getChildByName("gou").active = true;
                }
            }
            item.index = i;
        }

        var gameCardList = this.getGameCardList();
        for (var j = 0; j < gameCardList.length; j++) {
            const item = this.getViewItem3(j + 6);
            item.getChildByName("gou").active = false;
            item.index = j+6;
            cc.loader.load(gameCardList[j], function (err, tex) {
                item.getComponent(cc.Sprite).spriteFrame = new cc.SpriteFrame(tex);
                item.width = 162;
                item.height = 222;
                console.log("加载相册背景完成");
            });

            if (this.mainBgIndex == j + 6) {
                item.getChildByName("gou").active = true;
            }
        }
    },

    selectGroupBtn: function (index) {
        if (this.index != index) {
            this.index = index;

            this.itembg1.active = false;
            this.itembg2.active = false;
            this.itembg3.active = false;
            this.listview1.active = false;
            this.listview2.active = false;
            this.listview3.active = false;

            if (index == 1) {
                this.itembg1.active = true;
                this.listview1.active = true;
            } else if (index == 2) {
                this.itembg2.active = true;
                this.listview2.active = true;
            } else if (index == 3) {
                this.itembg3.active = true;
                this.listview3.active = true;
            }
        }
    },

    selectmainbgModel: function (event) {
        var index = event.target.index;
        this.selectmainbgModel0(index);
    },

    selectmainbgModel0: function(index) {
        if (index == 0) {
            this.dispatchEvent("SELECT_MAINBG_MODEL", index);
            jsb.reflection.callStaticMethod('org/cocos2dx/javascript/GameAPI', 'choosePhoto', "(I)V", 2);
        } else if (index != this.mainBgIndex || index == 5) {
            this.mainBgIndex = index;
            cc.sys.localStorage.setItem("MainBgIndex", index);
            for (var i = 1; i < this._listContent2.children.length; ++i) {
                this._listContent2.children[i].getChildByName("gou").active = false;
                if (i == index) {
                    this._listContent2.children[i].getChildByName("gou").active = true;
                }
            }

            this.dispatchEvent("SELECT_MAINBG_MODEL", index);
        }

        console.log("selectbgModel index: ", index);
    },

    selectcardbgModel: function (event) {
        var index = event.target.index;
        this.selectcardbgModel0(index);
        
    },

    selectcardbgModel0: function(index) {
        if (index == 0) {
            this.dispatchEvent("SELECT_CARDBG_MODEL", index);
            jsb.reflection.callStaticMethod('org/cocos2dx/javascript/GameAPI', 'choosePhoto', "(I)V", 3);
        } else if (index != this.cardBgIndex || index == 6) {
            this.cardBgIndex = index;
            cc.sys.localStorage.setItem("CardBgIndex", index);
            for (var i = 1; i < this._listContent3.children.length; ++i) {
                this._listContent3.children[i].getChildByName("gou").active = false;
                if (i == index) {
                    this._listContent3.children[i].getChildByName("gou").active = true;
                }
            }

            this.dispatchEvent("SELECT_CARDBG_MODEL", index);
        }

        console.log("selectcardbgModel index: ", index);
    },

    selectcardModel: function (target, index) {
        if (index != this.cardIndex) {
            this.cardIndex = index;
            cc.sys.localStorage.setItem("CardIndex", index);
            this.dispatchEvent("SELECT_CARD_MODEL", index);
            for (var i = 0; i < this._listContent1.children.length; ++i) {
                this._listContent1.children[i].getChildByName("gou").active = false;
                if (i == index - 1) {
                    this._listContent1.children[i].getChildByName("gou").active = true;
                }
            }
        }
    },

    onDestroy: function () {
        this._super();
        actionLib.backOut(this.node.getChildByName("content"));
    }
});
