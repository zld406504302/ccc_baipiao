var BaseMediator = require("BaseMediator")
cc.Class({
    extends:BaseMediator,

    properties: {

    },


    didRegister(){
        this.bind("CLICK_CLOSE_BTN", (data)=>{
            this.facade.sendNotification(appNotice.HIDE_NODE,{name:"ThemeNode"});
        }, this);

        this.bind("SELECT_MAINBG_MODEL", (data)=>{
            if(data != 0){
                this.facade.sendNotification(appNotice.UPDATE_MAINBG_MODEL, data);
            }
        }, this);

        this.bind("SELECT_CARDBG_MODEL", (data)=>{
            if(data != 0){
                this.facade.sendNotification(appNotice.UPDATE_CARDBG_MODEL, data);
            }
        }, this);

        this.bind("SELECT_CARD_MODEL", (data)=>{
            if(data != 0){
                this.facade.sendNotification(appNotice.UPDATE_CARD_MODEL, data);
            }
        }, this);

        
    },

    listNotificationInterests(){
        return [
            
        ];
    },

    handleNotification(notification){
        var data = notification.getBody();
        var view = this.viewComponent;
        var name = notification.getName();
        console.log("handleNotification data : " + name + ":" + JSON.stringify(data));
        switch(name){
            
        }
    },

    loadLocalimg(uri)
    {
        var my = document.getElementById("divCreator");
        if(my===null)
        {
            my = document.createElement("div");   
            document.body.appendChild(my);   
            my.style.position="absolute";   
            my.id="divCreator";
            my.style.width=100;   
            my.style.height=100;   
            my.style.backgroundColor="#ffffcc";   
        }
        my.innerHTML = '<img id=imghead>';
        var img = document.getElementById('imghead');
        img.onload = function()
        {
            var n=0;
            var spriteFrame=spImg.getComponent('cc.Sprite').spriteFrame;
            var texture=spriteFrame.getTexture();
            texture.initWithElement(this);
            texture.handleLoadedTexture();
            cc.log("width="+this.width);
            cc.log("height="+this.height);
            n++;
        }
        img.src = uri;
        my.style.display='none';
        my.style.visibility = "hidden";
    },

    tmpSelectFile(evt) {
        //console.log("image selected...");
        var file = evt.target.files[0];
        var type = file.type;
        if (!type) {
            type = mime[file.name.match(/\.([^\.]+)$/i)[1]];
        }
        var url = myCreateObjectURL(file);
        loadLocalimg(url);
        
    },

    myCreateObjectURL(blob){
        if(window.URL !== undefined)
            return window['URL']['createObjectURL'](blob);
        else
            return window['webkitURL']['createObjectURL'](blob);
    },

});
