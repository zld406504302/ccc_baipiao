var BaseMediator = require("BaseMediator")
cc.Class({
    extends:BaseMediator,

    properties: {

    },


    didRegister(){
        this.bind("CLICK_CLOSE_BTN", (data)=>{
            this.facade.sendNotification(appNotice.HIDE_NODE,{name:"ResultNode"});
        }, this);

        this.bind("NEW_GAME_BTN", (data)=>{
            this.facade.sendNotification(appNotice.SHOW_NODE, {name:"HandsNode", initData:1});
        }, this);
    },

    listNotificationInterests(){
        return [
            
        ];
    },

    initData(data){
        this.viewComponent.initData(data);
    },

    handleNotification(notification){
        var data = notification.getBody();
        var view = this.viewComponent;
        var name = notification.getName();
        console.log("handleNotification data : " + name + ":" + JSON.stringify(data));
        switch(name){
            
        }
    },

});
