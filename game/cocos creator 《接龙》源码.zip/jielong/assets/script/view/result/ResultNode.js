var BaseCmpt = require("BaseCmpt")
var ResultNodeMediator =require("ResultNodeMediator")
var Localization = require("Localization");

cc.Class({
    extends: BaseCmpt,
    mediatorName:ResultNodeMediator,
    properties: {

    },

    onLoad () {
        this._super();

        var closebtn = this.node.getChildByName("content").getChildByName("closebtn");
        closebtn.on('click', ()=>{
            this.hideNode("ResultNode");
            // this.dispatchEvent("CLICK_CLOSE_BTN");
        }, this);
        
        // this.node.getChildByName("bg").on('click', ()=>{
        //     this.hideNode("ResultNode");
        // }, this);

        var content = this.node.getChildByName("content");
        content.getChildByName("title").getComponent("cc.Label").string = Localization["Win"][window.language];

        this.contentlayout = content.getChildByName("contentlayout");
        for(var i = 0; i < this.contentlayout.children.length; ++i){
            var nameLabel = this.contentlayout.children[i].getChildByName("name").getComponent("cc.Label");
            if(i == 0){
                nameLabel.string = Localization["Time"][window.language];
            }else if(i == 1){
                nameLabel.string = Localization["Moves"][window.language];
            }else if(i == 2){
                nameLabel.string = Localization["Score"][window.language];
            }
        }

        var newgamebtn = content.getChildByName("newgamebtn"); 
        newgamebtn.getChildByName("New Label").string = Localization["NewGame"][window.language];
        newgamebtn.on('click', ()=>{
            this.dispatchEvent("NEW_GAME_BTN");
            this.hideNode("ResultNode");
        }, this);

        actionLib.backIn(this.node.getChildByName("content"));
    },

    initData:function(data){
        for(var i = 0; i < this.contentlayout.children.length; ++i){
            var numLabel = this.contentlayout.children[i].getChildByName("num").getComponent("cc.Label");
            if(i == 0){
                numLabel.string = data.time || 0;
            }else if(i == 1){
                numLabel.string = data.moveStep || 0;
            }else if(i == 2){
                numLabel.string = data.score || 0;
            }
        }
    },

    onDestroy:function(){
        this._super();
        actionLib.backOut(this.node.getChildByName("content"));
    }
});