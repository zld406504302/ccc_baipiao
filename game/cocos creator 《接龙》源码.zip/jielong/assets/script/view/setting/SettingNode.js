var BaseCmpt = require("BaseCmpt")
var SettingNodeMediator =require("SettingNodeMediator")
var setting_config = require("setting_config")
var Localization = require("Localization");

cc.Class({
    extends: BaseCmpt,
    mediatorName:SettingNodeMediator,
    properties: {

    },

    onLoad () {
        this._super();
        var closebtn = this.node.getChildByName("content").getChildByName("closebtn");
        closebtn.on('click', ()=>{
            this.hideNode("SettingNode");
        }, this);

        this.node.getChildByName("bg").on('click', ()=>{
            this.hideNode("SettingNode");
        }, this);

        var content = this.node.getChildByName("content");
        this._listContent = content.getChildByName("listview").getChildByName("view").getChildByName("content");
        this._viewitemTemp = this._listContent.children[0];
        this._listContent.removeChild(this._viewitemTemp);

        content.getChildByName("title").getComponent("cc.Label").string = Localization["Set"][window.language];


        var wanfabtn = content.getChildByName("wanfabtn");
        wanfabtn.getChildByName("New Label").getComponent("cc.Label").string = Localization["HowToPlay"][window.language];
        wanfabtn.on('click', ()=>{
            this.dispatchEvent("CLICK_WANFA_BTN");
        }, this);

        var exitbtn = content.getChildByName("exitbtn");
        exitbtn.getChildByName("New Label").getComponent("cc.Label").string = Localization["Btn_quitgame"][window.language];
        exitbtn.on('click', ()=>{
            this.dispatchEvent("CLICK_EXIT_BTN");
        }, this);

        var tjinfobtn = content.getChildByName("tjinfobtn");
        tjinfobtn.getChildByName("New Label").getComponent("cc.Label").string = Localization["Stats"][window.language];
        tjinfobtn.on('click', ()=>{
            this.dispatchEvent("CLICK_TJINFO_BTN");
        }, this);

        var themebtn = content.getChildByName("themebtn");
        themebtn.getChildByName("New Label").getComponent("cc.Label").string = Localization["Theme"][window.language];
        themebtn.on('click', ()=>{
            this.dispatchEvent("CLICK_THEME_BTN");
        }, this);

        var version = content.getChildByName("version");
        version.getComponent("cc.Label").string = "v2.0" + window.sysLanguage;

        this._nodeList = [];

        this.initData();

        actionLib.backIn(this.node.getChildByName("content"));
    },

    initData:function(){
        for(var i = 0; i < setting_config.length; ++i){
            var node = this.getViewItem(i);
            this._nodeList.push(node);
            var cfgData = setting_config[i];
            node.index = i;
            node.getChildByName("name").getComponent("cc.Label").string = Localization[cfgData.name][window.language];
            if(cfgData.type == 1){
                node.getChildByName("switchbtn").active = true;
                node.getChildByName("shortcutbtn").active = false;

                if(!cc.sys.localStorage.getItem(cfgData.key) || cc.sys.localStorage.getItem(cfgData.key) == 0){
                    node.getChildByName("switchbtn").getChildByName("switch_open").active = false;
                    node.getChildByName("switchbtn").getChildByName("switch_close").active = true;
                }else if(cc.sys.localStorage.getItem(cfgData.key) == 1){
                    node.getChildByName("switchbtn").getChildByName("switch_open").active = true;
                    node.getChildByName("switchbtn").getChildByName("switch_close").active = false;
                }
            }else if(cfgData.type == 2){
                node.getChildByName("switchbtn").active = false;
                node.getChildByName("shortcutbtn").active = true;
            }
        }
    },


    shrinkContent:function(num){
        while(this._listContent.childrenCount > num){
            var lastOne = this._listContent.children[this._listContent.childrenCount -1];
            this._listContent.removeChild(lastOne,true);
        }
    },

    getViewItem:function(index){
        if(this._listContent.childrenCount > index){
            return this._listContent.children[index];
        }
        var node = cc.instantiate(this._viewitemTemp);
        this._listContent.addChild(node);
        return node;
    },

    onSwitchBtn:function(event){
        var index = event.target.parent.index;
        if(this._nodeList[index]){
            if(this._nodeList[index].getChildByName("switchbtn").getChildByName("switch_close").active == true){
                this._nodeList[index].getChildByName("switchbtn").getChildByName("switch_close").active = false;
                this._nodeList[index].getChildByName("switchbtn").getChildByName("switch_open").active = true;

                cc.sys.localStorage.setItem(setting_config[index].key, 1);

                this.dispatchEvent("setting_update", {index:index, isOpen:1});
            }else{
                this._nodeList[index].getChildByName("switchbtn").getChildByName("switch_close").active = true;
                this._nodeList[index].getChildByName("switchbtn").getChildByName("switch_open").active = false;

                cc.sys.localStorage.setItem(setting_config[index].key, 0);

                this.dispatchEvent("setting_update", {index:index, isOpen:0});
            }
        }
    },

    onShortCutBtn:function(event){
        var index = event.target.parent.index;
        if(setting_config[index].name == "Privacy"){
            this.dispatchEvent("PRIVACY_CLICK");
        }else if(setting_config[index].name == "UI_more"){

        }
        
        // if(cc.sys.isBrowser){
        //     window.location.href = "https://www.block669.com/Privacy_Solitaire.html";
        // }else{
        //     cc.sys.openURL('https://www.block669.com/Privacy_Solitaire.html');
        // }
    },

    onDestroy:function(){
        this._super();
        actionLib.backOut(this.node.getChildByName("content"));
    }
});
