var BaseMediator = require("BaseMediator")
cc.Class({
    extends:BaseMediator,

    properties: {

    },

    didRegister(){
        this.bind("CLICK_CLOSE_BTN", (data)=>{
            this.facade.sendNotification(appNotice.HIDE_NODE,{name:"SettingNode"});
        }, this);

        this.bind("CLICK_WANFA_BTN", (data)=>{
            this.facade.sendNotification(appNotice.SHOW_NODE,{name:"HelpNode"});
        }, this);
        this.bind("CLICK_EXIT_BTN", (data)=>{
            if (cc.sys.isNative){
                cc.game.end();
            }else{
                window.history.back();              
            }
        }, this);
        this.bind("CLICK_TJINFO_BTN", (data)=>{
            this.facade.sendNotification(appNotice.SHOW_NODE,{name:"AddUpNode"});
        }, this);
        this.bind("CLICK_THEME_BTN", (data)=>{
            this.facade.sendNotification(appNotice.SHOW_NODE,{name:"ThemeNode"});
        }, this);

        this.bind("setting_update", (data)=>{
            if(data.index == 0){
                this.facade.sendNotification(appNotice.SETTINT_SOUND, data.isOpen);
            }else if(data.index == 1){
                this.facade.sendNotification(appNotice.SETTINT_THREED_CARD, data.isOpen);
            }else if(data.index == 2){
                this.facade.sendNotification(appNotice.SETTINT_LEFT_RIGHT, data.isOpen);
            }else if(data.index == 3){
                this.facade.sendNotification(appNotice.SETTINT_TIME_MODE, data.isOpen);
            }else if(data.index == 4){
                this.facade.sendNotification(appNotice.SETTINT_PUSH_TAG, data.isOpen);
            }else if(data.index == 5){
                this.facade.sendNotification(appNotice.SETTINT_AUTO_TIPS, data.isOpen);
            }else if(data.index == 7){
                this.facade.sendNotification(appNotice.SETTINT_JUMP_WIN, data.isOpen);
            }
        }, this);

        this.bind("PRIVACY_CLICK", (data)=>{
            this.facade.sendNotification(appNotice.SHOW_NODE,{name:"PrivacyNode"});
        }, this);
        
    },

    listNotificationInterests(){
        return [
            
        ];
    },

    handleNotification(notification){
        var data = notification.getBody();
        var view = this.viewComponent;
        var name = notification.getName();
        console.log("handleNotification data : " + name + ":" + JSON.stringify(data));
        switch(name){
            
        }
    },

});
