


//设置字符串的反转
String.prototype.reverse=function(){
  var str='';
  for(var index=this.length-1;index>=0;index--){
    str+=this[index];
  }
  return str;
}

//数组洗牌打乱
Array.prototype.shuffle = function() {
    var input = this;

    for (var i = input.length-1; i >=0; i--) {

        var randomIndex = Math.floor(Math.random()*(i+1));
        var itemAtIndex = input[randomIndex];

        input[randomIndex] = input[i];
        input[i] = itemAtIndex;
    }
    return input;
}

window.utils = {
    /**
     * 截取字符串（含中文）
    */
    subString:function(str,len){
        var strlen = 0;
        var s = "";
        for(var i = 0;i < str.length;i++){
            if(str.charCodeAt(i) > 128){
                strlen += 2;
            }else{
                strlen++;
            }
            s += str.charAt(i);
            if(strlen >= len){
                return s + "...";
            }
        }
        return str;
    },
    /**
     * 调试的时候用
     * 输出调用栈
     */
    stackTrace:function() {
        let _err = new Error();
        let stack = _err.stack;
        console.warn(stack);
    },

    //时间格式化 分:秒
    GetDateTime:function(time) {
        var m_string = "";
        var m ;

        var s_string = "";
        var s;
        //时
        if(time > 3600){
           return "60:00";
        }
        
        //分
        var left = time;
        m = Math.floor(left / 60);
        if(m < 10){
            m_string = "0" + m;
        }
        else {
            m_string = "" + m;
        }
        //秒
        s = left - 60 * m;
        if(s < 10){
            s_string = "0" + s;
        }
        else {
            s_string = "" + s;
        }

        return m_string + ":" + s_string;
    },

    //数字转化（万）
    numbertostring:function(num){
        if(num >= 100000){
            var ww = Math.floor(num / 10000);
            var qw = Math.floor((num % 10000) / 1000);
            var bw = Math.floor((num % 1000) / 100);
            var sw = Math.floor((num % 100) / 10);
            var gw = (num % 10);
            var str = "";
            if(bw == 0){
                if(qw == 0){
                    return ww + "万";
                }else{
                    return ww + "." + qw + "万";
                }
            }
            str = ww + "." + qw + bw;
            str = str.substring(0, 4) + "万";
            return str;
        }else if(num > 1000){
            var str = num.toString();
            str = str.substring(0, str.length - 3) + "," + str.substring(str.length - 3, 3);
            return str;
        }
        return num;
    },

     /**
     * 使用网络或resources中的资源重置图片文理
     * @param imageNode
     * @param url
     */
    restSpriteFrame(imageNode,url,cb){
        if(!(imageNode instanceof cc.Node)) return;
        if(typeof url != "string" ) return;
        let sp = imageNode.getComponent(cc.Sprite);
        if(!sp) return;

        let loadName = "loadRes";
        let p = url;
        if(url.indexOf("http") >= 0){
            loadName =  "load";
            let type = cc.path.extname(url).substr(1,3);
            p = {url: url, type: type != "jpg" ? "png" : "jpg"}
        }

        cc.loader[loadName](p,(err,tex)=>{
            if(err || !cc.isValid(sp)) return;
            sp.spriteFrame = new cc.SpriteFrame(tex);
            cb&&cb();
        })
    },

};