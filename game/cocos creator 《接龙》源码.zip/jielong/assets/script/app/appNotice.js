window.appNotice = {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//UI事件
    PRELOAD_COMPLETE:"PRELOAD_COMPLETE",                //{loadType:PreloadType.Node,name:""}
    PRELOAD_SHOW:"PRELOAD_SHOW",
    PRELOAD_PROGRESS:"PRELOAD_PROGRESS",                //{p:1,t:2}
    CHANGE_LAYER:"CHANGE_LAYER",                        //{name:"",loading:false}
    SHOW_NODE:"SHOW_NODE",                              //{name:"",loading:false}
    HIDE_NODE:"HIDE_NODE",                              //{name:""}
    DESTROY_NODE:"DESTROY_NODE",                        //{name:""}
    SHOW_POP:"SHOW_POP",                                //{name:"",,loading:false}
    HIDE_POP:"HIDE_POP",                                //{name:""}
    DESTROY_POP:"DESTROY_POP",                          //{name:""}
   
    SOCKET_NOTICE:"SOCKET_NOTICE",
    TOAST_SHOW:"TOAST_SHOW",


    LOADING_LOGO_SHOW:"LOADING_LOGO_SHOW",
    LOADING_LOGO_HIDE:"LOADING_LOGO_HIDE",

    //游戏切换前后台
    GAME_EVENT_SHOW:"GAME_EVENT_SHOW",
    GAME_EVENT_HIDE:"GAME_EVENT_HIDE",


    SHARE_WX:"SHARE_WX",                                //微信分享

    CARD_MOVE_BEGIN:"CARD_MOVE_BEGIN",
    CARD_MOVE_END:"CARD_MOVE_END",
    CARD_CLICK:"CARD_CLICK",
    GAME_BEGIN_RANDOM:"GAME_BEGIN_RANDOM",

    RESET_MATCH:"RESET_MATCH",   //重置牌局
    DAYILY_MATCH:"DAYILY_MATCH", //每日牌局

    SETTINT_SOUND:"SETTINT_SOUND",  //声音
    SETTINT_THREED_CARD:"SETTINT_THREED_CARD", //设置三张牌
    SETTINT_LEFT_RIGHT:"SETTINT_LEFT_RIGHT", //设置左右模式
    SETTINT_TIME_MODE:"SETTINT_TIME_MODE",  //设置时间模式
    SETTINT_PUSH_TAG:"SETTINT_PUSH_TAG",  //推送模式
    SETTINT_AUTO_TIPS:"SETTINT_AUTO_TIPS", //自动提示
    SETTINT_JUMP_WIN:"SETTINT_JUMP_WIN", //跳过赢的动画

    UPDATE_MAINBG_MODEL:"UPDATE_MAINBG_MODEL",
    UPDATE_CARDBG_MODEL:"UPDATE_CARDBG_MODEL",
    UPDATE_CARD_MODEL:"UPDATE_CARD_MODEL",

};

