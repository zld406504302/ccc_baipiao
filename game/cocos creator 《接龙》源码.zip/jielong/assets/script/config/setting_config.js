module.exports=[
	{"name":"Sound", "key":"soundTag", "type":1},
	{"name":"Draw3Cards", "key":"is3Card", "type":1},
	{"name":"LeftHand", "key":"leftRightMode", "type":1},
	{"name":"TimerMode", "key":"timeMode", "type":1},
	{"name":"NotificationKey", "key":"pushTag", "type":1},
	{"name":"AutoHint", "key":"autoTips", "type":1},
	{"name":"UI_more", "type":2},
	{"name":"Setting_SkipCelebrate", "key":"jumpWin", "type":1},
	{"name":"Privacy", "type":2}
]