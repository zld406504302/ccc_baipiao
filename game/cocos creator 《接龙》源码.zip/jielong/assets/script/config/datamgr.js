
window.datamgr = {
	subString:function(str,len){
		
}
window.addupdata_yzp = cc.sys.localStorage.getItem("addupdata_yzp");

set_addupdata_yzp(data, index){
	//牌局总数 成功牌局 最高分 最少成功移动 最短成功移动

}