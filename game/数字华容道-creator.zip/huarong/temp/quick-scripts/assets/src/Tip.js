(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/src/Tip.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '38413wl95FFmKnbWMpDbMVC', 'Tip', __filename);
// src/Tip.js

"use strict";

var i = require("GameDataManagerJS");
cc.Class({
    extends: cc.Component,
    properties: {
        bt_return: cc.Node,
        bt_resume: cc.Node,
        bt_start: cc.Node,
        targetPattern: cc.Node,
        numPrefab: cc.Prefab,
        puzzleLayer: cc.Node,
        buttonLayer: cc.Node
    },
    onEnable: function onEnable() {
        this.hide(), this.setPattern(), this.bt_return.on("touchstart", this.onReturn, this), this.node.parent.getComponent("Puzzle").game ? (this.bt_resume.active = !0, this.bt_resume.on("touchstart", this.onResume, this)) : (this.bt_start.active = !0, this.bt_start.on("touchstart", this.onPlay, this));
    },
    hide: function hide() {
        this.puzzleLayer.active = !1, this.buttonLayer.active = !1;
    },
    show: function show() {
        this.puzzleLayer.active = !0, this.buttonLayer.active = !0, this.node.active = !1, this.bt_resume.active = !1, this.bt_start.active = !1;
    },
    onReturn: function onReturn() {
        this.show(), this.node.parent.getComponent("Puzzle").game ? this.node.parent.getComponent("Puzzle").restart() : cc.director.loadScene("SelectLevel");
    },
    onPlay: function onPlay() {
        this.show(), this.node.parent.getComponent("Puzzle").gameStart();
    },
    onResume: function onResume() {
        this.show(), this.node.parent.getComponent("Puzzle").restart();
    },
    setPattern: function setPattern() {
        this.level = i.getInstance().getLevelNum(), this.length = this.level * this.level, this.setPuzzArray(), this.setPrefabs();
    },
    setPuzzArray: function setPuzzArray() {
        this.puzzleArray = [];
        for (var e = 1; e <= this.length; e++) {
            this.puzzleArray.push(e);
        }
    },
    setPrefabs: function setPrefabs() {
        this.cell = this.targetPattern.width / this.level;
        for (var e = 0; e < this.length; e++) {
            var t = cc.instantiate(this.numPrefab);
            t.width = this.cell, t.height = this.cell, this.puzzleArray[e] == this.length ? (t.getChildByName("Label").getComponent(cc.Label).string = "", t.getComponent(cc.Sprite).spriteFrame = null) : t.getChildByName("Label").getComponent(cc.Label).string = this.puzzleArray[e], t.getChildByName("Label").getComponent(cc.Label).fontSize = t.height / 2, this.targetPattern.addChild(t), t.x = e % this.level * this.cell + .5 * this.cell, t.y = -Math.floor(e / this.level) * this.cell - .5 * this.cell;
        }
    }
});

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=Tip.js.map
        