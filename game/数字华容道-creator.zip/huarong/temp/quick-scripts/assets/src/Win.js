(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/src/Win.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '2588cCV3eFPJJBDrmFXu1MZ', 'Win', __filename);
// src/Win.js

"use strict";

var o = require("GameDataManagerJS");
cc.Class({
    extends: cc.Component,
    properties: {
        blank: cc.Node,
        bt_home: cc.Node,
        score: cc.Label,
        bestLayer: cc.Node
    },
    onEnable: function onEnable() {
        this.game = this.node.parent.getComponent("Puzzle"), this.blank.on("touchstart", this.onBlank, this), this.setScore(), 7 == this.game.level && (this.node.getChildByName("bt_next").active = !1), this.scheduleOnce(this.setBestScore, 1.5);
    },
    setScore: function setScore() {
        var e = this.game.time.toString();
        e = e.substring(0, e.indexOf(".") + 2) + " s", this.score.string = e;
    },
    setBestScore: function setBestScore() {},
    onBlank: function onBlank() {},
    home: function home() {
        cc.director.loadScene("Start");
    },
    again: function again() {
        this.node.active = !1, this.game.gameStart();
    },
    flaunt: function flaunt() {},
    nextLevel: function nextLevel() {
        o.getInstance().setLevelNum(this.game.level + 1), cc.director.loadScene("Puzzle");
    },
    onDisable: function onDisable() {
        this.bestLayer.removeAllChildren();
    }
});

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=Win.js.map
        