(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/src/GameDataManagerJS.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '4ff1b8Jl0dC/qP9HWlft07b', 'GameDataManagerJS', __filename);
// src/GameDataManagerJS.js

"use strict";

var i = cc.Class({
    extends: cc.Component,
    properties: {
        m_curLevelNum: 0,
        playsound: !0
    },
    ctor: function ctor() {},
    statics: {
        _instance: null,
        getInstance: function getInstance() {
            return null === i._instance && (this._instance = new i()), i._instance;
        }
    },
    getLevelNum: function getLevelNum() {
        return this.m_curLevelNum;
    },
    setLevelNum: function setLevelNum(e) {
        this.m_curLevelNum = e;
    },
    changeStatus: function changeStatus() {
        this.playsound = !this.playsound;
    },
    getStatus: function getStatus() {
        return this.playsound;
    }
});
module.exports = i;

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=GameDataManagerJS.js.map
        