(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/src/Pause.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, 'c1b90TStYBIha+O13NLTPOQ', 'Pause', __filename);
// src/Pause.js

"use strict";

cc.Class({
    extends: cc.Component,
    properties: {
        blank: cc.Node,
        bt_restart: cc.Node
    },
    onEnable: function onEnable() {
        this.blank.on("touchstart", this.onBlank, this), this.bt_restart.on("touchstart", this.onRestart, this);
    },
    onBlank: function onBlank() {},
    onRestart: function onRestart() {
        this.node.active = !1, this.node.parent.getComponent("Puzzle").gameStart();
    }
});

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=Pause.js.map
        