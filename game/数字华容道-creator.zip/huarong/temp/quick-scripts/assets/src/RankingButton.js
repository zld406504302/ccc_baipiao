(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/src/RankingButton.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '70a7bcOJWRL7oj4Zl1OBlwJ', 'RankingButton', __filename);
// src/RankingButton.js

"use strict";

cc.Class({
    extends: cc.Component,
    properties: {
        activeFrame: {
            type: cc.SpriteFrame,
            default: []
        },
        negativeFrame: {
            type: cc.SpriteFrame,
            default: []
        },
        buttonArray: {
            type: cc.Node,
            default: []
        }
    },
    onLoad: function onLoad() {
        this.functionArray = [this.getRankData_3, this.getRankData_4, this.getRankData_5, this.getRankData_6, this.getRankData_7], this.timer = 0;
    },
    start: function start() {
        for (var e = 1; e < this.buttonArray.length; e++) {
            this.buttonArray[e].on("touchstart", this.functionArray[e], this);
        }this.cur_index = 0, this.last_index = 0;
    },
    getRankData_3: function getRankData_3() {
        this.timer < 30 || this.changeFrame(0);
    },
    getRankData_4: function getRankData_4() {
        this.timer < 30 || this.changeFrame(1);
    },
    getRankData_5: function getRankData_5() {
        this.timer < 30 || this.changeFrame(2);
    },
    getRankData_6: function getRankData_6() {
        this.timer < 30 || this.changeFrame(3);
    },
    getRankData_7: function getRankData_7() {
        this.timer < 30 || this.changeFrame(4);
    },
    changeFrame: function changeFrame(e) {
        this.last_index = this.cur_index, this.cur_index = e, this.buttonArray[this.last_index].getComponent(cc.Sprite).spriteFrame = this.activeFrame[this.last_index], this.buttonArray[this.last_index].on("touchstart", this.functionArray[this.last_index], this), this.buttonArray[this.cur_index].getComponent(cc.Sprite).spriteFrame = this.negativeFrame[this.cur_index], this.buttonArray[this.cur_index].off("touchstart", this.functionArray[this.cur_index], this), this.timer = 0;
    },
    onReturn: function onReturn() {
        this.node.active = !1;
    },
    update: function update(e) {
        this.timer++;
    }
});

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=RankingButton.js.map
        