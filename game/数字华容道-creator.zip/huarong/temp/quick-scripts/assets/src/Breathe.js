(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/src/Breathe.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '40592G+pL5KnIHcrdzajBr5', 'Breathe', __filename);
// src/Breathe.js

"use strict";

cc.Class({
    extends: cc.Component,
    properties: {
        magnify: 1,
        shrink: 1
    },
    start: function start() {
        var e = cc.scaleTo(1, this.magnify),
            t = cc.scaleTo(1, this.shrink),
            n = cc.repeatForever(cc.sequence(e, t));
        this.node.runAction(n);
    }
});

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=Breathe.js.map
        