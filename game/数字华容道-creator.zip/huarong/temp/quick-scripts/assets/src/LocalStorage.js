(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/src/LocalStorage.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '4f003VtB8hP/otirzJHXOIn', 'LocalStorage', __filename);
// src/LocalStorage.js

"use strict";

module.exports = {
    initItem: function initItem(e) {
        var t = cc.sys.localStorage.getItem(e.str);
        null != t && 0 != t.length || cc.sys.localStorage.setItem(e.str, e.number);
    },
    init: function init() {
        console.log("初始化本地数据"), this.initItem({
            str: "sound",
            number: 1
        }), this.initItem({
            str: "music",
            number: 1
        }), this.initItem({
            str: "score",
            number: 0
        });
    },
    get: function get(e) {
        return parseInt(cc.sys.localStorage.getItem(e));
    },
    set: function set(e, t) {
        cc.sys.localStorage.setItem(e, t);
    }
};

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=LocalStorage.js.map
        