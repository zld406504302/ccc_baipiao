(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/src/Adjust.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, 'b807bjdQ6lLQrN/GDWloADl', 'Adjust', __filename);
// src/Adjust.js

"use strict";

cc.Class({
    extends: cc.Component,
    properties: {},
    onLoad: function onLoad() {},
    start: function start() {},
    getNumber: function getNumber() {
        var e = cc.winSize,
            t = cc.view.getDesignResolutionSize();
        return e.height / e.width > t.height / t.width ? e.height / t.height : e.width / t.width;
    },
    single_getNumber: function single_getNumber() {
        var e = cc.winSize,
            t = cc.view.getDesignResolutionSize();
        return e.height / e.width > t.height / t.width ? e.width / t.width : 1;
    }
});

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=Adjust.js.map
        