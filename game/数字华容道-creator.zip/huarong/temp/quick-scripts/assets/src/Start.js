(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/src/Start.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, 'd0df4nrwytDA7skaOe2R8TD', 'Start', __filename);
// src/Start.js

"use strict";

var o = require("GameDataManagerJS");
cc.Class({
    extends: cc.Component,
    properties: {
        rankLayer: cc.Node,
        blank: cc.Node,
        shareTitleArray: {
            default: [],
            type: cc.String
        },
        shareImageArray: {
            default: [],
            type: cc.SpriteFrame
        },
        soundFrame: cc.SpriteFrame,
        silenceFrame: cc.SpriteFrame,
        bt_soundFrame: cc.Sprite
    },
    onLoad: function onLoad() {
        this.setSoundFrame();
    },
    onPlay: function onPlay() {
        cc.director.loadScene("SelectLevel");
    },
    onRank: function onRank() {},
    getRankData_3: function getRankData_3() {},
    onBlank: function onBlank() {},
    onShare: function onShare() {},
    onSound: function onSound() {
        o.getInstance().changeStatus();
        this.setSoundFrame();
    },
    setSoundFrame: function setSoundFrame() {
        o.getInstance().getStatus() ? this.bt_soundFrame.spriteFrame = this.soundFrame : this.bt_soundFrame.spriteFrame = this.silenceFrame;
    },

    start: function start() {},
    onDestroy: function onDestroy() {}
});

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=Start.js.map
        