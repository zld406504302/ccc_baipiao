(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/src/FitWidth.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '57eeehNw/BBA7UWX08ZJMF5', 'FitWidth', __filename);
// src/FitWidth.js

"use strict";

cc.Class({
    extends: cc.Component,
    properties: {},
    start: function start() {
        this.node.setScale(this.getNumber());
    },
    getNumber: function getNumber() {
        var e = cc.winSize,
            t = cc.view.getDesignResolutionSize();
        return e.height / e.width > t.height / t.width ? e.width / t.width : 1;
    }
});

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=FitWidth.js.map
        