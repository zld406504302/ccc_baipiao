cc.Class({
    extends: cc.Component,
    properties: {
        blank: cc.Node,
        bt_restart: cc.Node
    },
    onEnable: function () {
        this.blank.on("touchstart", this.onBlank, this), this.bt_restart.on("touchstart", this.onRestart, this);
    },
    onBlank: function () {},
    onRestart: function () {
        this.node.active = !1, this.node.parent.getComponent("Puzzle").gameStart();
    }
})