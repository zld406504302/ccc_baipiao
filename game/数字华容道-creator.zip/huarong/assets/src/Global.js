module.exports = {
    LocalStorage: require("LocalStorage"),
}