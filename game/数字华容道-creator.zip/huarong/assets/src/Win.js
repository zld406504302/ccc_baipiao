
var o = require("GameDataManagerJS");
cc.Class({
    extends: cc.Component,
    properties: {
        blank: cc.Node,
        bt_home: cc.Node,
        score: cc.Label,
        bestLayer: cc.Node
    },
    onEnable: function () {
        this.game = this.node.parent.getComponent("Puzzle"), this.blank.on("touchstart", this.onBlank, this),
            this.setScore(), 7 == this.game.level && (this.node.getChildByName("bt_next").active = !1),
            this.scheduleOnce(this.setBestScore, 1.5);
    },
    setScore: function () {
        var e = this.game.time.toString();
        e = e.substring(0, e.indexOf(".") + 2) + " s", this.score.string = e;
    },
    setBestScore: function () {
        
    },
    onBlank: function () {},
    home: function () {
        cc.director.loadScene("Start");
    },
    again: function () {
        this.node.active = !1, this.game.gameStart();
    },
    flaunt: function () {
        
    },
    nextLevel: function () {
        o.getInstance().setLevelNum(this.game.level + 1), cc.director.loadScene("Puzzle");
    },
    onDisable: function () {
        this.bestLayer.removeAllChildren();
    }
})