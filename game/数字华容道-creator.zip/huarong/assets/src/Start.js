var o = require("GameDataManagerJS");
cc.Class({
    extends: cc.Component,
    properties: {
        rankLayer: cc.Node,
        blank: cc.Node,
        shareTitleArray: {
            default: [],
            type: cc.String
        },
        shareImageArray: {
            default: [],
            type: cc.SpriteFrame
        },
        soundFrame: cc.SpriteFrame,
        silenceFrame: cc.SpriteFrame,
        bt_soundFrame: cc.Sprite,
    },
    onLoad: function () {
        this.setSoundFrame()
    },
    onPlay: function () {
        cc.director.loadScene("SelectLevel");
    },
    onRank: function () {

    },
    getRankData_3: function () {
    },
    onBlank: function () {},
    onShare: function () {},
    onSound: function () {
        o.getInstance().changeStatus();
        this.setSoundFrame();
    },
    setSoundFrame: function () {
        o.getInstance().getStatus() ? this.bt_soundFrame.spriteFrame = this.soundFrame : this.bt_soundFrame.spriteFrame = this.silenceFrame;
    },

    start: function () {
    },
    onDestroy: function () {
    }
})