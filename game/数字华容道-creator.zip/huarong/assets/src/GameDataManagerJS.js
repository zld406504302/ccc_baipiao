var i = cc.Class({
    extends: cc.Component,
    properties: {
        m_curLevelNum: 0,
        playsound: !0
    },
    ctor: function () {},
    statics: {
        _instance: null,
        getInstance: function () {
            return null === i._instance && (this._instance = new i()), i._instance;
        }
    },
    getLevelNum: function () {
        return this.m_curLevelNum;
    },
    setLevelNum: function (e) {
        this.m_curLevelNum = e;
    },
    changeStatus: function () {
        this.playsound = !this.playsound;
    },
    getStatus: function () {
        return this.playsound;
    }
});
module.exports = i