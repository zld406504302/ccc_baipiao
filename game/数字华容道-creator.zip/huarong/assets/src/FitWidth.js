cc.Class({
    extends: cc.Component,
    properties: {},
    start: function () {
        this.node.setScale(this.getNumber());
    },
    getNumber: function () {
        var e = cc.winSize,
            t = cc.view.getDesignResolutionSize();
        return e.height / e.width > t.height / t.width ? e.width / t.width : 1;
    }
})