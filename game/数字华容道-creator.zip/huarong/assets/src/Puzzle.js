var i = require("GameDataManagerJS")
cc.Class({
    extends: cc.Component,
    properties: {
        level_label: cc.Label,
        numPrefab: cc.Prefab,
        puzzleLayer: cc.Node,
        bt_refresh: cc.Node,
        bt_tip: cc.Node,
        bt_return: cc.Node,
        bt_sound: cc.Node,
        clock: cc.Label,
        step: cc.Label,
        overTimeLayer: cc.Node,
        winLayer: cc.Node,
        tipLayer: cc.Node,
        sound_click: {
            type: cc.AudioClip,
            default: null
        },
        sound_move: {
            type: cc.AudioClip,
            default: null
        },
        sound_win: {
            type: cc.AudioClip,
            default: null
        },
        soundFrame: cc.SpriteFrame,
        silenceFrame: cc.SpriteFrame,
        bt_soundFrame: cc.Sprite,
        duration: 0
    },
    onLoad: function () {
        this.level = i.getInstance().getLevelNum(), this.length = this.level * this.level,
            this.game = !1, this.level_label.string = this.level + " × " + this.level, this.setSoundFrame(),
            this.bt_refresh.on("touchstart", this.gameStart, this), this.bt_tip.on("touchstart", this.onTip, this),
            this.bt_return.on("touchstart", this.onReturn, this), this.bt_sound.on("touchstart", this.onSound, this),
            this.initMainMenuNum(), this.onTip(), this.blank_index = 0;
    },
    start: function () {
        this.puzzleLayer.on("touchstart", this.onTouch, this);
    },
    initMainMenuNum: function () {
        switch (this.mainMenuNum = "", this.level) {
            case 3:
                this.mainMenuNum = "x1";
                break;

            case 4:
                this.mainMenuNum = "x2";
                break;

            case 5:
                this.mainMenuNum = "x3";
                break;

            case 6:
                this.mainMenuNum = "x4";
                break;

            case 7:
                this.mainMenuNum = "x5";
        }
    },
    gameStart: function () {
        this.numOfStep = 0, this.step.string = this.numOfStep, this.time = 0, this.schedule(this.countTime, .1),
            this.puzzleLayer.removeAllChildren(), this.setPuzzArray(), this.setPrefabs(), this.checkAllAtFirst()
    },
    countStep: function () {
        this.numOfStep += 1, this.step.string = this.numOfStep;
    },
    countTime: function () {
        this.time += .1;
        var e = Math.floor(this.time / 60),
            t = Math.floor(this.time % 60);
        this.clock.string = e < 10 ? "0" + e + ":" : e + ":", this.clock.string += t < 10 ? "0" + t : t,
            59 == e && 59 == t && this.onOt();
    },
    onOt: function () {
        this.overTimeLayer.active = !0, this.unschedule(this.countTime);
    },
    restart: function () {
        this.schedule(this.countTime, .1);
    },
    onTip: function () {
        this.tipLayer.active = !0, this.unschedule(this.countTime);
    },
    onReturn: function () {
        cc.director.loadScene("Start");
    },
    onSound: function () {
        i.getInstance().changeStatus(), this.setSoundFrame();
    },
    setSoundFrame: function () {
        i.getInstance().getStatus() ? this.bt_soundFrame.spriteFrame = this.soundFrame : this.bt_soundFrame.spriteFrame = this.silenceFrame;
    },
    playMoveSound: function () {
        cc.audioEngine.playEffect(this.sound_move, !1);
    },
    playWinSound: function () {
        cc.audioEngine.playEffect(this.sound_win, !1);
    },
    setPuzzArray: function () {
        this.puzzleArray = [];
        for (var e = 1; e <= this.length; e++) this.puzzleArray.push(e);
        for (this.shuffle(); this.getNegativeSequence();) this.shuffle();
    },
    shuffle: function () {
        for (var e, t = 0; t < this.length; t++) {
            var n = Math.round(Math.random() * (this.length - 1));
            e = this.puzzleArray[n], this.puzzleArray[n] = this.puzzleArray[t], this.puzzleArray[t] = e;
        }
    },
    getNegativeSequence: function () {
        for (var e = 0, t = 0, n = 0; n < this.length - 1; n++)
            if (this.puzzleArray[n] != this.length)
                for (var i = n + 1; i < this.length; i++) this.puzzleArray[n] > this.puzzleArray[i] && e++;
            else t = Math.floor(n / this.level) + 1;
        return this.level % 2 ? e % 2 : (e + this.level - t) % 2;
    },
    setPrefabs: function () {
        this.cell = this.puzzleLayer.width / this.level;
        for (var e = 0; e < this.length; e++) {
            var t = cc.instantiate(this.numPrefab);
            t.width = this.cell, t.height = this.cell, this.puzzleArray[e] == this.length ? (t.getChildByName("Label").getComponent(cc.Label).string = "",
                    t.getComponent(cc.Sprite).spriteFrame = null, this.blank_index = e, console.log(this.blank_index)) : t.getChildByName("Label").getComponent(cc.Label).string = this.puzzleArray[e],
                t.getChildByName("Label").getComponent(cc.Label).fontSize = t.height / 2, this.puzzleLayer.addChild(t),
                t.x = e % this.level * this.cell + .5 * this.cell, t.y = -Math.floor(e / this.level) * this.cell - .5 * this.cell;
        }
    },
    traverse: function () {
        for (var e = this.puzzleLayer.getChildren(), t = 0; t < this.length; t++) console.log(e[t].getChildByName("Label").getComponent(cc.Label).string);
    },
    checkAllAtFirst: function () {
        this.game = !0;
        for (var e = this.puzzleLayer.getChildren(), t = 0; t < this.length - 1; t++) e[t].getChildByName("Label").getComponent(cc.Label).string == t + 1 || e[t].getChildByName("Label").getComponent(cc.Label).string;
    },
    checkAll: function () {
        this.traverse();
        for (var e = this.puzzleLayer.getChildren(), t = 0; t < this.length - 1; t++)
            if (e[t].getChildByName("Label").getComponent(cc.Label).string != t + 1) return !1;
        if (this.unschedule(this.countTime), cc.sys.localStorage.getItem("level_" + this.level) ? cc.sys.localStorage.getItem("level_" + this.level) > this.time && cc.sys.localStorage.setItem("level_" + this.level, this.time) : cc.sys.localStorage.setItem("level_" + this.level, this.time),
            cc.sys.localStorage.getItem("times_" + this.level)) {
            var n = cc.sys.localStorage.getItem("times_" + this.level);
            n = Math.round(n) + 1, cc.sys.localStorage.setItem("times_" + this.level, n);
        } else cc.sys.localStorage.setItem("times_" + this.level, 1);
        return this.win(), !0;
    },
    checkSingle: function () {
        return this.puzzleLayer.getChildren()[this.blank_index].getChildByName("Label").getComponent(cc.Label).string == this.blank_index + 1;
    },
    win: function () {
        this.winLayer.active = !0, this.winLayer.getComponent("Win").game = this, i.getInstance().getStatus() && this.playWinSound();
    },
    onTouch: function (e) {
        this.current_point = this.puzzleLayer.convertToNodeSpaceAR(e.touch._point), this.isNeighbouring() && this.exchange();
    },
    isNeighbouring: function () {
        return this.puzzleLayer.getChildren(), this.current_row = Math.floor(Math.abs(this.current_point.y) / this.cell),
            this.current_col = Math.floor(this.current_point.x / this.cell), this.current_index = this.current_row * this.level + this.current_col,
            console.log("点击了第" + this.current_row + "行"), console.log("点击了第" + this.current_col + "列"),
            console.log("this.current_index " + this.current_index), console.log("this.blank_index " + this.blank_index),
            this.current_index != this.blank_index && (this.blank_row = Math.floor(this.blank_index / this.level),
                this.blank_col = Math.floor(this.blank_index % this.level), console.log("this.blank_row " + this.blank_row),
                console.log("this.blank_col " + this.blank_col), this.current_row == this.blank_row || this.current_col == this.blank_col);
    },
    exchange: function () {
        var e = this.puzzleLayer.getChildren();
        if (this.current_row == this.blank_row)
            if (this.current_col < this.blank_col) {
                for (var t = this.current_index; t < this.blank_index; t++) {
                    var n = cc.moveBy(this.duration, cc.v2(this.cell, 0));
                    console.log("move_right"), console.log("i is " + t), console.log(e[t]), e[t].runAction(n);
                }
                e[this.blank_index].runAction(cc.moveBy(this.duration, cc.v2(-this.cell * (this.blank_col - this.current_col), 0))),
                    e[this.blank_index].setSiblingIndex(this.current_index);
            } else {
                for (var o = this.current_index; o > this.blank_index; o--) {
                    var a = cc.moveBy(this.duration, cc.v2(-this.cell, 0));
                    console.log("move_left"), console.log("i is " + o), e[o].runAction(a);
                }
                e[this.blank_index].runAction(cc.moveBy(this.duration, cc.v2(this.cell * (this.current_col - this.blank_col), 0))),
                    e[this.blank_index].setSiblingIndex(this.current_index);
            }
        else if (this.current_row > this.blank_row) {
            for (var s = this.blank_index + this.level; s <= this.current_index; s += this.level) {
                var c = cc.moveBy(this.duration, cc.v2(0, this.cell));
                console.log("move_up"), console.log("i is " + s), e[s].runAction(c), e[s].setSiblingIndex(s - this.level),
                    e[this.blank_index + 1].setSiblingIndex(s), this.blank_index = s;
            }
            e[this.blank_index].runAction(cc.moveBy(this.duration, cc.v2(0, -this.cell * (this.current_row - this.blank_row))));
        } else {
            for (var r = this.blank_index - this.level; r >= this.current_index; r -= this.level) {
                var l = cc.moveBy(this.duration, cc.v2(0, -this.cell));
                console.log("move_down"), console.log("i is " + r), e[r].runAction(l), e[r].setSiblingIndex(r + this.level),
                    e[this.blank_index - 1].setSiblingIndex(r), this.blank_index = r;
            }
            e[this.blank_index].runAction(cc.moveBy(this.duration, cc.v2(0, this.cell * (this.blank_row - this.current_row))));
        }
        this.blank_index = this.current_index, console.log(this.blank_index), i.getInstance().getStatus() && this.playMoveSound(),
            this.countStep(), this.checkAll();
    },
    onDestroy: function () {
        
    }
})