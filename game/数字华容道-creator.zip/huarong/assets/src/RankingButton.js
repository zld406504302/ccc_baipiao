cc.Class({
    extends: cc.Component,
    properties: {
        activeFrame: {
            type: cc.SpriteFrame,
            default: []
        },
        negativeFrame: {
            type: cc.SpriteFrame,
            default: []
        },
        buttonArray: {
            type: cc.Node,
            default: []
        }
    },
    onLoad: function () {
        this.functionArray = [this.getRankData_3, this.getRankData_4, this.getRankData_5, this.getRankData_6, this.getRankData_7],
            this.timer = 0;
    },
    start: function () {
        for (var e = 1; e < this.buttonArray.length; e++) this.buttonArray[e].on("touchstart", this.functionArray[e], this);
        this.cur_index = 0, this.last_index = 0;
    },
    getRankData_3: function () {
        this.timer < 30 || (this.changeFrame(0));
    },
    getRankData_4: function () {
        this.timer < 30 || (this.changeFrame(1));
    },
    getRankData_5: function () {
        this.timer < 30 || (this.changeFrame(2));
    },
    getRankData_6: function () {
        this.timer < 30 || (this.changeFrame(3));
    },
    getRankData_7: function () {
        this.timer < 30 || (this.changeFrame(4));
    },
    changeFrame: function (e) {
        this.last_index = this.cur_index, this.cur_index = e, this.buttonArray[this.last_index].getComponent(cc.Sprite).spriteFrame = this.activeFrame[this.last_index],
            this.buttonArray[this.last_index].on("touchstart", this.functionArray[this.last_index], this),
            this.buttonArray[this.cur_index].getComponent(cc.Sprite).spriteFrame = this.negativeFrame[this.cur_index],
            this.buttonArray[this.cur_index].off("touchstart", this.functionArray[this.cur_index], this),
            this.timer = 0;
    },
    onReturn: function () {
        this.node.active = !1;
    },
    update: function (e) {
        this.timer++;
    }
})