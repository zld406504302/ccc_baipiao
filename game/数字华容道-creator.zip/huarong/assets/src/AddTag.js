cc.Class({
    extends: cc.Component,
    start: function () {
        var e = this;
        e.node.getComponent(cc.Widget).enabled = !0
        e.node.getComponent(cc.Widget).isAlignTop = !0
        e.node.getComponent(cc.Widget).isAlignRight = !0
        e.node.active = !1
    },
    adaptionFun: function () {
        var e = cc.view.getFrameSize();
        this.ratio = e.height / e.width, this.node.getComponent(cc.Widget).top = 20, this.node.getComponent(cc.Widget).right = 100,
            this.ratio >= 2.1 ? (this.node.getComponent(cc.Widget).top += 20, this.node.getComponent(cc.Widget).right += 120) : this.ratio >= 2 ? (this.node.getComponent(cc.Widget).top += 20,
                this.node.getComponent(cc.Widget).right += 100) : this.ratio >= 1.8 ? (this.node.getComponent(cc.Widget).top += 20,
                this.node.getComponent(cc.Widget).right += 100) : this.ratio >= 1.7 ? (this.node.getComponent(cc.Widget).top += 25,
                this.node.getComponent(cc.Widget).right += 140) : this.ratio >= 1.6 ? (this.node.getComponent(cc.Widget).top -= 5,
                this.node.getComponent(cc.Widget).right += 80) : this.ratio >= 1.4 ? (this.node.getComponent(cc.Widget).top += 15,
                this.node.getComponent(cc.Widget).right += 100) : (this.node.getComponent(cc.Widget).top += 0,
                this.node.getComponent(cc.Widget).right += 60), console.log("top is: " + this.node.getComponent(cc.Widget).top),
            console.log("right is: " + this.node.getComponent(cc.Widget).right);
    },
    addToAni: function () {
        this.addToSeq = cc.repeatForever(cc.sequence(cc.moveBy(.5, cc.v2(30, 0)).easing(cc.easeCubicActionOut()), cc.moveBy(.5, cc.v2(-30, 0)).easing(cc.easeCubicActionIn()))),
            this.node.runAction(this.addToSeq);
    }
})