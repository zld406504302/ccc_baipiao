"use strict";
cc._RF.push(module, '7e6398U+D5BO7+laxZoHZVo', 'Select');
// src/Select.js

"use strict";

var i = require("GameDataManagerJS");
cc.Class({
    extends: cc.Component,
    properties: {
        levels: 0,
        selectBarPrefab: {
            default: null,
            type: cc.Prefab
        },
        content: cc.Node,
        bt_return: cc.Node
    },
    onLoad: function onLoad() {
        this.bt_return.on("touchstart", this.onReturn, this);
    },
    start: function start() {
        for (var e = 0; e < this.levels; e++) {
            var t = cc.instantiate(this.selectBarPrefab);
            t.getComponent("SelectBar").initBar(e + 3), this.content.addChild(t), t.on("touchend", this.onTouch, this);
        }
    },
    onTouch: function onTouch(e) {
        i.getInstance().setLevelNum(e.target.getComponent("SelectBar").level), console.log(e.target.getComponent("SelectBar").level), cc.director.loadScene("Puzzle");
    },
    onReturn: function onReturn() {
        cc.director.loadScene("Start");
    }
});

cc._RF.pop();