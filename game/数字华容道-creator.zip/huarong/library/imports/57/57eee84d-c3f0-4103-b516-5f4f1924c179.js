"use strict";
cc._RF.push(module, '57eeehNw/BBA7UWX08ZJMF5', 'FitWidth');
// src/FitWidth.js

"use strict";

cc.Class({
    extends: cc.Component,
    properties: {},
    start: function start() {
        this.node.setScale(this.getNumber());
    },
    getNumber: function getNumber() {
        var e = cc.winSize,
            t = cc.view.getDesignResolutionSize();
        return e.height / e.width > t.height / t.width ? e.width / t.width : 1;
    }
});

cc._RF.pop();