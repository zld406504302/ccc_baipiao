"use strict";
cc._RF.push(module, '40592G+pL5KnIHcrdzajBr5', 'Breathe');
// src/Breathe.js

"use strict";

cc.Class({
    extends: cc.Component,
    properties: {
        magnify: 1,
        shrink: 1
    },
    start: function start() {
        var e = cc.scaleTo(1, this.magnify),
            t = cc.scaleTo(1, this.shrink),
            n = cc.repeatForever(cc.sequence(e, t));
        this.node.runAction(n);
    }
});

cc._RF.pop();