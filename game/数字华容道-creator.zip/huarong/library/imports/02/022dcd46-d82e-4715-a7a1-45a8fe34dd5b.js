"use strict";
cc._RF.push(module, '022dc1G2C5HFaehRaj+NN1b', 'Global');
// src/Global.js

"use strict";

module.exports = {
    LocalStorage: require("LocalStorage")
};

cc._RF.pop();