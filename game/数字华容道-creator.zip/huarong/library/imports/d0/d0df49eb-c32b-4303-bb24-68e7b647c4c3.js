"use strict";
cc._RF.push(module, 'd0df4nrwytDA7skaOe2R8TD', 'Start');
// src/Start.js

"use strict";

var o = require("GameDataManagerJS");
cc.Class({
    extends: cc.Component,
    properties: {
        rankLayer: cc.Node,
        blank: cc.Node,
        shareTitleArray: {
            default: [],
            type: cc.String
        },
        shareImageArray: {
            default: [],
            type: cc.SpriteFrame
        },
        soundFrame: cc.SpriteFrame,
        silenceFrame: cc.SpriteFrame,
        bt_soundFrame: cc.Sprite
    },
    onLoad: function onLoad() {
        this.setSoundFrame();
    },
    onPlay: function onPlay() {
        cc.director.loadScene("SelectLevel");
    },
    onRank: function onRank() {},
    getRankData_3: function getRankData_3() {},
    onBlank: function onBlank() {},
    onShare: function onShare() {},
    onSound: function onSound() {
        o.getInstance().changeStatus();
        this.setSoundFrame();
    },
    setSoundFrame: function setSoundFrame() {
        o.getInstance().getStatus() ? this.bt_soundFrame.spriteFrame = this.soundFrame : this.bt_soundFrame.spriteFrame = this.silenceFrame;
    },

    start: function start() {},
    onDestroy: function onDestroy() {}
});

cc._RF.pop();