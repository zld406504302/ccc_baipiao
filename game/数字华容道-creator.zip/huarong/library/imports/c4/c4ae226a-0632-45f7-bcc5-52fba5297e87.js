"use strict";
cc._RF.push(module, 'c4ae2JqBjJF97zFUvulKX6H', 'Bespread');
// src/Bespread.js

"use strict";

cc.Class({
    extends: cc.Component,
    properties: {},
    start: function start() {
        this.node.setScale(this.getNumber());
    },
    getNumber: function getNumber() {
        var e = cc.winSize,
            t = cc.view.getDesignResolutionSize();
        return e.height / e.width > t.height / t.width ? e.height / t.height : e.width / t.width;
    }
});

cc._RF.pop();