"use strict";
cc._RF.push(module, 'f6174hSxfhDRZK2cD3DHLPr', 'SelectBar');
// src/SelectBar.js

"use strict";

cc.Class({
    extends: cc.Component,
    properties: {
        level: 0,
        level_label: cc.Label,
        best_label: cc.Label,
        times_label: cc.Label,
        starArray: {
            default: [],
            type: cc.Sprite
        },
        yellowStar: cc.SpriteFrame
    },
    init: function init() {
        this.levelArray_3 = [5, 8, 10, 15, 20, 25], this.levelArray_4 = [25, 30, 40, 50, 70, 80], this.levelArray_5 = [100, 120, 140, 160, 180, 200], this.levelArray_6 = [200, 220, 250, 300, 350, 400], this.levelArray_7 = [350, 380, 420, 450, 500, 520], this.array = [this.levelArray_3, this.levelArray_4, this.levelArray_5, this.levelArray_6, this.levelArray_7];
    },
    start: function start() {},
    initBar: function initBar(e) {
        if (this.init(), this.level = e, this.level_label.string = e + "×" + e, cc.sys.localStorage.getItem("level_" + this.level)) {
            this.bestTime = cc.sys.localStorage.getItem("level_" + this.level);
            var t = this.bestTime.toString();
            t = t.substring(0, t.indexOf(".") + 2), this.best_label.string = "最佳: " + t + "s", this.setStar();
        } else this.best_label.string = "最佳: --";
        if (cc.sys.localStorage.getItem("times_" + this.level)) {
            var n = cc.sys.localStorage.getItem("times_" + this.level);
            n = Math.round(n), this.times_label.string = "次数: " + n;
        } else this.times_label.string = "次数: --";
    },
    setStar: function setStar() {
        if (this.bestTime) {
            for (var e = this.array[this.level - 3], t = 0, n = this.array[this.level - 3].length - 1; n >= 0 && this.bestTime <= e[n]; n--) {
                t++;
            }for (var i = 0; i < t; i++) {
                this.starArray[i].spriteFrame = this.yellowStar;
            }
        }
    },
    update: function update(e) {}
});

cc._RF.pop();