"use strict";
cc._RF.push(module, 'b807bjdQ6lLQrN/GDWloADl', 'Adjust');
// src/Adjust.js

"use strict";

cc.Class({
    extends: cc.Component,
    properties: {},
    onLoad: function onLoad() {},
    start: function start() {},
    getNumber: function getNumber() {
        var e = cc.winSize,
            t = cc.view.getDesignResolutionSize();
        return e.height / e.width > t.height / t.width ? e.height / t.height : e.width / t.width;
    },
    single_getNumber: function single_getNumber() {
        var e = cc.winSize,
            t = cc.view.getDesignResolutionSize();
        return e.height / e.width > t.height / t.width ? e.width / t.width : 1;
    }
});

cc._RF.pop();