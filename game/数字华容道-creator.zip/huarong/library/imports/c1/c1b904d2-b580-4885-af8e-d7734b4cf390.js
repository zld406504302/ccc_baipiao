"use strict";
cc._RF.push(module, 'c1b90TStYBIha+O13NLTPOQ', 'Pause');
// src/Pause.js

"use strict";

cc.Class({
    extends: cc.Component,
    properties: {
        blank: cc.Node,
        bt_restart: cc.Node
    },
    onEnable: function onEnable() {
        this.blank.on("touchstart", this.onBlank, this), this.bt_restart.on("touchstart", this.onRestart, this);
    },
    onBlank: function onBlank() {},
    onRestart: function onRestart() {
        this.node.active = !1, this.node.parent.getComponent("Puzzle").gameStart();
    }
});

cc._RF.pop();