"use strict";
cc._RF.push(module, '4f003VtB8hP/otirzJHXOIn', 'LocalStorage');
// src/LocalStorage.js

"use strict";

module.exports = {
    initItem: function initItem(e) {
        var t = cc.sys.localStorage.getItem(e.str);
        null != t && 0 != t.length || cc.sys.localStorage.setItem(e.str, e.number);
    },
    init: function init() {
        console.log("初始化本地数据"), this.initItem({
            str: "sound",
            number: 1
        }), this.initItem({
            str: "music",
            number: 1
        }), this.initItem({
            str: "score",
            number: 0
        });
    },
    get: function get(e) {
        return parseInt(cc.sys.localStorage.getItem(e));
    },
    set: function set(e, t) {
        cc.sys.localStorage.setItem(e, t);
    }
};

cc._RF.pop();