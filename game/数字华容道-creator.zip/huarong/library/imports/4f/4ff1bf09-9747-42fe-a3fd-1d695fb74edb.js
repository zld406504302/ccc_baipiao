"use strict";
cc._RF.push(module, '4ff1b8Jl0dC/qP9HWlft07b', 'GameDataManagerJS');
// src/GameDataManagerJS.js

"use strict";

var i = cc.Class({
    extends: cc.Component,
    properties: {
        m_curLevelNum: 0,
        playsound: !0
    },
    ctor: function ctor() {},
    statics: {
        _instance: null,
        getInstance: function getInstance() {
            return null === i._instance && (this._instance = new i()), i._instance;
        }
    },
    getLevelNum: function getLevelNum() {
        return this.m_curLevelNum;
    },
    setLevelNum: function setLevelNum(e) {
        this.m_curLevelNum = e;
    },
    changeStatus: function changeStatus() {
        this.playsound = !this.playsound;
    },
    getStatus: function getStatus() {
        return this.playsound;
    }
});
module.exports = i;

cc._RF.pop();