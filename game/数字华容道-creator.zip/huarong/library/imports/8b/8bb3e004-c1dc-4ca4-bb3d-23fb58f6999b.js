"use strict";
cc._RF.push(module, '8bb3eAEwdxMpLs9I/tY9pmb', 'Block');
// src/Block.js

"use strict";

cc.Class({
    extends: cc.Component,
    properties: {
        bg: {
            default: [],
            type: cc.SpriteFrame
        }
    },
    isRight: function isRight() {
        this.node.getComponent(cc.Sprite).spriteFrame = this.bg[1];
    },
    isWrong: function isWrong() {
        this.node.getComponent(cc.Sprite).spriteFrame = this.bg[0];
    }
});

cc._RF.pop();