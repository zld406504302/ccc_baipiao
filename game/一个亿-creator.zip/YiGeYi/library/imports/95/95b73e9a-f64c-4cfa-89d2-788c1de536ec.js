"use strict";
cc._RF.push(module, '95b736a9kxM+onSeIwd5Tbs', 'CashData');
// Scripts/DataMap/InitCash/CashData.js

"use strict";

var CashData = cc.Class({
    name: "CashData",
    properties: {
        name: "",
        Id: cc.Integer,
        cash: cc.Integer,
        weight: 0.4
    }
});
module.exports = CashData;

cc._RF.pop();