"use strict";
cc._RF.push(module, '0592a+UO8RMNYlxga078oZp', 'TutorialStep');
// Scripts/Core/TutorialStep.js

"use strict";

var _cc$Enum;

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var TutorialStep = cc.Enum((_cc$Enum = {
    Market_1: 11,
    Market_2: 12,
    Market_3: 13,
    Market_4: 14
}, _defineProperty(_cc$Enum, "Market_1", 15), _defineProperty(_cc$Enum, "MateDate_1", 21), _defineProperty(_cc$Enum, "MateDate_2", 22), _defineProperty(_cc$Enum, "MateDate_3", 23), _defineProperty(_cc$Enum, "Business_1", 31), _defineProperty(_cc$Enum, "Business_2", 32), _defineProperty(_cc$Enum, "Business_3", 33), _defineProperty(_cc$Enum, "StockBonus_1", 41), _defineProperty(_cc$Enum, "DateToMarry_1", 51), _cc$Enum));
module.exports = TutorialStep;

cc._RF.pop();