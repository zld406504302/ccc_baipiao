"use strict";
cc._RF.push(module, '4aa4aQnGTZFX5fmP4gSZhed', 'AchieveCondData');
// Scripts/DataMap/Achieve/AchieveCondData.js

"use strict";

var AchieveCondData = cc.Class({
    name: "AchieveCondData",
    properties: {
        condType: cc.Integer,
        value: cc.Integer
    }
});
module.exports = AchieveCondData;

cc._RF.pop();