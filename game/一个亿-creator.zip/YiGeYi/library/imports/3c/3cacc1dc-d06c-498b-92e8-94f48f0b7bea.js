"use strict";
cc._RF.push(module, '3caccHc0GxJi5LolPSPC3vq', 'EventCost');
// Scripts/DataMap/EventData/EventCost.js

"use strict";

var EventCost = cc.Class({
    name: "EventCost",
    properties: {
        costType: cc.Integer,
        costNum: cc.Integer,
        desId: cc.Integer
    }
});
module.exports = EventCost;

cc._RF.pop();