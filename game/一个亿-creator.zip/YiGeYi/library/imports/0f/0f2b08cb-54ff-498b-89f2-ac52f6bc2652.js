"use strict";
cc._RF.push(module, '0f2b0jLVP9Ji4nyrFL2vCZS', 'MateGetCond');
// Scripts/DataMap/Mate/MateGetCond.js

"use strict";

var MateGetCond = cc.Class({
    name: "MateGetCond",
    properties: {
        unlockType: cc.Integer,
        value: cc.Integer
    }
});
module.exports = MateGetCond;

cc._RF.pop();