"use strict";
cc._RF.push(module, '92ad6/sQ0FEBqil3P2Gs4Nj', 'CostData');
// Scripts/DataMap/Skill/CostData.js

"use strict";

var CostData = cc.Class({
    name: "CostData",
    properties: {
        toLevel: cc.Integer,
        cost: cc.Integer,
        addBonus: cc.Integer
    }

});
module.exports = CostData;

cc._RF.pop();