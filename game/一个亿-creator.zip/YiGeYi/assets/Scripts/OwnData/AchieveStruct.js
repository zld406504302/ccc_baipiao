
//达到成就
var AchieveStruct = cc.Class({
	name:"AchieveStruct",
	properties:{
		icon:"",
		name:"",
		Id:cc.Integer,
		desId:cc.Integer,
		hasFinish:false,
	},
});
module.exports = AchieveStruct;
