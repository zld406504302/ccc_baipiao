
var CostData = cc.Class({
	name:"CostData",
    properties: {
        toLevel:cc.Integer,
        cost:cc.Integer,
        addBonus:cc.Integer,
    },

});
module.exports = CostData;
