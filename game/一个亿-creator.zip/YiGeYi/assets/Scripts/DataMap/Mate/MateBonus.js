
var MateBonus = cc.Class({
    name:"MateBonus",
    properties: {
        bonusType:cc.Integer,//加成类型
        bonusNum:cc.Integer,//数值
    },
});
module.exports = MateBonus;
