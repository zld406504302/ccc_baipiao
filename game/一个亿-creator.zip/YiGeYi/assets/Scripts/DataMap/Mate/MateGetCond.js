
var MateGetCond = cc.Class({
    name:"MateGetCond",
    properties: {
        unlockType:cc.Integer,
        value:cc.Integer,
    },
});
module.exports = MateGetCond;
