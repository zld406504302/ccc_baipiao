
var AchieveCondData = cc.Class({
    name:"AchieveCondData",
    properties: {
        condType:cc.Integer,
        value:cc.Integer,
    },
});
module.exports = AchieveCondData;
