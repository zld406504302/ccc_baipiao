
var EventResult = cc.Class({
    name: "EventResult",
    properties: {
        rewardType:cc.Integer,
        rewardNum:cc.Integer,
        rewardId:cc.Integer,
        desId:cc.Integer,
    },
});
module.exports = EventResult;
