
var EventCost = cc.Class({
    name:"EventCost",
    properties: {
        costType:cc.Integer,
        costNum:cc.Integer,
        desId:cc.Integer,
    },
});
module.exports = EventCost;
