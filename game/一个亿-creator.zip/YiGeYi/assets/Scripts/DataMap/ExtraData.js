//作为额外条件 数据
var ExtraData = cc.Class({
	name:"ExtraData",
    properties: {
       ItemType:cc.Integer,
       ItemId:cc.Integer,
    },
});
