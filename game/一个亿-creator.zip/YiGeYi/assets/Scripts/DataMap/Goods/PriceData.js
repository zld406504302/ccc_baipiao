var PriceData = cc.Class({
	name:"PriceData",
    properties: {
        lowprice:cc.Integer,
        highprice:cc.Integer,
        probability:0.25,
    },
});
module.exports = PriceData;
