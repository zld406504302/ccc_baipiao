
var CashData = cc.Class({
    name:"CashData",
    properties: {
    	name:"",
        Id:cc.Integer,
        cash:cc.Integer,
        weight:0.4,
    },
});
module.exports = CashData;
