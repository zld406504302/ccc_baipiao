var TutorialStep = cc.Enum({
    Market_1:11,
    Market_2:12,
    Market_3:13,
    Market_4:14,
    Market_1:15,

    MateDate_1:21,
    MateDate_2:22,
    MateDate_3:23,

    Business_1:31,
    Business_2:32,
    Business_3:33,

    StockBonus_1:41,//股票分红

    DateToMarry_1:51,//亲密度
});
module.exports = TutorialStep;
