var MateBonusType = cc.Enum({
    NULL:0,
    HP:1,
    Reputation:2,
    Money:3,
    WareHouseCapcity:4,
    Treat:5,
});
module.exports = MateBonusType;