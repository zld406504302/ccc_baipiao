//临时加成类型
var TempBonus = cc.Enum({
    NULL:0,
    BetBonus:1,
    LoveBonus:2,
    StockBonus:3,
    AssetBonus:4, //财神
});
module.exports = TempBonus;
