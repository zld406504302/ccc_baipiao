


# [fingerBasketball](./fingerBasketball)

[拇指投篮](https://mp.weixin.qq.com/s/VsbNtTL64J0xHIlhMUHCcQ)

cocos creator 3d v1.0.1  

![](./../img/fingerBasketball.gif)

[在线体验](http://lamyoung.gitee.io/web/fingerBasketball)

---

![](./../img/about.jpg)