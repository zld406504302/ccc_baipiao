雨滴落水效果！

[玩水效果-文档](https://mp.weixin.qq.com/s/-5FSWg4YuGgqwv3L9tQ2dA)

cocos creator 3d v1.0.2  

![](./../img/water.gif)


[在线体验](http://lamyoung.gitee.io/web/water)

---

![](./../img/about.jpg)