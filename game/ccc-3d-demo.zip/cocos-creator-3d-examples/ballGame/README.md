

[小鸡拍拍](https://mp.weixin.qq.com/s/sq_6PitkkHgDAj5bm1noPQ)

20191205 更新至 cocos creator 3d v1.0.1 。 修改射线检测。

cocos creator 3d v1.0.0  

![](./../img/ballGame.gif)

[在线体验](http://lamyoung.gitee.io/web/ballGame)


---

![](./../img/about.jpg)