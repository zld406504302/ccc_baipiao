"use strict";

System.register(["cc"], function (_export, _context) {
  "use strict";

  var _decorator, Component, Node, AnimationComponent, systemEvent, SystemEventType, geometry, CameraComponent, tweenUtil, math, LabelComponent, ModelComponent, director, _dec, _dec2, _dec3, _dec4, _dec5, _dec6, _dec7, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4, _descriptor5, _descriptor6, _temp, ccclass, property, BALL_INIT_X, BALL_MAX_Y, BALL_MIN_Y, BALL_CHICKEN_X, BALL_GAMEOVER_X, BALL_MAX_Z, GameMgr;

  _export({
    _dec: void 0,
    _dec2: void 0,
    _dec3: void 0,
    _dec4: void 0,
    _dec5: void 0,
    _dec6: void 0,
    _dec7: void 0,
    _class: void 0,
    _class2: void 0,
    _descriptor: void 0,
    _descriptor2: void 0,
    _descriptor3: void 0,
    _descriptor4: void 0,
    _descriptor5: void 0,
    _descriptor6: void 0,
    _temp: void 0
  });

  return {
    setters: [function (_cc) {
      _decorator = _cc._decorator;
      Component = _cc.Component;
      Node = _cc.Node;
      AnimationComponent = _cc.AnimationComponent;
      systemEvent = _cc.systemEvent;
      SystemEventType = _cc.SystemEventType;
      geometry = _cc.geometry;
      CameraComponent = _cc.CameraComponent;
      tweenUtil = _cc.tweenUtil;
      math = _cc.math;
      LabelComponent = _cc.LabelComponent;
      ModelComponent = _cc.ModelComponent;
      director = _cc.director;
    }],
    execute: function () {
      cc._RF.push(window.module || {}, "6adedwvgqlBOYzkqf31WL19", "GameMgr"); // begin GameMgr


      ccclass = _decorator.ccclass;
      property = _decorator.property;
      BALL_INIT_X = 80;
      BALL_MAX_Y = 12;
      BALL_MIN_Y = 0;
      BALL_CHICKEN_X = 55;
      BALL_GAMEOVER_X = 90;
      BALL_MAX_Z = 2.5;

      _export("GameMgr", GameMgr = (_dec = ccclass("GameMgr"), _dec2 = property(CameraComponent), _dec3 = property(Node), _dec4 = property(Node), _dec5 = property(ModelComponent), _dec6 = property(Node), _dec7 = property(LabelComponent), _dec(_class = (_class2 = (_temp =
      /*#__PURE__*/
      function (_Component) {
        babelHelpers.inherits(GameMgr, _Component);

        function GameMgr() {
          var _babelHelpers$getProt;

          var _this;

          babelHelpers.classCallCheck(this, GameMgr);

          for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
          }

          _this = babelHelpers.possibleConstructorReturn(this, (_babelHelpers$getProt = babelHelpers.getPrototypeOf(GameMgr)).call.apply(_babelHelpers$getProt, [this].concat(args)));
          babelHelpers.initializerDefineProperty(_this, "camera", _descriptor, babelHelpers.assertThisInitialized(_this));
          babelHelpers.initializerDefineProperty(_this, "node_gameover", _descriptor2, babelHelpers.assertThisInitialized(_this));
          babelHelpers.initializerDefineProperty(_this, "node_ball", _descriptor3, babelHelpers.assertThisInitialized(_this));
          babelHelpers.initializerDefineProperty(_this, "model_ball", _descriptor4, babelHelpers.assertThisInitialized(_this));
          babelHelpers.initializerDefineProperty(_this, "node_chicken", _descriptor5, babelHelpers.assertThisInitialized(_this));
          babelHelpers.initializerDefineProperty(_this, "lb_score", _descriptor6, babelHelpers.assertThisInitialized(_this));
          _this._node_balll_pos = new math.Vec3();
          _this._turn = 1;
          _this._score = 0;
          _this._ray = new geometry.ray();
          return _this;
        }

        babelHelpers.createClass(GameMgr, [{
          key: "start",
          value: function start() {
            this._node_balll_pos = this.node_ball.position.clone();
          }
        }, {
          key: "resetGame",
          value: function resetGame() {
            this._score = 0;
            this.lb_score.string = '0';
            this._turn = 1;
            this._node_balll_pos.x = BALL_INIT_X;
            this._node_balll_pos.y = BALL_MIN_Y;
            this._node_balll_pos.z = 0;
            this.node_gameover.active = false;
            this.node_ball.getComponent(AnimationComponent).play('ball_idle');
            systemEvent.on(SystemEventType.TOUCH_START, this.onClickBall, this);
          }
        }, {
          key: "onClickBall",
          //自己发射
          value: function onClickBall(touch, event) {
            var _this2 = this;

            if (this._turn === 1 && this._node_balll_pos.x >= (BALL_INIT_X + BALL_CHICKEN_X) * 0.5) {
              this.camera.screenPointToRay(touch._point.x, touch._point.y, this._ray);
              var rs = director.getScene().renderScene;

              if (rs.raycastSingleModel(this._ray, this.model_ball.model)) {
                var r = rs.rayResultSingleModel;

                for (var i = 0; i < r.length; i++) {
                  var item = r[i];

                  if (item.node.uuid == this.model_ball.node.uuid) {
                    this.node_ball.getComponent(AnimationComponent).play('ball_my');
                    this._turn = 0;
                    tweenUtil(this._node_balll_pos).stop().to(0.5, new math.Vec3((this.node_ball.position.x + BALL_CHICKEN_X) / 2, BALL_MAX_Y * (0.8 + 0.2 * Math.random()), 0)).to(0.5, new math.Vec3(BALL_CHICKEN_X, BALL_MIN_Y, 0)).call(function () {
                      _this2.chickenBall();
                    }).start();
                    break;
                  }
                }
              } // const result: { node: Node }[] = this.node_ball_click.scene.renderScene['raycast'](this._ray);
              // console.log(result)
              // if (result.some((i) => {
              //     if (i.node === this.node_ball_click) {
              //         return true;
              //     }
              // })) {
              //     this.node_ball.getComponent(AnimationComponent).play('ball_my');
              //     this._turn = 0;
              //     tweenUtil(this._node_balll_pos)
              //         .stop()
              //         .to(0.5, new math.Vec3((this.node_ball.position.x + BALL_CHICKEN_X) / 2, BALL_MAX_Y * (0.8 + 0.2 * Math.random()), 0))
              //         .to(0.5, new math.Vec3(BALL_CHICKEN_X, BALL_MIN_Y, 0))
              //         .call(() => { this.chickenBall() })
              //         .start();
              // }

            }
          }
        }, {
          key: "gameOver",
          value: function gameOver() {
            this.node_gameover.active = true;
            this.node_ball.getComponent(AnimationComponent).play('ball_idle');
            systemEvent.off(SystemEventType.TOUCH_START, this.onClickBall, this);
          } //小鸡发射

        }, {
          key: "chickenBall",
          value: function chickenBall() {
            this.node_ball.getComponent(AnimationComponent).play('ball_he');
            this.node_chicken.getComponent(AnimationComponent).play('chicken_jump');
            this.node_chicken.getComponent(AnimationComponent).crossFade('chicken_idle', 0.3);
            this._turn = 1;
            this.lb_score.string = "".concat(++this._score);
            var targetZ = -BALL_MAX_Z + 2 * BALL_MAX_Z * Math.random();
            var time = 1 / Math.pow(1.01, this._score);
            tweenUtil(this._node_balll_pos).stop().to(time, new math.Vec3((this.node_ball.position.x + BALL_INIT_X) / 2, BALL_MAX_Y * (0.8 + 0.2 * Math.random()), targetZ / 2)).to(time, new math.Vec3(BALL_GAMEOVER_X, BALL_MIN_Y, targetZ)).start();
          }
        }, {
          key: "update",
          value: function update(deltaTime) {
            if (this._node_balll_pos.x >= BALL_GAMEOVER_X) {
              this.gameOver();
            }

            this.node_ball.position = this._node_balll_pos;
          }
        }]);
        return GameMgr;
      }(Component), _temp), (_descriptor = babelHelpers.applyDecoratedDescriptor(_class2.prototype, "camera", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor2 = babelHelpers.applyDecoratedDescriptor(_class2.prototype, "node_gameover", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor3 = babelHelpers.applyDecoratedDescriptor(_class2.prototype, "node_ball", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor4 = babelHelpers.applyDecoratedDescriptor(_class2.prototype, "model_ball", [_dec5], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor5 = babelHelpers.applyDecoratedDescriptor(_class2.prototype, "node_chicken", [_dec6], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor6 = babelHelpers.applyDecoratedDescriptor(_class2.prototype, "lb_score", [_dec7], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      })), _class2)) || _class));

      cc._RF.pop(); // end GameMgr

    }
  };
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInByb2plY3Q6Ly8vYXNzZXRzL3NyYy9HYW1lTWdyLnRzIl0sIm5hbWVzIjpbIl9kZWNvcmF0b3IiLCJDb21wb25lbnQiLCJOb2RlIiwiQW5pbWF0aW9uQ29tcG9uZW50Iiwic3lzdGVtRXZlbnQiLCJTeXN0ZW1FdmVudFR5cGUiLCJnZW9tZXRyeSIsIkNhbWVyYUNvbXBvbmVudCIsInR3ZWVuVXRpbCIsIm1hdGgiLCJMYWJlbENvbXBvbmVudCIsIk1vZGVsQ29tcG9uZW50IiwiZGlyZWN0b3IiLCJjY2NsYXNzIiwicHJvcGVydHkiLCJCQUxMX0lOSVRfWCIsIkJBTExfTUFYX1kiLCJCQUxMX01JTl9ZIiwiQkFMTF9DSElDS0VOX1giLCJCQUxMX0dBTUVPVkVSX1giLCJCQUxMX01BWF9aIiwiR2FtZU1nciIsIl9ub2RlX2JhbGxsX3BvcyIsIlZlYzMiLCJfdHVybiIsIl9zY29yZSIsIl9yYXkiLCJyYXkiLCJub2RlX2JhbGwiLCJwb3NpdGlvbiIsImNsb25lIiwibGJfc2NvcmUiLCJzdHJpbmciLCJ4IiwieSIsInoiLCJub2RlX2dhbWVvdmVyIiwiYWN0aXZlIiwiZ2V0Q29tcG9uZW50IiwicGxheSIsIm9uIiwiVE9VQ0hfU1RBUlQiLCJvbkNsaWNrQmFsbCIsInRvdWNoIiwiZXZlbnQiLCJjYW1lcmEiLCJzY3JlZW5Qb2ludFRvUmF5IiwiX3BvaW50IiwicnMiLCJnZXRTY2VuZSIsInJlbmRlclNjZW5lIiwicmF5Y2FzdFNpbmdsZU1vZGVsIiwibW9kZWxfYmFsbCIsIm1vZGVsIiwiciIsInJheVJlc3VsdFNpbmdsZU1vZGVsIiwiaSIsImxlbmd0aCIsIml0ZW0iLCJub2RlIiwidXVpZCIsInN0b3AiLCJ0byIsIk1hdGgiLCJyYW5kb20iLCJjYWxsIiwiY2hpY2tlbkJhbGwiLCJzdGFydCIsIm9mZiIsIm5vZGVfY2hpY2tlbiIsImNyb3NzRmFkZSIsInRhcmdldFoiLCJ0aW1lIiwicG93IiwiZGVsdGFUaW1lIiwiZ2FtZU92ZXIiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBU0EsTUFBQUEsVSxPQUFBQSxVO0FBQVlDLE1BQUFBLFMsT0FBQUEsUztBQUFXQyxNQUFBQSxJLE9BQUFBLEk7QUFBTUMsTUFBQUEsa0IsT0FBQUEsa0I7QUFBb0JDLE1BQUFBLFcsT0FBQUEsVztBQUFhQyxNQUFBQSxlLE9BQUFBLGU7QUFBb0NDLE1BQUFBLFEsT0FBQUEsUTtBQUFVQyxNQUFBQSxlLE9BQUFBLGU7QUFBdUJDLE1BQUFBLFMsT0FBQUEsUztBQUFXQyxNQUFBQSxJLE9BQUFBLEk7QUFBTUMsTUFBQUEsYyxPQUFBQSxjO0FBQWdCQyxNQUFBQSxjLE9BQUFBLGM7QUFBZ0JDLE1BQUFBLFEsT0FBQUEsUTs7OzhFQUVwSDs7O0FBRGpFQyxNQUFBQSxPLEdBQXNCYixVLENBQXRCYSxPO0FBQVNDLE1BQUFBLFEsR0FBYWQsVSxDQUFiYyxRO0FBR1hDLE1BQUFBLFcsR0FBYyxFO0FBQ2RDLE1BQUFBLFUsR0FBYSxFO0FBQ2JDLE1BQUFBLFUsR0FBYSxDO0FBQ2JDLE1BQUFBLGMsR0FBaUIsRTtBQUNqQkMsTUFBQUEsZSxHQUFrQixFO0FBQ2xCQyxNQUFBQSxVLEdBQWEsRzs7eUJBR05DLE8sV0FEWlIsT0FBTyxDQUFDLFNBQUQsQyxVQUdIQyxRQUFRLENBQUNQLGVBQUQsQyxVQUdSTyxRQUFRLENBQUNaLElBQUQsQyxVQUdSWSxRQUFRLENBQUNaLElBQUQsQyxVQUdSWSxRQUFRLENBQUNILGNBQUQsQyxVQUdSRyxRQUFRLENBQUNaLElBQUQsQyxVQUdSWSxRQUFRLENBQUNKLGNBQUQsQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Z0JBR0RZLGUsR0FBNkIsSUFBSWIsSUFBSSxDQUFDYyxJQUFULEU7Z0JBQzdCQyxLLEdBQVEsQztnQkFFUkMsTSxHQUFTLEM7Z0JBa0JUQyxJLEdBQU8sSUFBSXBCLFFBQVEsQ0FBQ3FCLEdBQWIsRTs7Ozs7O2tDQWhCUDtBQUNKLGlCQUFLTCxlQUFMLEdBQXVCLEtBQUtNLFNBQUwsQ0FBZUMsUUFBZixDQUF3QkMsS0FBeEIsRUFBdkI7QUFDSDs7O3NDQUVtQjtBQUNoQixpQkFBS0wsTUFBTCxHQUFjLENBQWQ7QUFDQSxpQkFBS00sUUFBTCxDQUFjQyxNQUFkLEdBQXVCLEdBQXZCO0FBQ0EsaUJBQUtSLEtBQUwsR0FBYSxDQUFiO0FBQ0EsaUJBQUtGLGVBQUwsQ0FBcUJXLENBQXJCLEdBQXlCbEIsV0FBekI7QUFDQSxpQkFBS08sZUFBTCxDQUFxQlksQ0FBckIsR0FBeUJqQixVQUF6QjtBQUNBLGlCQUFLSyxlQUFMLENBQXFCYSxDQUFyQixHQUF5QixDQUF6QjtBQUNBLGlCQUFLQyxhQUFMLENBQW1CQyxNQUFuQixHQUE0QixLQUE1QjtBQUNBLGlCQUFLVCxTQUFMLENBQWVVLFlBQWYsQ0FBNEJuQyxrQkFBNUIsRUFBZ0RvQyxJQUFoRCxDQUFxRCxXQUFyRDtBQUNBbkMsWUFBQUEsV0FBVyxDQUFDb0MsRUFBWixDQUFlbkMsZUFBZSxDQUFDb0MsV0FBL0IsRUFBNEMsS0FBS0MsV0FBakQsRUFBOEQsSUFBOUQ7QUFDSDs7O0FBR0Q7c0NBQ29CQyxLLEVBQWNDLEssRUFBbUI7QUFBQTs7QUFDakQsZ0JBQUksS0FBS3BCLEtBQUwsS0FBZSxDQUFmLElBQW9CLEtBQUtGLGVBQUwsQ0FBcUJXLENBQXJCLElBQTBCLENBQUNsQixXQUFXLEdBQUdHLGNBQWYsSUFBaUMsR0FBbkYsRUFBd0Y7QUFDcEYsbUJBQUsyQixNQUFMLENBQVlDLGdCQUFaLENBQTZCSCxLQUFLLENBQUNJLE1BQU4sQ0FBYWQsQ0FBMUMsRUFBNkNVLEtBQUssQ0FBQ0ksTUFBTixDQUFhYixDQUExRCxFQUE2RCxLQUFLUixJQUFsRTtBQUNBLGtCQUFNc0IsRUFBRSxHQUFHcEMsUUFBUSxDQUFDcUMsUUFBVCxHQUFvQkMsV0FBL0I7O0FBQ0Esa0JBQUlGLEVBQUUsQ0FBQ0csa0JBQUgsQ0FBc0IsS0FBS3pCLElBQTNCLEVBQWlDLEtBQUswQixVQUFMLENBQWdCQyxLQUFqRCxDQUFKLEVBQTZEO0FBQ3pELG9CQUFNQyxDQUFDLEdBQUdOLEVBQUUsQ0FBQ08sb0JBQWI7O0FBQ0EscUJBQUssSUFBSUMsQ0FBQyxHQUFHLENBQWIsRUFBZ0JBLENBQUMsR0FBR0YsQ0FBQyxDQUFDRyxNQUF0QixFQUE4QkQsQ0FBQyxFQUEvQixFQUFtQztBQUMvQixzQkFBTUUsSUFBSSxHQUFHSixDQUFDLENBQUNFLENBQUQsQ0FBZDs7QUFDQSxzQkFBSUUsSUFBSSxDQUFDQyxJQUFMLENBQVVDLElBQVYsSUFBa0IsS0FBS1IsVUFBTCxDQUFnQk8sSUFBaEIsQ0FBcUJDLElBQTNDLEVBQWlEO0FBQzdDLHlCQUFLaEMsU0FBTCxDQUFlVSxZQUFmLENBQTRCbkMsa0JBQTVCLEVBQWdEb0MsSUFBaEQsQ0FBcUQsU0FBckQ7QUFDQSx5QkFBS2YsS0FBTCxHQUFhLENBQWI7QUFDQWhCLG9CQUFBQSxTQUFTLENBQUMsS0FBS2MsZUFBTixDQUFULENBQ0t1QyxJQURMLEdBRUtDLEVBRkwsQ0FFUSxHQUZSLEVBRWEsSUFBSXJELElBQUksQ0FBQ2MsSUFBVCxDQUFjLENBQUMsS0FBS0ssU0FBTCxDQUFlQyxRQUFmLENBQXdCSSxDQUF4QixHQUE0QmYsY0FBN0IsSUFBK0MsQ0FBN0QsRUFBZ0VGLFVBQVUsSUFBSSxNQUFNLE1BQU0rQyxJQUFJLENBQUNDLE1BQUwsRUFBaEIsQ0FBMUUsRUFBMEcsQ0FBMUcsQ0FGYixFQUdLRixFQUhMLENBR1EsR0FIUixFQUdhLElBQUlyRCxJQUFJLENBQUNjLElBQVQsQ0FBY0wsY0FBZCxFQUE4QkQsVUFBOUIsRUFBMEMsQ0FBMUMsQ0FIYixFQUlLZ0QsSUFKTCxDQUlVLFlBQU07QUFBRSxzQkFBQSxNQUFJLENBQUNDLFdBQUw7QUFBb0IscUJBSnRDLEVBS0tDLEtBTEw7QUFNQTtBQUNIO0FBQ0o7QUFDSixlQW5CbUYsQ0FxQnBGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNIO0FBQ0o7OztxQ0FFa0I7QUFDZixpQkFBSy9CLGFBQUwsQ0FBbUJDLE1BQW5CLEdBQTRCLElBQTVCO0FBQ0EsaUJBQUtULFNBQUwsQ0FBZVUsWUFBZixDQUE0Qm5DLGtCQUE1QixFQUFnRG9DLElBQWhELENBQXFELFdBQXJEO0FBQ0FuQyxZQUFBQSxXQUFXLENBQUNnRSxHQUFaLENBQWdCL0QsZUFBZSxDQUFDb0MsV0FBaEMsRUFBNkMsS0FBS0MsV0FBbEQsRUFBK0QsSUFBL0Q7QUFDSCxXLENBRUQ7Ozs7d0NBQ3NCO0FBQ2xCLGlCQUFLZCxTQUFMLENBQWVVLFlBQWYsQ0FBNEJuQyxrQkFBNUIsRUFBZ0RvQyxJQUFoRCxDQUFxRCxTQUFyRDtBQUNBLGlCQUFLOEIsWUFBTCxDQUFrQi9CLFlBQWxCLENBQStCbkMsa0JBQS9CLEVBQW1Eb0MsSUFBbkQsQ0FBd0QsY0FBeEQ7QUFDQSxpQkFBSzhCLFlBQUwsQ0FBa0IvQixZQUFsQixDQUErQm5DLGtCQUEvQixFQUFtRG1FLFNBQW5ELENBQTZELGNBQTdELEVBQTZFLEdBQTdFO0FBQ0EsaUJBQUs5QyxLQUFMLEdBQWEsQ0FBYjtBQUNBLGlCQUFLTyxRQUFMLENBQWNDLE1BQWQsYUFBMEIsRUFBRSxLQUFLUCxNQUFqQztBQUNBLGdCQUFNOEMsT0FBTyxHQUFHLENBQUNuRCxVQUFELEdBQWMsSUFBSUEsVUFBSixHQUFpQjJDLElBQUksQ0FBQ0MsTUFBTCxFQUEvQztBQUNBLGdCQUFNUSxJQUFJLEdBQUcsSUFBS1QsSUFBSSxDQUFDVSxHQUFMLENBQVMsSUFBVCxFQUFlLEtBQUtoRCxNQUFwQixDQUFsQjtBQUNBakIsWUFBQUEsU0FBUyxDQUFDLEtBQUtjLGVBQU4sQ0FBVCxDQUNLdUMsSUFETCxHQUVLQyxFQUZMLENBRVFVLElBRlIsRUFFYyxJQUFJL0QsSUFBSSxDQUFDYyxJQUFULENBQWMsQ0FBQyxLQUFLSyxTQUFMLENBQWVDLFFBQWYsQ0FBd0JJLENBQXhCLEdBQTRCbEIsV0FBN0IsSUFBNEMsQ0FBMUQsRUFBNkRDLFVBQVUsSUFBSSxNQUFNLE1BQU0rQyxJQUFJLENBQUNDLE1BQUwsRUFBaEIsQ0FBdkUsRUFBdUdPLE9BQU8sR0FBRyxDQUFqSCxDQUZkLEVBR0tULEVBSEwsQ0FHUVUsSUFIUixFQUdjLElBQUkvRCxJQUFJLENBQUNjLElBQVQsQ0FBY0osZUFBZCxFQUErQkYsVUFBL0IsRUFBMkNzRCxPQUEzQyxDQUhkLEVBSUtKLEtBSkw7QUFLSDs7O2lDQUVNTyxTLEVBQW1CO0FBQ3RCLGdCQUFJLEtBQUtwRCxlQUFMLENBQXFCVyxDQUFyQixJQUEwQmQsZUFBOUIsRUFBK0M7QUFDM0MsbUJBQUt3RCxRQUFMO0FBQ0g7O0FBQ0QsaUJBQUsvQyxTQUFMLENBQWVDLFFBQWYsR0FBMEIsS0FBS1AsZUFBL0I7QUFDSDs7O1FBL0d3QnJCLFM7Ozs7O2lCQUdDLEk7Ozs7Ozs7aUJBR0osSTs7Ozs7OztpQkFHSixJOzs7Ozs7O2lCQUdXLEk7Ozs7Ozs7aUJBR1IsSTs7Ozs7OztpQkFHTSxJOzs7O29CQTVCYiIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IF9kZWNvcmF0b3IsIENvbXBvbmVudCwgTm9kZSwgQW5pbWF0aW9uQ29tcG9uZW50LCBzeXN0ZW1FdmVudCwgU3lzdGVtRXZlbnRUeXBlLCBUb3VjaCwgRXZlbnRUb3VjaCwgZ2VvbWV0cnksIENhbWVyYUNvbXBvbmVudCwgVmVjMywgdHdlZW5VdGlsLCBtYXRoLCBMYWJlbENvbXBvbmVudCwgTW9kZWxDb21wb25lbnQsIGRpcmVjdG9yIH0gZnJvbSBcImNjXCI7XG5jb25zdCB7IGNjY2xhc3MsIHByb3BlcnR5IH0gPSBfZGVjb3JhdG9yO1xuXG5cbmNvbnN0IEJBTExfSU5JVF9YID0gODA7XG5jb25zdCBCQUxMX01BWF9ZID0gMTI7XG5jb25zdCBCQUxMX01JTl9ZID0gMDtcbmNvbnN0IEJBTExfQ0hJQ0tFTl9YID0gNTU7XG5jb25zdCBCQUxMX0dBTUVPVkVSX1ggPSA5MDtcbmNvbnN0IEJBTExfTUFYX1ogPSAyLjU7XG5cbkBjY2NsYXNzKFwiR2FtZU1nclwiKVxuZXhwb3J0IGNsYXNzIEdhbWVNZ3IgZXh0ZW5kcyBDb21wb25lbnQge1xuXG4gICAgQHByb3BlcnR5KENhbWVyYUNvbXBvbmVudClcbiAgICBjYW1lcmE6IENhbWVyYUNvbXBvbmVudCA9IG51bGw7XG5cbiAgICBAcHJvcGVydHkoTm9kZSlcbiAgICBub2RlX2dhbWVvdmVyOiBOb2RlID0gbnVsbDtcblxuICAgIEBwcm9wZXJ0eShOb2RlKVxuICAgIG5vZGVfYmFsbDogTm9kZSA9IG51bGw7XG5cbiAgICBAcHJvcGVydHkoTW9kZWxDb21wb25lbnQpXG4gICAgbW9kZWxfYmFsbDogTW9kZWxDb21wb25lbnQgPSBudWxsO1xuXG4gICAgQHByb3BlcnR5KE5vZGUpXG4gICAgbm9kZV9jaGlja2VuOiBOb2RlID0gbnVsbDtcblxuICAgIEBwcm9wZXJ0eShMYWJlbENvbXBvbmVudClcbiAgICBsYl9zY29yZTogTGFiZWxDb21wb25lbnQgPSBudWxsO1xuXG4gICAgcHJpdmF0ZSBfbm9kZV9iYWxsbF9wb3M6IG1hdGguVmVjMyA9IG5ldyBtYXRoLlZlYzMoKTtcbiAgICBwcml2YXRlIF90dXJuID0gMTsvLzEtbXkgMi1oZTtcblxuICAgIHByaXZhdGUgX3Njb3JlID0gMDtcblxuICAgIHN0YXJ0KCkge1xuICAgICAgICB0aGlzLl9ub2RlX2JhbGxsX3BvcyA9IHRoaXMubm9kZV9iYWxsLnBvc2l0aW9uLmNsb25lKCk7XG4gICAgfVxuXG4gICAgcHJpdmF0ZSByZXNldEdhbWUoKSB7XG4gICAgICAgIHRoaXMuX3Njb3JlID0gMDtcbiAgICAgICAgdGhpcy5sYl9zY29yZS5zdHJpbmcgPSAnMCc7XG4gICAgICAgIHRoaXMuX3R1cm4gPSAxO1xuICAgICAgICB0aGlzLl9ub2RlX2JhbGxsX3Bvcy54ID0gQkFMTF9JTklUX1g7XG4gICAgICAgIHRoaXMuX25vZGVfYmFsbGxfcG9zLnkgPSBCQUxMX01JTl9ZO1xuICAgICAgICB0aGlzLl9ub2RlX2JhbGxsX3Bvcy56ID0gMDtcbiAgICAgICAgdGhpcy5ub2RlX2dhbWVvdmVyLmFjdGl2ZSA9IGZhbHNlO1xuICAgICAgICB0aGlzLm5vZGVfYmFsbC5nZXRDb21wb25lbnQoQW5pbWF0aW9uQ29tcG9uZW50KS5wbGF5KCdiYWxsX2lkbGUnKTtcbiAgICAgICAgc3lzdGVtRXZlbnQub24oU3lzdGVtRXZlbnRUeXBlLlRPVUNIX1NUQVJULCB0aGlzLm9uQ2xpY2tCYWxsLCB0aGlzKTtcbiAgICB9XG5cbiAgICBwcml2YXRlIF9yYXkgPSBuZXcgZ2VvbWV0cnkucmF5KCk7XG4gICAgLy/oh6rlt7Hlj5HlsIRcbiAgICBwcml2YXRlIG9uQ2xpY2tCYWxsKHRvdWNoOiBUb3VjaCwgZXZlbnQ6IEV2ZW50VG91Y2gpIHtcbiAgICAgICAgaWYgKHRoaXMuX3R1cm4gPT09IDEgJiYgdGhpcy5fbm9kZV9iYWxsbF9wb3MueCA+PSAoQkFMTF9JTklUX1ggKyBCQUxMX0NISUNLRU5fWCkgKiAwLjUpIHtcbiAgICAgICAgICAgIHRoaXMuY2FtZXJhLnNjcmVlblBvaW50VG9SYXkodG91Y2guX3BvaW50LngsIHRvdWNoLl9wb2ludC55LCB0aGlzLl9yYXkpO1xuICAgICAgICAgICAgY29uc3QgcnMgPSBkaXJlY3Rvci5nZXRTY2VuZSgpLnJlbmRlclNjZW5lO1xuICAgICAgICAgICAgaWYgKHJzLnJheWNhc3RTaW5nbGVNb2RlbCh0aGlzLl9yYXksIHRoaXMubW9kZWxfYmFsbC5tb2RlbCkpIHtcbiAgICAgICAgICAgICAgICBjb25zdCByID0gcnMucmF5UmVzdWx0U2luZ2xlTW9kZWw7XG4gICAgICAgICAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCByLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGl0ZW0gPSByW2ldO1xuICAgICAgICAgICAgICAgICAgICBpZiAoaXRlbS5ub2RlLnV1aWQgPT0gdGhpcy5tb2RlbF9iYWxsLm5vZGUudXVpZCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5ub2RlX2JhbGwuZ2V0Q29tcG9uZW50KEFuaW1hdGlvbkNvbXBvbmVudCkucGxheSgnYmFsbF9teScpO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5fdHVybiA9IDA7XG4gICAgICAgICAgICAgICAgICAgICAgICB0d2VlblV0aWwodGhpcy5fbm9kZV9iYWxsbF9wb3MpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLnN0b3AoKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC50bygwLjUsIG5ldyBtYXRoLlZlYzMoKHRoaXMubm9kZV9iYWxsLnBvc2l0aW9uLnggKyBCQUxMX0NISUNLRU5fWCkgLyAyLCBCQUxMX01BWF9ZICogKDAuOCArIDAuMiAqIE1hdGgucmFuZG9tKCkpLCAwKSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAudG8oMC41LCBuZXcgbWF0aC5WZWMzKEJBTExfQ0hJQ0tFTl9YLCBCQUxMX01JTl9ZLCAwKSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAuY2FsbCgoKSA9PiB7IHRoaXMuY2hpY2tlbkJhbGwoKSB9KVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC5zdGFydCgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIC8vIGNvbnN0IHJlc3VsdDogeyBub2RlOiBOb2RlIH1bXSA9IHRoaXMubm9kZV9iYWxsX2NsaWNrLnNjZW5lLnJlbmRlclNjZW5lWydyYXljYXN0J10odGhpcy5fcmF5KTtcbiAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKHJlc3VsdClcbiAgICAgICAgICAgIC8vIGlmIChyZXN1bHQuc29tZSgoaSkgPT4ge1xuICAgICAgICAgICAgLy8gICAgIGlmIChpLm5vZGUgPT09IHRoaXMubm9kZV9iYWxsX2NsaWNrKSB7XG4gICAgICAgICAgICAvLyAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICAgICAgLy8gICAgIH1cbiAgICAgICAgICAgIC8vIH0pKSB7XG4gICAgICAgICAgICAvLyAgICAgdGhpcy5ub2RlX2JhbGwuZ2V0Q29tcG9uZW50KEFuaW1hdGlvbkNvbXBvbmVudCkucGxheSgnYmFsbF9teScpO1xuICAgICAgICAgICAgLy8gICAgIHRoaXMuX3R1cm4gPSAwO1xuICAgICAgICAgICAgLy8gICAgIHR3ZWVuVXRpbCh0aGlzLl9ub2RlX2JhbGxsX3BvcylcbiAgICAgICAgICAgIC8vICAgICAgICAgLnN0b3AoKVxuICAgICAgICAgICAgLy8gICAgICAgICAudG8oMC41LCBuZXcgbWF0aC5WZWMzKCh0aGlzLm5vZGVfYmFsbC5wb3NpdGlvbi54ICsgQkFMTF9DSElDS0VOX1gpIC8gMiwgQkFMTF9NQVhfWSAqICgwLjggKyAwLjIgKiBNYXRoLnJhbmRvbSgpKSwgMCkpXG4gICAgICAgICAgICAvLyAgICAgICAgIC50bygwLjUsIG5ldyBtYXRoLlZlYzMoQkFMTF9DSElDS0VOX1gsIEJBTExfTUlOX1ksIDApKVxuICAgICAgICAgICAgLy8gICAgICAgICAuY2FsbCgoKSA9PiB7IHRoaXMuY2hpY2tlbkJhbGwoKSB9KVxuICAgICAgICAgICAgLy8gICAgICAgICAuc3RhcnQoKTtcbiAgICAgICAgICAgIC8vIH1cbiAgICAgICAgfVxuICAgIH1cblxuICAgIHByaXZhdGUgZ2FtZU92ZXIoKSB7XG4gICAgICAgIHRoaXMubm9kZV9nYW1lb3Zlci5hY3RpdmUgPSB0cnVlO1xuICAgICAgICB0aGlzLm5vZGVfYmFsbC5nZXRDb21wb25lbnQoQW5pbWF0aW9uQ29tcG9uZW50KS5wbGF5KCdiYWxsX2lkbGUnKTtcbiAgICAgICAgc3lzdGVtRXZlbnQub2ZmKFN5c3RlbUV2ZW50VHlwZS5UT1VDSF9TVEFSVCwgdGhpcy5vbkNsaWNrQmFsbCwgdGhpcyk7XG4gICAgfVxuXG4gICAgLy/lsI/puKHlj5HlsIRcbiAgICBwcml2YXRlIGNoaWNrZW5CYWxsKCkge1xuICAgICAgICB0aGlzLm5vZGVfYmFsbC5nZXRDb21wb25lbnQoQW5pbWF0aW9uQ29tcG9uZW50KS5wbGF5KCdiYWxsX2hlJyk7XG4gICAgICAgIHRoaXMubm9kZV9jaGlja2VuLmdldENvbXBvbmVudChBbmltYXRpb25Db21wb25lbnQpLnBsYXkoJ2NoaWNrZW5fanVtcCcpO1xuICAgICAgICB0aGlzLm5vZGVfY2hpY2tlbi5nZXRDb21wb25lbnQoQW5pbWF0aW9uQ29tcG9uZW50KS5jcm9zc0ZhZGUoJ2NoaWNrZW5faWRsZScsIDAuMyk7XG4gICAgICAgIHRoaXMuX3R1cm4gPSAxO1xuICAgICAgICB0aGlzLmxiX3Njb3JlLnN0cmluZyA9IGAkeysrdGhpcy5fc2NvcmV9YDtcbiAgICAgICAgY29uc3QgdGFyZ2V0WiA9IC1CQUxMX01BWF9aICsgMiAqIEJBTExfTUFYX1ogKiBNYXRoLnJhbmRvbSgpO1xuICAgICAgICBjb25zdCB0aW1lID0gMSAvIChNYXRoLnBvdygxLjAxLCB0aGlzLl9zY29yZSkpO1xuICAgICAgICB0d2VlblV0aWwodGhpcy5fbm9kZV9iYWxsbF9wb3MpXG4gICAgICAgICAgICAuc3RvcCgpXG4gICAgICAgICAgICAudG8odGltZSwgbmV3IG1hdGguVmVjMygodGhpcy5ub2RlX2JhbGwucG9zaXRpb24ueCArIEJBTExfSU5JVF9YKSAvIDIsIEJBTExfTUFYX1kgKiAoMC44ICsgMC4yICogTWF0aC5yYW5kb20oKSksIHRhcmdldFogLyAyKSlcbiAgICAgICAgICAgIC50byh0aW1lLCBuZXcgbWF0aC5WZWMzKEJBTExfR0FNRU9WRVJfWCwgQkFMTF9NSU5fWSwgdGFyZ2V0WikpXG4gICAgICAgICAgICAuc3RhcnQoKTtcbiAgICB9XG5cbiAgICB1cGRhdGUoZGVsdGFUaW1lOiBudW1iZXIpIHtcbiAgICAgICAgaWYgKHRoaXMuX25vZGVfYmFsbGxfcG9zLnggPj0gQkFMTF9HQU1FT1ZFUl9YKSB7XG4gICAgICAgICAgICB0aGlzLmdhbWVPdmVyKCk7XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5ub2RlX2JhbGwucG9zaXRpb24gPSB0aGlzLl9ub2RlX2JhbGxsX3BvcztcbiAgICB9XG59XG4iXX0=