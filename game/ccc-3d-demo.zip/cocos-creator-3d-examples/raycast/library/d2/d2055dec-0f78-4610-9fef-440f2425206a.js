"use strict";

System.register(["cc"], function (_export, _context) {
  "use strict";

  var _decorator, director, Component, Node, CanvasComponent, CameraComponent, ModelComponent, geometry, systemEvent, SystemEventType, PhysicsSystem, LabelComponent, _dec, _dec2, _dec3, _dec4, _dec5, _dec6, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4, _descriptor5, _temp, ccclass, property, GameMgr;

  _export({
    _dec: void 0,
    _dec2: void 0,
    _dec3: void 0,
    _dec4: void 0,
    _dec5: void 0,
    _dec6: void 0,
    _class: void 0,
    _class2: void 0,
    _descriptor: void 0,
    _descriptor2: void 0,
    _descriptor3: void 0,
    _descriptor4: void 0,
    _descriptor5: void 0,
    _temp: void 0
  });

  return {
    setters: [function (_cc) {
      _decorator = _cc._decorator;
      director = _cc.director;
      Component = _cc.Component;
      Node = _cc.Node;
      CanvasComponent = _cc.CanvasComponent;
      CameraComponent = _cc.CameraComponent;
      ModelComponent = _cc.ModelComponent;
      geometry = _cc.geometry;
      systemEvent = _cc.systemEvent;
      SystemEventType = _cc.SystemEventType;
      PhysicsSystem = _cc.PhysicsSystem;
      LabelComponent = _cc.LabelComponent;
    }],
    execute: function () {
      cc._RF.push(window.module || {}, "d20553sD3hGEJ/vRA8kJSBq", "GameMgr"); // begin GameMgr


      ccclass = _decorator.ccclass;
      property = _decorator.property;

      _export("GameMgr", GameMgr = (_dec = ccclass("GameMgr"), _dec2 = property({
        type: CameraComponent
      }), _dec3 = property({
        type: Node
      }), _dec4 = property({
        type: ModelComponent
      }), _dec5 = property({
        type: CanvasComponent
      }), _dec6 = property({
        type: LabelComponent
      }), _dec(_class = (_class2 = (_temp =
      /*#__PURE__*/
      function (_Component) {
        babelHelpers.inherits(GameMgr, _Component);

        function GameMgr() {
          var _babelHelpers$getProt;

          var _this;

          babelHelpers.classCallCheck(this, GameMgr);

          for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
          }

          _this = babelHelpers.possibleConstructorReturn(this, (_babelHelpers$getProt = babelHelpers.getPrototypeOf(GameMgr)).call.apply(_babelHelpers$getProt, [this].concat(args)));
          babelHelpers.initializerDefineProperty(_this, "camera_3d", _descriptor, babelHelpers.assertThisInitialized(_this));
          babelHelpers.initializerDefineProperty(_this, "node_volleyball", _descriptor2, babelHelpers.assertThisInitialized(_this));
          babelHelpers.initializerDefineProperty(_this, "model_basketball", _descriptor3, babelHelpers.assertThisInitialized(_this));
          babelHelpers.initializerDefineProperty(_this, "canvas_2d", _descriptor4, babelHelpers.assertThisInitialized(_this));
          babelHelpers.initializerDefineProperty(_this, "label_info", _descriptor5, babelHelpers.assertThisInitialized(_this));
          _this._ray = new geometry.ray();
          return _this;
        }

        babelHelpers.createClass(GameMgr, [{
          key: "onEnable",
          value: function onEnable() {
            this.node_volleyball.on(Node.EventType.TOUCH_START, function () {
              console.log('不可能看见我');
            }, this);
            systemEvent.on(SystemEventType.TOUCH_START, this.onTouchStart, this);
          }
        }, {
          key: "onDisable",
          value: function onDisable() {
            systemEvent.off(SystemEventType.TOUCH_START, this.onTouchStart, this);
          }
        }, {
          key: "onTouchStart",
          value: function onTouchStart(touch, event) {
            this.label_info.string = '白玉无冰';
            this.camera_3d.screenPointToRay(touch._point.x, touch._point.y, this._ray); //基于物理碰撞器的射线检测

            if (PhysicsSystem.instance.raycast(this._ray)) {
              var r = PhysicsSystem.instance.raycastResults;

              for (var i = 0; i < r.length; i++) {
                var item = r[i];

                if (item.collider.node.uuid == this.node_volleyball.uuid) {
                  this.label_info.string = '点了排球';
                }
              }
            } //基于模型的射线检测


            var rs = director.getScene().renderScene;

            if (rs.raycastSingleModel(this._ray, this.model_basketball.model)) {
              var _r = rs.rayResultSingleModel;

              for (var _i = 0; _i < _r.length; _i++) {
                var _item = _r[_i];

                if (_item.node.uuid == this.model_basketball.node.uuid) {
                  this.label_info.string = '点了篮球';
                }
              }
            } //基于 UITransform 组件的射线检测


            var uiCamera = this.canvas_2d.camera;
            uiCamera.screenPointToRay(this._ray, touch._point.x, touch._point.y);

            if (rs.raycastAllCanvas(this._ray)) {
              var result = rs.rayResultCanvas;

              for (var _i2 = result.length; _i2--;) {
                var _item2 = result[_i2];

                if (_item2.node.uuid == this.label_info.node.uuid) {
                  this.label_info.string = '点了文字';
                }
              }
            }
          }
        }]);
        return GameMgr;
      }(Component), _temp), (_descriptor = babelHelpers.applyDecoratedDescriptor(_class2.prototype, "camera_3d", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor2 = babelHelpers.applyDecoratedDescriptor(_class2.prototype, "node_volleyball", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor3 = babelHelpers.applyDecoratedDescriptor(_class2.prototype, "model_basketball", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor4 = babelHelpers.applyDecoratedDescriptor(_class2.prototype, "canvas_2d", [_dec5], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor5 = babelHelpers.applyDecoratedDescriptor(_class2.prototype, "label_info", [_dec6], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      })), _class2)) || _class)); // 欢迎关注公众号【白玉无冰】


      cc._RF.pop(); // end GameMgr

    }
  };
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInByb2plY3Q6Ly8vYXNzZXRzL3NyYy9HYW1lTWdyLnRzIl0sIm5hbWVzIjpbIl9kZWNvcmF0b3IiLCJkaXJlY3RvciIsIkNvbXBvbmVudCIsIk5vZGUiLCJDYW52YXNDb21wb25lbnQiLCJDYW1lcmFDb21wb25lbnQiLCJNb2RlbENvbXBvbmVudCIsImdlb21ldHJ5Iiwic3lzdGVtRXZlbnQiLCJTeXN0ZW1FdmVudFR5cGUiLCJQaHlzaWNzU3lzdGVtIiwiTGFiZWxDb21wb25lbnQiLCJjY2NsYXNzIiwicHJvcGVydHkiLCJHYW1lTWdyIiwidHlwZSIsIl9yYXkiLCJyYXkiLCJub2RlX3ZvbGxleWJhbGwiLCJvbiIsIkV2ZW50VHlwZSIsIlRPVUNIX1NUQVJUIiwiY29uc29sZSIsImxvZyIsIm9uVG91Y2hTdGFydCIsIm9mZiIsInRvdWNoIiwiZXZlbnQiLCJsYWJlbF9pbmZvIiwic3RyaW5nIiwiY2FtZXJhXzNkIiwic2NyZWVuUG9pbnRUb1JheSIsIl9wb2ludCIsIngiLCJ5IiwiaW5zdGFuY2UiLCJyYXljYXN0IiwiciIsInJheWNhc3RSZXN1bHRzIiwiaSIsImxlbmd0aCIsIml0ZW0iLCJjb2xsaWRlciIsIm5vZGUiLCJ1dWlkIiwicnMiLCJnZXRTY2VuZSIsInJlbmRlclNjZW5lIiwicmF5Y2FzdFNpbmdsZU1vZGVsIiwibW9kZWxfYmFza2V0YmFsbCIsIm1vZGVsIiwicmF5UmVzdWx0U2luZ2xlTW9kZWwiLCJ1aUNhbWVyYSIsImNhbnZhc18yZCIsImNhbWVyYSIsInJheWNhc3RBbGxDYW52YXMiLCJyZXN1bHQiLCJyYXlSZXN1bHRDYW52YXMiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQVNBLE1BQUFBLFUsT0FBQUEsVTtBQUFZQyxNQUFBQSxRLE9BQUFBLFE7QUFBVUMsTUFBQUEsUyxPQUFBQSxTO0FBQVdDLE1BQUFBLEksT0FBQUEsSTtBQUFNQyxNQUFBQSxlLE9BQUFBLGU7QUFBNkJDLE1BQUFBLGUsT0FBQUEsZTtBQUFpQkMsTUFBQUEsYyxPQUFBQSxjO0FBQWdCQyxNQUFBQSxRLE9BQUFBLFE7QUFBaUJDLE1BQUFBLFcsT0FBQUEsVztBQUFhQyxNQUFBQSxlLE9BQUFBLGU7QUFBaUJDLE1BQUFBLGEsT0FBQUEsYTtBQUFlQyxNQUFBQSxjLE9BQUFBLGM7Ozs4RUFFbkc7OztBQURqRUMsTUFBQUEsTyxHQUFzQlosVSxDQUF0QlksTztBQUFTQyxNQUFBQSxRLEdBQWFiLFUsQ0FBYmEsUTs7eUJBR0pDLE8sV0FEWkYsT0FBTyxDQUFDLFNBQUQsQyxVQUVIQyxRQUFRLENBQUM7QUFBRUUsUUFBQUEsSUFBSSxFQUFFVjtBQUFSLE9BQUQsQyxVQUdSUSxRQUFRLENBQUM7QUFBRUUsUUFBQUEsSUFBSSxFQUFFWjtBQUFSLE9BQUQsQyxVQUdSVSxRQUFRLENBQUM7QUFBRUUsUUFBQUEsSUFBSSxFQUFFVDtBQUFSLE9BQUQsQyxVQUdSTyxRQUFRLENBQUM7QUFBRUUsUUFBQUEsSUFBSSxFQUFFWDtBQUFSLE9BQUQsQyxVQUdSUyxRQUFRLENBQUM7QUFBRUUsUUFBQUEsSUFBSSxFQUFFSjtBQUFSLE9BQUQsQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztnQkFHREssSSxHQUFxQixJQUFJVCxRQUFRLENBQUNVLEdBQWIsRTs7Ozs7O3FDQUVsQjtBQUNQLGlCQUFLQyxlQUFMLENBQXFCQyxFQUFyQixDQUF3QmhCLElBQUksQ0FBQ2lCLFNBQUwsQ0FBZUMsV0FBdkMsRUFBb0QsWUFBTTtBQUN0REMsY0FBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksUUFBWjtBQUNILGFBRkQsRUFFRyxJQUZIO0FBSUFmLFlBQUFBLFdBQVcsQ0FBQ1csRUFBWixDQUFlVixlQUFlLENBQUNZLFdBQS9CLEVBQTRDLEtBQUtHLFlBQWpELEVBQStELElBQS9EO0FBRUg7OztzQ0FFVztBQUNSaEIsWUFBQUEsV0FBVyxDQUFDaUIsR0FBWixDQUFnQmhCLGVBQWUsQ0FBQ1ksV0FBaEMsRUFBNkMsS0FBS0csWUFBbEQsRUFBZ0UsSUFBaEU7QUFDSDs7O3VDQUVZRSxLLEVBQWNDLEssRUFBbUI7QUFDMUMsaUJBQUtDLFVBQUwsQ0FBZ0JDLE1BQWhCLEdBQXlCLE1BQXpCO0FBQ0EsaUJBQUtDLFNBQUwsQ0FBZUMsZ0JBQWYsQ0FBZ0NMLEtBQUssQ0FBQ00sTUFBTixDQUFhQyxDQUE3QyxFQUFnRFAsS0FBSyxDQUFDTSxNQUFOLENBQWFFLENBQTdELEVBQWdFLEtBQUtsQixJQUFyRSxFQUYwQyxDQUcxQzs7QUFDQSxnQkFBSU4sYUFBYSxDQUFDeUIsUUFBZCxDQUF1QkMsT0FBdkIsQ0FBK0IsS0FBS3BCLElBQXBDLENBQUosRUFBK0M7QUFDM0Msa0JBQU1xQixDQUFDLEdBQUczQixhQUFhLENBQUN5QixRQUFkLENBQXVCRyxjQUFqQzs7QUFDQSxtQkFBSyxJQUFJQyxDQUFDLEdBQUcsQ0FBYixFQUFnQkEsQ0FBQyxHQUFHRixDQUFDLENBQUNHLE1BQXRCLEVBQThCRCxDQUFDLEVBQS9CLEVBQW1DO0FBQy9CLG9CQUFNRSxJQUFJLEdBQUdKLENBQUMsQ0FBQ0UsQ0FBRCxDQUFkOztBQUNBLG9CQUFJRSxJQUFJLENBQUNDLFFBQUwsQ0FBY0MsSUFBZCxDQUFtQkMsSUFBbkIsSUFBMkIsS0FBSzFCLGVBQUwsQ0FBcUIwQixJQUFwRCxFQUEwRDtBQUN0RCx1QkFBS2hCLFVBQUwsQ0FBZ0JDLE1BQWhCLEdBQXlCLE1BQXpCO0FBQ0g7QUFDSjtBQUNKLGFBWnlDLENBYzFDOzs7QUFDQSxnQkFBTWdCLEVBQUUsR0FBRzVDLFFBQVEsQ0FBQzZDLFFBQVQsR0FBb0JDLFdBQS9COztBQUNBLGdCQUFJRixFQUFFLENBQUNHLGtCQUFILENBQXNCLEtBQUtoQyxJQUEzQixFQUFpQyxLQUFLaUMsZ0JBQUwsQ0FBc0JDLEtBQXZELENBQUosRUFBbUU7QUFDL0Qsa0JBQU1iLEVBQUMsR0FBR1EsRUFBRSxDQUFDTSxvQkFBYjs7QUFDQSxtQkFBSyxJQUFJWixFQUFDLEdBQUcsQ0FBYixFQUFnQkEsRUFBQyxHQUFHRixFQUFDLENBQUNHLE1BQXRCLEVBQThCRCxFQUFDLEVBQS9CLEVBQW1DO0FBQy9CLG9CQUFNRSxLQUFJLEdBQUdKLEVBQUMsQ0FBQ0UsRUFBRCxDQUFkOztBQUNBLG9CQUFJRSxLQUFJLENBQUNFLElBQUwsQ0FBVUMsSUFBVixJQUFrQixLQUFLSyxnQkFBTCxDQUFzQk4sSUFBdEIsQ0FBMkJDLElBQWpELEVBQXVEO0FBQ25ELHVCQUFLaEIsVUFBTCxDQUFnQkMsTUFBaEIsR0FBeUIsTUFBekI7QUFDSDtBQUNKO0FBQ0osYUF4QnlDLENBMEIxQzs7O0FBQ0EsZ0JBQU11QixRQUFRLEdBQUcsS0FBS0MsU0FBTCxDQUFlQyxNQUFoQztBQUNBRixZQUFBQSxRQUFRLENBQUNyQixnQkFBVCxDQUEwQixLQUFLZixJQUEvQixFQUFxQ1UsS0FBSyxDQUFDTSxNQUFOLENBQWFDLENBQWxELEVBQXFEUCxLQUFLLENBQUNNLE1BQU4sQ0FBYUUsQ0FBbEU7O0FBQ0EsZ0JBQUlXLEVBQUUsQ0FBQ1UsZ0JBQUgsQ0FBb0IsS0FBS3ZDLElBQXpCLENBQUosRUFBb0M7QUFDaEMsa0JBQU13QyxNQUFNLEdBQUdYLEVBQUUsQ0FBQ1ksZUFBbEI7O0FBQ0EsbUJBQUssSUFBSWxCLEdBQUMsR0FBR2lCLE1BQU0sQ0FBQ2hCLE1BQXBCLEVBQTRCRCxHQUFDLEVBQTdCLEdBQWtDO0FBQzlCLG9CQUFNRSxNQUFJLEdBQUdlLE1BQU0sQ0FBQ2pCLEdBQUQsQ0FBbkI7O0FBQ0Esb0JBQUlFLE1BQUksQ0FBQ0UsSUFBTCxDQUFVQyxJQUFWLElBQWtCLEtBQUtoQixVQUFMLENBQWdCZSxJQUFoQixDQUFxQkMsSUFBM0MsRUFBaUQ7QUFDN0MsdUJBQUtoQixVQUFMLENBQWdCQyxNQUFoQixHQUF5QixNQUF6QjtBQUNIO0FBQ0o7QUFDSjtBQUNKOzs7UUFyRXdCM0IsUzs7Ozs7aUJBRWEsSTs7Ozs7OztpQkFHTCxJOzs7Ozs7O2lCQUdXLEk7Ozs7Ozs7aUJBR04sSTs7Ozs7OztpQkFHQSxJOztrQ0EyRDFDOzs7b0JBM0VrQiIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IF9kZWNvcmF0b3IsIGRpcmVjdG9yLCBDb21wb25lbnQsIE5vZGUsIENhbnZhc0NvbXBvbmVudCwgRXZlbnRUb3VjaCwgQ2FtZXJhQ29tcG9uZW50LCBNb2RlbENvbXBvbmVudCwgZ2VvbWV0cnksIFRvdWNoLCBzeXN0ZW1FdmVudCwgU3lzdGVtRXZlbnRUeXBlLCBQaHlzaWNzU3lzdGVtLCBMYWJlbENvbXBvbmVudCB9IGZyb20gXCJjY1wiO1xuY29uc3QgeyBjY2NsYXNzLCBwcm9wZXJ0eSB9ID0gX2RlY29yYXRvcjtcblxuQGNjY2xhc3MoXCJHYW1lTWdyXCIpXG5leHBvcnQgY2xhc3MgR2FtZU1nciBleHRlbmRzIENvbXBvbmVudCB7XG4gICAgQHByb3BlcnR5KHsgdHlwZTogQ2FtZXJhQ29tcG9uZW50IH0pXG4gICAgcmVhZG9ubHkgY2FtZXJhXzNkOiBDYW1lcmFDb21wb25lbnQgPSBudWxsO1xuXG4gICAgQHByb3BlcnR5KHsgdHlwZTogTm9kZSB9KVxuICAgIHJlYWRvbmx5IG5vZGVfdm9sbGV5YmFsbDogTm9kZSA9IG51bGw7XG5cbiAgICBAcHJvcGVydHkoeyB0eXBlOiBNb2RlbENvbXBvbmVudCB9KVxuICAgIHJlYWRvbmx5IG1vZGVsX2Jhc2tldGJhbGw6IE1vZGVsQ29tcG9uZW50ID0gbnVsbDtcblxuICAgIEBwcm9wZXJ0eSh7IHR5cGU6IENhbnZhc0NvbXBvbmVudCB9KVxuICAgIHJlYWRvbmx5IGNhbnZhc18yZDogQ2FudmFzQ29tcG9uZW50ID0gbnVsbDtcblxuICAgIEBwcm9wZXJ0eSh7IHR5cGU6IExhYmVsQ29tcG9uZW50IH0pXG4gICAgcmVhZG9ubHkgbGFiZWxfaW5mbzogTGFiZWxDb21wb25lbnQgPSBudWxsO1xuXG4gICAgcHJpdmF0ZSBfcmF5OiBnZW9tZXRyeS5yYXkgPSBuZXcgZ2VvbWV0cnkucmF5KCk7XG5cbiAgICBvbkVuYWJsZSgpIHtcbiAgICAgICAgdGhpcy5ub2RlX3ZvbGxleWJhbGwub24oTm9kZS5FdmVudFR5cGUuVE9VQ0hfU1RBUlQsICgpID0+IHtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKCfkuI3lj6/og73nnIvop4HmiJEnKVxuICAgICAgICB9LCB0aGlzKTtcblxuICAgICAgICBzeXN0ZW1FdmVudC5vbihTeXN0ZW1FdmVudFR5cGUuVE9VQ0hfU1RBUlQsIHRoaXMub25Ub3VjaFN0YXJ0LCB0aGlzKTtcblxuICAgIH1cblxuICAgIG9uRGlzYWJsZSgpIHtcbiAgICAgICAgc3lzdGVtRXZlbnQub2ZmKFN5c3RlbUV2ZW50VHlwZS5UT1VDSF9TVEFSVCwgdGhpcy5vblRvdWNoU3RhcnQsIHRoaXMpO1xuICAgIH1cblxuICAgIG9uVG91Y2hTdGFydCh0b3VjaDogVG91Y2gsIGV2ZW50OiBFdmVudFRvdWNoKSB7XG4gICAgICAgIHRoaXMubGFiZWxfaW5mby5zdHJpbmcgPSAn55m9546J5peg5YawJ1xuICAgICAgICB0aGlzLmNhbWVyYV8zZC5zY3JlZW5Qb2ludFRvUmF5KHRvdWNoLl9wb2ludC54LCB0b3VjaC5fcG9pbnQueSwgdGhpcy5fcmF5KTtcbiAgICAgICAgLy/ln7rkuo7niannkIbnorDmkp7lmajnmoTlsITnur/mo4DmtYtcbiAgICAgICAgaWYgKFBoeXNpY3NTeXN0ZW0uaW5zdGFuY2UucmF5Y2FzdCh0aGlzLl9yYXkpKSB7XG4gICAgICAgICAgICBjb25zdCByID0gUGh5c2ljc1N5c3RlbS5pbnN0YW5jZS5yYXljYXN0UmVzdWx0cztcbiAgICAgICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgci5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgICAgIGNvbnN0IGl0ZW0gPSByW2ldO1xuICAgICAgICAgICAgICAgIGlmIChpdGVtLmNvbGxpZGVyLm5vZGUudXVpZCA9PSB0aGlzLm5vZGVfdm9sbGV5YmFsbC51dWlkKSB7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMubGFiZWxfaW5mby5zdHJpbmcgPSAn54K55LqG5o6S55CDJ1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIC8v5Z+65LqO5qih5Z6L55qE5bCE57q/5qOA5rWLXG4gICAgICAgIGNvbnN0IHJzID0gZGlyZWN0b3IuZ2V0U2NlbmUoKS5yZW5kZXJTY2VuZTtcbiAgICAgICAgaWYgKHJzLnJheWNhc3RTaW5nbGVNb2RlbCh0aGlzLl9yYXksIHRoaXMubW9kZWxfYmFza2V0YmFsbC5tb2RlbCkpIHtcbiAgICAgICAgICAgIGNvbnN0IHIgPSBycy5yYXlSZXN1bHRTaW5nbGVNb2RlbDtcbiAgICAgICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgci5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgICAgIGNvbnN0IGl0ZW0gPSByW2ldO1xuICAgICAgICAgICAgICAgIGlmIChpdGVtLm5vZGUudXVpZCA9PSB0aGlzLm1vZGVsX2Jhc2tldGJhbGwubm9kZS51dWlkKSB7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMubGFiZWxfaW5mby5zdHJpbmcgPSAn54K55LqG56+u55CDJ1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIC8v5Z+65LqOIFVJVHJhbnNmb3JtIOe7hOS7tueahOWwhOe6v+ajgOa1i1xuICAgICAgICBjb25zdCB1aUNhbWVyYSA9IHRoaXMuY2FudmFzXzJkLmNhbWVyYTtcbiAgICAgICAgdWlDYW1lcmEuc2NyZWVuUG9pbnRUb1JheSh0aGlzLl9yYXksIHRvdWNoLl9wb2ludC54LCB0b3VjaC5fcG9pbnQueSk7XG4gICAgICAgIGlmIChycy5yYXljYXN0QWxsQ2FudmFzKHRoaXMuX3JheSkpIHtcbiAgICAgICAgICAgIGNvbnN0IHJlc3VsdCA9IHJzLnJheVJlc3VsdENhbnZhcztcbiAgICAgICAgICAgIGZvciAobGV0IGkgPSByZXN1bHQubGVuZ3RoOyBpLS07KSB7XG4gICAgICAgICAgICAgICAgY29uc3QgaXRlbSA9IHJlc3VsdFtpXTtcbiAgICAgICAgICAgICAgICBpZiAoaXRlbS5ub2RlLnV1aWQgPT0gdGhpcy5sYWJlbF9pbmZvLm5vZGUudXVpZCkge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLmxhYmVsX2luZm8uc3RyaW5nID0gJ+eCueS6huaWh+Wtlyc7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxufVxuXG5cbi8vIOasoui/juWFs+azqOWFrOS8l+WPt+OAkOeZveeOieaXoOWGsOOAkSJdfQ==