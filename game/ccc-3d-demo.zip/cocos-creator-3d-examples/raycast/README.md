

[射线检测](https://mp.weixin.qq.com/s/ATbpJNKromv17ke1cWgDDw)

cocos creator 3d v1.0.1  

![](./../img/raycast.gif)



---

![](./../img/about.jpg)