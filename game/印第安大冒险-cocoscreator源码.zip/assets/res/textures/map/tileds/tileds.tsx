<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.5" name="tileds" tilewidth="16" tileheight="16" tilecount="420" columns="28">
 <image source="tileds.png" width="448" height="240"/>
</tileset>
