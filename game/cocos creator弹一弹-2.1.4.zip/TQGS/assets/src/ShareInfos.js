cc.Class({
    extends: cc.Component,
    statics: {
        init: function() {
            this.Infos = [{
                text: "弹球高手，一起来弹一弹",
                url: "https://mmocgame.qpic.cn/wechatgame/VW5UT1uqQ5rwQ7DB7JQWaAk07hvL2tWD1OV4WAImxU7J2ic7ButM0MMktdHexUgJd/0"
            }, {
                text: "弹球高手，一起来弹一弹",
                url: "https://mmocgame.qpic.cn/wechatgame/VW5UT1uqQ5rwQ7DB7JQWaAk07hvL2tWD1OV4WAImxU7J2ic7ButM0MMktdHexUgJd/0"
            }, {
                text: "全民弹一弹,弹球高手等你来战",
                url: "https://mmocgame.qpic.cn/wechatgame/VW5UT1uqQ5rwQ7DB7JQWaAk07hvL2tWD1OV4WAImxU7J2ic7ButM0MMktdHexUgJd/0"
            }, {
                text: "全民弹一弹,弹球高手等你来战",
                url: "https://mmocgame.qpic.cn/wechatgame/VW5UT1uqQ5rwQ7DB7JQWaAk07hvL2tWD1OV4WAImxU7J2ic7ButM0MMktdHexUgJd/0"
            }]
        },
        getShareInfos: function(t) {
            return this.Infos[t]
        }
    }
});