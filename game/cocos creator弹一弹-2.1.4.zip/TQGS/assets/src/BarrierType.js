module.exports = cc.Enum({
    IsBomb: 1,
    IsAddBall: 2,
    IsAddScore: 3,
    IsHell: 4,
    IsCuty: 5
});