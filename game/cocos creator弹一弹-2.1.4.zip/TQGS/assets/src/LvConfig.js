cc.Class({
    name: "LvConfig",
    statics: {}
});