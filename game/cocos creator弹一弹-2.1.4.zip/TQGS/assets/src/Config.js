

module.exports = {
    groupBallInGame: "ballInGame",
    groupBallInRecycle: "ballInRecycle",
    groupBallInHell: "ballInHell",
    bomb: "bomb",
    barrier: "barrier",
    default: "default"
}