

module.exports = cc.Enum({
    PointA: 1,
    PointB: 2,
    PointC: 3,
    PointD: 4,
    PointE: 5,
    PointF: 6,
    PointG: 7,
    PointH: 8,
    PointI: 9,
    PointJ: 10
});