# 六边形消除  
玩法有改动的六边形消除


### 兼容

cocos creator 2.0+


在线试玩: [体验地址](https://zx6733090.github.io/)
