##1 搭建项目开发环境
1.1 安装 CocosCreator

##2 打开项目
2.1 选择打开其他项目，然后选择本项目目录

2.2 项目初始化后你会看到

![Image][1]

##3 运行项目
3.1 可以选择浏览器和模拟器运行项目

![Image][5]

3.2 点击小三角运行项目

![Image][2]

*浏览器运行*

![Image][4]

*模拟器运行*

![Image][3]

[1]: https://raw.githubusercontent.com/liang3472/BasketBall/master/screenshot/screenshot1.png
[2]: https://raw.githubusercontent.com/liang3472/BasketBall/master/screenshot/screenshot2.png
[3]: https://raw.githubusercontent.com/liang3472/BasketBall/master/screenshot/screenshot3.png
[4]: https://raw.githubusercontent.com/liang3472/BasketBall/master/screenshot/screenshot4.png
[5]: https://raw.githubusercontent.com/liang3472/BasketBall/master/screenshot/screenshot5.png
