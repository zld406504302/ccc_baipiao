﻿
namespace CL.View.Entity.Interface
{
    public class udv_ParaAccBalance
    {
        public string username { get; set; }
    }
}
