﻿
namespace CL.View.Entity.Coupons
{
    /// <summary>
    /// 购彩券余额
    /// </summary>
    public class udv_Coupons
    {
        public long pid { set; get; }

        public long ba { set; get; }
    }
}
