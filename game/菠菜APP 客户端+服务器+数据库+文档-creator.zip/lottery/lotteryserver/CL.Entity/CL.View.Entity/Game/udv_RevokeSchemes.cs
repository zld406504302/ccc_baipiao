﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CL.View.Entity.Game
{
    public class udv_RevokeSchemes
    {
        public long ssid { set; get; }
        public long uuid { set; get; }
        public string issue { set; get; }
        public string name { set; get; }
        public string num { set; get; }
        public long amount { set; get; }
        public string mobile { set; get; }
    }
}
