﻿using CL.Json.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CL.Entity.Json.Omission
{
    public class OmissionResult : JsonResult
    {
        public string Data { set; get; }
    }
}
