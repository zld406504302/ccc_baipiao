﻿
namespace CL.Json.Entity
{
    public class JsonResult
    {
        public int Code { set; get; }
        public string Msg { set; get; }
    }
}
