
cc.Class({
    extends: cc.Component,
    onLoad(){
      this.node.on('touchend',()=>{CL.SOUND.play_effect()},this)
    }
});

