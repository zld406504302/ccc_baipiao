cc.Class({
    extends: cc.Component,

    properties: {
    },

    // use this for initialization
    onLoad: function () {
    },

    playEnd:function(){
        this.node.dispatchEvent( new cc.Event.EventCustom('playEnd', true) );
    },

});
