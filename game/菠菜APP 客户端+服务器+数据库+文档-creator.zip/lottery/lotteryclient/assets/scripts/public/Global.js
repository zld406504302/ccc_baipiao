window.CL = {
    HTTP:null,//HTTP通讯
    NET:null,//sokectio通讯
    MANAGECENTER:null,
    SOUND:null
}