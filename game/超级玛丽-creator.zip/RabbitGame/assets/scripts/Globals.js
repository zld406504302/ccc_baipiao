window.Global = {
    isGotCoin: false,
    addSpeed: 1,
    level2Open:false,
    enemyIsAlive:true,
    playIsAlive:true,
    volume:0,
};