
cc.Class({
    extends: cc.Component,

    properties: {
        word_normal: cc.SpriteFrame,
        word_correct: cc.SpriteFrame,
        word_tile: cc.SpriteFrame,
        word_selected: cc.SpriteFrame,
        word_unselected: cc.SpriteFrame,
        word_wrong: cc.SpriteFrame,
    },

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start () {

    },

    // update (dt) {},
});
