cc.Class({
    extends: cc.Component,

    properties: {
    },

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start () {
    },

    btn_start() {
        sceneManager.show("game", 28)
    }

    // update (dt) {},
});
