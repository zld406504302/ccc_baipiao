/*
 * @Author: xxZhang
 * @Date: 2019-11-27 19:07:01
 * @Description: 全局变量定义处
 */
import { AppMgr } from "./AppManager";

window["app"] = AppMgr;