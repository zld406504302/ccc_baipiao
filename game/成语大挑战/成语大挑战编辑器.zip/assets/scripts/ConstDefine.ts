/*
 * @Author: xxZhang
 * @Date: 2019-11-29 09:53:34
 * @Description: 常量定义
 */

// 格子类别
export const GRID_STATUS = {
    EMPTY: 1,                   // 空
    HAS_CHAR: 2,                // 有词
    REMOVE_CHAR: 3,             // 移除词
}
