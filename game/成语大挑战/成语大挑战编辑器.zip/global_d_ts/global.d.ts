/*
 * @Author: xxZhang
 * @Date: 2019-11-27 19:08:34
 * @Description: 
 */
import AppManager from "../assets/scripts/AppManager";

declare let app: AppManager;

