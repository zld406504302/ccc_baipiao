/*
 * @Description: In User Settings Edit
 * @Author: your name
 * @Date: 2019-10-08 11:21:22
 * @LastEditTime: 2019-10-11 11:12:10
 * @LastEditors: Please set LastEditors
 */

cc.Class({
    extends: cc.Component,

    properties: {
        startCover: {
            default: null,
            type: cc.Node,
            displayName: "开始面"
        },
        game: {
            default: null,
            type: cc.Node,
            displayName: "游戏面"
        },
    },

    onLoad: function () {
        this.node.on("startActive", this.startActive, this);
        this.gameScript = this.game.getComponent("polar-game");
    },

    startActive(event) {
        let detail = event.detail;
        if (detail) {
            if (detail.active) {
                this.startCover.active = true;
            } else {
                switch (detail.game) {
                    case "easy":
                        this.gameScript.gameInit(15);
                        break;
                    case "difficult":
                        this.gameScript.gameInit(5);
                        break;            
                }
            }
        };
    },

    onEnable: function () {
        cc.director.getCollisionManager().enabled = true;
        //cc.director.getCollisionManager().enabledDebugDraw = true;
    },

    onDisable: function () {
        cc.director.getCollisionManager().enabled = false;
        //cc.director.getCollisionManager().enabledDebugDraw = false;
    },
});
