<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.3.4" name="floor" tilewidth="32" tileheight="32" tilecount="7" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="4">
  <image width="32" height="32" source="tile/tile_dirt001.png"/>
 </tile>
 <tile id="5">
  <image width="32" height="32" source="tile/tile_grass001.png"/>
 </tile>
 <tile id="6">
  <image width="32" height="32" source="tile/tile_lab001.png"/>
 </tile>
 <tile id="7">
  <image width="32" height="32" source="tile/tile_water001.png"/>
 </tile>
 <tile id="8">
  <image width="32" height="32" source="tile/tile_lab002.png"/>
 </tile>
 <tile id="9">
  <image width="32" height="32" source="tile/tile_grass002.png"/>
 </tile>
 <tile id="10">
  <image width="32" height="32" source="tile/tile_dark001.png"/>
 </tile>
</tileset>
