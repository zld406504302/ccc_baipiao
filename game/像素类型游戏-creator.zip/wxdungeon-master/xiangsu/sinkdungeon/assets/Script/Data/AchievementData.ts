export default class AchievementData{
    index = 0;
    monsters :{[key:string]:number}={};
    playerLifes = 0;
}