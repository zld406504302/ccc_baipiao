cc.Class({
    extends: cc.Component,

    properties: {
        ["分数"]: 0,
    },

    // use this for initialization
    onLoad: function () {

    },

    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});
