"use strict";
cc._RF.push(module, 'f90693GTmlGS7T5fknnDNTy', 'GameData');
// script/GameData.js

"use strict";

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

cc.Class({
    extends: cc.Component,

    properties: _defineProperty({}, "分数", 0),

    // use this for initialization
    onLoad: function onLoad() {}

    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});

cc._RF.pop();