var ps = require('PS');

cc.Class({
    extends: cc.Component,

    properties: {
        ui: cc.Node,
        hero: cc.Node, // 主角
        pre_pillar: cc.Prefab, // 柱子预制
        pillar_container: cc.Node, // 柱子容器
        ship: cc.Node, // 船
        rope1: cc.Node, // 绳子
        rope2: cc.Node,
        logo: cc.Node, // logo
        btn_start: cc.Node, // 开始游戏按钮
        speed: 100, // 柱子下移速度
        panel_renew: cc.Node, // 复活面板
        lbl_score: cc.Label, // 得分
        lbl_coin: cc.Label, // 金币
        panel_gameOver: cc.Node, // 游戏结束面板
        lbl_gameOverScore: cc.Label, // 游戏结束面板得分
        lbl_gameOverCoin: cc.Label, // 游戏结束面板金币
        label_best_score: cc.Label, // 游戏结束面板最高分
        guide: cc.Node, // 游戏引导
        audio_node: cc.Node, // 音效

        panel_setting: cc.Node, // 设置面板
        btn_music_on: cc.Node,
        btn_music_off: cc.Node,
        btn_effect_on: cc.Node,
        btn_effect_off: cc.Node,

        panel_rank: cc.Node, // 排行榜面板

        shareImgs: [cc.Texture2D], // 分享图片

        pre_alert: cc.Prefab, // 弹窗
        particle_bone: cc.Prefab, // 骨头粒子
        // decorationNode: cc.Node, // 装饰节点
        particle_click: cc.Prefab, // 点击粒子预制

        btn_pause: cc.Node, // 暂停按钮
        panel_pause: cc.Node, // 暂停面板

        panel_get_drumstick: cc.Node, // 获得鸡腿面板
        panel_money: cc.Node, // 领现金面板

        panel_box: cc.Node, // 宝箱面板
        icon_item: cc.Node, // 道具图标
        spr_speed: cc.SpriteFrame, // 加速道具图标
        spr_magnet: cc.SpriteFrame, // 磁铁道具图标
        item_description: cc.Label, // 道具描述

        btn_drumstick_renew: cc.Node, // 鸡腿复活按钮
        // lbl_drumstick_num: cc.Label, // 鸡腿复活数量
    },

    // LIFE-CYCLE CALLBACKS:

    onLoad () {
        cc.view.setDesignResolutionSize(750, 1334, cc.ResolutionPolicy.EXACT_FIT);
        cc.director.getCollisionManager().enabled = true;
        // 开启右上角分享
        if(window.wx){
            window.wx.showShareMenu();
            var idx = Math.floor(Math.random() * 4);
            var that = this;
            window.wx.onShareAppMessage(function () {
                return {
                  title: '这个游戏福利超级好！！！有鸡腿吃还能领钱！！！',
                  imageUrl:that.shareImgs[idx]
                }
            })
            wx.updateShareMenu({
                withShareTicket: true
            })

            // 云开发初始化
            wx.cloud.init({
                env: 'climb1-release'
              })
        };
        ps.createBannerAd();
        ps.createVideoAd();
        ps.createGameClub();
    },

    start() {
        this.audio = this.audio_node.getComponent('audio'); // 音乐
        this.audio.playBgm();
        this.isMoving = false; // 柱子是否下移
        this.createPillar();
        // 注册点击事件
        this.node.on('touchstart', function (e) {
            // 点击粒子特效
            var particle = cc.instantiate(this.particle_click);
            var pos = this.node.convertToNodeSpaceAR(e.getLocation());
            particle.setPosition(pos);
            this.node.addChild(particle);

            if (pos.x < 0) {
                // 点击左边屏幕
                this.heroMoveLeft();
            } else {
                // 点击右边屏幕
                this.heroMoveRight();
            }
        }.bind(this)); 
        this.initData();
        this.setAnim();
        this.initPanelSetting();
    },

    // 初始化数据
    initData(){
        this.oldScore = cc.sys.localStorage.getItem("climb1-score");
        if(this.oldScore){
            this.lbl_score.string = "最高：" + this.oldScore + '米';
        }else{
            this.oldScore = 0;
            this.lbl_score.string = '最高：0米';
        }

        this.oldCoin = cc.sys.localStorage.getItem("climb1-coin") - 0;
        if(this.oldCoin){
            this.lbl_coin.string =  this.oldCoin;
        }else{
            this.oldCoin = 0;
            this.lbl_coin.string = '0';
        }
    },

    // 设置船和柱子的动画
    setAnim(){
        // 船动画
        var shipAction = cc.sequence(cc.moveBy(2,0,30),cc.moveBy(2,0,-30)).repeatForever();
        this.ship.runAction(shipAction);
        this.pillar_container.runAction(shipAction.clone());

        // 绳子动画
        this.rope1.runAction(shipAction.clone());
        this.rope2.runAction(shipAction.clone());
        
        // logo动画
        var logoAction = cc.repeatForever(cc.sequence(cc.scaleTo(5,1.1,1.1),cc.scaleTo(5,1,1)));
        this.logo.runAction(logoAction);

         // 开始按钮动画
        //  var btnAction = cc.repeatForever(cc.sequence(cc.scaleTo(1,1.05,1.05),cc.scaleTo(1,1,1)));
        var btnAction = cc.repeatForever(cc.sequence(cc.jumpBy(1,0,0,10,3),cc.delayTime(4))); 
        this.btn_start.runAction(btnAction);
    },

    // 停止船和柱子的动画
    stopAnim(){
        this.ship.stopAllActions();
        this.ship.setPosition(0,-491);
        this.pillar_container.stopAllActions();
        this.pillar_container.setPosition(0,0);
    },

    // 打开设置面板
    openSetting(){
        ps.hideGameClub();
        this.audio.playEffect('click');
        this.panel_setting.active = true;
    },
    // 关闭设置面板
    closeSetting(){
        ps.showGameClub();
        this.audio.playEffect('click');
        this.panel_setting.active = false;
    },

    //初始化设置面板
    initPanelSetting(){
        this.btn_music_on.active = !ps.isMusicOn;
        this.btn_music_off.active = ps.isMusicOn;
        this.btn_effect_on.active = !ps.isEffectOn;
        this.btn_effect_off.active = ps.isEffectOn;
    },

    // 开启音乐
    openMusic(){
        this.audio.playEffect('click');
        this.btn_music_on.active = false;
        this.btn_music_off.active = true;
        ps.isMusicOn = true;
        this.audio.playBgm();
    },

    // 关闭音乐
    closeMusic(){
        this.audio.playEffect('click');
        this.btn_music_on.active = true;
        this.btn_music_off.active = false;
        ps.isMusicOn = false;
        this.audio.stopAll();
    },
    
    // 开启音效
    openEffect(){
        this.audio.playEffect('click');
        this.btn_effect_on.active = false;
        this.btn_effect_off.active = true;
        ps.isEffectOn = true;
    },

    // 关闭音效
    closeEffect(){
        this.audio.playEffect('click');
        this.btn_effect_on.active = true;
        this.btn_effect_off.active = false;
        ps.isEffectOn = false;
    },

    // 开始游戏
    startGame() {
        ps.hideGameClub();
        this.stopAnim();
        this.audio.playEffect('click');
        this.ui.active = false;
        this.btn_pause.active = true;
        this.guide.active = true;
        this.scheduleOnce(function(){
            this.guide.active = false;
        }.bind(this),4);
        this.initGame();
    },

    // 初始化游戏
    initGame(){
        this.renewTimes = 0;
        this.isMoving = true;
        this.score = 0;
        this.coin = 0; 
        this.hero.y = -667;
        this.speed = 250;
        this.schedule(this.heroMoveLeft, 0.11, 2);
        ps.showBannerAd();
    },

    // 暂停游戏
    pauseGame(){
        this.getComponent('rank').removeRank();
        ps.hideBannerAd();
        this.scheduleOnce(function(){
            ps.showBannerAd();
            this.panel_pause.active = true;
            cc.director.pause();
        },0.2)
        
    },

    // 继续游戏
    resumeGame(){
        ps.hideBannerAd();
        this.scheduleOnce(function(){
            ps.showBannerAd();
        },0.5)
        cc.director.resume();
        this.panel_pause.active = false;
    },


    // 创建柱子
    createPillar(){
        if(this.pillar1){
            this.pillar1.removeFromParent();
        }
        if(this.pillar2){
            this.pillar2.removeFromParent();
        }
        this.pillar1 = cc.instantiate(this.pre_pillar);
        this.pillar_container.addChild(this.pillar1);
        this.pillar2 = cc.instantiate(this.pre_pillar);
        this.pillar_container.addChild(this.pillar2);
        this.pillar2.setPosition(0,1334);
    },

    //角色左边上移
    heroMoveLeft() {
        if (this.isMoving) {
            this.hero.x = -90;
            this.hero.scaleX = 1;
            if(!this.isSpeeding){
                this.heroMove();
            }
        }
    },
    //角色右边上移
    heroMoveRight() {
        if (this.isMoving) {
            this.hero.x = 90;
            this.hero.scaleX = -1;
            if(!this.isSpeeding){
                this.heroMove();
            }
        }
    },

    // 角色上移
    heroMove(){
        this.hero.getChildByName('hero').getComponent(cc.Animation).play();
        this.audio.playEffect('climb');
        if (this.hero.y < 0) {
            var action = cc.moveBy(0.1, 0, 333.5);
            this.hero.runAction(action);
        } else {
            var action = cc.moveBy(0.1, 0, -333.5-this.speed/333.5);
            this.pillar1.runAction(action);
            this.pillar2.runAction(action.clone());
        }
        this.score++;
        this.lbl_score.string = '高度：' + this.score + '米';
        this.speed = 250 + Math.floor(this.score/30)*50;
    },

    // 获得金币
    getCoin(num){
        this.audio.playEffect('coin');
        this.coin += num;
        this.lbl_coin.string =this.oldCoin + this.coin;
        // 骨头粒子特效
        var bone = cc.instantiate(this.particle_bone);
        this.pillar_container.addChild(bone);
        bone.setPosition(this.hero.getPosition());
    },

    // 获得宝箱
    getBox(){
        this.panel_box.active = true;
        if(Math.random()<0.5){
            this.itemType = 'speed';
            this.icon_item.getComponent(cc.Sprite).spriteFrame = this.spr_speed;
            this.item_description.string = '快速冲刺一段距离！';
        }else{
            this.itemType = 'magnet';
            this.icon_item.getComponent(cc.Sprite).spriteFrame = this.spr_magnet;
            this.item_description.string = '将附近的鸡腿吸过来！';
        }
        this.scheduleOnce(function(){
            cc.director.pause();
        },0.1);
    },

    // 关闭宝箱面板
    closePanelBox(){
        cc.director.resume();
        this.panel_box.active = false;
    },

    // 点击好友助力按钮
    onBtnShareClicked(){
        if (window.wx) {
            var title = '爬不动了，快来帮帮我……';
            var idx = Math.floor(Math.random() * 4);
            // ps.share(title, this.shareImgs[idx],this.getItem.bind(this));
            ps.share(title, this.shareImgs[idx],function(id){
                if(ps.isGroupIdOk(id)){
                    this.getItem();
                }else{
                    this.alert('短时间内分享到同一个群会影响到别人哦~');
                }
            }.bind(this));
        } else {
            cc.log("道具分享");
        }
    },

    // 获取道具
    getItem(){
        this.closePanelBox();
        if(this.itemType == 'speed'){
            this.getSpeedItem();
        }else if(this.itemType == 'magnet'){
            this.getMagnetItem();
        }
    },

    // 获得加速道具
    getSpeedItem(){
        if(this.isSpeeding){
            return;
        }
        this.audio.playEffect('get');
        this.isSpeeding = true;
        this.schedule(this.heroMove,0.11,20);
        this.scheduleOnce(function(){
            this.hero.getChildByName('smoke').active = true;
        }.bind(this),0.3);
       
        this.scheduleOnce(function(){
            this.isSpeeding = false;
            this.hero.getChildByName('smoke').active = false;
        }.bind(this),2.8);
    },

    // 获得磁铁道具
    getMagnetItem(){
        if(this.isMagneting){
            return;
        }
        this.audio.playEffect('get');
        this.isMagneting = true;
        this.hero.getChildByName('circle').active = true;
        this.scheduleOnce(function(){
            this.isMagneting = false;
            this.hero.getChildByName('circle').active = false;
        }.bind(this),10);
    },

    // 打开获得鸡腿面板
    openGetStrumstickPanel(){
        ps.hideGameClub();
        this.panel_get_drumstick.active = true;
    },

    // 关闭领鸡腿面板
    closeGetStrumstickPanel(){
        ps.showGameClub();
        this.panel_get_drumstick.active = false;
    },

    // 领鸡腿
    addStrumSticks(){
       ps.videoAdCallBack = function(){
            this.oldCoin = this.oldCoin + 300;
            cc.sys.localStorage.setItem('climb1-coin', this.oldCoin+'');
            this.lbl_coin.string = this.oldCoin;
            this.alert('成功领取300鸡腿');
            this.closeGetStrumstickPanel();
        }.bind(this);
        ps.playVideoAd();
    },

    // 打开领现金面板
    openGetMoneyPanel(){
        ps.hideGameClub();
        this.panel_money.active = true;
    },

    // 关闭领现金面板
    closeGetMoneyPanel(){
        ps.showGameClub();
        this.panel_money.active = false;
    },

    // 领现金
    getMoney(){
        if(window.wx){
            wx.openCustomerServiceConversation();
        }
    },

    // 游戏失败
    gameFail() {
        this.getComponent('rank').removeRank();
        this.scheduleOnce(function(){
            this.audio.playEffect('fail');
        }.bind(this),0.5);
       
        this.isMoving = false;
        // 角色掉下来的动画
        this.hero.stopAllActions();

        var action = null;
        if(this.hero.x > 0){
            // 从右边掉下
            action = cc.bezierBy(1,[cc.p(0,0),cc.p(150,300),cc.p(300,-1000)]);
        }else{
            // 从左边掉下
            action = cc.bezierBy(1,[cc.p(0,0),cc.p(-150,300),cc.p(-300,-1000)]);
        }
        var func = cc.callFunc(function(){
            if(this.renewTimes == 0){
                this.panel_renew.active = true;
                this.btn_drumstick_renew.active = true;
                ps.showBannerAd();
            }else if(this.renewTimes >= 1){
                this.panel_renew.active = true;
                this.btn_drumstick_renew.active = false;
                ps.showBannerAd();
            }
            // else if(this.renewTimes >= 20){
            //     this.gameOver();
            // }
        }.bind(this));
        this.hero.runAction(cc.sequence(action,func));
        this.setAnim();
       
    },

    // 游戏结束
    gameOver(){
        // 保存最高分
        // var oldScore = cc.sys.localStorage.getItem("climb1-score");
        // if (!oldScore) {
        //     oldScore = 0;
        // }
        var bestScore = this.oldScore;
        if (this.score > bestScore) {
            bestScore = this.score;
        }
        cc.sys.localStorage.setItem('climb1-score', bestScore+'');
        this.label_best_score.string = bestScore + '米';

        // 保存金币数
        cc.sys.localStorage.setItem('climb1-coin', (this.oldCoin + this.coin)+'');

        this.getComponent('rank').submitScore(this.score);
        this.scheduleOnce(function () {
            this.getComponent('rank').getRowRank();
            this.panel_renew.active = false;
            ps.hideBannerAd();
            this.panel_gameOver.active = true;
            this.lbl_gameOverScore.string = this.score + '米';
            this.lbl_gameOverCoin.string = this.coin;
        }.bind(this), 0.2);
    },

    // 复活
    renew(){
        this.stopAnim();  
        this.panel_renew.active = false;
        ps.hideBannerAd();
        this.scheduleOnce(function(){
            ps.showBannerAd();
        },0.5)
        this.hero.stopAllActions();
        this.hero.setPosition(-90,-667);
        this.hero.scaleX = 1;
        this.isMoving = true;
        this.getSpeedItem(); 
        this.createPillar();
        this.renewTimes += 1;
        this.alert('复活成功');
    },

    // 视频复活
    renewVideo(){
        ps.videoAdCallBack = this.renew.bind(this);
        ps.playVideoAd();
    },

    // 鸡腿复活
    renewDrumstick() {
        this.audio.playEffect('click');
        if(this.oldCoin + this.coin >= 30){
            this.oldCoin = this.oldCoin + this.coin - 30;
            cc.sys.localStorage.setItem('climb1-coin', this.oldCoin+'');
            this.lbl_coin.string = this.oldCoin;
            this.coin = 0;
            this.renew();
        }else{
            // 鸡腿不足
            this.alert('鸡腿不足……');
        }
    },

    // 重新开始
    replay(){
        this.audio.playEffect('click');
        this.stopAnim();  
        this.panel_gameOver.active = false;
        this.getComponent('rank').removeRank();
        this.initGame();
        this.initData();
        this.createPillar();
    },

    // 返回菜单
    backToMenu(){
        cc.director.loadScene('game');
        ps.showGameClub();
    },

    // 打开排行榜
    openRank() {
        ps.hideGameClub();
        this.audio.playEffect('click');
        this.panel_rank.active = true;
        this.getComponent('rank').getColumnRank();
    },

    // 关闭排行榜
    closeRank() {
        ps.showGameClub();
        this.audio.playEffect('click');
        this.panel_rank.active = false;
        this.getComponent('rank').removeRank();
    },

    //普通分享
    shareNormal(){
        if (window.wx) {
            var title = '这个游戏福利超级好！！！有鸡腿吃还能领钱！！！';
            var idx = Math.floor(Math.random() * 4);
            ps.share(title, this.shareImgs[idx]);
        } else {
            cc.log("普通分享");
        }
    },

    // 发起挑战
    shareScore(){
        if (window.wx) {
            var title = '本海盗爬了' + this.score + '米，你能超过我吗？';
            var idx = Math.floor(Math.random() * 4);
            ps.share2(title, this.shareImgs[idx],this.backToMenu);
        } else {
            cc.log("发起挑战");
        }
    },

    // 更多小游戏
    moreGame(){
        if(window.wx){
            window.wx.navigateToMiniProgram({
                appId:'wx0effe2a96a202f6f'
            })
        }
    },

    moreGame2(){
        if(window.wx){
            window.wx.navigateToMiniProgram({
                appId:'wx39d60b9b276d434d'
            })
        }
    },

    // 弹窗
    alert(text){
        var alert = cc.instantiate(this.pre_alert);
        this.node.addChild(alert);
        alert.getComponent('alert').setText(text);
    },

    update(dt) {
        if (this.isMoving) {
            // 船移动
            if (this.ship) {
                this.ship.y -= this.speed * dt;
                if (this.ship.y <= -1000) {
                    this.ship.removeFromParent();
                }
            }
            // 柱子移动
            this.pillar1.y -= this.speed * dt;
            if (this.pillar1.y <= -1334) {
                this.pillar1.y = this.pillar2.y + this.pillar1.height;
                this.pillar1.getComponent('pillar').resetPiller();
                // this.getComponent('rank').getNextFriendData(this.score);
            }
            this.pillar2.y -= this.speed * dt;
            if (this.pillar2.y <= -1334) {
                this.pillar2.y = this.pillar1.y + this.pillar1.height;
                this.pillar2.getComponent('pillar').resetPiller();
                this.getComponent('rank').getNextFriendData(this.score);
            }
            // 主角移动
            this.hero.y -= this.speed * dt;
            if(this.hero.y < -800){
                this.audio.playEffect('water');
                this.gameFail();
            }

            // 磁铁道具效果
            if(this.isMagneting){
                this.pillar1.getComponent('pillar').item_container.children.forEach(itemGroup => {
                    itemGroup.children.forEach(item => {
                        var itemY = itemGroup.convertToWorldSpaceAR(item).y;
                        var itemX = itemGroup.convertToWorldSpaceAR(item).x;
                        var heroY = this.hero.parent.convertToWorldSpaceAR(this.hero).y;
                        var heroX = this.hero.parent.convertToWorldSpaceAR(this.hero).x;

                        if(itemY > heroY){
                            if(itemY - heroY < 500){
                                var angle = Math.atan((itemX-heroX)/(itemY-heroY));
                                item.x -= Math.sin(angle)*1600*dt;
                                item.y -= Math.cos(angle)*1600*dt;
                            }
                        }else{
                            if(heroY - itemY < 500){
                                var angle = Math.atan((itemX-heroX)/(itemY-heroY));
                                item.x += Math.sin(angle)*1600*dt;
                                item.y += Math.cos(angle)*1600*dt;
                            }
                        }
                    })
                });
                this.pillar2.getComponent('pillar').item_container.children.forEach(itemGroup => {
                    itemGroup.children.forEach(item => {
                        var itemY = itemGroup.convertToWorldSpaceAR(item).y;
                        var itemX = itemGroup.convertToWorldSpaceAR(item).x;
                        var heroY = this.hero.parent.convertToWorldSpaceAR(this.hero).y;
                        var heroX = this.hero.parent.convertToWorldSpaceAR(this.hero).x;

                        if(itemY > heroY){
                            if(itemY - heroY < 500){
                                var angle = Math.atan((itemX-heroX)/(itemY-heroY));
                                item.x -= Math.sin(angle)*1600*dt;
                                item.y -= Math.cos(angle)*1600*dt;
                            }
                        }else{
                            if(heroY - itemY < 500){
                                var angle = Math.atan((itemX-heroX)/(itemY-heroY));
                                item.x += Math.sin(angle)*1600*dt;
                                item.y += Math.cos(angle)*1600*dt;
                            }
                        }
                    })
                })
            }
        }
    },
});
