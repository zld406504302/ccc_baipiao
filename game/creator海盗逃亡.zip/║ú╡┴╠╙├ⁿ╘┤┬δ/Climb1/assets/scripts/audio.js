var ps = require('PS');
cc.Class({
    extends: cc.Component,

    properties: {
        bgm_game:{
            default:null,
            url:cc.AudioClip,
            displayName: "游戏背景音乐",
        },

        effect_click:{
            default:null,
            url:cc.AudioClip,
            displayName: "点击音效",
        },
        
        effect_fail:{
            default:null,
            url:cc.AudioClip,
            displayName: "失败音效",
        },

       effect_climb:{
            default:null,
            url:cc.AudioClip,
            displayName: "上爬音效",
        },

        effect_coin:{
            default:null,
            url:cc.AudioClip,
            displayName: "金币音效",
        },

        effect_get:{
            default:null,
            url:cc.AudioClip,
            displayName: "获得道具音效",
        },

        effect_hit:{
            default:null,
            url:cc.AudioClip,
            displayName: "撞飞障碍音效",
        },

        effect_konck:{
            default:null,
            url:cc.AudioClip,
            displayName: "被障碍撞到音效",
        },

        effect_water:{
            default:null,
            url:cc.AudioClip,
            displayName: "沉水音效",
        }



    },

    // use this for initialization
    onLoad: function () {
        cc.audioEngine.uncacheAll();
        this.bgmVolum = 0.5;
        this.effectVolum = 1;
    },

    start(){
        this.scheduleOnce(function(){
             this.playBgm();
        }.bind(this),2);
       
    },

    // 播放游戏背景音乐
    playBgm:function(){
        cc.audioEngine.stopAll();
        if(ps.isMusicOn){
            cc.audioEngine.play(this.bgm_game,true,this.bgmVolum);
        }
    },

    // 播放音效
    playEffect(type){
        if(ps.isEffectOn){
            var key = "effect_" + type;
            cc.audioEngine.play(this[key],false,this.effectVolum);
        }
    },

    // 停止播放
    stopAll(){
        cc.audioEngine.stopAll();
    }
   

    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});
