cc.Class({
    extends: cc.Component,
    properties: {
        display: cc.Sprite,
    },

    start () {
        if (window.wx != undefined) {
            this.tex = new cc.Texture2D();
            window.sharedCanvas.width = 750;
            window.sharedCanvas.height = 1334; 
        }
    },

    // 移除排行榜
    removeRank() {
        if (window.wx != undefined) {
            window.wx.postMessage({
                messageType: 0
            });
        } else {
            cc.log("移除排行榜")
        }

        this.schedule(this._updateSubDomainCanvas,0.2,15);
    },

    // 提交得分
    submitScore(score){
        // let score = 233;
        if (window.wx != undefined) {
            window.wx.postMessage({
                messageType: 3,
                MAIN_MENU_NUM: "x1",
                score: score,
            });
        } else {
            cc.log("提交得分: x1 : " + score)
        }
    },

    // 获取横向排行
    getRowRank(event) {
        if (window.wx != undefined) {
            window.sharedCanvas.width = 750;
            window.sharedCanvas.height = 1334;
            this.display.node.x = 0;
            this.display.node.y = 0;

            window.wx.postMessage({// 发消息给子域
                messageType: 4,
                MAIN_MENU_NUM: "x1"
            });
        } else {
            cc.log("获取横向展示排行榜数据。x1");
        }
        this.schedule(this._updateSubDomainCanvas,0.2,15);
    },

    // 获取纵向排行
    getColumnRank(event) {
        if (window.wx != undefined) {
            // 发消息给子域
            window.wx.postMessage({
                messageType: 1,
                MAIN_MENU_NUM: "x1"
            });
        } else {
            cc.log("获取好友排行榜数据。x1");
        }
        this.schedule(this._updateSubDomainCanvas,0.2,15);
    },

    // 获取超越好友信息
    getNextFriendData(score) {
        if (window.wx != undefined) {
            window.sharedCanvas.width = 150;
            window.sharedCanvas.height = 267;
            this.display.node.x = 300;
            this.display.node.y = 360;
            // 发消息给子域
            window.wx.postMessage({
                messageType: 6,
                MAIN_MENU_NUM: "x1",
                score: score,
            });
        } else {
            cc.log("获取即将超越的好友数据。x1");
        }
        this.scheduleOnce(this._updateSubDomainCanvas,1);
        // if (window.sharedCanvas != undefined) {
        //     this.display.spriteFrame = new cc.SpriteFrame(this.tex);
        // }
    },




    // 刷新子域的纹理
    _updateSubDomainCanvas() {
        if (!this.tex) {
            return;
        }
        if (window.sharedCanvas != undefined) {
            this.tex.initWithElement(window.sharedCanvas);
            this.tex.handleLoadedTexture();
            this.display.spriteFrame = new cc.SpriteFrame(this.tex);
        }
    },

    update () {
        // this._updateSubDomainCanvas();
    }
});