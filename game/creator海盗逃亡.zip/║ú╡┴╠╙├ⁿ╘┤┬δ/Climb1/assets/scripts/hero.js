
cc.Class({
    extends: cc.Component,

    properties: {
        
    },

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start () {
        this.game = cc.find('Canvas').getComponent('game');
    },

    onCollisionEnter(other,self){
        if(other.node.group == 'barrier'){
            if(this.game.isSpeeding){
                this.game.audio.playEffect('hit');
                if(other.node.x > 0){
                    var pos = other.node.getPosition();
                    var action1 = cc.rotateBy(0.3,360);
                    var action2 = cc.moveBy(0.3,500,1000);
                    var func = cc.callFunc(function(){
                        other.node.setPosition(pos);
                        other.node.rotation = 0;
                    });
                    other.node.runAction(cc.sequence(cc.spawn(action1,action2),func));
                }else{
                    var pos = other.node.getPosition();
                    var action1 = cc.rotateBy(0.3,-360);
                    var action2 = cc.moveBy(0.3,-500,1000);
                    var func = cc.callFunc(function(){
                        other.node.setPosition(pos);
                        other.node.rotation = 0;
                    });
                    other.node.runAction(cc.sequence(cc.spawn(action1,action2),func));
                }
            }else{
                this.game.audio.playEffect('konck');
                this.game.gameFail();
            }
            other.node.group = 'default';
        }else if(other.node.group == 'item'){
            var type = other.getComponent('item').type;
            if(type == 'coin'){
                this.game.getCoin(1);
            }else if(type == 'box'){
                this.game.getBox();
            }
            // else if(type == 'speed'){
            //     this.game.getSpeedItem();
            // }else if(type == 'magnet'){
            //     this.game.getMagnetItem();
            // }
            other.node.active = false;
        }
        
    }

    // update (dt) {},
});
