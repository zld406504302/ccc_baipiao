var ps = {
    isMusicOn: true,
    isEffectOn: true,

    groupIdArr: [], // 分享过群的id
    
    createBannerAd: function () { // 创建横幅广告
        if (window.wx) {
            // banner广告
            let { screenWidth } = wx.getSystemInfoSync();
            let { screenHeight } = wx.getSystemInfoSync();
            this.bannerAd = wx.createBannerAd({
                adUnitId: 'adunit-59167580c6ec06cf',
                style: {
                    left: 0,
                    top: screenHeight - screenWidth / 3.47,
                    width: screenWidth,
                }
            });
        }
    },
    showBannerAd() { // 显示横幅广告
        if (this.bannerAd) {
            this.bannerAd.show();
        }
    },
    hideBannerAd() { // 隐藏横幅广告
        if (this.bannerAd) {
            this.bannerAd.hide();
        }
    },
    destroyBannerAd: function () { // 销毁横幅广告
        if (this.bannerAd) {
            this.bannerAd.destroy();
        }
    },
    createVideoAd: function () { // 创建视频广告
        if (window.wx) {
            this.videoAd = wx.createRewardedVideoAd({ adUnitId: 'adunit-5aed15d9b5d79371' });
            this.videoAd.onClose(function (res) {
                if (res && res.isEnded || res === undefined) {
                    // 正常播放结束，可以下发游戏奖励
                    if (this.videoAdCallBack) {
                        this.videoAdCallBack();
                    }
                }
                else {
                    // 播放中途退出，不下发游戏奖励
                }

            }.bind(this));
        }
    },
    playVideoAd: function () { // 播放视频广告
        if (this.videoAd) {
            this.videoAd.show();
        }
    },

    createGameClub: function () { // 创建游戏圈按钮
        if (window.wx && !this.gameClubBtn) {
            let { screenWidth } = wx.getSystemInfoSync();
            let { screenHeight } = wx.getSystemInfoSync();
            this.gameClubBtn = wx.createGameClubButton({
                icon: 'white',
                style: {
                    left: screenWidth*0.8,
                    top: screenHeight*0.12,
                    width: 50,
                    height: 50
                }
            })
        }
    },

    showGameClub:function(){ // 显示游戏圈按钮
        if(window.wx){
            if(this.gameClubBtn){
                this.gameClubBtn.show();
            }
        }
    },

    hideGameClub: function(){ // 隐藏游戏圈按钮
        if(window.wx){
            if(this.gameClubBtn){
                this.gameClubBtn.hide();
            }
        }
    },

    destroyGameClub:function(){ // 销毁游戏圈按钮
        if(window.wx){
            if(this.gameClubBtn){
                this.gameClubBtn.destroy();
            }
        }
    },
 
    share: function(title,img,callback){
        if(window.wx){
            window.wx.shareAppMessage({
                title: title,
                imageUrl: img,
                success: function(res){
                    if(!callback){
                        return;
                    }
                    if (res.shareTickets) {
                        wx.getShareInfo({
                          shareTicket: res.shareTickets[0],
                          success: function (res) {
                            console.log('getShareTiket---shareTicket-->' + JSON.stringify(res))
                            //获取encryptedData、iv
                            let js_encryptedData = res.encryptedData
                            let js_iv = res.iv
                            wx.login({
                              success: function (res) {
                                //获取code
                                console.log('code-->' + res.code)
                               
                                //调用云函数，破解opengid
                                wx.cloud.callFunction({
                                  name: 'opengid',
                                  data: {
                                    js_code: res.code,
                                    appId: 'wxcee22af2adc3a3d1',
                                    encryptedData: js_encryptedData,
                                    iv: js_iv
                                  },
                                  success: function (res) {
                                    console.log('打印opengid' + res.result.openGId);                
                                    // console.log('res' + JSON.stringify(res));
                                    callback(res.result.openGId);
                                  },
                                  fail: function (err) {
                                    console.log('getShareTiket---err' + JSON.stringify(err))
                                  }             
                                })
                              }
                            })
                          }
                        })
                      }
                }
            })
        }
    },

    share2: function(title,img,callback){
        if(window.wx){
            window.wx.shareAppMessage({
                title: title,
                imageUrl: img,
                success: function(res){
                    if(callback){
                        callback();
                    }
                }
            })
        }
    },

    isGroupIdOk: function(id){
        if(this.groupIdArr.indexOf(id) == -1){
            this.groupIdArr.push(id);
            return true;
        }else{
            return false;
        }
    }
}
module.exports = ps;