
cc.Class({
    extends: cc.Component,

    properties: {
        barrier_container: cc.Node, // 障碍物容器
        item_container: cc.Node, // 道具容器
    },

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start() {

    },

    // 重置柱子
    resetPiller() {
        this.resetBarriers();
        this.resetItems();
    },

    // 重置障碍
    resetBarriers() {
        var barrierArr = this.barrier_container.children;
        barrierArr.forEach(function(element) {
            element.getComponent('barrier').reset();
        }, this);
    },

    // 重置道具
    resetItems(){
        var itemsArr = this.item_container.children;
        itemsArr.forEach(function(items) {
            items.getChildByName('left').getComponent('item').reset();
            items.getChildByName('right').getComponent('item').reset();
        }, this);
    },

    // update (dt) {

    // },
});
