
cc.Class({
    extends: cc.Component,

    properties: {
       lbl_text: cc.Label, // 文字
    },

    // LIFE-CYCLE CALLBACKS:

    onLoad () {
        this.node.scale = 0;
    },

    // 设置文字
    setText(text){
        this.lbl_text.string = text;
    },

    start () {
        var action1 = cc.scaleTo(0.1,1,1);
        var action2 = cc.delayTime(1.5);
        var action3 = cc.fadeOut(1);
        var action4 = cc.callFunc(function(){
            this.node.removeFromParent();
        }.bind(this));
        var seq = cc.sequence(action1,action2,action3,action4);
        this.node.runAction(seq);
        // 弹窗两秒后消失
        // this.scheduleOnce(function(){
        //     this.node.removeFromParent();
        // }.bind(this),1)
    },

    // update (dt) {},
});
