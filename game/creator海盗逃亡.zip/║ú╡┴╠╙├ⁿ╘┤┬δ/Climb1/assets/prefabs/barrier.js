
cc.Class({
    extends: cc.Component,

    properties: {
        barrier_left: cc.Node,
        barrier_right: cc.Node,
        spr_barrier: [cc.SpriteFrame],
    },

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start() {
        
    },

    // 重置障碍物
    reset() {
        var randomNum = Math.random();
        if (randomNum < 0.4) {
            this.barrier_left.active = true;
            this.barrier_right.active = false;
            this.barrier_left.getComponent(cc.Sprite).spriteFrame = 
            this.spr_barrier[Math.floor(Math.random()*this.spr_barrier.length)];
        } else if (randomNum < 0.8) {
            this.barrier_left.active = false;
            this.barrier_right.active = true;
            this.barrier_right.getComponent(cc.Sprite).spriteFrame = 
            this.spr_barrier[Math.floor(Math.random()*this.spr_barrier.length)];
        } else {
            this.barrier_left.active = false;
            this.barrier_right.active = false;
        }
        this.barrier_left.group = 'barrier';
        this.barrier_right.group = 'barrier';
    }

    // update (dt) {},
});
