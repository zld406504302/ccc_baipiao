
cc.Class({
    extends: cc.Component,

    properties: {
       spr_coin: cc.SpriteFrame, // 金币图片
       //spr_speed: cc.SpriteFrame, // 加速图片
       //spr_magnet: cc.SpriteFrame, // 磁铁图片
       spr_box: cc.SpriteFrame, // 宝箱图片
    },

    // LIFE-CYCLE CALLBACKS:

    onLoad () {
        
    },

    start () {
      
    },

    // 重置道具
    reset(){
        if(!this.game){
            this.game = cc.find('Canvas').getComponent('game');
        }
        var randomNum = Math.random();
        // if(randomNum < 0.004 && !this.game.isSpeeding){
        //     // 加速道具
        //     this.node.active = true;
        //     this.type = 'speed';
        //     this.getComponent(cc.Sprite).spriteFrame = this.spr_speed;
        // }else if(randomNum < 0.008 && !this.game.isMagneting){
        //     // 磁铁道具
        //     this.node.active = true;
        //     this.type = 'magnet';
        //     this.getComponent(cc.Sprite).spriteFrame = this.spr_magnet;
        // }
        
        if(randomNum < 0.006 && !this.game.isSpeeding && !this.game.isMagneting){
            // 获得宝箱
            this.node.active = true;
            this.type = 'box';
            this.getComponent(cc.Sprite).spriteFrame = this.spr_box;
        }else if(randomNum < 0.5){
            // 金币
            this.node.active = true;
            this.type = 'coin';
            this.getComponent(cc.Sprite).spriteFrame = this.spr_coin;
        }else{
            // 留空
            this.node.active = false;
        }
        if(this.node.name == 'left'){
            this.node.x = -130;
        }else if(this.node.name == 'right'){
            this.node.x = 130;
        }
        this.node.y = 0;

    }

    // update (dt) {},
});
