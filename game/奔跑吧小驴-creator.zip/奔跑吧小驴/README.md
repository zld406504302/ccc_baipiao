# creator_item_xlgh
cocos creator v1.9.1 奔跑吧小驴 微信小游戏 工程, 工程比较完整，包括微信子域的工程。
微信子域的小BUG在CSDN上有说明，后面的项目时已经修复，此工程并没有。

https://blog.csdn.net/qq_26902237

由于时间仓促，代码中仍在些许小问题。有问题可以在CSDN上给我留言

浏览器下试玩  https://gamefun2018.github.io/cocos_creator_xlgh/index.html ，未对Web下做适配，只作为演示用途
如果你也想将自己的游戏放在Web上，可以参照我的CSDN中的 "如何使用Git构建cocos creator游戏的web测试版"
