
cc.Class({
    extends: cc.Component,

    properties: {
    },


    onLoad() {
        var ske = this.node.getComponent(sp.Skeleton);
        this.ske = ske;
    },

    start() {
        let all = cc.find("Canvas");
        let acc = cc.find("Canvas/yaogan");
        all.pauseSystemEvents(true);
        this.ske.setAnimation(0, "ruchang", false);
        this.ske.setCompleteListener((trackEntry) => {
            if (trackEntry.animation.name == "ruchang") {
                this.ske.setAnimation(0, "zhongjian", false);
            } else if (trackEntry.animation.name == "zhongjian") {
                this.ske.setAnimation(0, "jiewei", false);
            } else if (trackEntry.animation.name == "jiewei") {
                acc.resumeSystemEvents(true);//恢复所有触摸点击事件
                this.scheduleOnce(() => {
                    this.node.destroy();
                    cc.director.emit("hudun1");
                    cc.director.emit("nuosijj");
                }, 0.5)
            }
        })
    },

});
