// Learn cc.Class:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/class.html
//  - [English] http://docs.cocos2d-x.org/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/reference/attributes.html
//  - [English] http://docs.cocos2d-x.org/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/life-cycle-callbacks.html
//  - [English] https://www.cocos2d-x.org/docs/creator/manual/en/scripting/life-cycle-callbacks.html

cc.Class({
    extends: cc.Component,

    properties: {
        jijiazidan: cc.Prefab,
        jjzd: cc.Prefab,
    },

    update() {
        this.x++;
        if (this.x > 60) {
            this.dan(this.fashedian, this.paoguan);
            this.x = 0;
            if (this.zy == true) {
                this.zy = false
            } else {
                this.zy = true
            }
        }
        this.y++;
        if (this.y > 20) {
            this.zidan();
            this.y = 0
            if (this.sx == true) {
                this.sx = false
            } else {
                this.sx = true
            }
        }

    },

    start() {
        this.zy = true;
        this.sx = true;
        this.x = 0;
        this.y = 0;
        // this.dan();
        this.shuzu = []
        cc.director.on("jjxs", function () {
            for (let i = 0; i < this.shuzu.length; i++) {
                this.shuzu[i].destroy();
            }
        }, this);
        // cc.loader.loadRes("sounds/shoot4", cc.AudioClip, (eve) => {//播放道具音乐
        //     let effect = cc.audioEngine.playEffect(eve,true);
        //     cc.audioEngine.setVolume(effect, 0.8);
        // })
        cc.director.emit("playEffect", "shoot4", 0.6);//播放音效；
    },
    //发射导弹
    dan() {
        let fashedian = this.toWorldPosition(this.node.getChildByName("2")); //发射点
        let paoguan = this.toWorldPosition(this.node.getChildByName("1"))  //炮管  2个点得到一条直线计算弧度角度和方向
        let fashedian1 = this.toWorldPosition(this.node.getChildByName("4")); //发射点
        let it = cc.instantiate(this.jijiazidan);//实例化子弹
        it.parent = cc.find("Canvas");//父节点
        this.shuzu.push(it)
        if (this.zy == true) {
            it.position = fashedian1
        } else {
            it.position = fashedian; //导弹出生点为发射点
        }
        let isx = fashedian.x - paoguan.x; //向量
        let isy = fashedian.y - paoguan.y; //计算出方向 
        let rad = Math.atan2(isy, isx);//弧度
        it.rotation = - cc.misc.radiansToDegrees(rad); //转换为角度
        if (it.rotation > 0 && it.rotation <= 90) {
            it.curDir = "rightDown"
        } else if (it.rotation > 90 && it.rotation <= 180) {
            it.curDir = "leftDown"
        } else if (it.rotation < 0 && it.rotation >= -90) {
            it.curDir = "rightUp"
        } else {
            it.curDir = "leftUp"
        }
        this.movingAction(it);
    },
    // 导弹移动以及反弹
    movingAction(it) {
        //传入It得到撞击后的位置
        let dest = this.getDestPoint(it)
        this.startPos = it.position;
        this.endPos = dest
        let distance = this.startPos.sub(this.endPos).mag() / 500
        //顺序动作先执行移动移动执行完后在调用自身
        var seq = cc.sequence(
            cc.moveTo(distance, dest),
            cc.callFunc(function () {
                if (it.curDir == "leftUp") {
                    if (it.rotation < 0) {
                        it.rotation = -180 - it.rotation;
                    } else {
                        it.rotation = - it.rotation;
                    }
                } else if (it.curDir == "rightDown") {
                    if (it.rotation < 0) {
                        it.rotation = - it.rotation;
                    } else {
                        it.rotation = 180 - it.rotation;
                    }
                } else if (it.curDir == "leftDown") {
                    if (it.rotation < 0) {
                        it.rotation = - it.rotation;
                    } else {
                        it.rotation = 180 - it.rotation;
                    }

                } else {
                    if (it.rotation < 0) {
                        it.rotation = -180 - it.rotation;
                    } else {
                        it.rotation = - it.rotation;
                    }
                }
                this.movingAction(it);
            }, this)
        );
        it.runAction(seq);
    },

    toWorldPosition(node) {//转为世界坐标
        let worldPos = node.convertToWorldSpaceAR(cc.v2(0, 0));
        let startPos = cc.find("Canvas").convertToNodeSpaceAR(worldPos);
        return startPos;
    },

    zidan() {
        if (this.sx == true) {
            this.firePointa = this.node.getChildByName("6");
        } else {
            this.firePointa = this.node.getChildByName("8");
        }
        let itf = cc.instantiate(this.jjzd);//实例化子弹
        itf.parent = cc.find("Canvas");//父节点
        itf.position = this.toWorldPosition(this.firePointa);
        if (this.sx == true) {
            this.play = this.toWorldPosition(this.node.getChildByName("5"));
            this.fire = this.toWorldPosition(this.node.getChildByName("6"));
        } else {
            this.play = this.toWorldPosition(this.node.getChildByName("7"));
            this.fire = this.toWorldPosition(this.node.getChildByName("8"));
        }
        let isx = this.fire.x - this.play.x;
        let isy = this.fire.y - this.play.y;
        let jd = this.node.parent;
        itf.rotation = jd.rotation;
        let isv = cc.v2(isx, isy).normalize();//单位向量化
        let ac = cc.moveBy(3, cc.v2(cc.winSize.width * isv.x, cc.winSize.width * isv.y))
        var finished = cc.callFunc(function () {
            itf.destroy();
        }, this);
        var ty = cc.sequence(ac, finished)
        itf.runAction(ty);
    },

    //得到反弹后相撞的那个点的坐标
    getDestPoint(it) {
        let dest
        if (it.curDir == "leftDown") {
            dest = this.getLeftPoint(it);
            it.curDir = "rightDown";
            if (false == this.isValidPoint(dest)) {
                dest = this.getDownPoint(it);
                it.curDir = "leftUp";
            }
        } else if (it.curDir == "leftUp") {
            dest = this.getLeftPoint(it);
            it.curDir = "rightUp";
            if (false == this.isValidPoint(dest)) {
                dest = this.getUpPoint(it);
                it.curDir = "leftDown";
            }
        } else if (it.curDir == "rightDown") {
            dest = this.getRightPoint(it);
            it.curDir = "leftDown";
            if (false == this.isValidPoint(dest)) {
                dest = this.getDownPoint(it);
                it.curDir = "rightUp";
            }
        } else {
            dest = this.getRightPoint(it);
            it.curDir = "leftUp";
            if (false == this.isValidPoint(dest)) {
                dest = this.getUpPoint(it);
                it.curDir = "rightDown";
            }
        }
        return dest;
    },

    getDownPoint(it) {
        let lastAngle = cc.misc.degreesToRadians(-it.rotation);  //将之前赋值过得it的roattion转换得到幅度
        let tanValue = Math.tan(lastAngle);
        let py = -cc.winSize.height / 2;
        //已知的一个点的x坐标 -已知的一个点的y坐标-相撞后的y坐标（因为是上边界所以可以得到Y坐标 就是屏幕高度除以2）在调用Math.tan方法传入这条直线的幅度
        let px = it.x - (it.y - py) / tanValue;
        return cc.v2(px, py);
    },

    getUpPoint(it) {
        let lastAngle = cc.misc.degreesToRadians(-it.rotation);  //将之前赋值过得it的roattion转换得到幅度
        let tanValue = Math.tan(lastAngle);
        let py = cc.winSize.height / 2;
        //已知的一个点的x坐标 -已知的一个点的y坐标-相撞后的y坐标（因为是上边界所以可以得到Y坐标 就是屏幕高度除以2）在调用Math.tan方法传入这条直线的幅度
        let px = it.x - (it.y - py) / tanValue;
        return cc.v2(px, py);
    },

    getRightPoint(it) {
        let lastAngle = cc.misc.degreesToRadians(-it.rotation);  //将之前赋值过得it的roattion转换得到幅度
        let tanValue = Math.tan(lastAngle);
        let px = cc.winSize.width / 2;
        //求y就把之前上面的参数改一下即可 y放前面 用已知的x-撞到的位置的x就可以得出撞击点的Y坐标
        let py = it.y - (it.x - px) * tanValue;
        return cc.v2(px, py);
    },

    getLeftPoint(it) {
        let lastAngle = cc.misc.degreesToRadians(-it.rotation);  //将之前赋值过得it的roattion转换得到幅度
        let tanValue = Math.tan(lastAngle);
        let px = -cc.winSize.width / 2;
        let py = it.y - (it.x - px) * tanValue;
        return cc.v2(px, py);
    },

    isValidPoint(p) {
        if (p.x >= -cc.winSize.width / 2
            && p.x <= cc.winSize.width / 2
            && p.y >= -cc.winSize.height / 2
            && p.y <= cc.winSize.height / 2) {
            return true;
        }
        return false;
    }
});
