let AiAllState = cc.Enum({//怪物移动状态
    init:-1,//初始
    Walk: -1,//移动
    Die: -1,//死
    AttackStart: -1,//开始攻击
    Standby: -1,//待机
    wall: -1,//碰撞box
});
cc.Class({//怪物攻击类
    extends: cc.Component,
    properties: {
        AiState: {
            type: AiAllState,////怪物所有状态
            default: AiAllState.init
        },
        hp: 200,
        AttackGap: 3,//攻击间隔
        AttackType: 0,//攻击方式
        AttackKind: 0,//怪物ID
        speed: 2,//怪物移动速度
        die: cc.Prefab,//碎片
        wait: false,//暂停
    },

    start() {
        this.player = cc.v2(0, 0);//玩家
        this.Ai();//调用对应AI
        this.time = new Date().getTime();//计时器
        // this. frameEventsLogon();//注册帧事件
    },
    Ai() {
        // this.loadPicture();//加载怪物图片
        this.bornPosition();//出生位置
    },
    frameEventsLogon() {//注册帧事件
        let animation = this.node.getComponent(cc.Animation);
        animation.on("play", this.attackStartEvent(), this);
    },
    loadPicture() {//加载怪物图片
        cc.loader.loadRes("pic", cc.SpriteFrame, (err, spriteFrame) => {
            if (err) {
                cc.log("picture have bug or no loading it");//判数据有否
            }
            else {
                this.node.getComponent(cc.Sprite).spriteFrame = spriteFrame;//加载图片
                this.node.addComponent(cc.BoxCollider);//加碰撞体
            }
        });
    },
    bornPosition() {//出生位置
        let it = cc.find("Canvas/AiPanrent");//怪物父节点  置（0，0）；
        this.node.parent = it;
        let posX = Math.random() * (cc.winSize.width+this.node.width) * 2 - (cc.winSize.width+this.node.width);//x,y
        let posY = Math.random() *(cc.winSize.height+this.node.height) * 2 - (cc.winSize.height+this.node.height);
        if ((posX > (-cc.winSize.width) / 2 && posX < (cc.winSize.width) / 2) || (posY > (-cc.winSize.height) / 2 && posY < (cc.winSize.height) / 2)) {//在地图内则递归刷新位置
            this.bornPosition();//出生位置
            if (this.node.x < -cc.winSize.width / 2 - this.node.width / 2) {
                this.node.x = -cc.winSize.width / 2 - this.node.width / 2;
            }
            if (this.node.x > cc.winSize.width / 2 + this.node.width / 2) {
                this.node.x = cc.winSize.width / 2 + this.node.width / 2;
            }
            if (this.node.y < -cc.winSize.height / 2 - this.node.height / 2) {
                this.node.y = -cc.winSize.height / 2 - this.node.height / 2;
            }
            if (this.node.y > cc.winSize.height / 2 + this.node.height / 2) {
                this.node.y = cc.winSize.height / 2 + this.node.height / 2;
            }
        }
        else {//不在地图内则确定位置
            this.node.x = posX;
            this.node.y = posY;
            // return cc.v2(this.node.x, this.node.y);
        }
    },
    targetPosition() {//目标位置
        let it = cc.find("Canvas/Player");
        if (it.x > this.node.x) {
            this.node.scaleX = -1;
        }
        else {
            this.node.scaleX = 1;
        }
        return cc.v2(it.x, it.y);
    },
    update() {
        if (this.wait) {
            this.node.stopAllActions();
            this.node.getComponent(cc.Animation).pause();
        }
        else {
            this.node.resumeAllActions();
            this.node.getComponent(cc.Animation).resume();
            this.stateEvent();//状态事件
        }
    },
    stateEvent() {//状态事件
        if (this.hp <= 0) {
            this.AiState = AiAllState.Die;//变更为死亡状态
            this.hp=1;
        }
        if (this.AiState == AiAllState.Walk) {//行走状态
            let target = this.targetPosition();//目标位置
            let isx = target.x - this.node.x;//x,y插值
            let isy = target.y - this.node.y;
            let dis = cc.v2(isx, isy).normalizeSelf();
            this.node.x += dis.x * this.speed;
            this.node.y += dis.y * this.speed;
            let newTime = new Date().getTime();
            if ((newTime - this.time) >= this.AttackGap * 1000) {
                this.attackPlayer(target);//攻击玩家
                this.AiState = AiAllState.AttackStart;//变更为开始攻击状态
                this.time = newTime;
            }
        }
        else if (this.AiState == AiAllState.AttackStart) {//开始攻击状态
            // this.AiState = AiAllState.AttackTime;//变为攻击中状态
            let newTime = new Date().getTime();
            if ((newTime - this.time) >= 1.2 * 1000) {
                this.time = newTime;
                this.AiState = AiAllState.Walk;//变更为行走状态
                this.node.getComponent(cc.Animation).play("monster2_1");//播放动画
            }
        }
        else if (this.AiState == AiAllState.Die) {//死亡状态
            this.AiState = AiAllState.Standby;//变为待机状态
            this.node.removeComponent(cc.PolygonCollider);
            this.node.getComponent(cc.Animation).play("monster2_die");//播放动画
            this.dieDorpAnimation();//死亡掉落动画
            this.boxPrized();//道具箱生成
        }
        else if (this.AiState == AiAllState.wall) {//碰到护盾
            let speedPlayer = cc.find("Canvas/Player").getComponent("PlayerControl").speed;
            let isx = this.other.node.x - this.node.x;
            let isy = this.other.node.y - this.node.y;
            let vBox = this.toWorldPosition(this.node, this.other.node);//坐标插值单位向量化
            // let vBox = cc.v2(isx, isy).normalizeSelf();
            this.node.x += vBox.x * speedPlayer * 3;
            this.node.y += vBox.y * speedPlayer * 3;
        }
        else if (this.AiState == AiAllState.init)//初始状态
        {
            this.initState();//初始状态
        }
    },
    attackPlayer(target) {//攻击玩家
        this.node.getComponent(cc.Animation).play("monster2_att");//播放动画
        let isx = Math.random() * cc.winSize.width - cc.winSize.width / 2;
        let isy = Math.random() * cc.winSize.height - cc.winSize.height / 2;
        this.lookPlayer();//朝向玩家
        let move = cc.sequence(
            cc.delayTime(0.5),
            cc.moveTo(0.5, target),
            cc.moveTo(0.2, cc.v2(isx, isy)),
            cc.callFunc(()=>{
                this.node.rotation = 0;
            })
        )
        this.node.runAction(move);
    },
    boxPrized() {//道具箱生成
        let n=Math.floor(Math.random()*3);
        if(n==0){
            cc.director.emit("PropsBox", this.node);
        }
    },
    dieDorpAnimation() {//死亡掉落动画
        let it = cc.sequence(
            cc.delayTime(0.3),
            cc.spawn(
                cc.moveBy(1, cc.v2(0, -cc.winSize.height)),
                cc.rotateBy(1, 180)
            ),
            cc.removeSelf(),
        )
        this.node.runAction(it);

    },
    lookPlayer() {//朝向玩家
        let player = cc.find("Canvas/Player");
        if(this.node.scaleX==-1){
            this.node.scaleX=1;
        }
        let isx = player.x - this.node.x;
        let isy = player.y - this.node.y;
        let rad = Math.atan2(isy, isx);
        let degree = cc.misc.radiansToDegrees(rad);
        this.node.rotation = -degree-90;
        // this.node.roatation = 90;
    },
    onCollisionEnter(other, self) {
        if (other.node.group == "Player" && this.AiState == AiAllState.AttackStart) {
            cc.director.emit("playHpReduce",20);//play受到毒针攻击检测
        }
        if (other.node.group == "Dun") {
            this.unscheduleAllCallbacks();
            this.other = other;
            this.node.stopAllActions();
            this.AiState = AiAllState.wall;//变更为  碰撞体box
        }
    },
    onCollisionStay(other, self) {
        if (other.node.group == "Dun") {
            this.other = other;
            // this.AiState = AiAllState.wall;//变更为  碰撞体box
        }
    },
    onCollisionExit(other, self) {
        if (other.node.group == "Dun") {
            this.AiState = AiAllState.Standby;//变更为  行走
            this.scheduleOnce(()=>{
                this.AiState = AiAllState.Walk;//变更为  行走
            },1)
        }
    },
    initState() {//初始状态
        let target = this.targetPosition();//目标位置
        let isx = target.x - this.node.x;//x,y插值
        let isy = target.y - this.node.y;
        let dis = cc.v2(isx, isy).normalizeSelf();
        this.node.x += dis.x * this.speed;
        this.node.y += dis.y * this.speed;
        if (this.node.x > -cc.winSize.width / 2 + this.node.width / 2 &&
            this.node.x < cc.winSize.width / 2 - this.node.width / 2 &&
            this.node.y > -cc.winSize.height / 2 + this.node.height / 2 &&
            this.node.y < cc.winSize.height / 2 - this.node.height / 2) {
            this.AiState = AiAllState.Walk;//变更为行走状态
        }
    },
    toWorldPosition(node, node1) {//坐标插值单位向量化
        let world = node.convertToWorldSpaceAR(cc.v2(0, 0));
        let world1 = node1.convertToWorldSpaceAR(cc.v2(0, 0));
        let isx = world.x - world1.x;
        let isy = world.y = world1.y;
        let v = cc.v2(isx, isy).normalizeSelf();
        return v;
    }
});
