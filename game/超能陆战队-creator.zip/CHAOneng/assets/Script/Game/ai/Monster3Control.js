let AiAllState = cc.Enum({//怪物移动状态
    init: -1,//初始
    Walk: -1,//移动
    Stand: -1,//站立
    Die: -1,//死
    Standby: -1,//待机
    wall: -1,//碰撞box
});
cc.Class({//怪物攻击类
    extends: cc.Component,
    properties: {
        AiState: {
            type: AiAllState,////怪物所有状态
            default: AiAllState.Walk
        },
        hp: 200,
        AttackGap: 3,//攻击间隔
        AttackType: 0,//攻击方式
        AttackKind: 0,//怪物ID
        speed: -2,//怪物移动速度
        die: cc.Prefab,//碎片
        line: cc.Prefab,//线
        web: cc.Prefab,//网
        wait: false,//暂停
    },

    start() {
        this.dun=false;
        this.player = cc.v2(0, 0);//玩家
        this.zhizhuY = 0;//蜘蛛y
        this.Ai();//调用对应AI
        this.time = new Date().getTime();//计时器
        // this. frameEventsLogon();//注册帧事件
    },
    Ai() {
        // this.loadPicture();//加载怪物图片
        this.bornPosition();//出生位置
        this._line = this.initLine();//蜘蛛吐丝
    },
    frameEventsLogon() {//注册帧事件
        let animation = this.node.getComponent(cc.Animation);
        animation.on("play", this.attackStartEvent(), this);
    },
    bornPosition() {//出生位置
        let it = cc.find("Canvas/AiPanrent");//怪物父节点  置（0，0）；
        this.node.parent = it;
        let posX = Math.random() * (cc.winSize.width - 200) - (cc.winSize.width - 200) / 2;//x,y
        let posY = cc.winSize.height / 2 + 15;
        this.node.x = posX;
        this.node.y = posY;
    },
    update() {
        if (this.wait) {
            this.node.stopAllActions();
            this.node.getComponent(cc.Animation).pause();
        }
        else {
            this.node.resumeAllActions();
            this.node.getComponent(cc.Animation).resume();
            this.stateEvent();//状态事件
        }
    },
    stateEvent() {//状态事件
        if (this.hp <= 0) {//我死了
            this.AiState = AiAllState.die;
        }
        if (this.AiState == AiAllState.Walk) {//移动状态
            let ySub1 = cc.winSize.height / 2 - 50;//上限
            let ySub2 = cc.find("Canvas/budong UI/" + this._line.name).y;//下限
            this.node.y += this.speed;
            if (this.speed > 0) {
                if (this.node.y > ySub1) {
                    this.AiState = AiAllState.Stand;//站立状态
                }
            } else {
                if (this.node.y < ySub2) {
                    this.AiState = AiAllState.Stand;//站立状态
                }
            }
        }
        else if (this.AiState == AiAllState.Stand) {//站立状态
            this.AiState = AiAllState.Standby;//待机状态
            this.scheduleOnce(() => {//站立3秒
                this.speed = -this.speed;
                this.AiState = AiAllState.Walk;
                this.node.rotation += 180;
            }, 3)
        }
        else if (this.AiState == AiAllState.die) {//死亡状态
            this.AiState = AiAllState.Standby;//待机状态
            this.node.removeComponent(cc.PolygonCollider);
            this.dieDorpAnimation();//死亡掉落动画
            this.boxPrized();//道具箱生成
            this.hp = 1;
        }
    },
    initLine() {//蜘蛛吐丝
        this.node.getComponent(cc.Animation).play("monster3_1");//播放动画
        let it = cc.instantiate(this.line);
        it.parent = cc.find("Canvas/budong UI");
        it.position = this.node;
        let move = cc.sequence(
            cc.moveTo(1, cc.v2(this.node.x, cc.winSize.height / 4)),//移动1/4距离时蜘蛛开始移动
            cc.spawn(
                cc.callFunc(() => {
                    this.AiState = AiAllState.Walk;
                }),
                cc.moveBy(2.5, cc.v2(0, -cc.winSize.height * 0.55))//移动1/4距离时蜘蛛开始移动
            )
        );
        it.runAction(move);
        return it;
    },
    boxPrized() {//道具箱生成
        let n=Math.floor(Math.random()*3);
        if(n==0){
            cc.director.emit("PropsBox", this.node);
        }
    },
    dieDorpAnimation() {//死亡掉落动画
        let it = cc.sequence(
            cc.delayTime(0.3),
            cc.spawn(
                cc.moveBy(1, cc.v2(0, -cc.winSize.height)),
                cc.rotateBy(1, 180)
            ),
            cc.callFunc(() => {
                this._line.destroy();
            }),
            cc.removeSelf(),
        )
        this.node.runAction(it);

    },
    onCollisionEnter(other, self) {
        if (other.node.group == "Player") {
            if(this.dun==false){
                cc.director.emit("webPlayer", this.web, other.node);//碰到主角用网困住它
            }
        }
        if (other.node.group == "Dun") {
            this.dun=true;
        }
    },
    onCollisionStay(other, self) {
        if (other.node.group == "Dun") {
            this.dun=true;
        }
    },
    onCollisionExit(other, self) {
        if (other.node.group == "Dun") {
            this.dun=false;
        }
    },
});