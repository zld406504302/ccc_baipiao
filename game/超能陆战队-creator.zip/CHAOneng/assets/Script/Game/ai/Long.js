let AiAllState = cc.Enum({
    daiji: -1,//待机
    die: -1,//死亡
    attack: -1,//攻击中
})
cc.Class({
    extends: cc.Component,

    properties: {
        AiState: {
            type: AiAllState,
            default: AiAllState.daiji,
        },
        hp: 3000,
        attackGap: 3,//攻击间隔
        gongji1Ratio: 0.3,//攻击方式1比列
        gongji2Ratio: 0.7,//攻击方式2比列
        zidan1: cc.Prefab,//激光
        zidan2: cc.Prefab,//炸弹
        zidan1Effect: cc.Prefab,//炸弹特效
        difficulty: 1,//困难程度  1不随机  2下限随机  3正常随机 4上限随机 5最大值
        zidan1Num: 5,//子弹1数量
        zidan2Num: 2,//子弹数量
        zidan1RandomRange: 3,//子弹1数量随机范围
        zidan2RandomRange: 3,//子弹1数量随机范围
        attackGap: 5,//攻击间隔
        hongzha:cc.Prefab,//轰炸
        hit:cc.Prefab,//爆炸
        tou:cc.SpriteFrame,
    },

    start() {
        this.shiled=cc.find("Canvas/BgRoot/BossShield");
        this.shiled.active=true;
        this.touxiang=cc.find("Canvas/BgRoot/BossShield/bosstou");
        this.touxiang.getComponent(cc.Sprite).spriteFrame=this.tou;
        this.time = new Date().getTime();
        this.ani = this.node.getComponent(sp.Skeleton);
        this.node.position=cc.v2(288,59);
    },
    attackType() {//随机攻击方式
        let type = Math.random();
        if (type < this.gongji1Ratio) {//确定为攻击方式1
            this.AiState = AiAllState.die;
            let it = this.ani.setAnimation(0, "gongji", false);
            if (it) {
                // 注册动画的结束回调
                this.ani.setCompleteListener((trackEntry) => {
                    if (trackEntry.animation.name == "gongji") {
                        this.attack1(this.zidan1Num);//攻击方式1
                        this.time = new Date().getTime();
                        this.AiState = AiAllState.daiji;
                        this.ani.setAnimation(0, "daiji", true);
                    }
                })
            }
        }
        else {//确定为攻击方式2
            this.AiState = AiAllState.die;
            let it = this.ani.setAnimation(0, "gongji2", false);
            if (it) {
                // 注册动画的结束回调
                this.ani.setCompleteListener((trackEntry) => {
                    if (trackEntry.animation.name == "gongji2") {
                        this.attack2(this.zidan2Num);//攻击方式1
                        this.time = new Date().getTime();
                        this.AiState = AiAllState.daiji;
                        this.ani.setAnimation(0, "daiji", true);
                    }
                })
            }
        }
    },
    attack1(num) {//攻击方式1//激光  发射夹角90°
        num = 6;
        let destance = 1000;
        let startAngel = 225;
        let maxAngel = 60;
        for (let i = 0; i < num; i++) {
            let zidan = cc.instantiate(this.zidan1);
            zidan.parent = cc.find("Canvas/EffectPanrent");
            let angel = startAngel - i * maxAngel / (num - 1);
            let rad = cc.misc.degreesToRadians(angel);
            let desty = Math.sin(rad) * destance;
            let destx = Math.cos(rad) * destance;
            zidan.rotation = 360 - angel;
            zidan.position = this.node.position;
            zidan.runAction(
                cc.sequence(
                    cc.moveBy(3, cc.v2(destx, desty)),
                    cc.removeSelf()
                )
            );
        }
    },
    attack2(num) {//攻击方式2// 炸弹

        for (let i = 0; i < num; i++) {
            let zidan = cc.instantiate(this.zidan2);
            zidan.position = this.node;
            zidan.parent = cc.find("Canvas/EffectPanrent");
            let randomX = Math.random() * (cc.winSize.width - this.node.width) - (cc.winSize.width - this.node.width) / 2;
            let bezierTo = cc.bezierTo(3.1, [
                cc.v2(this.node.x, this.node.y),
                cc.v2(this.node.x - cc.winSize.width / 7, cc.winSize.height / 2),
                cc.v2(randomX, -cc.winSize.height * 0.4)
            ]);
            zidan.runAction(
                cc.sequence(
                    cc.spawn(
                        bezierTo,
                        cc.rotateBy(3, 360),
                    ),
                    cc.callFunc(() => {
                        cc.director.emit("hit",zidan,this.zidan1Effect);//炸弹爆炸特效
                        zidan.destroy();
                    })
                ),
            )
        }
    },
    update() {
        this.shiled.getComponent(cc.ProgressBar).progressBar=this.hp/3000;
        // console.log(this.AiState,this.hp);
        if (this.AiState == AiAllState.attack) {//攻击状态
            this.attackType();//随机攻击方式
        }
        else if (this.AiState == AiAllState.daiji) {//待机状态
            let newTime = new Date().getTime();
            if ((newTime - this.time) > 1000 * this.attackGap) {
                this.AiState = AiAllState.attack;
            }
            if (this.hp <= 0) {//播放死亡动画
                this.AiState = AiAllState.die;
                this.hp = 0.0001;
                cc.director.emit("longDie",this.node,this.hit,this.hongzha);//炸弹爆炸特效
            }
        }
    },   
});
