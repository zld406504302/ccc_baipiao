cc.Class({
    extends: cc.Component,

    properties: {
        body: [cc.SpriteFrame],//身体碎片
        bodyPrefab: cc.Prefab,//模板
    },

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start() {
        this.createBody();//身体生成
    },
    createBody() {//身体生成
        for (let i = 0; i < this.body.length; i++) {
            let it = cc.instantiate(this.bodyPrefab);
            this.node.addChild(it);
            it.getComponent(cc.Sprite).spriteFrame = this.body[i];
            this.curveDraw(it);//绘制动画曲线
        }
    },
    curveDraw(target) {//绘制动画曲线
        let isx = Math.random() * cc.winSize.width - cc.winSize.width / 2;
        let it = cc.bezierTo(1, [
            cc.v2(target.x, target.y),
            cc.v2(0, cc.winSize.height),
            cc.v2(isx, -cc.winSize.height - 10),
        ]);
        target.runAction(cc.sequence(it, cc.removeSelf()));
    },
    ww(target) {
        ;//绘制动画曲线
        var ctx = target.getComponent(cc.Graphics);
        ctx.moveTo(20, 20);
        ctx.bezierCurveTo(20, 100, 200, 100, 200, 20);
        ctx.stroke();
    },
    update() {
        if (this.node.children == 0) {
            this.node.destroy();
        }
    }

});
