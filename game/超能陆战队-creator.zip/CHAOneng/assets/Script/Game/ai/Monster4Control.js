let AiAllState = cc.Enum({//怪物移动状态
    Walk: -1,//移动
    Die: -1,//死
    Standby: -1,//待机
});
cc.Class({//怪物攻击类
    extends: cc.Component,
    properties: {
        AiState: {
            type: AiAllState,////怪物所有状态
            default: AiAllState.Walk
        },
        hp: 200,
        AttackGap: 3,//攻击间隔
        AttackType: 0,//攻击方式
        AttackKind: 0,//怪物ID
        speed: -2,//怪物移动速度
        die: cc.Prefab,//碎片
        wait: false,//暂停
        hit: cc.Prefab,//爆炸特效
    },

    start() {
        this.Ai();//调用对应AI
        // this. frameEventsLogon();//注册帧事件
    },
    Ai() {
        // this.loadPicture();//加载怪物图片
        this.bornPosition();//出生位置
    },
    frameEventsLogon() {//注册帧事件
        let animation = this.node.getComponent(cc.Animation);
        animation.on("play", this.attackStartEvent(), this);
    },
    bornPosition() {//出生位置
        let it = cc.find("Canvas/AiPanrent");//怪物父节点  置（0，0）；
        this.node.parent = it;
        let posX = Math.random() * (cc.winSize.width+this.node.width) * 2 - (cc.winSize.width+this.node.width);//x,y
        let posY = Math.random() *(cc.winSize.height+this.node.height) * 2 - (cc.winSize.height+this.node.height);
        if ((posX > (-cc.winSize.width) / 2 && posX < (cc.winSize.width) / 2) || (posY > (-cc.winSize.height) / 2 && posY < (cc.winSize.height) / 2)) {//在地图内则递归刷新位置
            this.bornPosition();//出生位置
        }
        else {//不在地图内则确定位置
            this.node.x = posX;
            this.node.y = posY;
            // return cc.v2(this.node.x, this.node.y);
        }
    },
    targetPosition() {//目标位置
        let it = cc.find("Canvas/Player");
        if (it.x > this.node.x) {
            this.node.scaleX = -1;
        }
        else {
            this.node.scaleX = 1;
        }
        return cc.v2(it.x, it.y);
    },
    update() {
        if (this.wait) {
            this.node.stopAllActions();
            this.node.getComponent(cc.Animation).pause();
        }
        else {
            this.node.resumeAllActions();
            this.node.getComponent(cc.Animation).resume();
            this.stateEvent();//状态事件
        }
    },
    onCollisionEnter(other, self) {
        if (other.node.group == "Dun") {
            cc.director.emit("hit", this.node, this.hit);//炸弹爆炸特效
            this.node.destroy();
        }
    },
    stateEvent() {//状态事件
        if(this.hp<=0){//我死了
            this.hp=1;
            this.AiState=AiAllState.die;
        }
        if(this.AiState==AiAllState.Walk){
            this.AiState=AiAllState.Standby;
            let it  =this.targetPosition() ;//目标位置
            let isx=it.x-this.node.x;
            let isy=it.y-this.node.y;
            let v=cc.v2(isx,isy).normalizeSelf();
            let moveBy = cc.moveBy(8, cc.v2(v.x*cc.winSize.width*1.5, v.y*cc.winSize.width*1.5));
            this.node.runAction(cc.sequence(
                moveBy,
              cc.removeSelf()
            ));
        }
        else if(this.AiState==AiAllState.die){
            this.AiState=AiAllState.Standby;
            this.dieDorpAnimation();//死亡掉落动画
            this.boxPrized() ;//道具箱生成
        }
    },
    boxPrized() {//道具箱生成
        let n=Math.floor(Math.random()*3);
        if(n==0){
            cc.director.emit("PropsBox", this.node);
        }
    },
    dieDorpAnimation() {//死亡掉落动画
        let it = cc.sequence(
            cc.delayTime(0.3),
            cc.spawn(
                cc.moveBy(1, cc.v2(0, -cc.winSize.height)),
                cc.rotateBy(1, 180)
            ),
            cc.removeSelf(),
        )
        this.node.runAction(it);

    },
})