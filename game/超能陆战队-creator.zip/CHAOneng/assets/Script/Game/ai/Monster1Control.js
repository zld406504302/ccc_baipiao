let AiAllState = cc.Enum({//怪物移动状态
    init: -1,//初始
    Walk: -1,//移动
    Die: -1,//死
    SelfDetonate: -1,//自爆
    Standby: -1,//待机
    wall: -1,//碰撞box
});
cc.Class({//怪物攻击类
    extends: cc.Component,

    properties: {
        AiState: {
            type: AiAllState,////怪物所有状态
            default: AiAllState.init
        },
        hp: 100,
        AttackGap: 0,//攻击间隔
        AttackType: 0,//攻击方式
        AttackKind: 0,//怪物ID
        speed: 2,//怪物移动速度
        die: cc.Prefab,//碎片
        wait: false,//暂停
        hit: cc.Prefab,//爆炸特效
        hurtValue: 20,//伤害值
    },

    start() {
        this.Ai();//调用对应AI
    },
    Ai() {
        // this.loadPicture();//加载怪物图片
        this.bornPosition();//出生位置
    },
    bornPosition() {//出生位置
        let it = cc.find("Canvas/AiPanrent");//怪物父节点  置（0，0）；
        this.node.parent = it;
        let posX = Math.random() * (cc.winSize.width + this.node.width) * 2 - (cc.winSize.width + this.node.width);//x,y
        let posY = Math.random() * (cc.winSize.height + this.node.height) * 2 - (cc.winSize.height + this.node.height);
        if ((posX > (-cc.winSize.width) / 2 && posX < (cc.winSize.width) / 2) || (posY > (-cc.winSize.height) / 2 && posY < (cc.winSize.height) / 2)) {//在地图内则递归刷新位置
            this.bornPosition();//出生位置
            if (this.node.x < -cc.winSize.width / 2 - this.node.width / 2) {
                this.node.x = -cc.winSize.width / 2 - this.node.width / 2;
            }
            if (this.node.x > cc.winSize.width / 2 + this.node.width / 2) {
                this.node.x = cc.winSize.width / 2 + this.node.width / 2;
            }
            if (this.node.y < -cc.winSize.height / 2 - this.node.height / 2) {
                this.node.y = -cc.winSize.height / 2 - this.node.height / 2;
            }
            if (this.node.y > cc.winSize.height / 2 + this.node.height / 2) {
                this.node.y = cc.winSize.height / 2 + this.node.height / 2;
            }
        }
        else {//不在地图内则确定位置
            this.node.x = posX;
            this.node.y = posY;
            // return cc.v2(this.node.x, this.node.y);
        }
    },
    targetPosition() {//目标位置
        let it = cc.find("Canvas/Player");
        if (it.x > this.node.x) {
            this.node.scaleX = -1;
        }
        else {
            this.node.scaleX = 1;
        }
        return cc.v2(it.x, it.y);
    },
    update() {
        if (this.wait) {
            this.node.stopAllActions();
            this.node.getComponent(cc.Animation).pause();
        }
        else {
            this.node.resumeAllActions();
            this.node.getComponent(cc.Animation).resume();
            this.stateEvent();//状态事件
        }
    },
    stateEvent() {//状态事件
        if (this.hp <= 0) {
            this.hp = 1;
            this.AiState = AiAllState.Die;//变更为死亡状态
            this.scheduleOnce(()=>{
                this.node.destroy();
            },3)
        }
        if (this.AiState == AiAllState.Walk) {//行走状态
            let target = this.targetPosition();//目标位置
            let isx = target.x - this.node.x;//x,y插值
            let isy = target.y - this.node.y;
            let dis = cc.v2(isx, isy).normalizeSelf();
            this.node.x += dis.x * this.speed;
            this.node.y += dis.y * this.speed;
            if (cc.v2(isx, isy).mag() < 95) {
                this.node.removeComponent(cc.PolygonCollider);
                let moveto = cc.moveBy(0.1, cc.v2(isx, isy));
                this.node.runAction(moveto);
                this.AiState = AiAllState.SelfDetonate;//变更为自爆状态
            }
        }
        else if (this.AiState == AiAllState.Die) {//死亡状态
            this.AiState = AiAllState.Standby;//变为待机状态
            this.node.removeComponent(cc.PolygonCollider);
            this.node.getComponent(cc.Animation).play("monster1_die");//播放动画
            this.dieDorpAnimation();//死亡掉落动画
            this.boxPrized();//道具箱生成
            this.dieDeal();//死亡效果
        }
        else if (this.AiState == AiAllState.SelfDetonate) {//自爆状态
            this.AiState = AiAllState.Standby;//变为待机状态
            //播放站立动画
            let ani = this.node.getComponent(cc.Animation).play("monster1_die");//播放动画
            let it = cc.find("Canvas/Player");
            cc.director.emit("hit", it, this.hit);//炸弹爆炸特效
            cc.director.emit("playHpReduce", this.hurtValue);
            cc.director.emit("subHp", it, this.hurtValue);//主角  或者怪物受到伤害减血
            ani.on("finished", () => {
                this.node.destroy();
            }, this)
        }
        else if (this.AiState == AiAllState.wall) {//碰到护盾
            let speedPlayer = cc.find("Canvas/Player").getComponent("PlayerControl").speed;
            let isx = this.other.node.x - this.node.x;
            let isy = this.other.node.y - this.node.y;
            let vBox = this.toWorldPosition(this.node, this.other.node);//坐标插值单位向量化
            // let vBox = cc.v2(isx, isy).normalizeSelf();
            this.node.x += vBox.x * speedPlayer * 3;
            this.node.y += vBox.y * speedPlayer * 3;
            console.log(speedPlayer, vBox.x, vBox.y + "哈哈哈哈");
        }
        else if (this.AiState == AiAllState.init)//初始状态
        {
            this.initState();//初始状态
        }
    },
    dieDeal() {//死亡效果
        let _die1 = cc.instantiate(this.die);//爆炸碎片
        _die1.parent = cc.find("Canvas/BoxParent");
        _die1.position = this.node.position;
    },
    boxPrized() {//道具箱生成
        let n=Math.floor(Math.random()*3);
        if(n==0){
            cc.director.emit("PropsBox", this.node);
        }
    },
    dieDorpAnimation() {//死亡掉落动画
        let it = cc.sequence(
            cc.delayTime(0.3),
            cc.spawn(
                cc.moveBy(1, cc.v2(0, -cc.winSize.height)),
                cc.rotateBy(1, 180)
            ),
            cc.removeSelf(),
        )
        this.node.runAction(it);
    },
    reduceHp(_hp) {//减血
        this.hp -= _hp;
    },
    onCollisionEnter(other, self) {
        if (other.node.group == "Dun") {
            this.unscheduleAllCallbacks();
            this.other = other;
            this.node.stopAllActions();
            this.AiState = AiAllState.wall;//变更为  碰撞体box
        }
    },
    onCollisionStay(other, self) {
        if (other.node.group == "Dun") {
            this.other = other;
            // this.AiState = AiAllState.wall;//变更为  碰撞体box
        }
    },
    onCollisionExit(other, self) {
        if (other.node.group == "Dun") {
            this.AiState = AiAllState.Standby;//变更为  行走
            this.scheduleOnce(() => {
                this.AiState = AiAllState.Walk;//变更为  行走
            }, 1)
        }
    },
    initState() {//初始状态
        let target = this.targetPosition();//目标位置
        let isx = target.x - this.node.x;//x,y插值
        let isy = target.y - this.node.y;
        let dis = cc.v2(isx, isy).normalizeSelf();
        this.node.x += dis.x * this.speed;
        this.node.y += dis.y * this.speed;
        if (this.node.x > -cc.winSize.width / 2 + this.node.width / 2 &&
            this.node.x < cc.winSize.width / 2 - this.node.width / 2 &&
            this.node.y > -cc.winSize.height / 2 + this.node.height / 2 &&
            this.node.y < cc.winSize.height / 2 - this.node.height / 2) {
            this.AiState = AiAllState.Walk;//变更为行走状态
        }
    },
    toWorldPosition(node, node1) {//坐标插值单位向量化
        let world = node.convertToWorldSpaceAR(cc.v2(0, 0));
        let world1 = node1.convertToWorldSpaceAR(cc.v2(0, 0));
        let isx = world.x - world1.x;
        let isy = world.y = world1.y;
        let v = cc.v2(isx, isy).normalizeSelf();
        return v;
    }
});
