cc.Class({
    extends: cc.Component,//主角控制类

    properties: {
        hp: 100,
        hpStrip: cc.ProgressBar,//血条
        attack1: cc.Label,//子弹1库存
        attack2: cc.Label,//子弹2库存
        attack3: cc.Label,//子弹3库存
        bingdongProps: cc.Label,//道具冰冻库存
        hudunProps: cc.Label,//道具护盾库存
        rocketProps: cc.Label,//道具火箭库存
        addHp: cc.Prefab,//加血
    },

    start() {
        cc.director.on("护盾", () => {
            this.kaiguan = true;
        }, this)
        cc.director.on("护盾消失", () => {
            this.kaiguan = false;
        }, this)
        this.kaiguan = false;
        this.stopMove = false;
        this.moveXL = false;//是否x左移动  ture 移动  false不移动
        this.moveXR = false;//是否x右移动  ture 移动  false不移动
        this.moveYU = false;//上移
        this.moveYD = false;//下移
        this.speed = 10;//速度
        this.speedProps = 600;//道具移动速度
        let zidan1 = Number(localStorage.getItem("子弹"))
        let zidan2 = Number(localStorage.getItem("火箭弹"))
        let zidan3 = Number(localStorage.getItem("火焰弹"))
        if (zidan1 > 100) {
            this.attack1Rest = zidan1;
        } else {
            this.attack1Rest = 100;
        }   //攻击方式1子弹剩余量

        if (zidan2 > 10) {
            this.attack2Rest = zidan2
        } else {
            this.attack2Rest = 10;   //攻击方式2子弹剩余量
        }

        if (zidan3 > 10) {
            this.attack3Rest = zidan3;
        } else {
            this.attack3Rest = 10;   //攻击方式3子弹剩余量
        }
        this.bingdongPropsRest = Number(localStorage.getItem("冰冻")) || 0;//道具冰冻库存
        this.hudunPropsRest = Number(localStorage.getItem("护盾")) ||0;//道具护盾库存
        this.rocketPropsRest = Number(localStorage.getItem("轰炸")) ||0;;//道具火箭库存
        this.aiPanent = cc.find("Canvas/AiPanrent");//怪物父节点  置（0，0）；
        this.monitor();//监听事件
        this.attackKuShow();//子弹剩余量显示
        cc.director.on("playHpReduce", (value) => {
            cc.director.emit("playEffect", "herohurt", 0.6);//播放音效；
            if (this.kaiguan == false) {
                this.hp -= value;
            }
            this.attackKuShow();//子弹剩余量显示  血条显示
        });
        cc.director.on("propsADD", this.moveToTarget, this);//增加道具
        cc.director.on("reduceZidan", this.reduceZidan, this);//发射子弹，，减少库存量
        cc.director.on("updateProps", this.updateProp, this);//刷新道具数量
        cc.director.getCollisionManager().enabled = true;

    },

    nearestPosition() {//最近目标位置
        if (this.aiPanent.childrenCount == 0) {
            return;
        }
        let ais = this.aiPanent.children;//所有怪物数组
        let dis = this.distanceFromTarget(ais[0]);
        let target = ais[0];
        for (let i = 0; i < ais.length; i++) {
            let gap = this.distanceFromTarget(ais[i]);
            if (gap < dis) {
                dis = gap;
                target = ais[i];//取最小距离
            }
        }
        if (target != null) {
            this.lookTarget(target);//面向目标，   旋转
        }
    },
    distanceFromTarget(target) {//到目标点的距离
        let isx = target.x - this.node.x;//x,y插值
        let isy = target.y - this.node.y;
        return cc.v2(isx, isy).mag();
    },
    lookTarget(target) {//面向目标，   旋转
        let isx = target.x - this.node.x;//x,y插值
        let isy = target.y - this.node.y;
        let rad = Math.atan2(isy, isx);//弧度
        let degree = cc.misc.radiansToDegrees(rad);//角度
        this.node.rotation = -degree;
        if (target.x >= this.node.x) {
            this.node.scale = cc.v2(1, 1);
        }
        else {
            this.node.scale = cc.v2(1, -1);
        }
    },
    monitor() {//监听事件
        cc.systemEvent.on(cc.SystemEvent.EventType.KEY_DOWN, this.onKeyDown, this);//按下
        cc.systemEvent.on(cc.SystemEvent.EventType.KEY_UP, this.onKeyUp, this);//松开
        // this.banMove();//禁止移动
    },
    attackKuShow() {//   刷新     子弹剩余量显示  血条显示  道具显示
        this.attack1.string = this.attack1Rest;
        this.attack2.string = this.attack2Rest;
        this.attack3.string = this.attack3Rest;
        this.bingdongProps.string = this.bingdongPropsRest;
        this.hudunProps.string = this.hudunPropsRest;
        this.rocketProps.string = this.rocketPropsRest;
        this.hpStrip.progress = this.hp / 100;
    },
    onKeyDown(event) {//按下
        switch (event.keyCode) {
            case cc.macro.KEY.w: if (!this.stopMove) { this.moveYU = true; } break;
            case cc.macro.KEY.s: if (!this.stopMove) { this.moveYD = true; } break;
            case cc.macro.KEY.a: if (!this.stopMove) { this.moveXL = true; } break;
            case cc.macro.KEY.d: if (!this.stopMove) { this.moveXR = true; } break;
        }
    },
    onKeyUp(event) {//松开
        switch (event.keyCode) {
            case cc.macro.KEY.w: this.moveYU = false; break;
            case cc.macro.KEY.s: this.moveYD = false; break;
            case cc.macro.KEY.a: this.moveXL = false; break;
            case cc.macro.KEY.d: this.moveXR = false; break;
        }
    },
    update() {
        if (this.hp <= 0) {
            this.hp = 0.0001;
            let num = cc.find("Canvas/AllBtn/hecai1").getComponent("Praise").killNum;
            cc.director.emit("GameOver", num, false);
            cc.loader.loadRes("sounds/herodead", cc.AudioClip, (err, clip) => {
                cc.audioEngine.playMusic(clip, false);
                cc.audioEngine.setMusicVolume(0.8);
            })
            cc.find("Canvas").pauseSystemEvents(true);//暂停所有触摸点击事件
            this.node.removeComponent(cc.BoxCollider);
            this.node.runAction(
                cc.spawn(
                    cc.rotateBy(3, 360),
                    cc.moveBy(3, cc.v2(0, -cc.winSize.height))
                ),
                cc.removeSelf()
            )
        }
        else {
            this.moveType();//移动
            this.nearestPosition();//最近目标位置
        }
    },
    moveType() {//移动
        if (this.moveXL) {
            if (this.node.x - this.speed < (-cc.winSize.width / 2 + this.node.width / 2)) {
                return;
            }
            this.node.x -= this.speed;
        }
        if (this.moveXR) {
            if (this.node.x + this.speed > (cc.winSize.width / 2 - this.node.width / 2)) {
                return;
            }
            this.node.x += this.speed;
        }
        if (this.moveYU) {
            if (this.node.y + this.speed > (cc.winSize.height / 2 - this.node.height / 2)) {
                return;
            }
            this.node.y += this.speed;
        }
        if (this.moveYD) {
            if (this.node.y - this.speed < (-cc.winSize.height / 2 + this.node.height / 2)) {
                return;
            }
            this.node.y -= this.speed;
        }
    },
    propsTarget(index) {//道具移动终点
        let target;
        switch (index) {
            case 0: target = cc.find("Canvas"); break;
            case 1: target = cc.find("Canvas/budong UI/BloodStrip"); break;
            case 2: target = cc.find("Canvas/budong UI/Bullte1Rest"); break;
            case 3: target = cc.find("Canvas/budong UI/Bullte2Rest"); break;
            case 4: target = cc.find("Canvas/budong UI/Bullte3Rest"); break;
            case 5: target = cc.find("Canvas/AllBtn/IceBtn"); break;
            case 6: target = cc.find("Canvas/AllBtn/ShieldBtn"); break;
            case 7: target = cc.find("Canvas/AllBtn/RocketBtn"); break;
        }
        return target;
    },
    addProps(index, value) {//增加道具数量
        switch (index) {
            case 0: return;
            case 1: this.hp += value;
                if (this.hp >= 100) {
                    this.hp = 100;
                }
                cc.instantiate(this.addHp); break;
            case 2:
                this.attack1Rest += value;
                cc.director.emit("playEffect", "s_drop1", 0.6);//播放音效；
                break;
            case 3:
                this.attack2Rest += value;
                    cc.director.emit("playEffect", "s_drop1", 0.6);//播放音效；
                break;
            case 4: this.attack3Rest += value;
                cc.director.emit("playEffect", "s_drop2", 0.6);//播放音效；
                break;
            case 5:
                this.bingdongPropsRest += value;
                cc.director.emit("playEffect", "s_drop3", 0.6);//播放音效；
                break;
            case 6:
                this.hudunPropsRest += value;
                cc.director.emit("playEffect", "s_drop3", 0.6);//播放音效；
                break;
            case 7:
                this.rocketPropsRest += value;
                cc.director.emit("playEffect", "s_drop2", 0.6);//播放音效；
                break;

        }
    },
    moveToTarget(node, index,value) {//移动到目标点    node,prefab,index
        let target = this.propsTarget(index);//道具移动终点
        let isx = target.x - node.x;
        let isy = target.y - node.y;
        let v = cc.v2(isx, isy).mag();
        let seq = cc.sequence(
            cc.delayTime(0.1),
            cc.moveBy(0.3, cc.v2(0, 50)),
            cc.moveTo(v / this.speedProps, cc.v2(target.x, target.y)),
            cc.callFunc(() => {
                node.destroy();
                this.addProps(index, value);//道具增加
                if(index==1){
                    cc.director.emit("addHpShow",value);
                }
                this.attackKuShow();//子弹剩余量显示
            })
        )
        if (target.name == "Canvas") {
            node.runAction(cc.sequence(
                cc.moveBy(0.3, cc.v2(0, 50)),
                cc.removeSelf()
            ));
        }
        else {
            node.runAction(seq);
        }
    },
    reduceZidan(index, value) {//发射子弹，，减少库存量
        switch (index) {
            case 0: this.attack1Rest -= value;
                break;
            case 1: this.attack2Rest -= value;
                break;
            case 2: this.attack3Rest -= value;
                break;
            case 3:
                this.bingdongPropsRest -= value;
                break;
            case 4: this.hudunPropsRest -= value;
                break;
            case 5:
                this.rocketPropsRest -= value;
                break;
        }
        this.attackKuShow();//子弹剩余量显示
    },
    findValueTarget(index) {//找到要改变值的对象
        switch (index) {
            case 0: return this.attack1Rest;
            case 1: return this.attack2Rest;
            case 2: return this.attack3Rest;
            case 3: return this.bingdongPropsRest;
            case 4: return this.hudunPropsRest;
            case 5: return this.rocketPropsRest;
        }
    },
    updateProp() {//更新道具
        if (this.attack1Rest > 100) {
            localStorage.setItem("子弹", this.attack1Rest);
        }
        if (this.attack2Rest > 10) {
            localStorage.setItem("火箭弹", this.attack2Rest);
        }
        if (this.attack3Rest > 5) {
            localStorage.setItem("火焰弹", this.attack3Rest);
        }
        localStorage.setItem("护盾", this.bingdongPropsRest);
        localStorage.setItem("冰冻", this.hudunPropsRest);
        localStorage.setItem("轰炸", this.rocketPropsRest);
    }
});
