cc.Class({
    extends: cc.Component,

    properties: {
        qiang1: cc.Node,
        qiang2: cc.Node,
        qiang3: cc.Node,
        reduceBlood: cc.Prefab,//减血
        iceProp: cc.Prefab,//冰冻道具
        // shiledProp:cc.Prefab,//护盾道具
        rockeProp: cc.Prefab,//火箭道具
        waveNum: cc.Label,//第几波
        hit: cc.Prefab,//炸弹爆炸特效
        hongzha: cc.Prefab,//one轰炸
        nuosi: cc.Prefab,
        abossHP: cc.Node,
        music: { type: cc.AudioClip, default: [] },
        nuosiBtN: cc.Button,//洛斯button
    },
    start() {
        // this.wait = true;//false  true暂停
        this.kaihuo()
        cc.director.on("subHp", this.redunceHp, this);//主角  或者怪物受到伤害减血
        cc.director.on("webPlayer", this.webCreate, this);//蜘蛛网生成及其销毁
        cc.director.on("hit", this.hitEffect, this);//炸弹爆炸特效
        cc.director.on("longDie", this.longDie, this);//炸弹爆炸特效
        cc.director.on("playMusic", this.playMusic, this);//播放背景音乐；
        cc.director.on("playEffect", this.playEffect, this);//播放音效；
        cc.director.emit("playMusic", "battle", 0.5);//播放背景音乐；
        // cc.director.emit("playEffect", "51", 0.6);//播放音效；
        this.bosshp = 1;
        this.prs = this.abossHP.getComponent(cc.ProgressBar)
        this.prs.progress = this.bosshp;
        cc.director.on("护盾", () => {
            this.kaiguan = true;
        }, this)

        cc.director.on("护盾消失", () => {
            this.kaiguan = false;
        }, this)
        this.kaiguan = false;
        this.luosiValue = Number(localStorage.getItem("luosiValue"));
        if(this.luosiValue >= 100){
            this.nuosiBtN.interactable = true;//洛斯button
            this.nuosiBtN.node.getChildByName("Background").getComponent(cc.Sprite).fillRange=1;
        }
        else{
            this.nuosiBtN.interactable = false;//洛斯button
            this.nuosiBtN.node.getChildByName("Background").getComponent(cc.Sprite).fillRange=this.luosiValue/100;
        }
    },
    kaihuo() {
        this.qiang1.on(cc.Node.EventType.TOUCH_START, function () {
            cc.director.emit("开火1");
            this.qiang1.scale = cc.v2(0.9, 0.9);
            this.schedule(this.shoot1, 0.2);
        }, this)
        this.qiang1.on(cc.Node.EventType.TOUCH_END, function () {
            this.unschedule(this.shoot1);
            this.qiang1.scale = cc.v2(1, 1);
        }, this)

        this.qiang1.on(cc.Node.EventType.TOUCH_CANCEL, function () {
            this.unschedule(this.shoot1);
            this.qiang1.scale = cc.v2(1, 1);
        }, this)



        this.qiang2.on(cc.Node.EventType.TOUCH_START, function () {
            cc.director.emit("开火2");
            this.qiang2.scale = cc.v2(0.9, 0.9);
            this.schedule(this.shoot2, 0.2);
        }, this)
        this.qiang2.on(cc.Node.EventType.TOUCH_END, function () {
            this.unschedule(this.shoot2);
            this.qiang2.scale = cc.v2(1, 1);
        }, this)

        this.qiang2.on(cc.Node.EventType.TOUCH_CANCEL, function () {
            this.unschedule(this.shoot2);
            this.qiang2.scale = cc.v2(1, 1);
        }, this)


        this.qiang3.on(cc.Node.EventType.TOUCH_START, function () {
            cc.director.emit("开火3");
            this.qiang3.scale = cc.v2(0.9, 0.9);
            // this.schedule(this.shoot3, 0.2);
        }, this)
        this.qiang3.on(cc.Node.EventType.TOUCH_END, function () {
            // this.unschedule(this.shoot3);
            this.qiang3.scale = cc.v2(1, 1);
        }, this)

        this.qiang3.on(cc.Node.EventType.TOUCH_CANCEL, function () {
            // this.unschedule(this.shoot3);
            this.qiang3.scale = cc.v2(1, 1);
        }, this)
        this.banShoot();//禁止射击
    },
    shoot1() {//开火
        cc.director.emit("开火1");
    },

    shoot2() {//开火
        cc.director.emit("开火2");
    },
    shoot3() {//开火
        cc.director.emit("开火3");
    },
    banShoot() {//禁止射击
        cc.director.on("禁止开火", () => {
            this.unschedule(this.shoot1);
            this.unschedule(this.shoot2);
            this.unschedule(this.shoot3);
            this.qiang1.scale = cc.v2(1, 1);
            this.qiang2.scale = cc.v2(1, 1);
            this.qiang3.scale = cc.v2(1, 1);
        }, this);
    },
    addBoxCanvas() {
    },
    redunceHp(node, str) {//减血
        if (node.name == "Player") {
            if (this.kaiguan == true) {
                return;
            }
        }
        let it = cc.instantiate(this.reduceBlood);
        it.getChildByName("reduceHp").getComponent(cc.Label).string = ":" + str;
        it.parent = cc.find("Canvas");
        it.position = cc.v2(node.x, node.y + 50);
        let children = node._components;;
        children.forEach(element => {
            cc.log(node.name)
            // console.log(typeof(element.AiState));
            if (typeof (element.AiState) == "number") {
                element.hp -= str;
                if (node.name == 'long' || node.name == 'jiqirenboss') {
                    this.bosshp -= str / 3000
                    this.prs.progress = this.bosshp
                }
                if (element.hp <= 0) {
                    cc.director.emit("hecai");
                }
            }

        });
        this.scheduleOnce(() => {
            it.destroy();
        }, 1)
    },
    waitBtn() {//等待  暂停按钮
        let all = cc.find("Canvas");
        let but = cc.find("Canvas/AllBtn/WaitBtn")
        if (cc.game.isPaused()) {
            cc.game.resume();
            all.resumeSystemEvents(true);//恢复所有触摸点击事件
        } else {
            //延迟执行暂停
            this.scheduleOnce(function () {
                all.pauseSystemEvents(true);//暂停所有触摸点击事件
                but.resumeSystemEvents(true);
                cc.game.pause();
            }, 0.15);
        }
    },
    lceBtn() {//冰冻按钮
        let index = 3;
        let player = cc.find("Canvas/Player");//查看是否还有子弹
        let target = player.getComponent("PlayerControl").findValueTarget(index);//找到要改变值的对象
        if (target <= 0) {
            return;//没有子弹返回
        }
        cc.audioEngine.playMusic(this.music[0], false)
        // cc.loader.loadRes("sounds/s_prop3", cc.AudioClip, (eve) => {//播放道具音乐
        //     let effect = cc.audioEngine.playEffect(eve);
        //     cc.audioEngine.setVolume(effect, 0.8);
        // })
        player.getComponent("PlayerControl").reduceZidan(index, 1);//发射子弹，，减少库存量
        let ais = cc.find("Canvas/AiPanrent");
        let _children = ais.children;
        _children.forEach(element => {//ai
            let have = element.getChildByName("bingdong");
            if (!have) {//没有冰冻就创建
                let it = cc.instantiate(this.iceProp);
                it.parent = element;
            }
            else {//有冰冻删除后再创建
                have.destroy();
                let it = cc.instantiate(this.iceProp);
                it.parent = element;
            }
        });
    },
    shieldBtn() {//护盾
        let index = 4;
        let player = cc.find("Canvas/Player");
        let target = player.getComponent("PlayerControl").findValueTarget(index);//找到要改变值的对象
        if (target <= 0) {
            return;
        }
        cc.audioEngine.playMusic(this.music[1], false)
        // cc.loader.loadRes("sounds/s_prop2", cc.AudioClip, (eve) => {
        //     let effect = cc.audioEngine.playEffect(eve);
        //     cc.audioEngine.setVolume(effect, 0.8);
        // })
        player.getComponent("PlayerControl").reduceZidan(index, 1);//发射子弹，，减少库存量
        cc.director.emit("hudun");
    },
    rockeBtn() {//火箭
        let index = 5;
        let player = cc.find("Canvas/Player");
        let target = player.getComponent("PlayerControl").findValueTarget(index);//找到要改变值的对象
        if (target <= 0) {
            return;
        }
        cc.loader.loadRes("sounds/hedan", cc.AudioClip, (eve) => {
            let effect = cc.audioEngine.playEffect(eve);
            cc.audioEngine.setVolume(effect, 0.8);
        })
        player.getComponent("PlayerControl").reduceZidan(index, 1);//发射子弹，，减少库存量
        let it = cc.instantiate(this.rockeProp);
        it.parent = cc.find("Canvas/EffectPanrent");
    },
    webCreate(prefab, node) {//蜘蛛网生成及其销毁
        let it = cc.instantiate(prefab);
        it.parent = this.node;
        it.position = node;
        let player = cc.find("Canvas/Player").getComponent("PlayerControl");
        player.stopMove = true;
        this.scheduleOnce(() => {
            player.stopMove = false;
            it.destroy();
        }, 3)
    },
    hitEffect(node, prefab) {//爆炸特效
        let it = cc.instantiate(prefab);
        it.parent = cc.find("Canvas");
        it.position = node.position;
        let ani = it.getComponent(cc.Animation);
        ani.on("finished", () => {
            it.destroy();
        }, this)
    },
    longDie(node, prefab1, prefab2) {//龙死了
        let ku = [
            cc.v2(node.x, node.y),
            cc.v2(node.x - 50, node.y + 20),
            cc.v2(node.x + 50, node.y - 20),
            cc.v2(node.x, node.y + 20)
        ];
        node.removeComponent(cc.CircleCollider);
        for (let i = 0; i < ku.length; i++) {
            let it = cc.instantiate(node);
            it.position = ku[i];
            this.scheduleOnce(() => {
                cc.director.emit("hit", it, prefab1);//炸弹爆炸特效;
                it.destroy();
                if (i == ku.length - 1) {
                    node.destroy();
                    let ta = cc.instantiate(prefab2);
                    ta.parent = cc.find("Canvas");
                    ta.position = node.position;
                    this.scheduleOnce(() => {
                        ta.destroy();
                    }, 0)
                }
            }, 0.3 * i);
        }
    },

    nuosia() {
            this.nuosiBtN.interactable = false;//洛斯button
            let it = cc.instantiate(this.nuosi)
            it.parent = this.node;
            it.position = cc.v2(0, 0)
            localStorage.setItem("luosiValue",0);
    },
    playMusic(str, value) {
        cc.loader.loadRes("sounds/" + str, cc.AudioClip, (err, clip) => {
            cc.audioEngine.playMusic(clip, true);
            cc.audioEngine.setMusicVolume(value);
        });
    },
    playEffect(str, value) {
        cc.loader.loadRes("sounds/" + str, cc.AudioClip, (err, clip) => {
            cc.audioEngine.playEffect(clip, false);
            cc.audioEngine.setEffectsVolume(value);
        });
    }
});
