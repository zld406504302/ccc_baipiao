cc.Class({
    extends: cc.Component,

    properties: {
        obj1: cc.Prefab,//攻击方式1
        obj2: cc.Prefab,//攻击方式2
        obj3: cc.Prefab,//攻击方式3
        attack1: cc.Label,//子弹1库存
        attack2: cc.Label,//子弹2库存
        attack3: cc.Label,//子弹3库存
        danjia: cc.Prefab, //弹夹
        nuosijj: cc.Prefab,
        objMusic: [cc.AudioClip],
    },


    start() {
        this.jjxs = false;
        this.zd4 = false;
        cc.director.on("开火1", function () {
            let zidan1 = this.attack1.getComponent(cc.Label)
            if (zidan1.string == 0) {
                return;
            }
            var anim = this.node.getComponent(cc.Animation);
            let animState = anim.play('Pler clip');
            animState.wrapMode = cc.WrapMode.Loop;
            anim.playAdditive('zidan1');
            this.yidalipao(this.obj1, 0);
            this.danjiasc();
        }, this);

        cc.director.on("开火2", function () {
            let zidan1 = this.attack2.getComponent(cc.Label)
            if (zidan1.string == 0) {
                return;
            }
            var anim = this.node.getComponent(cc.Animation);
            let animState = anim.play('Player2');
            animState.wrapMode = cc.WrapMode.Loop;
            anim.playAdditive('zidan2');
            this.yidalipao(this.obj2, 1);
        }, this);

        cc.director.on("开火3", function () {
            let zidan1 = this.attack3.getComponent(cc.Label)
            if (zidan1.string == 0) {
                return;
            }
            cc.audioEngine.playMusic(this.objMusic[2], false)
            var anim = this.node.getComponent(cc.Animation);
            let animState = anim.play('Player 3');
            animState.wrapMode = cc.WrapMode.Loop;
            anim.playAdditive('zidan3', 2);
            let firePoint = this.node.getChildByName("firePointStart");
            let it = cc.instantiate(this.obj3);//实例化子弹
            let zuobiao = this.toWorldPosition(firePoint)
            it.parent = cc.find("Canvas")//父节点
            it.rotation = this.node.rotation;
            it.position = zuobiao;
            let player = cc.find("Canvas/Player");
            player.getComponent("PlayerControl").reduceZidan(2, 1);//发射子弹，，减少库存量
        }, this);

        cc.director.on("nuosijj", function () {
            this.jj = cc.instantiate(this.nuosijj);
            this.jj.parent = this.node
            this.jj.position = cc.v2(0, 0)
        }, this);



        cc.director.on("jjxs", function () {
            this.jj.destroy();
            let all = cc.find("Canvas");
            all.resumeSystemEvents(true)
        }, this);


    },

    yidalipao(x, index) {
        let player = cc.find("Canvas/Player");
        let target = player.getComponent("PlayerControl").findValueTarget(index);//找到要改变值的对象
        if (target <= 0) {
            return;
        }
        cc.audioEngine.playEffect(this.objMusic[index], false);
        cc.audioEngine.setEffectsVolume(0.5);
        player.getComponent("PlayerControl").reduceZidan(index, 1);//发射子弹，，减少库存量
        let firePoint = this.node.getChildByName("firePointEnd");
        let it = cc.instantiate(x);//实例化子弹
        it.parent = cc.find("Canvas");//父节点
        it.rotation = this.node.rotation;//角度一致 
        it.position = this.toWorldPosition(firePoint);//转为世界坐标;//子弹生成的位置
        let targetPos = this.launchDirection();//发射方向
        let ac = cc.moveBy(1, cc.v2(cc.winSize.width * targetPos.x, cc.winSize.width * targetPos.y))
        var finished = cc.callFunc(function () {
            it.destroy();
        }, this);
        var ty = cc.sequence(ac, finished)
        it.runAction(ty);
    },

    launchDirection() {//发射方向
        let play = this.toWorldPosition(this.node.getChildByName("firePointStart"));//转为世界坐标  玩家
        let fire = this.toWorldPosition(this.node.getChildByName("firePointEnd"));//转为世界坐标  开火点
        let isx = fire.x - play.x;
        let isy = fire.y - play.y;
        let isv = cc.v2(isx, isy).normalize();//单位向量化
        return isv;
    },
    toWorldPosition(node) {//转为世界坐标
        let worldPos = node.convertToWorldSpaceAR(cc.v2(0, 0));
        let startPos = cc.find("Canvas").convertToNodeSpaceAR(worldPos);
        return startPos;
    },

    danjiasc() {
        let it = cc.instantiate(this.danjia);
        let c = this.node.getChildByName("DanJia")
        let csj = c.convertToWorldSpaceAR(cc.v2(0, 0));
        let xsj = cc.find("Canvas").convertToNodeSpaceAR(csj)
        it.parent = cc.find("Canvas")
        it.position = cc.v2(xsj.x, xsj.y)
        let a = Math.floor(Math.random() * 200)
        let b = Math.floor(Math.random() * 50) + 350;
        let d = Math.floor(Math.random() * 10)
        if (d % 4 === 0) {
            let itc = cc.bezierTo(1.2, [
                cc.v2(xsj.x + a, xsj.y + 300),
                cc.v2(xsj.x + a + 50, xsj.y - b),
                cc.v2(xsj.x + a, xsj.y - b),
            ]);
            it.runAction(itc)
        } else {
            let cad = cc.bezierTo(1.2, [
                cc.v2(xsj.x - a, xsj.y + 300),
                cc.v2(xsj.x - a - 50, xsj.y - b),
                cc.v2(xsj.x - a, xsj.y - b),
            ]);
            it.runAction(cad)
        }
        this.scheduleOnce(() => {
            it.destroy();
        }, 1)
    }
});
