

cc.Class({
    extends: cc.Component,

    properties: {

        speed:10,
    },

      update(){
       if(this.fw ==false){
           if(this.node.x+this.x/10 <(cc.winSize.width / 2 - this.node.width/2)&& this.node.x+this.x/10>(-cc.winSize.width / 2 + this.node.width/2)){
               if(this.node.y+this.y/10<(cc.winSize.height / 2 - this.node.height / 2)&&this.node.y+this.y/10>(-cc.winSize.height / 2 + this.node.height / 2)){
                this.node.x = this.node.x +this.x/10;
                this.node.y = this.node.y +this.y/10;
               }
           }
           if(this.node.x+this.x/10>(cc.winSize.width / 2 -this.node.width/2)|| this.node.x+this.x/10<(-cc.winSize.width / 2 + this.node.width/2)){
            if(this.node.y+this.y/10<(cc.winSize.height / 2 - this.node.height / 2)&&this.node.y+this.y/10>(-cc.winSize.height / 2 + this.node.height / 2)){
                this.node.y = this.node.y +this.y/10;
            }
           }
           if(this.node.y+this.y/10>(cc.winSize.height / 2 - this.node.height / 2)||this.node.y+this.y/10<(-cc.winSize.height / 2 + this.node.height / 2)){
            if(this.node.x+this.x/10<(cc.winSize.width / 2 - this.node.width/2)&& this.node.x+this.x/10>(-cc.winSize.width / 2 + this.node.width/2)){
                this.node.x = this.node.x +this.x/10;
            }
           }
       }  
      },
    start () {
        this.fw =true;
        cc.director.on('遥杆', function (x,y) {
            this.fw =false;
          this.x =x;
          this.y =y;
        }, this);
        cc.director.on("遥杆复位",function () {
            this.fw =true;
          }, this);
    },

});
