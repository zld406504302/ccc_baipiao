

cc.Class({
    extends: cc.Component,

    properties: {
        Rocker: cc.Node,
        Max_r: 60,
    },



    start() {
        this.qishi = cc.v2(0, 0)
        
        this.Rocker.on(cc.Node.EventType.TOUCH_START, function (e) {
            var w_pos = e.getLocation(); //先获取触摸节点的坐标   
            var pos = this.node.convertToNodeSpaceAR(w_pos); //转换为在 父节点下的坐标
            if (pos.mag() > 60) {
                pos.normalizeSelf();
                pos = cc.v2(pos.x * 60, pos.y * 60);
            }
            this.Rocker.setPosition(pos);
            cc.director.emit("遥杆", pos.x, pos.y)
        }, this);

        this.Rocker.on(cc.Node.EventType.TOUCH_MOVE, function (e) {
            var w_pos = e.getLocation(); //先获取触摸节点的坐标
            var pos = this.node.convertToNodeSpaceAR(w_pos); //转换为在父节点下的坐标
            if (pos.mag() > 60) {
                pos.normalizeSelf();
                pos = cc.v2(pos.x * 60, pos.y * 60);
            } 
            this.Rocker.setPosition(pos);
            cc.director.emit("遥杆", pos.x, pos.y)
        }, this);

        this.Rocker.on(cc.Node.EventType.TOUCH_END, function (e) {
            this.Rocker.setPosition(this.qishi);
            cc.director.emit("遥杆复位")
        }, this);

        this.Rocker.on(cc.Node.EventType.TOUCH_CANCEL, function (e) {
            this.Rocker.setPosition(this.qishi);
            cc.director.emit("遥杆复位")
        }, this)
    },

});
