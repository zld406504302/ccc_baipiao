let AiAllState = cc.Enum({//怪物移动状态
    Walk: -1,//移动
    Stand: -1,//站立
    WalkAttack: -1,//移动攻击
    StandAttack: -1,//站立攻击
    Die: -1,//死
});
cc.Class({//怪物攻击类
    extends: cc.Component,

    properties: {
        AiState: {
            type: AiAllState,////怪物所有状态
            default: AiAllState.Stand
        },
        hp: 0,
        AttackGap: 0,//攻击间隔
        AttackType: 0,//攻击方式
        AttackKind: 0,//怪物ID
    },

    start() {
        this.Ai();//调用对应AI
    },
    Ai() {
        // this.loadPicture();//加载怪物图片
        this.bornPosition();//出生位置
    },
    bornPosition() {//出生位置
        let it = cc.find("Canvas/AiPanrent");//怪物父节点  置（0，0）；
        this.node.parent = it;
        let posX = Math.random() * cc.winSize.width * 2 - cc.winSize.width;//x,y
        let posY = Math.random() * cc.winSize.height * 2 - cc.winSize.height;
        if ((posX > (-cc.winSize.width) / 2 && posX < (cc.winSize.width) / 2) || (posY > (-cc.winSize.height) / 2 && posY < (cc.winSize.height) / 2)) {//在地图内则递归刷新位置
             this.bornPosition();//出生位置
        }
        else {//不在地图内则确定位置
            this.node.x = posX;
            this.node.y = posY;
            // return cc.v2(this.node.x, this.node.y);
        }
    },
    targetPosition() {//目标位置
        let it = cc.find("Canvas/Player");
        if(it.x>this.node.x){
            // this.node.getComponent(cc.Sprite).flipX=true;
        //   this.node.flipX=true;
        this.node.scaleX=-1;
        }
        else{
            // this.node.getComponent(cc.Sprite).flipX=false;
            // this.node.flipX=false;
            this.node.scaleX=1;
        }
        return cc.v2(it.x, it.y);
    },
    update() {
        // console.log("位置:"+this.node.x+this.node.y);
        this.stateEvent();//状态事件
    },
    stateEvent() {//状态事件
        if (this.AiState == AiAllState.Walk) {//行走状态
            let target = this.targetPosition();//目标位置
            let isx = target.x - this.node.x;//x,y插值
            let isy = target.y - this.node.y;
            let speed = 1;//还未改为读表速度
            let dis = cc.v2(isx, isy).normalizeSelf();
            this.node.x += dis.x * speed;
            this.node.y += dis.y * speed;
            // console.log("位置//行走状态:"+this.node.x+this.node.y);
        }
        else if (this.AiState == AiAllState.Stand) {//站立状态
            //播放站立动画
            // console.log("位置this.AiState.Stand) {//站立状态:"+this.node.x+this.node.y);
        }
        else if (this.AiState == AiAllState.StandAttack) {//攻击状态
            //播放站立动画
            // console.log("位置this.AiState.StandAttack) {//攻击状态) {//站立状态:"+this.node.x+this.node.y);
        }
    }

});
