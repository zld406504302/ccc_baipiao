let aiGencerCfg = require("../Config/AiGencerCfg");//ai生成表
cc.Class({
    extends: cc.Component,

    properties: {
        ais: [cc.Prefab],//所有ai
        wxyj:cc.Prefab,
        abossHP: cc.Node,
        bosstou: [cc.SpriteFrame],
    },
    start() {
        this.create = false;
        this._pass =parseInt (localStorage.getItem("选择关卡"));//关卡
        if (!this._pass) {
            this._pass = 1;
        }
        this.mids = aiGencerCfg[this._pass].Mids;//所有波数ai类型
        this.boNum = 0;//第几波
        this.createAiTime = 0;
        this.scheduleOnce(() => {
            this.createBoAi();//创建第几波ai
        }, 0)
        this.abossHP.active = false;
        this.prs = this.abossHP.getComponent(cc.ProgressBar)
    },
    createBoAi() {//创建第几波ai
        if(!this.mids[this.boNum])  return;
        let arr = this.mids[this.boNum];//第几波所有集合
        let typeArr = arr.split("-");//解析数组  第几波所有ai类型
        cc.director.emit("bo", this.boNum, aiGencerCfg[this._pass].Wave);//波数显示
        cc.director.emit("boShow", this.boNum, this);//第几波显示
        this.scheduleOnce(() => {
            for (let i = 0; i < aiGencerCfg[this._pass].Amount[this.boNum]; i++) {
                let type = Math.floor(Math.random() * typeArr.length);
                if(typeArr[type] == 10 ){
                    type = 4
                }
                let time = Math.floor(Math.random() * aiGencerCfg[this._pass].Time[this.boNum]);
                this.createAiTime += time / 1000;
                this.scheduleOnce(() => {
                    this.createAi(type);//生成ai
                    this.create = true;
                }, this.createAiTime);
            }
        }, 2);
    },
    createAi(type) {//生成ai
        if(type==4){
                let ift = cc.instantiate(this.wxyj);
                cc.director.emit("playEffect", "warnning", 0.6);//播放音效；
                ift.parent =this.node
                ift.position = cc.v2(0,0)
                var ske = ift.getComponent(sp.Skeleton);
                let tx = this.abossHP.getChildByName("bosstou")
                let txa = tx.getComponent(cc.Sprite)
                txa.spriteFrame = this.bosstou[1]
                this.abossHP.active = true;
                // this.kong = new cc.Node(),
                // this.node.addChild(this.kong);
              ske.setCompleteListener(() => {
                  ift.destroy();
                //   this.scheduleOnce(() => {
                  let it = cc.instantiate(this.ais[type]);//
                  this.node.addChild(it);//添加ai
                  it.x = 235.5;
                // }, 2);
              })
        }else if(type == 5){
            let ift = cc.instantiate(this.wxyj);
            ift.parent =cc.find("Canvas")
            ift.position = cc.v2(0,0)
            cc.director.emit("playEffect", "warnning", 0.6);//播放音效；
            var ske = ift.getComponent(sp.Skeleton);
            let tx = this.abossHP.getChildByName("bosstou")
            let txa = tx.getComponent(cc.Sprite)
            txa.spriteFrame = this.bosstou[0]
            this.abossHP.active = true;
          ske.setCompleteListener(() => {
              ift.destroy();
              this.scheduleOnce(() => {
              let it = cc.instantiate(this.ais[type]);//
              this.node.addChild(it);//添加ai
              it.x = 235.5;
            }, 2);
          })

        }else{
            let it = cc.instantiate(this.ais[type]);//
            this.node.addChild(it);//添加ai
            it.x = 10000;
        }
    },
    dataIt() {//数据
        // this.
    },
    update() {
        if (this.boNum > this.mids.length-1) {//结算
            let num = cc.find("Canvas/AllBtn/hecai1").getComponent("Praise").killNum;
            cc.director.emit("GameOver", num, true);
            this.create = false;
            this.boNum=-1;
        } 
        else {
            if (this.create) {
                let child = cc.find("Canvas/AiPanrent")
                let childa = child.children;
                if (childa == 0) {
                    this.create = false;
                    this.boNum++;
                    this.createBoAi();//创建第几波ai
                }
            }
        }
        if(this.prs.progress <= 0.02){ 
            this.boNum = this.boNum +1;
            this.prs.progress = 0.021
        }

    },
    multipleHp(target){//血量递增；
        let children=target._components;
        children.forEach(element => {
            if(element.hp){
                element.hp*= aiGencerCfg[this._pass].Hp;
            }
        });
    }
});
