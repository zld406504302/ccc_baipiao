cc.Class({
    extends: cc.Component,

    properties: {
        hurtValue:10,//伤害
        die:false,//false不销毁 true 销毁
        hit:cc.Prefab,//炸弹爆炸特效
        hitTrue:false,//是否爆炸
    },
    start() {
    },
    onCollisionEnter(other, self) {//
        if (other.node.group == "Box") {
            this.node.destroy();
        }
        if (other.node.group == "Ai") {
            //播放子弹结束效果
            cc.director.emit("subHp", other.node,this.hurtValue);
            if(this.hitTrue){
                cc.director.emit("hit",other.node,this.hit);//炸弹爆炸特效
            }
            if(!this.die){
                this.node.destroy();
            }
        }
        if (other.node.group == "Player") {
            if(!this.die){
                this.node.removeComponent(cc.BoxCollider);
            }
            // this.node.removeComponent(cc.BoxCollider);
            cc.director.emit("playHpReduce", this.hurtValue);
           cc.director.emit("subHp", other.node,this.hurtValue);
            if(this.die){
                cc.director.emit("hit",other.node,this.hit);//炸弹爆炸特效
                this.node.destroy();
            }
        }
    },
    update(){
        if(this.node.x<-cc.winSize.width/2  || this.node.x>cc.winSize.width/2
             ||this.node.y<-cc.winSize.height/2  ||this.node.y>cc.winSize.height/2   ){
                this.node.destroy();
             }
    }
});
