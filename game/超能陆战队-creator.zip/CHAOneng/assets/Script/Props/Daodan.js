cc.Class({
    extends: cc.Component,

    properties: {
        bg: cc.Node,
        xian: cc.Node,
        daodan: cc.Node,
        hongzha: cc.Node,
    },
    start() {
        this.time = 1;
        let _hongzha = this.hongzha.getComponent(sp.Skeleton);
        this.hongzha.x = 1000;
        let all = cc.find("Canvas");
        all.pauseSystemEvents(true);//暂停所有触摸点击事件
        this.pauseAll(all);//遍历子节点
        cc.loader.loadRes("sounds/hedan",cc.AudioClip,(err,clip)=>{
            cc.audioEngine.pauseMusic();
            cc.audioEngine.playEffect(clip,false);
            cc.audioEngine.setEffectsVolume(0.8);
        })
        this.scheduleOnce(() => {
            this.bg.destroy();
            this.xian.destroy();
            this.daodan.destroy();
            this.hongzha.x = 0;
            cc.loader.loadRes("sounds/hebao",cc.AudioClip,(err,clip)=>{
                cc.audioEngine.playEffect(clip,false);
                cc.audioEngine.setEffectsVolume(0.8);
            })
            let it = _hongzha.setAnimation(0, "hongzha", false);
            if (it) {
                // 注册动画的结束回调
                _hongzha.setCompleteListener((trackEntry) => {
                    if (trackEntry.animation.name == "hongzha") {
                        cc.audioEngine.resumeMusic();
                        this.resumeAll(all);//遍历子节点
                        all.resumeSystemEvents(true);//恢复所有触摸点击事件
                        this.node.destroy();
                    }
                })
            }
        }, 3);
    },
    pauseAll(target) {//遍历子节点
        target.pauseAllActions();
        let children = target.children;
        children.forEach(element => {
            if (element.name != "daodanRoot") {
                let it = element._components;
                it.forEach(ele => {
                    if (typeof ele.AiState=="number") {
                        ele.wait =true;
                    }
                });
                this.pauseAll(element);//遍历子节点
            }
        });
    },
    resumeAll(target) {//恢复动作
        let children = target.children;
        target.resumeAllActions();
        children.forEach(element => {
            let it = element._components;
            it.forEach(ele => {
                if (typeof ele.AiState=="number") {
                    ele.wait =false;
                    ele.hp-=100;
                }
            });
            this.resumeAll(element);//遍历子节点
        });
    }
});
