cc.Class({
    extends: cc.Component,

    properties: {
        timeLabel: cc.Label,//护盾时间
    },
    start() {
        this.node.x = 10000;
        this.startTime = 0;
        this.allTime = 0;
        this.hd1 = false;
        cc.director.on("hudun1", () => {
            cc.director.emit("护盾");
            if (this.allTime == 0) {
                this.allTime = 15;
                this.startTime = new Date().getTime();
                this.node.x = 0;
                this.node.scale = cc.v2(1.3,1.3) ;
                this.hd1 =true;
            }
        })
        
        cc.director.on("hudun", () => {
            cc.director.emit("护盾");
            if (this.allTime == 0) {
                this.allTime = 5;
                this.startTime = new Date().getTime();
                this.node.x = 0;
            }
            else {
                this.allTime += 3;
            }
        });
    },
    update() {
        if (this.allTime != 0) {
            let newTime = new Date().getTime();
            let it = this.allTime - (newTime - this.startTime) / 1000;
            if (it <= 0) {
                this.allTime = 0;
                this.node.x = 10000;
                this.node.scale = cc.v2(1,1)
                cc.director.emit("护盾消失");
                if(this.hd1 == true){
                    cc.director.emit("jjxs");
                    cc.director.emit("护盾消失");
                }
            }
            else {
                this.timeLabel.string = Math.floor(it);
                if(this.hd1 == false){
                    this.toPosition();//转坐标
                }else{
                    this.toPosition1();
                }
            }
        }
    },
    toPosition() {//转坐标
        let worldPos = this.node.convertToWorldSpaceAR(cc.v2(0, 0));
        let nodePos = this.node.parent.convertToNodeSpaceAR(cc.v2(worldPos.x, worldPos.y + 58));
        let nodePos1 = this.node.parent.convertToNodeSpaceAR(cc.v2(worldPos.x + 10, worldPos.y + 58));
        this.timeLabel.node.position = nodePos;
        let isx = nodePos1.x - nodePos.x;//x,y插值
        let isy = nodePos1.y - nodePos.y;
        let rad = Math.atan2(isy, isx);//弧度
        let degree = cc.misc.radiansToDegrees(rad);//角度
        this.timeLabel.node.rotation = -degree;
        this.timeLabel.node.scaleY = this.node.parent.scaleY;
    },
    toPosition1() {//转坐标
        let worldPos = this.node.convertToWorldSpaceAR(cc.v2(0, 0));
        let nodePos = this.node.parent.convertToNodeSpaceAR(cc.v2(worldPos.x, worldPos.y + 98));
        let nodePos1 = this.node.parent.convertToNodeSpaceAR(cc.v2(worldPos.x + 10, worldPos.y + 98));
        this.timeLabel.node.position = nodePos;
        let isx = nodePos1.x - nodePos.x;//x,y插值
        let isy = nodePos1.y - nodePos.y;
        let rad = Math.atan2(isy, isx);//弧度
        let degree = cc.misc.radiansToDegrees(rad);//角度
        this.timeLabel.node.rotation = -degree;
        this.timeLabel.node.scaleY = this.node.parent.scaleY;
    },
    // onCollisionEnter(other,self){
    //     if(other.group=="Ai"){
    //         let isx=other.x-this.node.x;
    //         let isy=other.y-this.node.y;
    //         let rad=Math.atan2(isy,isx);
    //         let degree=cc.misc.radiansToDegrees(rad);
    //         other.node.run
    //     }
    // }
});
