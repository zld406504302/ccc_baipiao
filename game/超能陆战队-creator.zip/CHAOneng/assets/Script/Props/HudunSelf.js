
cc.Class({
    extends: cc.Component,

    onCollisionEnter(other, self) {//
        console.log("1111");
        if(other.node.group=="AiButtle"){
            other.node.destroy();
        }
        if(other.node.group=="Ai"){
            other.node.destroy();
        }
    },
});
