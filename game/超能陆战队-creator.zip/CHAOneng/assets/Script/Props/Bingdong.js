cc.Class({
    extends: cc.Component,

    properties: {
    },
    start() {
        this.pauseAll(this.node.parent.parent);//暂停
        this.scheduleOnce(() => {
            this.resumeAll(this.node.parent.parent);//恢复动作
            this.node.destroy();
        }, 3);
    },
    pauseAll(target) {//遍历子节点
        let children = target.children;
        children.forEach(element => {
            let it = element._components;
            it.forEach(ele => {
                if (typeof ele.AiState == "number") {
                    ele.wait = true;
                }
            });
            this.pauseAll(element);//遍历子节点
        });
    },
    resumeAll(target) {//恢复动作
        let children = target.children;
        children.forEach(element => {
            let it = element._components;
            it.forEach(ele => {
                if (typeof ele.AiState == "number") {
                    ele.wait = false;
                }
            });
            this.resumeAll(element);//遍历子节点
        });
    }
});
