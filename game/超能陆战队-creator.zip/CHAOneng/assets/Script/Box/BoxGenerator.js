cc.Class({
    extends: cc.Component,

    properties: {
        box: cc.Prefab,//箱子
    },
    start() {
        cc.director.on("PropsBox", (pos) => {
            this.createPrize(pos.x, pos.y);//box角度
        }, this);
    },
    createPrize(x, y) {//box角度
        let it = cc.instantiate(this.box);
        this.node.addChild(it);
        let degree = Math.random() * 360;
        it.rotation = degree;//旋转角度
        it.x = x;
        it.y = y;
        if (it.x > 0) {
            it.runAction(cc.sequence(
                cc.moveBy(8, cc.v2(-cc.winSize.width,0)),
                cc.removeSelf()
            ))
        }
        else {
            it.runAction(cc.sequence(
                cc.moveBy(8, cc.v2(cc.winSize.width,0)),
                cc.removeSelf()
            ))
        }
    },
});
