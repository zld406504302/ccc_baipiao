cc.Class({
    extends: cc.Component,
    properties: {
        // prizes: [cc.SpriteFrame],//奖励道具
        prizePrefab: cc.Prefab,//奖励道具模板
        prizes: {
            type: cc.SpriteFrame,
            default: []
        }
    },
    start() {
    },
    onCollisionEnter: function (other, self) {
        if (other.node.group == "Player") {
            this.node.getComponent(cc.Animation).play("boxPrize");
            this.node.removeComponent(cc.BoxCollider);
            cc.director.emit("playEffect", "box", 0.6);//播放音效；
            this.createProp();//刷出道具
            this.node.runAction(
                cc.sequence(
                    cc.fadeOut(1),
                    cc.removeSelf()
                )
            )
        }
    },
    createProp() {//刷出道具
        let index = Math.floor(Math.random() * this.prizes.length);//生成随机道具
        let propNum = 0;
        let value=0;
        switch (index) {
            case 0: break;
            case 1: value = Math.random();
                if (value < 0.3) {
                    propNum = 10;
                }
                else if (value > 0.3 && value < 0.9) {
                    propNum = 20;
                }
                else {
                    propNum = 30;
                }
                break;
            case 2: value = Math.floor(Math.random() * 16) + 1;//1-10的数
                propNum = value * 5; break;
            case 3: value = Math.floor(Math.random() * 3) + 1;//1-10的数
                propNum = value * 5; break;
            case 4: value = Math.floor(Math.random() * 5) + 1;//1-10的数
                propNum = value * 3; break;
            case 5: value = Math.floor(Math.random() * 5) + 1;//1-10的数
                propNum = value; break;
            case 6: value = Math.floor(Math.random() * 3) + 1;//1-10的数
                propNum = value; break;
            case 7:
                propNum = 1; break;
        }
        let it = cc.instantiate(this.prizePrefab);
        it.parent = cc.find("Canvas/BoxParent");
        it.position = this.node.position;
        it.getComponent(cc.Sprite).spriteFrame = this.prizes[index];
        if(propNum==0){
            it.getChildByName("value").string="";
        }
        else{
            it.getChildByName("value").string=propNum;
        }
        cc.director.emit("propsADD", it, index,propNum);//增加道具 
    }
});
