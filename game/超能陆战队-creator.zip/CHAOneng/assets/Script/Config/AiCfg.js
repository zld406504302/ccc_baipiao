var AiCfg = {
	1: {"Time": "0.2",},
	2: {"Time": "0.5",},
	3: {"Time": "0.7",},
	4: {"Time": "0.9",},
}
module.exports = AiCfg;