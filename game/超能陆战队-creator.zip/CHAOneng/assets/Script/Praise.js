cc.Class({
    extends: cc.Component,

    properties: {
        hecais: [cc.SpriteFrame],//喝彩
        hecaisMusic: [cc.AudioClip],//喝彩音乐
        prompting: [cc.SpriteFrame],//提示，预警
        promptingMusic: [cc.AudioClip],////提示，预警音乐
    },
    start() {
        this.killNum=0;//杀敌数
        this.index = 0;
        this.hecaiIndex = 0;
        this.startPos = cc.v2(30000, 0);
        this.endPos = cc.v2(0, 0);
        this.node.position = this.startPos;
        this.showCount = 0;//当前已经有的数
        this.needCount = 5;//播放赞美动画许需要的数
        cc.director.on("hecai", () => {
            this.showCount++;//当前已经有的数
            this.killNum++;//杀敌数
            if (this.needCount <= this.showCount) {
                this.hecaiIndex++;
                this.hecaiShowIt();//展示喝彩图
                this.needCount=Math.floor(Math.random()*3)+2;
                this.showCount = 0;//当前已经有的数
            }
        }, this);
        cc.director.on("prompting", () => {
            this.showIt();
            this.index++;
        });
    },
    hecaiShowIt() {//展示喝彩图
        this.hecaiIndex %= this.hecais.length;
        //播放音乐
        cc.audioEngine.playEffect(this.hecaisMusic[this.hecaiIndex], false);
        this.node.position = this.endPos;
        this.node.getComponent(cc.Sprite).spriteFrame = this.hecais[this.hecaiIndex];
        this.node.runAction(cc.spawn(
            cc.delayTime(0.5),
            cc.fadeOut(1),
            cc.scaleBy(1, (10, 10))
        ));
        this.scheduleOnce(() => {
            this.node.position = this.startPos;
            this.node.opacity = 255;
            this.node.scale = (1, 1);
        }, 2);
    },
    promptingShowIt() {//提示，预警
        this.node.x = -cc.winSize.width / 2 - this.node.width / 2;
        let seq = cc.sequence(
            cc.moveTo(1, cc.v2(0, 0)),
            cc.delayTime(1),
            cc.moveTo(1, cc.v2(cc.winSize.width / 2 + this.node.width / 2, 0)),
            cc.callFunc(() => {
                this.node.position = this.startPos;
            })
        );
        this.node.runAction(seq);
        //播放音乐
    },
});
