let AiAllState = cc.Enum({
    daiji: -1,//待机
    die: -1,//死亡
    attack: -1,//攻击中
})

cc.Class({
    extends: cc.Component,

    properties: {
        AiState: {
            type: AiAllState,
            default: AiAllState.daiji,
        },
        jiguangpao: cc.Prefab,
        jiguangsd: cc.Prefab,
        hp: 3000,
        hit: cc.Prefab,
        hongzha: cc.Prefab,//轰炸

    },

    onLoad() {
        var ske = this.node.getComponent(sp.Skeleton);
        this.ske = ske;
        this.node.setSiblingIndex(2);
        this.node.position=cc.v2(235.3,25.1);
    },

    update() {
        if (this.AiState == AiAllState.daiji) {
            this.timer++;
            if (this.timer >= 240) {
                this.AiState = AiAllState.attack;
            }
        }

        if (this.AiState == AiAllState.attack) {
            let a = Math.floor(Math.random() * 10) % 4
            if (a == 1) {
                this.jiguangpao1()
            }
            if (a == 2) {
                this.jiguangpao2()
            }
            if (a == 3) {
                this.jiguangpao3()
            }
            this.AiState = AiAllState.daiji;
                this.ske.addAnimation(0, "daiji", true);
        this.timer = 0
        }
        if (this.hp <= 0) {
            cc.director.emit("longDie", this.node, this.hit, this.hongzha)
        }

    },


    start() {
        this.cishu = 0;
        this.timer = 0;
        this.shuzu = [];
        this.zuobiao = [cc.v2(-400, 240), cc.v2(-400, -240), cc.v2(100, 240), cc.v2(100, -240)]
        this.jiaodu = [-135, 135, -75, 65]
        this.ske.setAnimation(0, "daiji", true);

        cc.director.on("shanchudonghua", function () {
            this.cishu++;
            if (this.cishu < 2) {
                this.scheduleOnce(() => {
                    let it = cc.instantiate(this.jiguangsd);//实例化子弹
                    it.parent = this.node.getChildByName("1")
                    it.position = cc.v2(0, 0);
                    let player = cc.find("Canvas/Player")
                    let fashedian = this.toWorldPosition(it); //发射点
                    let paoguan = this.toWorldPosition(player)
                    let isx = fashedian.x - paoguan.x; //向量
                    let isy = fashedian.y - paoguan.y; //计算出方向 
                    let rad = Math.atan2(isy, isx);//弧度
                    it.rotation = - cc.misc.radiansToDegrees(rad); //转换为角度
                }, 0.5)
            }
            if (this.cishu == 2) {
                this.cishu = 0;
                return;
            }
        }, this)
    },




    jiguangpao1() {
        this.ske.clearTracks();
        this.ske.addAnimation(0, "shoupao1", false);
        if (this.ske.animation == "shoupao1") {
            this.scheduleOnce(() => {
                let it = cc.instantiate(this.jiguangpao);//实例化子弹
                it.parent = this.node.getChildByName("2")
                it.position = cc.v2(0, 0);
                this.shuzu.push(it)
            }, 0.8)
        }
    },




    jiguangpao2() {
        this.ske.clearTracks();
        this.ske.addAnimation(0, "shoupao2", false);
        this.scheduleOnce(() => {
            let it = cc.instantiate(this.jiguangsd);//实例化子弹
            it.parent = this.node.getChildByName("1")
            it.position = cc.v2(0, 0);
            this.shuzu.push(it)
            let player = cc.find("Canvas/Player")
            let fashedian = this.toWorldPosition(it); //发射点
            let paoguan = this.toWorldPosition(player)
            let isx = fashedian.x - paoguan.x; //向量
            let isy = fashedian.y - paoguan.y; //计算出方向 
            let rad = Math.atan2(isy, isx);//弧度
            it.rotation = - cc.misc.radiansToDegrees(rad); //转换为角度
        }, 0.6)
    },


    jiguangpao3() {
        this.ske.clearTracks();
        this.ske.addAnimation(0, "pao1", false);
        if (this.ske.animation == "pao1") {
            for (let i = 0; i < 4; i++) {
                let it = cc.instantiate(this.jiguangpao);//实例化子弹
                it.parent = cc.find("Canvas")
                it.rotation = this.jiaodu[i];
                it.position = this.zuobiao[i];
                this.shuzu.push(it)
            }
            this.jiguangpao1()
        }
    },





    toWorldPosition(node) {//转为世界坐标
        let worldPos = node.convertToWorldSpaceAR(cc.v2(0, 0));
        let startPos = cc.find("Canvas").convertToNodeSpaceAR(worldPos);
        return startPos;
    },


});
