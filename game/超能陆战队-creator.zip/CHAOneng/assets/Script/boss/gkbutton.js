// Learn cc.Class:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/class.html
//  - [English] http://docs.cocos2d-x.org/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/reference/attributes.html
//  - [English] http://docs.cocos2d-x.org/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/life-cycle-callbacks.html
//  - [English] https://www.cocos2d-x.org/docs/creator/manual/en/scripting/life-cycle-callbacks.html

cc.Class({
    extends: cc.Component,

    properties: {
        js:[cc.SpriteFrame],
        xz: cc.Prefab,
       
    },
    start () {
       this.jindu = Number(localStorage.getItem('MyPass'));//关卡
       if(this.jindu==0){
           this.jindu = 1;
           localStorage.setItem("MyPass",1);
       }
       let spritea = this.node.getChildByName("Background")
       this.guanka = spritea .getChildByName("Label")
       this.spritr = spritea.getComponent(cc.Sprite)
          this.gk = this.guanka.getComponent(cc.Label)
        if(this.gk.string == this.jindu ||this.gk.string<this.jindu){
            this.node.getComponent(cc.Button).interactable = true;
            this.spritr.spriteFrame = this.js[0]
        }else{
           this.node.getComponent(cc.Button).interactable = false;
            this.spritr.spriteFrame = this.js[1]
            this.guanka.active = false;

        }
        if(this.gk.string == this.jindu ){
            this.it = cc.instantiate(this.xz);
            this.it.parent = this.node;
            this.it.setSiblingIndex(0)
            this.it.position = cc.v2(0,0) 
            let worldPos = this.node.convertToWorldSpaceAR(cc.v2(0, 0));
            let startPos = cc.find("Canvas/scrollview/view/content").convertToNodeSpaceAR(worldPos);
            cc.director.emit("zuobiao",startPos);    
        }else{
            if(this.it){
                this.it.destroy();
            }
        }
    },

    tiaozhuan(){
        localStorage.setItem("选择关卡",this.gk.string);
        cc.director.loadScene("Game");
    },
    fanhui(){
        cc.director.loadScene("Start");
    },
  
});
