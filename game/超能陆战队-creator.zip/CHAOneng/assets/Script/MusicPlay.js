let MusicCfg = require("./Config/MusicCfg");
let music = {
    loadMusic(id, size) {
        let it = MusicCfg[id];
        if (it.Type == 1) {
            cc.loader.loadRes(it.Path, cc.AudioClip, (eve) => {
                cc.audioEngine.playMusic(eve, true, size);
            })
        }
        else {
            cc.loader.loadRes(it.Path, cc.AudioClip, (eve) => {
                let effect = cc.audioEngine.playEffect(eve);
                cc.audioEngine.setVolume(effect, size);
            })
        }
    }
}
module.exports = music;
