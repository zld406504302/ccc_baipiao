
cc.Class({
    extends: cc.Component,

    properties: {
     
    },

    start () {
        var spawn = cc.spawn(cc.moveTo(0.5, cc.v2(0,-5)),  cc.scaleTo(0.5, 1.6),cc.fadeOut(0.6),);
        var spawna = cc.spawn(  cc.scaleTo(0.1, 1),cc.fadeTo(0,255),);
        var seq = cc.repeatForever(
            cc.sequence(
                spawn,
                spawna
            ));
     this.node.runAction(seq);
    },




});
