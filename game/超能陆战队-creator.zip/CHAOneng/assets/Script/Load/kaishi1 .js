
cc.Class({
  extends: cc.Component,
  properties: {
    bg:cc.AudioClip,
    clip:cc.AudioClip,
  },
  start() {
    var seq = cc.repeatForever(
      cc.sequence(
        cc.scaleTo(0.5, 1),
        cc.scaleTo(0.5, 0.8)
      ));
    this.node.runAction(seq);
    cc.audioEngine.playMusic(this.bg,true,1);
  },
  kaishi() {
    cc.audioEngine.playEffect(this.clip);
    cc.director.loadScene("Opt");
  }
});
