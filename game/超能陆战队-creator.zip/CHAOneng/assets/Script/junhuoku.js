// Learn cc.Class:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/class.html
//  - [English] http://docs.cocos2d-x.org/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/reference/attributes.html
//  - [English] http://docs.cocos2d-x.org/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/life-cycle-callbacks.html
//  - [English] https://www.cocos2d-x.org/docs/creator/manual/en/scripting/life-cycle-callbacks.html

cc.Class({
    extends: cc.Component,

    properties: {
       zidan1:cc.Label,
       zidan2:cc.Label,
       zidan3:cc.Label,
       daoju1:cc.Label,
       daoju2:cc.Label,
       daoju3:cc.Label,
       sprite:cc.Node,
       music: { type: cc.AudioClip, default: [] },

    },

    onLoad(){
        this.node.active = false;
    },

    start () {
   
        let zd1 = this.zidan1.getComponent(cc.Label)
        zd1.string =localStorage.getItem("子弹")||0;
        let zd2 = this.zidan2.getComponent(cc.Label)
        zd2.string =localStorage.getItem("火箭弹")||0;
        let zd3 = this.zidan3.getComponent(cc.Label)
        zd3.string =localStorage.getItem("火焰弹")||0;
        let dj1 = this.daoju1.getComponent(cc.Label)
        dj1.string =localStorage.getItem("护盾")||0;
        let dj2 = this.daoju2.getComponent(cc.Label)
        dj2.string =localStorage.getItem("冰冻")||0;
        let dj3 = this.daoju3.getComponent(cc.Label)
        dj3.string =localStorage.getItem("轰炸")||0;

        this.sprite.on(cc.Node.EventType.TOUCH_END, function () {
            this.node.active = false;
        }, this);


    },

    xianshi(){
        cc.audioEngine.playMusic(this.music[0], false)
        this.node.active = true;
    }

});
