cc.Class({
    extends: cc.Component,

    properties: {
        front: cc.Node,//前面
        back: cc.Node,//后面
        props: [cc.SpriteFrame],
        pic: cc.Sprite,//图片
        num: cc.Label,//数量
    },

    start() {
        this.clip = 0;//是否点击
        this.show=false;
        this.front.scale = cc.v2(1, 1);
        this.back.scale = cc.v2(0, 1);
        this.front.on(cc.Node.EventType.TOUCH_END, this.flop, this);
        this.propNum = 0;
    },
    flop() {//翻牌
        if (this.clip==0) {
            this.front.runAction(cc.sequence(
                cc.callFunc(() => {
                    let arr = this.node.parent.children;
                    this.show=true;
                    arr.forEach(element => {
                        let it= element.getComponent("Card");
                        if(!it.show){
                            it.clip=1;
                        }
                    });
                }),
                cc.scaleTo(0.2, 1.2, 1.2),
                cc.scaleTo(0.2, 1, 1),
                cc.scaleTo(0.6, 0, 1),
                cc.callFunc(() => {
                    let n = Math.floor(Math.random() * this.props.length);
                    this.pic.spriteFrame = this.props[n];
                    this.numByProps(n,true);//道具数量
                    this.back.runAction(cc.scaleTo(0.6, 1, 1));
                }),
                cc.removeSelf()
            ))
        }
    },
    otherFlop() {//其他道具
        this.front.runAction(cc.sequence(
            cc.scaleTo(0.2, 1.2, 1.2),
            cc.scaleTo(0.2, 1, 1),
            cc.scaleTo(0.6, 0, 1),
            cc.callFunc(() => {
                let n = Math.floor(Math.random() * this.props.length);
                this.pic.spriteFrame = this.props[n];
                this.back.color = new cc.Color(59, 255, 255);
                this.numByProps(n,false);//道具数量
                this.back.runAction(cc.scaleTo(0.6, 1, 1));
            }),
            cc.removeSelf()
        ))
    },
    addProps(index, value) {//更新道具数量
        let it = cc.find("Canvas/Player").getComponent("PlayerControl");
        switch (index) {
            case 0: it.attack1Rest += value; break;
            case 1: it.attack2Rest += value; break;
            case 2: it.attack3Rest += value; break;
            case 3: it.bingdongPropsRest += value; break;
            case 4: it.hudunPropsRest += value; break;
            case 5: it.rocketPropsRest += value; break;
        }
        cc.director.emit("updateProps");//刷新道具数量
    },
    numByProps(index,isAdd) {//道具数量
        let value;
        switch (index) {
            case 0: value = Math.floor(Math.random() * 10) + 1;//1-10的数
                this.propNum = value * 50; break;
            case 1: value = Math.floor(Math.random() * 10) + 1;//1-10的数
                this.propNum = value * 5; break;
            case 2: value = Math.floor(Math.random() * 10) + 1;//1-10的数
                this.propNum = value * 5; break;
            case 3: value = Math.floor(Math.random() * 10) + 1;//1-10的数
                this.propNum = value * 1; break;
            case 4: value = Math.floor(Math.random() * 7) + 1;//1-10的数
                this.propNum = value * 1; break;
            case 5: value = Math.floor(Math.random() * 5) + 1;//1-10的数
                this.propNum = value * 1; break;
        }
        this.num.string = this.propNum;
        if (isAdd) {
            this.addProps(index, this.propNum);//更新道具数量
        }
    },
    update() {
        if (this.clip == 1) {//有卡牌被翻了
            this.clip = 2;
            this.scheduleOnce(()=>{
                this.otherFlop();//其他道具
            },1)
        }
    }
});
