cc.Class({
    extends: cc.Component,

    properties: {
        boNum: [cc.SpriteFrame],//波数   中间的
        boNumNew: cc.Sprite,//波数   中间的
        frequencyNum: cc.Label,//当前波数   头顶的
        frequencyNumCount: cc.Label,//总波数  头顶的
        boRoot: cc.Node,//波数节点
    },
    start() {
        this.node.x = 10000;
        cc.director.on("bo", this.boShow, this);//波数显示
        cc.director.on("boShow", this.boNumShow, this);//第几波显示
    },
    boShow(num, numCount) {//波数显示
        this.frequencyNum.string = num + 1;
        this.frequencyNumCount.string = numCount;
    },
    boNumShow(num) {//第几波  显示    最多10波
        this.node.x = -cc.winSize.width / 2 - this.node.width / 2;
        this.boNumNew.spriteFrame = this.boNum[num];
        let seq = cc.sequence(
            cc.moveTo(1, cc.v2(0, 0)),
            cc.delayTime(1),
            cc.moveTo(1, cc.v2(cc.winSize.width / 2 + this.node.width / 2, 0)),
            cc.callFunc(() => {
                this.node.x = 10000;
            })
        );
        this.node.runAction(seq);
        //播放音乐
    },
});
