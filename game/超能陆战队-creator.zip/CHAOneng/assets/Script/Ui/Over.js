

cc.Class({
    extends: cc.Component,

    properties: {
        win: cc.Node,//胜利
        lose: cc.Node,//失败
        over: cc.Node,//结算固定节点
        killNum: cc.Label,//杀敌数
        card: cc.Node,//抽卡界面
        cardSelfRoot: cc.Node,//卡片的父节点
        cardSelf: cc.Prefab,//卡片预设体
    },

    start() {
        this.win.active = false;
        this.lose.active = false;
        this.over.active = false;
        this.card.active = false;
        cc.director.on("GameOver", this.overGame, this);
    },
    overGame(num, yesOfNo) {
        cc.director.emit("禁止开火");
        cc.find("Canvas").pauseSystemEvents(true);//禁用按钮和点击事件
        cc.find("Canvas/EffectPanrent").resumeSystemEvents(true);//禁用按钮和点击事件
        cc.find("Canvas/MaskUi").active=true;
        if (yesOfNo) {
            this.win.active = true;
        }
        else {
            this.lose.active = true;
        }
        this.over.active = true;
        this.killNum.string = num;
    },
    winSure() {//胜利界面  确定
        this.win.active = false;
        this.over.active = false;
        this.card.active = true;
        let unlookPass = Number(localStorage.getItem("选择关卡"));
        let pass = parseInt(localStorage.getItem("MyPass"));//关卡
        let luosiValue = Number(localStorage.getItem("luosiValue"));
        localStorage.setItem("luosiValue", luosiValue + Math.floor(unlookPass / 3));
        if (pass == unlookPass) {
            localStorage.setItem("MyPass", pass + 1);
        }
        // cc.find("Canvas").pauseSystemEvents(true);//禁用按钮和点击事件
        for (let i = 0; i < 5; i++) {
            let it = cc.instantiate(this.cardSelf);
            it.parent = this.cardSelfRoot;
        }
    },
    loseSure() {//失败界面  确定
        cc.director.emit("updateProps");//刷新道具数量
        cc.director.loadScene("Opt");
    },
    cardSure() {//翻牌界面  确定
        cc.director.loadScene("Opt");
    },
});
