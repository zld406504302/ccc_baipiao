cc.Class({
    extends: cc.Component,
    properties: {
        hpShow: cc.Prefab,
    },
    start() {
        cc.director.on("addHpShow",this.moveBig, this);
    },
    moveBig(value) {//变大动画
        let it = cc.instantiate(this.hpShow);
        it.getComponent(cc.Label).string=value;
        this.node.addChild(it);
        it.position=cc.v2(0,0);
        it.opacity = 255;
        it.runAction(
            cc.sequence(
                cc.spawn(
                    cc.fadeOut(1.5),
                    cc.scaleTo(0.5, 1.5, 1.5),
                    cc.moveBy(0.5, cc.v2(100, 0))
                ),
                cc.removeSelf()
            )
        )
    }
});
