

cc.Class({
    extends: cc.Component,

    properties: {
        bg1Root:cc.Node,
        bg2Roodt:cc.Node,
        bg1:cc.Node,//背景1移动
        bg2_1:cc.Node,//背景bg2_1移动  山
        bg2_2:cc.Node,//背景bg2_2移动  云
    },
    start () {
        let pass=Number(localStorage.getItem("选择关卡"));
        this.bgType=pass%2;
        if(this.bgType>0){
            this.bgType1();//背景类型1移动
        }
        else{
            this.bgType2();//背景类型2移动
        }
    },
    bgType1(){//背景类型1移动
        this.bg1Root.active=true;
        this.bg2Roodt.active=false;
        this.move(this.bg1,10,1);//移动
    },
    bgType2(){//背景类型2移动
        this.bg1Root.active=false;
        this.bg2Roodt.active=true;
        this.move(this.bg2_1,10,1);//移动
        this.move(this.bg2_2,10,-1);//移动
    },
    move(it,time,dir){//移动   //对象 时间  方向 1左 -1右
        let ta=cc.instantiate(it);
        ta.parent=it.parent;
        ta.x=cc.winSize.width;
        let seqIt=cc.sequence(
            cc.moveTo(time,cc.v2(-cc.winSize.width*dir,it.y)),
            cc.callFunc(()=>{
                it.x=cc.winSize.width;
            }),
            cc.moveTo(time,cc.v2(0,it.y)),
        );
        let seqTa=cc.sequence(
            cc.moveTo(time*2,cc.v2(-cc.winSize.width*dir,it.y)),
            cc.callFunc(()=>{
                ta.x=cc.winSize.width;
            })
        );
        it.runAction(cc.repeatForever(seqIt));
        ta.runAction(cc.repeatForever(seqTa));
    },
});
