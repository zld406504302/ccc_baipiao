cc.Class({
    extends: cc.Component,

    properties: {
        hurtValue:10,//伤害
    },
    start() {
    },
    onCollisionEnter(other, self) {
        if (other.node.group == "Player") {
            cc.director.emit("playHpReduce", this.hurtValue);
           cc.director.emit("subHp", other.node,this.hurtValue);
        }
    },
    update(){
        if(this.node.x<-cc.winSize.width/2  || this.node.x>cc.winSize.width/2
             ||this.node.y<-cc.winSize.height/2  ||this.node.y>cc.winSize.height/2   ){
                this.node.destroy();
             }
    }
});
