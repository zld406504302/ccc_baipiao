
cc.Class({
    extends: cc.Component,
    properties: {
        main_node: {
            default: null,
            type: cc.Node
        },
        body: {
            default: null,
            type: cc.Node
        },
        buff: {
            default: null,
            type: cc.Node
        },
        yinYing: {
            default: null,
            type: cc.Node
        },
        skinID: 0,
        effectTag: -1
    },
    start: function () {
        this.showBuff(0);
    },
    getSkinID: function () {
        return this.skinID;
    },
    setSkin: function (o) {
        this.skinID = o; 
        this.node.x = this.main_node.getComponent("Main").tree.x - 235
        this.shiftLeft()
        t.setCurrentSkin(o, !1);
    },
    onHitFinish: function () {
        this.playAnimation("stand");
        var o = -1;
        this.node.scaleX = 1, 0 < this.node.x && (o = 1, this.node.scaleX = -1), this.node.setPosition(Math.abs(this.node.x) * o, this.node.y);
    },
    playAnimation: function (o) {
        this.body.getComponent(cc.Animation).stop()
        this.body.getComponent(cc.Animation).play(o + "_" + this.skinID)
        if ("hit" == o) {
            this.body.getComponent(cc.Animation).on("finished", this.onHitFinish, this)
        }
    },
    shiftLeft: function () {
        this.playAnimation("stand")
        this.node.anchorX = .5
        this.node.scaleX = 1
        this.node.setPosition(-1 * Math.abs(this.node.x), this.node.y);
    },
    shiftRight: function () {
        this.playAnimation("stand")
        this.node.anchorX = .5
        this.node.setPosition(1 * Math.abs(this.node.x), this.node.y)
            this.node.scaleX = -1;
    },
    showBuff: function (o) {
    }
})