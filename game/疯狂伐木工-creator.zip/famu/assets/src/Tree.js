
cc.Class({
    extends: cc.Component,
    properties: {
        main_node: {
            default: null,
            type: cc.Node
        },
        treeNodePrefab: {
            default: null,
            type: cc.Prefab
        },
        muzhuangSprite: {
            default: null,
            type: cc.Node
        },
        treeNodes: [],
        treeNodesCache: [],
        deltaY: null,
        yDuration: .05,
        yDeltaTime: 0,
        cutAble: !0,
        diff: [],
        cur_diff: 50,
        base_diff: 50,
        diff_step: 1,
        isDark: !1
    },
    updateTree: function (a) {
        var e = this.getHeadNode();
        if (this.yDeltaTime = 0 >= this.yDeltaTime ? a : this.yDeltaTime / 2 + a / 2, e) {
            var t = e.y;
            if (0 < t) {
                this.cutAble = !1, 0 < t && (t -= this.deltaY), 0 >= t && (t = 0, this.cutAble = !0),
                    e.y = t;
                for (var n, o = 1; o < this.treeNodes.length; o++) n = this.treeNodes[o], n.y = this.treeNodes[o - 1].y + n.getContentSize().height;
            } else this.cutAble = !0;
        }
    },
    start: function () {
        this.diff = [5, 5, 4, 4, 4, 4, 4, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2];
        for (var o = 1; o < this.diff.length; o++) this.diff[o] += this.diff[o - 1];
        this.restart(!1);
    },
    restart: function (o) {
        for (this.isDark = o; 0 < this.treeNodes.length;) this.treeNodesCache.push(this.treeNodes.shift());
        this.main_node.removeAllChildren();
        for (var e = 0; 10 > e; e++) this.generateNewTreeNode(0);
        this.setNearBranchsBlank(3, !1);
    },
    addTreeNode: function (o) {
        o.zIndex = 0, this.treeNodes.push(o), null == o.parent && this.main_node.addChild(o),
            o.setPosition(0, o.getContentSize().height * (this.treeNodes.length - 1)), o.stopAllActions();
    },
    deleteHeadNode: function () {
        var a = this.treeNodes.shift();
        a.zIndex = 1, this.treeNodesCache.push(a);
        var e = this.treeNodes[0],
            t = Math.max(e.getContentSize().height, e.y),
            n = this.yDuration / this.yDeltaTime;
        return this.deltaY = t / n, a;
    },
    printTreeNodes: function () {
        cc.log("tree nodes ---------");
        for (var o = 0; o < this.treeNodes.length; o++) cc.log(this.treeNodes[o].getComponent("TreeNode").type);
    },
    getHeadNode: function () {
        return 0 < this.treeNodes.length ? this.treeNodes[0] : null;
    },
    getSecondHeadNode: function () {
        return 1 < this.treeNodes.length ? this.treeNodes[1] : null;
    },
    generateNewTreeNode: function (o) {
        var e = this.createTreeNode(),
            t = {
                branch: this.generateBranch(o),
                score: 1
            };
        return this.setBranch(e, t), e.setRotation(0), this.addTreeNode(e), e;
    },
    generateScore: function () {
        return 1;
    },
    generateBranch: function (o) {
        if (0 == this.treeNodes.length) return 0;
        var e = 0;
        return o >= this.diff_step && (e = parseInt(o / this.diff_step) - 1, e = Math.min(e, this.diff.length - 1),
            this.cur_diff = this.base_diff + this.diff[e]), 0 < this.treeNodes[this.treeNodes.length - 1].getComponent("TreeNode").type || 100 * Math.random() > this.cur_diff ? 0 : parseInt(2 * Math.random()) + 1;
    },
    createTreeNode: function () {
        var a = null;
        (a = 5 < this.treeNodesCache.length ? this.treeNodesCache.shift() : cc.instantiate(this.treeNodePrefab)).getComponent("TreeNode").add.active = !1;
        var e = "images/bg/body",
            t = "images/bg/branch",
            n = "images/bg/scene_muzhuang";
        this.isDark && (e = "images/bg/body2", t = "images/bg/branch2", n = "images/bg/scene_muzhuang2");
        var i = this;
        return cc.loader.loadRes(e, cc.SpriteFrame, function (e, o) {
            e ? cc.error(e.message || e) : a.getComponent(cc.Sprite).spriteFrame = o;
        }), cc.loader.loadRes(n, cc.SpriteFrame, function (o, e) {
            o ? cc.error(o.message || o) : i.muzhuangSprite.getComponent(cc.Sprite).spriteFrame = e;
        }), cc.loader.loadRes(t, cc.SpriteFrame, function (e, o) {
            e ? cc.error(e.message || e) : a.getComponent("TreeNode").branch.getComponent(cc.Sprite).spriteFrame = o;
        }), a;
    },
    setBranch: function (o, e) {
        let a = Math.abs
        o.getComponent("TreeNode").type = e.branch, o.getComponent("TreeNode").score = parseInt(e.score);
        var t = o.getComponent("TreeNode").branch,
            n = o.getComponent("TreeNode").add;
        t.active = 0 < e.branch, 1 == e.branch ? (t.scaleX = -1, t.x = -1 * o.getContentSize().width / 2,
            n.x = -1 * a(n.x)) : 2 == e.branch && (t.scaleX = t.scaleY = 1, t.x = o.getContentSize().width / 2,
            n.x = a(n.x));
    },
    setNearBranchsBlank: function (d, e) {
        var t = {
                branch: 0,
                score: 1
            },
            n = "images/bg/branch";
        this.isDark && (n = "images/bg/branch2");
        var i = this;
        cc.loader.loadRes(n, cc.SpriteFrame, function (o, n) {
            if (o) cc.error(o.message || o);
            else {
                var c = new cc.Node();
                i.main_node.parent.addChild(c);
                for (var a = 0; a < d; a++) {
                    var s = i.treeNodes[a],
                        r = s.getComponent("TreeNode").type;
                    if (0 < r && e) {
                        var p = s.getComponent("TreeNode").branch,
                            l = new cc.Node();
                        l.addComponent(cc.Sprite).spriteFrame = n, l.anchorX = p.anchorX, l.anchorY = p.anchorY,
                            l.scaleX = p.scaleX, l.x = p.x + s.x + i.main_node.x, l.y = p.y + s.y + i.main_node.y,
                            c.addChild(l), l.runAction(cc.jumpBy(.8, cc.v2(2 * (400 * r - 600), -900), 500, 1).easing(cc.easeOut(2))),
                            l.runAction(cc.rotateBy(.8, 240 * (r - 1.5)));
                    }
                    i.setBranch(i.treeNodes[a], t);
                }
                c.runAction(cc.sequence([cc.delayTime(.8), cc.hide(), cc.callFunc(function () {
                    console.log("node remove "), c.removeFromParent();
                })]));
            }
        });
    },
    isCutAble: function () {
        return this.cutAble;
    }
})