
cc.Class({
    extends: cc.Component,
    properties: {
        mainNode: {
            default: null,
            type: cc.Node
        },
        okItem: {
            default: null,
            type: cc.Node
        },
        cancelItem: {
            default: null,
            type: cc.Node
        },
        okLabel: {
            default: null,
            type: cc.Node
        },
        desLabel: {
            default: null,
            type: cc.Node
        },
        cancelLabel: {
            default: null,
            type: cc.Node
        },
        cardLabel: {
            default: null,
            type: cc.Node
        },
        panel: {
            default: null,
            type: cc.Node
        },
        layer: {
            default: null,
            type: cc.Node
        },
        fuhuoka: {
            default: null,
            type: cc.Node
        },
        callBack: null
    },
    start: function () {},
    showDialog: function (o, e, t, n, s) {
        this.node.active = !0, this.node.zIndex = 0, this.callBack = n, this.useCard = s,
            this.cardLabel.getComponent(cc.Label).string = "×" + r.lifeCardCount, this.desLabel.getComponent(cc.RichText).string = o,
            this.layer.opacity = 0, this.panel.y = 900, this.panel.runAction(cc.moveTo(.2, cc.v2(0, 0)).easing(cc.easeInOut(1.5))),
            this.layer.runAction(cc.fadeTo(.2, 150).easing(cc.easeInOut(1.5))), this.fuhuoka.active = i.can_pay(),
            null == t ? (this.cancelItem.active = !1, this.okItem.x = 0) : (this.cancelItem.active = !0,
                this.okItem.x = -1 * this.cancelItem.x);
    },
    click_ok: function () {
        cc.loader.loadRes("audios/button", cc.AudioClip, function (o, e) {
            cc.audioEngine.playEffect(e);
        }), this.callBack(!0), this.hidePanel();
    },
    click_cancel: function () {
        cc.loader.loadRes("audios/button", cc.AudioClip, function (o, e) {
            cc.audioEngine.playEffect(e);
        }), this.callBack(!1), this.hidePanel();
    },
    click_resurrection: function () {
        cc.loader.loadRes("audios/button", cc.AudioClip, function (o, e) {
            cc.audioEngine.playEffect(e);
        }), i.can_pay() && (this.useCard(), this.hidePanel());
    },
    hidePanel: function () {
        var o = this;
        this.layer.runAction(cc.fadeTo(.2, 0)), this.panel.runAction(cc.sequence([cc.moveTo(.2, cc.v2(0, 900)).easing(cc.easeInOut(1.5)), cc.callFunc(function () {
            o.node.active = !1;
        })]));
    }
})