

cc.Class({
    extends: cc.Component,
    properties: {
        mainNode: {
            default: null,
            type: cc.Node
        },
        timber: {
            default: null,
            type: cc.Node
        },
        skinPanel: {
            default: null,
            type: cc.Node
        },
        buffPanel: {
            default: null,
            type: cc.Node
        },
        rankNode: {
            default: null,
            type: cc.Node
        },
        buffNode: {
            default: null,
            type: cc.Node
        },
        skinNode: {
            default: null,
            type: cc.Node
        },
        scorePanel: {
            default: null,
            type: cc.Node
        },
        titleNode: {
            default: null,
            type: cc.Node
        },
        newBuffNode: {
            default: null,
            type: cc.Node
        },
        newSkinNode: {
            default: null,
            type: cc.Node
        },
        hasOriPos: !1
    },
    start: function () {},
    showMenuPanel: function (o) {
        this.node.active = !0, o && (this.hasOriPos || (this.hasOriPos = !0, this.oriPosX = this.node.x,
                    this.oriPosY = this.node.y, this.titleOriPosX = this.titleNode.x, this.titleOriPosY = this.titleNode.y),
                this.node.y = this.oriPosY - 300, this.node.runAction(cc.sequence([cc.delayTime(.2), cc.moveTo(.2, cc.v2(this.oriPosX, this.oriPosY)).easing(cc.easeInOut(1.5))])),
                this.titleNode.y = this.titleOriPosY + 600, this.titleNode.runAction(cc.sequence([cc.delayTime(.2), cc.moveTo(.2, cc.v2(this.titleOriPosX, this.titleOriPosY)).easing(cc.easeInOut(1.5))]))),
            this.checkNewItem();
    },
    clickPlay: function () {
        cc.loader.loadRes("audios/button", cc.AudioClip, function (o, e) {
            cc.audioEngine.playEffect(e);
        }); 
        this.scorePanel.getComponent("ScorePanel").hidePanel()
        this.hidePanel()
        this.mainNode.getComponent("Main").restart();
    },
    clickBoardBack: function () {
    },
    clickBoard: function (n, e) {
    },
    clickBuff: function () {
    },
    clickSkins: function () {
    },
    hidePanel: function () {
        if (0 != this.node.active) {
            var o = this;
            this.hasOriPos || (this.hasOriPos = !0, this.oriPosX = this.node.x, this.oriPosY = this.node.y,
                this.titleOriPosX = this.titleNode.x, this.titleOriPosY = this.titleNode.y), this.node.runAction(cc.sequence([cc.moveTo(.2, cc.v2(this.oriPosX, this.oriPosY - 300)).easing(cc.easeInOut(1.5)), cc.callFunc(function () {
                o.node.active = !1;
            })])), this.titleNode.runAction(cc.moveTo(.2, cc.v2(this.titleOriPosX, this.titleOriPosY + 600)).easing(cc.easeInOut(1.5)));
        }
    },
    showShakeBuff: function () {
    },
    checkNewItem: function () {
    }
})