
cc.Class({
    extends: cc.Component,
    properties: {
        tap1: {
            default: null,
            type: cc.Node
        },
        tap2: {
            default: null,
            type: cc.Node
        }
    },
    start: function () {
        this.tap1.getComponent(cc.Animation).play("hintL"), this.tap2.getComponent(cc.Animation).play("hintR");
    }
})