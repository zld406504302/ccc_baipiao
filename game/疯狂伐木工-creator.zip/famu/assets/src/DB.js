

class DB {
    constructor() {
        this.highScore = 0
        this.allScore = 0
        this.showUnLockSkins = [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
        this.currentSkin = 0
    }

    saveUserProfile() {
        cc.sys.localStorage.setItem("userProfile", this);
    }

    saveScore() {
        // this.saveUserProfile()
    }
}

window.db = new DB()
