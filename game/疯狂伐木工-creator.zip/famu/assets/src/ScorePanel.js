
cc.Class({
    extends: cc.Component,
    properties: {
        mainNode: {
            default: null,
            type: cc.Node
        },
        selfNode: {
            default: null,
            type: cc.Node
        },
        scoreLabel: {
            default: null,
            type: cc.Node
        },
        highScoreLabel: {
            default: null,
            type: cc.Node
        },
        allScoreLabel: {
            default: null,
            type: cc.Node
        },
        hasOriPos: !1,
        score: 0,
        newScoreNode: {
            default: null,
            type: cc.Node
        }
    },
    start: function () {},
    showScorePanel: function (o) {
        this.node.active = !0
        this.setScore(o)
        this.hasOriPos || (this.hasOriPos = !0,
                this.oriPosX = this.node.x, this.oriPosY = this.node.y), this.node.y = this.oriPosY + 1e3,
            this.node.runAction(cc.sequence([cc.delayTime(.2), cc.moveTo(.2, cc.v2(this.oriPosX, this.oriPosY)).easing(cc.easeInOut(1.5))]));
    },
    hidePanel: function () {
        if (this.node.active) {
            this.hasOriPos || (this.hasOriPos = !0, this.oriPosX = this.node.x, this.oriPosY = this.node.y);
            var o = this;
            this.node.runAction(cc.sequence([
                cc.moveTo(.2, cc.v2(this.oriPosX, this.oriPosY + 1e3)).easing(cc.easeInOut(1.5)), 
            cc.callFunc(function () {
                o.node.active = !1;
            })]));
        }
    },
    setScore: function (o) {
        this.score = o,
        
        this.newScoreNode.active = !1
        this.newScoreNode.active = db.saveScore(this.score)
        this.scoreLabel.getComponent("cc.Label").string = o
        this.highScoreLabel.getComponent("cc.Label").string = db.highScore
        this.allScoreLabel.getComponent("cc.Label").string = db.allScore
    },
    restart: function () {
        this.hidePanel(), this.mainNode.getComponent("Main").restart();
    },
    clickShare: function () {
    }
})