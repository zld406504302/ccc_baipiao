
cc.Class({
    extends: cc.Component,
    properties: {
        mainCavas: {
            default: null,
            type: cc.Node
        },
        tree: {
            default: null,
            type: cc.Node
        },
        timber: {
            default: null,
            type: cc.Node
        },
        _canTouch: !0,
        isGameOver: !0,
        scorePanel: {
            default: null,
            type: cc.Node
        },
        cutCount: 0,
        score: 0,
        scoreLabel: {
            default: null,
            type: cc.Node
        },
        diffLabel: {
            default: null,
            type: cc.Node
        },
        timeBar: {
            default: null,
            type: cc.Node
        },
        menuPanel: {
            default: null,
            type: cc.Node
        },
        pausePanel: {
            default: null,
            type: cc.Node
        },
        timeBarSprite: {
            default: null,
            type: cc.Node
        },
        buffPanel: {
            default: null,
            type: cc.Node
        },
        skinPanel: {
            default: null,
            type: cc.Node
        },
        dialogPanel: {
            default: null,
            type: cc.Node
        },
        rankNode: {
            default: null,
            type: cc.Node
        },
        gameInfoNode: {
            default: null,
            type: cc.Node
        },
        bgSprite: {
            default: null,
            type: cc.Node
        },
        groundSprite: {
            default: null,
            type: cc.Node
        },
        nextFriendNode: {
            default: null,
            type: cc.Node
        },
        maskNode: {
            default: null,
            type: cc.Node
        },
        hintNode: {
            default: null,
            type: cc.Node
        },
        hintDesNode: {
            default: null,
            type: cc.Node
        },
        hintDesLabel: {
            default: null,
            type: cc.Node
        },
        nextField: {
            default: null,
            type: cc.Node
        },
        waitingMask: {
            default: null,
            type: cc.Node
        },
        adSprite: {
            default: null,
            type: cc.Node
        },
        rechargeSprite: {
            default: null,
            type: cc.Node
        },
        rechargePanel: {
            default: null,
            type: cc.Node
        },
        privilegePanel: {
            default: null,
            type: cc.Node
        },
        feaverMax: 600,
        feaverTriple: 500,
        feaverdouble: 400,
        dropRateBase: 8,
        dropRateStep: .125,
        curDropRate: 0,
        curFeaver: 300,
        dropRateMax: 10,
        curDiff: 0,
        addRateStep: 10,
        curAddRateStep: 10,
        clickStack: [],
        lastClickType: 0,
        clickCount: 0,
        buffState: 0,
        highDpsCount: 0,
        dpsFeaverNeed: 5,
        protectBuffNeed: 10,
        doubleBuffNeed: 20,
        tripleBuffNeed: 30,
        cavasPos: null,
        firstTime: !0,
        isPause: !0,
        hasRecover: !1,
        timeBarFrame: null,
        hintType: 0,
        lastIsDark: !1,
        videoRate: 0,
        hongbaoNode: {
            type: cc.Node,
            default: null
        }
    },
    onLoad: function () {
        console.log("onload")
        this.node.on(cc.Node.EventType.TOUCH_START, function (o) {
            this.click_action(o);
        }, this)
        this.node.on(cc.Node.EventType.TOUCH_END, function () {}, this)
        this.node.on(cc.Node.EventType.TOUCH_CANCEL, function () {}, this);
        this.cavasPos = this.mainCavas.getPosition()
    },
    start: function () {
        // this.adSprite.active = !1, this.rechargeSprite.active = !1
        cc.game.setFrameRate(60);
    },
    updateInfo: function () {
        var o = this.curDiff;
        this.curDiff = parseInt(parseInt(this.cutCount) / this.tree.getComponent("Tree").diff_step),
        this.scoreLabel.getComponent(cc.Label).string = parseInt(this.score), 
        this.timeBar.getComponent(cc.ProgressBar).progress = this.curFeaver / this.feaverMax
        
        if (parseInt(this.curDiff) > parseInt(o)) {
            this.diffLabel.getComponent(cc.Label).string = "难度等级: " + this.curDiff
            this.diffLabel.runAction(cc.sequence([cc.scaleTo(.2, 1.5).easing(cc.easeOut(2)), cc.scaleTo(.15, 1)]))
        }
    },
    updateFeaver: function () {},
    click_action: function (a) {
        var e = this.tree.getComponent("Tree");
        if (!this.isGameOver) {
            this.isPause && (this.isPause = !1, this.pausePanel.active = !1);
            var t = 0;
            if (a.getLocation().x >= cc.winSize.width / 2) {
                if (t = 2, 1 == this.hintNode.active && t != this.hintType) return;
                this.timber.getComponent("Timber").shiftRight();
            } else {
                if (t = 1, 1 == this.hintNode.active && t != this.hintType) return;
                this.timber.getComponent("Timber").shiftLeft();
            }
            this.lastClickType = t, ++this.clickCount;
            var n = e.getHeadNode(),
                i = n.getComponent("TreeNode").type;
            this.clickStack.push(t), 10 < this.clickStack.length && this.clickStack.shift(),
                t != i && this.cutNode(t, e, n), t == (i = e.getHeadNode().getComponent("TreeNode").type) && (this.showShake(),
                    0 == this.buffState ? this.checkUseRecover() : (this.buffState = 0, this.highDpsCount = 0,
                        this.timber.getComponent("Timber").showBuff(0), this.tree.getComponent("Tree").setNearBranchsBlank(6, !0)));
        }
    },
    showShake: function () {
        this.mainCavas.stopAllActions()
        this.mainCavas.runAction(cc.sequence([cc.moveBy(.05, cc.v2(5, 5)), cc.callFunc(function () {
            cc.loader.loadRes("audios/ouch", cc.AudioClip, function (o, e) {
                cc.audioEngine.playEffect(e);
            });
        }), cc.moveBy(.05, cc.v2(-15, -15)), cc.moveBy(.05, cc.v2(20, 25)), cc.moveTo(.05, this.cavasPos)]));
    },
    showHint: function (o) {
        if (o) {
            this.pausePanel.active = !1;
            var e = this.tree.getComponent("Tree").getSecondHeadNode().getComponent("TreeNode").type;
            0 == this.lastClickType && (this.lastClickType = 1);
            var t = this.lastClickType;
            1 == e && (t = 2), 2 == e && (t = 1), this.hintType = t, this.maskNode.opacity = 125,
                this.maskNode.active = !0, this.hintNode.active = !0, this.hintNode.scaleX = parseInt(2 * (t - 1.5)),
                this.hintDesNode.active = !0, this.hintDesLabel.active = !0, this.hintDesLabel.getComponent(cc.Label).string = t == this.lastClickType ? "点击屏幕伐木" : "要撞了，切换到另一边";
        } else this.maskNode.active = !1, this.hintNode.active = !1, this.hintDesNode.active = !1,
            this.hintDesLabel.active = !1;
    },
    cutNode: function (o, e, t) {
        ++this.cutCount, this.timber.getComponent("Timber").playAnimation("hit"), e.deleteHeadNode(),
            t.runAction(cc.jumpBy(.4, cc.v2(2.7 * (-1 * (600 * o - 900)), -200), 320, 1).easing(cc.easeOut(1))),
            t.runAction(cc.rotateBy(.4, 1.1 * (360 * o - 540)).easing(cc.easeOut(1))), e.generateNewTreeNode(this.score);
        var n = 1,
            i = e.getHeadNode().getComponent("TreeNode").type;
        (o != this.lastClickType && 0 < this.lastClickType && 0 < i && (n = 3), this.curFeaver += this.curAddRateStep * n,
            this.curFeaver = Math.min(this.curFeaver, this.feaverMax), 2 < this.buffState) && (n *= this.buffState,
            cc.loader.loadRes("audios/hui", cc.AudioClip, function (o, e) {
                cc.audioEngine.playEffect(e, !1);
            })), cc.loader.loadRes("audios/hit1_01", cc.AudioClip, function (o, e) {
            cc.audioEngine.playEffect(e);
        });
        var d = parseInt(t.getComponent("TreeNode").score) * n;
        this.score = parseInt(this.score) + d;
        var a = parseInt(this.score);
        (this.score = a + 1), this.updateInfo(),
            30 >= db.highScore && 15 > this.score ? this.showHint(!0) : this.showHint(!1);
    },
    timeBarEffect: function () {
        var o = this,
            a = this;
        cc.loader.loadRes("images/blood", cc.SpriteFrame, function (o, e) {
            o ? cc.error(o.message || o) : a.timeBarSprite.getComponent(cc.Sprite).spriteFrame = e;
        }), this.timeBarSprite.runAction(cc.sequence([cc.delayTime(.02), cc.callFunc(function () {
            o.timeBarSprite.getComponent(cc.Sprite).spriteFrame = o.timeBarFrame;
        })]));
    },
    useLifeCard: function () {
    },
    checkUseRecover: function () {
        this.toCardRecover()
    },
    toCardRecover: function () {
        this.isGameOver =true
        this.gameOver();
    },
    recover: function () {
        this.hasRecover = !0, this.tree.getComponent("Tree").setNearBranchsBlank(6, !0),
            this.pausePanel.active = !0, this.curFeaver = 600, this.timeBar.getComponent(cc.ProgressBar).progress = this.curFeaver / this.feaverMax;
    },
    gameOver: function () {
        if (this.gameInfoNode.active = !1, this.isGameOver = !0, this.unscheduleAllCallbacks(),
            this.scorePanel.getComponent("ScorePanel").showScorePanel(this.score), 
            this.menuPanel.getComponent("MenuPanel").showMenuPanel(!0),
            this.checkNewUnlock(), (200 <= p.highScore && (p.vip && changeRechargeIcon(),
                this.rechargeSprite.active = !0), this.adGameImage && (this.adSprite.active = !0)),
            this.bannerAdID) {
            var o = cc.view.getVisibleSize(),
                e = o.width,
                t = o.height;
            cc.log("winwidth " + e), s.loadBanner(this.bannerAdID, {
                x: e / 2 - 150,
                y: t
            }, {
                width: 300,
                height: 150
            }, function () {});
        }
    },
    checkNewUnlock: function () {
        this.menuPanel.getComponent("MenuPanel").checkNewItem();
    },
    restart: function () {
        
        this.isGameOver = !1, 
        this.isPause = !0, 
        this.hasRecover = !1, 
        this.vipRecovered = !1,
        this.cardRecovered = !1, 
        this.clickCount = 0, 
        this.score = 0, 
        this.buffState = 0,
        this.highDpsCount = 0, 
        this.cutCount = 0, 
        this.timber.setPosition(this.tree.x - 235, this.tree.y - 50),
        this.timber.getComponent("Timber").shiftLeft(), 
        this.firstTime = !1, 
        this.timeBar.getComponent(cc.ProgressBar).progress = .5,
        this.curDropRate = .06, 
        this.curFeaver = 300, 
        this.clickStack = [], 
        this.timber.getComponent("Timber").showBuff(0),
        this.menuPanel.getComponent("MenuPanel").hidePanel(), 
        this.pausePanel.active = !0,
        this.gameInfoNode.active = !0, 
        this.checkBarColor(), 
        this.checkChangeDayNight(), //this.rankNode.getComponent("RankNode").refreshNextFriendByScore(!0, 0),
        this.schedule(function () {
            this.updatePerSecond();
        }, 1), 
        this.updatePerFiveSecond(), 
        this.schedule(function () {
            this.updatePerFiveSecond();
        }, 2), 
        this.updateInfo(), 
        30 < db.highScore,
         30 >= db.highScore && 15 > this.score && this.showHint(!0);
    },
    checkChangeDayNight: function () {

    },
    checkBarColor: function () {
        var o = this;
        cc.loader.loadRes("images/blood1", cc.SpriteFrame, function (e, t) {
            e ? cc.error(e.message || e) : (o.timeBarSprite.getComponent(cc.Sprite).spriteFrame = t,
                o.timeBarFrame = t);
        });
    },
    changeTimberSkin: function (o) {
        this.timber.getComponent("Timber").setSkin(o), i.isBuffUnlock(i.BUFF_PROTECT) && this.timber.getComponent("Timber").showBuff(1);
    },
    update: function (o) {
        this.tree.getComponent("Tree").updateTree(o), 
        0 == this.isGameOver && 0 == this.isPause && 0 == this.hintNode.active && (this.curDropRate = this.dropRateBase + this.dropRateStep * this.curDiff,
            20 < this.curDiff ? this.curDropRate = this.dropRateBase + .5 * (this.dropRateStep * (this.curDiff - 20)) + 20 * this.dropRateStep : 10 < this.curDiff && (this.curDropRate = this.dropRateBase + .75 * (this.dropRateStep * (this.curDiff - 10)) + 10 * this.dropRateStep),
            this.curDropRate = Math.min(this.curDropRate, this.dropRateMax), this.curFeaver -= this.curDropRate,
            this.timeBar.getComponent(cc.ProgressBar).progress = this.curFeaver / this.feaverMax,
            0 >= this.curFeaver && this.checkUseRecover());
    },
    updatePerFiveSecond: function () {
    },
    updatePerSecond: function () {
    },
    clickAd: function () {
    },
    clickRecharge: function () {
    },
    clickToShare: function () {
    },
})