
cc.Class({
    extends: cc.Component,
    properties: {
        branch: {
            default: null,
            type: cc.Node
        },
        add: {
            default: null,
            type: cc.Node
        },
        type: 0,
        score: 1
    },
    start: function () {}
})