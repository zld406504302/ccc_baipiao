(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/Scrpits/Scene/Pass.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, 'd5848gfPb5Hop77YxZwF9hN', 'Pass', __filename);
// Scrpits/Scene/Pass.js

'use strict';

cc.Class({
    extends: cc.Component,

    properties: {},

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start: function start() {

        var levelID = cc.globalDt.getData('level');
        if (levelID > 4) {
            this.scheduleOnce(this.toLevelScene, 1);
            return;
        }
        cc.globalDt.modifyData('level', levelID);
        this.scheduleOnce(this.toGameScene, 1);
    },
    toLevelScene: function toLevelScene() {
        cc.director.loadScene('LevelScene');
    },
    toGameScene: function toGameScene() {
        cc.director.loadScene('GameScene');
    }
}
// update (dt) {},
);

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=Pass.js.map
        