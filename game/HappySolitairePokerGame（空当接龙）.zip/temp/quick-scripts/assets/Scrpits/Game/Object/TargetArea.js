(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/Scrpits/Game/Object/TargetArea.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '3d4248B5dxBOaLqDJEAV0fg', 'TargetArea', __filename);
// Scrpits/Game/Object/TargetArea.js

'use strict';

cc.Class({
    extends: cc.Component,

    properties: {},

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start: function start() {
        this.rect = this.node.getBoundingBox();

        this.gameEmitter = cc.emitterCache.getEmitter('GameEmitter');
        this.gameEmitter.on('targetRect', this.isInRect.bind(this));
    },
    initWithData: function initWithData(data) {
        //cc.log(data);
        if (!data) {
            //cc.log("data为空！");
            return;
        }
        this.dt = {
            id: data.id
        };
    },


    //判断是否在包围盒内
    isInRect: function isInRect(data) {
        this.result = false;
        var isInRect = this.rect.contains(data.pos);
        if (isInRect) {
            //this.isExist=true;
            this.gameEmitter.emit("theCardToTargetArea", this.dt.id, data.num, data.type);
            if (this.result) {
                var tData = {
                    id: data.id,
                    pos: this.node.position,
                    oldState: data.state,
                    newState: "targetCard",
                    oldStateID: data.stateID,
                    newStateID: this.dt.id
                };
                this.gameEmitter.emit("setCardPos", tData);
            }
        }
    }
}
// update (dt) {},
);

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=TargetArea.js.map
        