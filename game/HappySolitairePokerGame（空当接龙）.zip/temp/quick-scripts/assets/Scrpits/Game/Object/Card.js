(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/Scrpits/Game/Object/Card.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '318dev6JKNKDpp/XMcOdGFO', 'Card', __filename);
// Scrpits/Game/Object/Card.js

'use strict';

cc.Class({
    extends: cc.Component,

    properties: {
        cardAtlas: cc.SpriteAtlas
    },

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start: function start() {
        this.isPlace = false;
        this.isMove = false;
        this.rect = this.node.getBoundingBox();
        //cc.log(rect);
        this.gameEmitter = cc.emitterCache.getEmitter('GameEmitter');

        this.node.on(cc.Node.EventType.TOUCH_START, this.onTouchBegan, this);
        this.node.on(cc.Node.EventType.TOUCH_MOVE, this.onTouchMove, this);
        this.node.on(cc.Node.EventType.TOUCH_END, this.onTouchEnd, this);
        this.node.on(cc.Node.EventType.TOUCH_CANCEL, this.onTouchCancel, this);
    },
    initWithData: function initWithData(data) {
        //cc.log(data);
        if (!data) {
            //cc.log("data为空！");
            return;
        }
        this.dt = {
            id: data.id,
            num: data.num,
            type: data.type,
            imgName: data.imgName,
            isMove: data.isMove,
            state: data.state,
            stateID: data.stateID,
            birthPos: data.birthPos
        };
        this.sprite = this.node.getComponent(cc.Sprite);
        this.sprite.spriteFrame = this.cardAtlas.getSpriteFrame(this.dt.imgName);
    },


    //点击时
    onTouchBegan: function onTouchBegan(event) {
        this.isPlace = false;
        this.isMove = false;
        if (this.dt.state === "freeCard") {
            this.isMove = true;
            this.gameEmitter.emit('changeFreeAreaState', this.dt.stateID, false);
        }
        // else if(this.dt.state==="targetCard"){
        //     this.isMove=false;
        // }
        else if (this.dt.state === "gameCard") {
                this.gameEmitter.emit("decCardMove", this.dt.id);
            }
    },


    //移动
    onTouchMove: function onTouchMove(event) {
        if (!this.isMove) {
            return;
        }
        //更改卡牌层级关系
        var zIndex = cc.globalDt.getData('zIndex');
        zIndex++;
        cc.globalDt.modifyData('zIndex', zIndex);
        this.node.zIndex = zIndex;

        var worldPos = event.getLocation();
        var pos = this.node.parent.convertToNodeSpaceAR(worldPos);
        this.node.position = pos;
    },


    //点击结束
    onTouchEnd: function onTouchEnd() {
        if (!this.isMove) {
            return;
        }
        //cc.log('ky');
        var gData = {
            id: this.dt.id,
            num: this.dt.num,
            state: this.dt.state,
            stateID: this.dt.stateID,
            pos: this.node.position
        };
        this.gameEmitter.emit("gameRect", gData);

        var fData = {
            id: this.dt.id,
            state: this.dt.state,
            stateID: this.dt.stateID,
            pos: this.node.position
        };
        this.gameEmitter.emit('freeRect', fData);

        var tData = {
            id: this.dt.id,
            num: this.dt.num,
            type: this.dt.type,
            state: this.dt.state,
            stateID: this.dt.stateID,
            pos: this.node.position
        };
        this.gameEmitter.emit('targetRect', tData);

        if (!this.isPlace) {
            if (this.dt.state === "freeCard") {
                this.gameEmitter.emit('changeFreeAreaState', this.dt.stateID, true);
            }
            this.node.position = this.dt.birthPos;
        }

        //this.move();
    },


    //离开屏幕
    onTouchCancel: function onTouchCancel() {
        this.node.position = this.dt.birthPos;
    },


    // update (dt) {},

    onDestroy: function onDestroy() {
        this.node.off(cc.Node.EventType.TOUCH_START, this.onTouchBegan, this);
        this.node.off(cc.Node.EventType.TOUCH_MOVE, this.onTouchMove, this);
        this.node.off(cc.Node.EventType.TOUCH_END, this.onTouchEnd, this);
        this.node.off(cc.Node.EventType.TOUCH_CANCEL, this.onTouchCancel, this);
    }
});

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=Card.js.map
        