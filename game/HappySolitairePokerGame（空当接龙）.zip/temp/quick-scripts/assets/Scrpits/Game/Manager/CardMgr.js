(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/Scrpits/Game/Manager/CardMgr.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '3beaaEyUgtHkJyJCjXnFNav', 'CardMgr', __filename);
// Scrpits/Game/Manager/CardMgr.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        cardPfb: cc.Prefab,
        freeAreaPfb: cc.Prefab,
        targetAreaPfb: cc.Prefab
    },

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start: function start() {
        this.arrSurplusCard = []; //剩余卡牌数组
        this.arrCardJs = []; //卡牌js数组
        this.arrFreeAreaJs = []; //卡牌空闲区js数组
        this.arrTargetAreaJs = []; //卡牌目标区js数组
        this.arrGameCard = new Array(8); //八列游戏卡牌数组
        for (var i = 0; i < 8; i++) {
            this.arrGameCard[i] = [];
        }
        this.arrTargetCard = new Array(4); //目标卡牌数组
        for (var j = 0; j < 4; j++) {
            this.arrTargetCard[j] = [];
        }
        this.arrFreeCard = []; //空闲可移动数组


        this.addFreeArea();
        this.addTargetArea();

        this.initAllCard();
        this.addAllCard();

        this.gameEmitter = cc.emitterCache.getEmitter('GameEmitter');
        this.gameEmitter.on("setCardPos", this.setCardPos.bind(this)); //注册设置卡牌位置事件
        this.gameEmitter.on("decCardMove", this.decCardMove.bind(this)); //注册判断卡牌是否可移动
        this.gameEmitter.on("gameRect", this.isInRect.bind(this)); //注册判断卡牌是否在最表面
        this.gameEmitter.on("changeFreeAreaState", this.changeFreeAreaState.bind(this)); //注册改变空闲区状态
        this.gameEmitter.on("theCardToTargetArea", this.theCardToTargetArea.bind(this)); //注册判断卡牌是否可以添加到目标区
    },


    //初始化所有扑克牌
    initAllCard: function initAllCard() {
        for (var i = 1; i < 14; i++) {
            var data1 = void 0,
                data2 = void 0,
                data3 = void 0,
                data4 = void 0;
            if (i < 10) {
                data1 = {
                    id: 4 * i - 4,
                    num: i,
                    type: 0,
                    imgName: "fang_0" + i + "@3x"
                };
                data2 = {
                    id: 4 * i - 3,
                    num: i,
                    type: 1,
                    imgName: "love_0" + i + "@3x"
                };
                data3 = {
                    id: 4 * i - 2,
                    num: i,
                    type: 2,
                    imgName: "mei_0" + i + "@3x"
                };
                data4 = {
                    id: 4 * i - 1,
                    num: i,
                    type: 3,
                    imgName: "tao_0" + i + "@3x"
                };
            } else {
                data1 = {
                    id: 4 * i - 4,
                    num: i,
                    type: 0,
                    imgName: "fang_" + i + "@3x"
                };
                data2 = {
                    id: 4 * i - 3,
                    num: i,
                    type: 1,
                    imgName: "love_" + i + "@3x"
                };
                data3 = {
                    id: 4 * i - 2,
                    num: i,
                    type: 2,
                    imgName: "mei_" + i + "@3x"
                };
                data4 = {
                    id: 4 * i - 1,
                    num: i,
                    type: 3,
                    imgName: "tao_" + i + "@3x"
                };
            }

            this.arrSurplusCard.push(data1);
            this.arrSurplusCard.push(data2);
            this.arrSurplusCard.push(data3);
            this.arrSurplusCard.push(data4);
        }
    },


    //在指定位置添加扑克
    addOneCard: function addOneCard(index, pos) {
        var len = this.arrSurplusCard.length;
        if (len <= 0) {
            //如果没有卡牌返回0
            return 0;
        }
        var cardN = cc.instantiate(this.cardPfb);
        cardN.parent = this.node;
        cardN.position = pos;
        var nIndex = Math.floor(Math.random() * len);

        var data = {
            id: this.arrSurplusCard[nIndex].id,
            num: this.arrSurplusCard[nIndex].num,
            type: this.arrSurplusCard[nIndex].type,
            imgName: this.arrSurplusCard[nIndex].imgName,
            isMove: false,
            state: "gameCard",
            stateID: index,
            birthPos: pos
        };
        var cardJS = cardN.getComponent("Card");
        cardJS.initWithData(data);
        this.arrCardJs.push(cardJS);
        this.arrSurplusCard.splice(nIndex, 1);

        var data1 = {
            id: data.id,
            num: data.num,
            index: data.stateID
        };
        this.arrGameCard[index].push(data1);
        return 1;
    },


    //添加所有卡牌
    addAllCard: function addAllCard() {
        for (var i = 0; i < 7; i++) {
            for (var j = 0; j < 8; j++) {
                var add = this.addOneCard(j, cc.v2(-805 + j * 230, -i * 50));
                if (!add) {
                    //如果没有卡牌返回
                    return;
                }
            }
        }
    },


    //遍历arrGameCard数组,通过id获取指定数据
    getCardByID: function getCardByID(id) {
        for (var i = 0; i < 8; i++) {
            var len = this.arrGameCard[i].length;
            if (len > 0) {
                var ID = this.arrGameCard[i][len - 1].id;
                if (ID === id) {
                    return this.arrGameCard[i][len - 1];
                }
            }
        }
    },


    //遍历js数组,通过id获取指定数组js
    getJsByID: function getJsByID(id, arrName) {
        //cc.log("数组长度"+this.arrCardJs.length);
        var arr = [];
        if (arrName === "arrCardJs") {
            arr = this.arrCardJs;
        } else if (arrName === "arrFreeAreaJs") {
            arr = this.arrFreeAreaJs;
        } else if (arrName === "arrTargetAreaJs") {
            arr = this.arrTargetAreaJs;
        }

        //cc.log(arr);
        for (var i = 0, len = arr.length; i < len; i++) {
            // cc.log(arr[i].dt.id);
            if (id === arr[i].dt.id) {
                return arr[i];
            }
        }
    },


    //判断卡牌是否可移动
    decCardMove: function decCardMove(id) {
        for (var i = 0; i < 8; i++) {
            //cc.log(this.arrGameCard[i]);
            var len = this.arrGameCard[i].length;
            if (len > 0) {
                var ID = this.arrGameCard[i][len - 1].id;
                if (id === ID) {
                    var cardJs = this.getJsByID(id, "arrCardJs");
                    cardJs.isMove = true;
                    return;
                }
            }
        }
    },


    //连接时更新游戏卡牌位置
    setGameCardPos: function setGameCardPos(id, pos) {
        var cardJs = this.getJsByID(id, "arrCardJs");
        cardJs.node.position = pos;
        cardJs.dt.birthPos = pos;
    },


    //通过id设置节点位置,更改状态
    setCardPos: function setCardPos(data) {
        var cardJs = this.getJsByID(data.id, "arrCardJs");
        cardJs.node.position = data.pos;
        cardJs.dt.birthPos = data.pos;
        cardJs.dt.state = data.newState;
        cardJs.dt.stateID = data.newStateID;

        //将卡牌从原数组中删除
        //cc.log(this.arrGameCard[data1.index]);
        if (data.oldState === "gameCard") {
            this.arrGameCard[data.oldStateID].pop();
        }
    },


    //判断是否在包围盒内
    isInRect: function isInRect(data) {
        var id = data.id;
        var num = data.num;
        var state = data.state;
        var index = data.stateID;
        var pos = data.pos;
        for (var i = 0; i < 8; i++) {
            var len = this.arrGameCard[i].length;
            var isIn = false;
            var x = 0;
            var y = 0;
            var isLink = false;
            //cc.log(len);
            if (len > 0) {
                //cc.log(this.arrGameCard[i][len-1]);
                var ID = this.arrGameCard[i][len - 1].id;
                if (ID !== id) {
                    var data2 = this.getCardByID(ID);
                    if (data2.num - 1 === num) {
                        isLink = true;
                    }
                    var cardJs = this.getJsByID(ID, "arrCardJs");
                    var rect = cardJs.node.getBoundingBox();
                    //cc.log(rect);
                    isIn = rect.contains(pos);
                    x = cardJs.node.x;
                    y = cardJs.node.y - 50;
                }
            } else {
                var _rect = new cc.Rect(-805 + i * 230 - 100, -200, 200, 600);
                //let rect=new cc.Rect.fromMinMax(cc.v2(-805 + i * 230-100,0),cc.v2(cc.v2(-805 + i * 230+100,400)));
                //cc.log(rect);
                isLink = true;
                isIn = _rect.contains(pos);
                x = -805 + i * 230;
                y = 0;
            }
            if (isIn && isLink) {

                var data1 = {
                    id: id,
                    num: num,
                    index: i
                };
                //cc.log(data1);
                this.arrGameCard[i].push(data1);
                var gData = {
                    id: id,
                    pos: cc.v2(x, y),
                    oldState: state,
                    newState: "gameCard",
                    oldStateID: index,
                    newStateID: i
                };
                this.setCardPos(gData);
                var Len = this.arrGameCard[i].length;
                if (Len > 9) {
                    for (var j = 0; j < Len; j++) {
                        var gID = this.arrGameCard[i][j].id;
                        this.setGameCardPos(gID, cc.v2(-805 + i * 230, -j * (400 / Len)));
                    }
                }
                return;
            }
        }
    },


    //判断目标卡牌是否全部集齐
    collectComplete: function collectComplete() {
        cc.log("开始收集");
        var isCollect = true;
        for (var i = 0; i < 4; i++) {
            var len = this.arrTargetCard[i].length;
            if (len < 13) {
                isCollect = false;
                break;
            }
        }
        if (isCollect) {
            cc.log("已收齐");
            this.gameEmitter.emit("showNodeByName", "passBox");
        }
    },


    //添加空闲可移动区
    addFreeArea: function addFreeArea() {
        for (var i = 0; i < 4; i++) {
            var cardN = cc.instantiate(this.freeAreaPfb);
            cardN.parent = this.node;
            cardN.position = cc.v2(-805 + i * 230, 250);

            var freeAreaJs = cardN.getComponent('FreeArea');
            var data = {
                id: i
            };
            freeAreaJs.initWithData(data);
            this.arrFreeAreaJs.push(freeAreaJs);
        }
    },


    //改变空闲可移动区状态
    changeFreeAreaState: function changeFreeAreaState(stateID, stateType) {
        var freeAreaJs = this.getJsByID(stateID, "arrFreeAreaJs");
        freeAreaJs.isExist = stateType;
    },


    //添加目标区
    addTargetArea: function addTargetArea() {
        for (var i = 0; i < 4; i++) {
            var cardN = cc.instantiate(this.targetAreaPfb);
            cardN.parent = this.node;
            cardN.position = cc.v2(115 + i * 230, 250);

            var targetAreaJs = cardN.getComponent('TargetArea');
            var data = {
                id: i
            };
            targetAreaJs.initWithData(data);
            this.arrTargetAreaJs.push(targetAreaJs);
        }
    },


    //判断卡牌是否可以添加到目标区
    theCardToTargetArea: function theCardToTargetArea(stateID, cardNum, Type) {
        var targetAreaJs = this.getJsByID(stateID, "arrTargetAreaJs");
        var len = this.arrTargetCard[stateID].length;
        var data = {
            num: cardNum, //数字大小
            type: Type //花色
        };

        cc.log(data);
        if (len <= 0) {
            if (cardNum === 1) {
                this.arrTargetCard[stateID].push(data);
                targetAreaJs.result = true;
            }
        } else {
            if (cardNum - 1 === this.arrTargetCard[stateID][len - 1].num && Type === this.arrTargetCard[stateID][len - 1].type) {
                this.arrTargetCard[stateID].push(data);
                targetAreaJs.result = true;
            }
        }

        //测试使用
        // this.arrTargetCard[stateID].push(data);
        // targetAreaJs.result = true;
        this.collectComplete();
    }
}

// update (dt) {},
);

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=CardMgr.js.map
        