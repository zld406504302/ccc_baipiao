(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/Scrpits/Data/ConfigDt.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '622e2MQ82pFSo0JL8n83uGS', 'ConfigDt', __filename);
// Scrpits/Data/ConfigDt.js

'use strict';

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var Data = require('Data');

var ConfigDt = function () {
    function ConfigDt(jsonDt) {
        _classCallCheck(this, ConfigDt);

        this.arrData = jsonDt;
    }

    //通过id获取指定数据


    _createClass(ConfigDt, [{
        key: 'getDataByID',
        value: function getDataByID(id) {
            for (var i = 0; i < this.arrData.length; i++) {
                var data = this.arrData[i];
                if (data.id === id) {
                    return data;
                }
            }
            return null;
        }

        //修改数据

    }, {
        key: 'modifyData',
        value: function modifyData(arrDt) {
            if (arrDt) {
                this.arrData = arrDt;
            }
        }
    }]);

    return ConfigDt;
}();

module.exports = ConfigDt;

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=ConfigDt.js.map
        