(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/Scrpits/Function/ShowAndHide.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '28419FVpFJAeJCxDEQI728+', 'ShowAndHide', __filename);
// Scrpits/Function/ShowAndHide.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        arrBoxN: [cc.Node]
    },

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start: function start() {
        this.audioMgr = cc.find("AudioMgr").getComponent("AudioMgr"); //获取音效管理者
        for (var i = 0, len = this.arrBoxN.length; i < len; i++) {
            this.arrBoxN[i].active = false;
        }
    },


    // update (dt) {},

    //显示弹框
    showBox: function showBox(event, boxID) {
        this.audioMgr.playBtnMusic();
        this.arrBoxN[boxID].active = true;
    },


    //隐藏弹框
    hideBox: function hideBox(event, boxID) {
        this.arrBoxN[boxID].active = false;
    }
});

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=ShowAndHide.js.map
        