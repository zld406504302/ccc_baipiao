(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/Scrpits/Function/Background.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '28792oZRAFNTqcDMir/oLIl', 'Background', __filename);
// Scrpits/Function/Background.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        backgroundN: cc.Node,
        arrBackground: [cc.SpriteFrame]
    },

    // LIFE-CYCLE CALLBACKS:

    onLoad: function onLoad() {
        var sprite = this.backgroundN.getComponent(cc.Sprite);
        var ratio = cc.winSize.width / cc.winSize.height;
        cc.log(ratio);
        if (parseFloat(ratio) < parseFloat(2)) {
            sprite.spriteFrame = this.arrBackground[0];
            cc.log("1");
        } else {
            sprite.spriteFrame = this.arrBackground[1];
            cc.log("2");
        }
    },
    start: function start() {}
}

// update (dt) {},
);

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=Background.js.map
        