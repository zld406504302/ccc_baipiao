(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/Scrpits/Common/EmitterCache.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '438cb58IdpAc6nKQymQab1u', 'EmitterCache', __filename);
// Scrpits/Common/EmitterCache.js

'use strict';

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var EmitterCache = function () {
    function EmitterCache() {
        _classCallCheck(this, EmitterCache);

        this.cache = {};
    }

    _createClass(EmitterCache, [{
        key: 'addEmitter',
        value: function addEmitter(key, emitter) {
            if (typeof key !== 'string' || key.length <= 0) {
                return null;
            }
            if (!this.cache[key]) {
                this.cache[key] = emitter;
            }
            return this.cache[key];
        }
    }, {
        key: 'removeEmitter',
        value: function removeEmitter(key) {
            if (typeof key !== 'string' || key.length <= 0) {
                return;
            }
            delete this.cache[key];
        }
    }, {
        key: 'getEmitter',
        value: function getEmitter(key) {
            if (typeof key !== 'string' || key.length <= 0) {
                return null;
            }
            return this.cache[key];
        }
    }]);

    return EmitterCache;
}();

module.exports = EmitterCache;

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=EmitterCache.js.map
        