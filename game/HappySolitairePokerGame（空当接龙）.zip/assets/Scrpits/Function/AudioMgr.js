

cc.Class({
    extends: cc.Component,

    properties: {
        bgMusic:{
            type:cc.AudioClip,
            default:null,
        },
        btnMusic:{
            type:cc.AudioClip,
            default:null,
        },
        removeMusic:{
            type:cc.AudioClip,
            default:null,
        },
        // dealCardMusic:{
        //     type:cc.AudioClip,
        //     default:null,
        // },
    },


    onLoad () {
        cc.game.addPersistRootNode(this.node);
    },

    start () {
        this.volume=1;
    },

    //播放背景音乐
    playBgMusic(){
        this.audioID1=cc.audioEngine.play(this.bgMusic,true,0.5);
    },


    //停止背景音乐
    stopBgMusic(){
        if(this.audioID1!==undefined){
            cc.audioEngine.stop(this.audioID1);
            this.audioID1=undefined;
        }
        return;
    },

    //调节所有音量大小
    setAllVolume(volume){
        this.volume=volume;
        cc.audioEngine.setVolume(this.audioID1,volume);
    },

    //播放按钮音效
    playBtnMusic(){
        let audioID2=cc.audioEngine.play(this.btnMusic,false,this.volume);
    },

    startBtnMusic(){
        this.volume=1;
    },

    stopBtnMusic(){
        this.volume=0;
    },

    //播放消除音效
    playRemoveMusic(){
        let audioID3=cc.audioEngine.play(this.removeMusic,false,this.volume);
        
    },

    // //播放发牌卡牌音效
    // playDealCardMusic(){
    //     let audioID4=cc.audioEngine.play(this.dealCardMusic,false,this.volume);
        
    // },
    // update (dt) {},
});
