

cc.Class({
    extends: cc.Component,

    properties: {
        backgroundN:cc.Node,
        arrBackground:[cc.SpriteFrame],
    },

    // LIFE-CYCLE CALLBACKS:

    onLoad () {
        let sprite=this.backgroundN.getComponent(cc.Sprite);
        let ratio=cc.winSize.width/cc.winSize.height;
        cc.log(ratio);
        if(parseFloat(ratio)<parseFloat(2)){
            sprite.spriteFrame=this.arrBackground[0];
            cc.log("1");
        }
        else{
            sprite.spriteFrame=this.arrBackground[1];
            cc.log("2");
        }
    },

    start () {

    },

    // update (dt) {},
});
