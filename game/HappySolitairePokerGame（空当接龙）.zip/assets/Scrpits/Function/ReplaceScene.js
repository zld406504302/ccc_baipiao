

cc.Class({
    extends: cc.Component,

    properties: {

    },

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start () {

    },

    //通过名字更换场景
    replaceScene(event,sceneName){
        cc.director.loadScene(sceneName);
    },

    // update (dt) {},
});
