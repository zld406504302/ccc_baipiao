class Data{
    constructor(){
        this.dataObj = {};
    }
    
    //添加数据
    addData(key, value){
        if (this.dataObj[key]) {
            return;
        }
        this.dataObj[key] = value;
    }

    //得到数据
    getData(key){
        return this.dataObj[key];
    }

    //修改数据
    modifyData(key, value){
        if (this.dataObj[key]!==undefined) {
            if(this.dataObj[key]===value){
                return;
            }
            this.dataObj[key] = value;
        }
    }
}

module.exports = Data;