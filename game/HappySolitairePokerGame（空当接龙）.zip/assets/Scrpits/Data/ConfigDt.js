let Data = require('Data');
class ConfigDt{
    constructor(jsonDt){
        this.arrData = jsonDt;
    }

    //通过id获取指定数据
    getDataByID(id){
        for(let i = 0; i < this.arrData.length; i++){
            let data = this.arrData[i];
            if (data.id === id) {
                return data;
            }
        }
        return null;
    }

    //修改数据
    modifyData(arrDt){
        if(arrDt){
            this.arrData = arrDt;
        }      
    }
}

module.exports = ConfigDt;