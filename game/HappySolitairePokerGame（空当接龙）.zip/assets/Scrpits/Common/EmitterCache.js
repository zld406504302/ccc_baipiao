
class EmitterCache{
    constructor(){
        this.cache = {};
    }

    addEmitter(key, emitter){
        if (typeof(key) !== 'string' || key.length <= 0) {
            return null;
        }
        if (!this.cache[key]) {
            this.cache[key] = emitter;
        }
        return this.cache[key];
    }

    removeEmitter(key){
        if (typeof(key) !== 'string' || key.length <= 0) {
            return;
        }
        delete this.cache[key];
    }

    getEmitter(key){
        if (typeof(key) !== 'string' || key.length <= 0) {
            return null;
        }
        return this.cache[key];
    }
}
module.exports = EmitterCache;
