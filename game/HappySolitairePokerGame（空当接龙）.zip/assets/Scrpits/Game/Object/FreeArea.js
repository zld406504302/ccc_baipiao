

cc.Class({
    extends: cc.Component,

    properties: {
  
    },

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start () {
        this.rect=this.node.getBoundingBox();
        this.isExist=false;

        this.gameEmitter=cc.emitterCache.getEmitter('GameEmitter');
        this.gameEmitter.on('freeRect',this.isInRect.bind(this));

        //cc.log(this.dt.id);
    },


    initWithData(data){
        //cc.log(data);
        if(!data){
            //cc.log("data为空！");
            return;
        }
        this.dt={
            id:data.id,
        }
    },


    //判断是否在包围盒内
    isInRect(data){
        let isInRect= this.rect.contains(data.pos);
        //cc.log(this.dt.id,this.isExist);
        if(isInRect && !this.isExist){
            this.isExist=true;
            let fData={
                id:data.id,
                pos:this.node.position,
                oldState:data.state,
                newState:"freeCard",
                oldStateID:data.stateID,
                newStateID:this.dt.id,
            };
            this.gameEmitter.emit("setCardPos",fData);
        }
    },
    // update (dt) {},
});
