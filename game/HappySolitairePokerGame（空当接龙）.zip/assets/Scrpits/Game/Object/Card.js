

cc.Class({
    extends: cc.Component,

    properties: {
        cardAtlas:cc.SpriteAtlas,
    },

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start () {
        this.isPlace=false;
        this.isMove=false;
        this.rect=this.node.getBoundingBox();
        //cc.log(rect);
        this.gameEmitter=cc.emitterCache.getEmitter('GameEmitter');

        this.node.on(cc.Node.EventType.TOUCH_START, this.onTouchBegan, this);
        this.node.on(cc.Node.EventType.TOUCH_MOVE, this.onTouchMove, this);
        this.node.on(cc.Node.EventType.TOUCH_END, this.onTouchEnd, this);
        this.node.on(cc.Node.EventType.TOUCH_CANCEL, this.onTouchCancel, this);
    },

    initWithData(data){
        //cc.log(data);
        if(!data){
            //cc.log("data为空！");
            return;
        }
        this.dt={
            id:data.id,
            num:data.num,
            type:data.type,
            imgName:data.imgName,
            isMove:data.isMove,
            state:data.state,
            stateID:data.stateID,
            birthPos:data.birthPos,
        }
        this.sprite=this.node.getComponent(cc.Sprite);
        this.sprite.spriteFrame=this.cardAtlas.getSpriteFrame(this.dt.imgName);
    },



    //点击时
    onTouchBegan(event){
        this.isPlace=false;
        this.isMove=false;
        if(this.dt.state==="freeCard"){
            this.isMove=true;
            this.gameEmitter.emit('changeFreeAreaState',this.dt.stateID,false);
        }
        // else if(this.dt.state==="targetCard"){
        //     this.isMove=false;
        // }
        else if(this.dt.state==="gameCard"){
            this.gameEmitter.emit("decCardMove", this.dt.id);
        }
    },

    //移动
    onTouchMove(event){
        if(!this.isMove){
            return;
        }
        //更改卡牌层级关系
        let zIndex=cc.globalDt.getData('zIndex');
        zIndex++;
        cc.globalDt.modifyData('zIndex',zIndex);
        this.node.zIndex=zIndex;

        let worldPos=event.getLocation();
        let pos=this.node.parent.convertToNodeSpaceAR(worldPos);
        this.node.position=pos;
    },

    //点击结束
    onTouchEnd(){
        if(!this.isMove){
            return;
        }
        //cc.log('ky');
        let gData={
            id:this.dt.id,
            num:this.dt.num,
            state:this.dt.state,
            stateID:this.dt.stateID,
            pos:this.node.position
        };
        this.gameEmitter.emit("gameRect", gData);

        let fData={
            id:this.dt.id,
            state:this.dt.state,
            stateID:this.dt.stateID,
            pos:this.node.position
        };
        this.gameEmitter.emit('freeRect',fData);

        let tData={
            id:this.dt.id,
            num:this.dt.num,
            type:this.dt.type,
            state:this.dt.state,
            stateID:this.dt.stateID,
            pos:this.node.position
        };
        this.gameEmitter.emit('targetRect',tData);

        if(!this.isPlace){
            if(this.dt.state==="freeCard"){
                this.gameEmitter.emit('changeFreeAreaState',this.dt.stateID,true);
            }
            this.node.position=this.dt.birthPos;
        }

        //this.move();
    },

    //离开屏幕
    onTouchCancel(){
        this.node.position=this.dt.birthPos;
    },

    // update (dt) {},

    onDestroy(){
        this.node.off(cc.Node.EventType.TOUCH_START, this.onTouchBegan, this);
        this.node.off(cc.Node.EventType.TOUCH_MOVE, this.onTouchMove, this);
        this.node.off(cc.Node.EventType.TOUCH_END, this.onTouchEnd, this);
        this.node.off(cc.Node.EventType.TOUCH_CANCEL, this.onTouchCancel, this);
    },
});
