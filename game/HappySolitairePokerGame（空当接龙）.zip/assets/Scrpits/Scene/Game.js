const Emitter=require('Emitter');

cc.Class({
    extends: cc.Component,

    properties: {
        timeLabel:cc.Label,
        pauseBoxN:cc.Node,
        passBoxN:cc.Node,
        overBoxN:cc.Node,
    },

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start () {
        this.loadData();
        this.isPass=false;
        

        this.mode=cc.globalDt.getData('mode');
        let level=cc.globalDt.getData('level');
        this.oneSecond=0;
        this.time=560-level*60;
        this.curTime=560-level*60;
        this.timeLabel.string=this.time;
        this.isPause=false;

        this.pauseBoxN.active=false;
        this.passBoxN.active=false;
        this.overBoxN.active=false;
        
    },

    loadData () {
        //获取全局播放器
        this.audioMgr = cc.find("AudioMgr").getComponent("AudioMgr"); 

        //创建消息主体
        cc.emitterCache.addEmitter('GameEmitter', new Emitter());
        this.gameEmitter=cc.emitterCache.getEmitter('GameEmitter');
        this.gameEmitter.on("showNodeByName",this.showNodeByName.bind(this));
    },


    //显示暂停框
    showPauseBox(){
        this.isPause=true;
        
        this.pauseBoxN.active=true;
    },

    //隐藏暂停框
    hidePauseBox(){
        this.isPause=false;
        this.pauseBoxN.active=false;
    },

    //通过名字显示指定节点
    showNodeByName(nodeName){
        if(nodeName==="passBox"){
            this.isPass=true;
            this.isPause=true;
            // this.passBoxN.zIndex=1;
            this.passBoxN.active=true;
        }
        else if(nodeName==="overBox"){
            this.isPause=true;
            // this.overBoxN.zIndex=1;
            this.overBoxN.active=true;
        }
    },

    //继续时间倒计时
    continueTime(){
        this.isPause=false;
    },

    //停止时间倒计时
    pauseTime(){
        this.isPause=true;
    },

    update (dt) {
        if(this.isPause){
            return;
        }
        this.oneSecond+=dt;
        if(this.oneSecond>=1){
            this.oneSecond=0;
            this.time-=1;
            if(this.time<0){
                this.time=0;
                this.showNodeByName("overBox");
            }
            this.timeLabel.string=this.time+"s";
        }
    },

    //通过名字更换场景
    replaceSceneByName(event,sceneName){
        //cc.globalDt.modifyData('score',this.curScore);
        cc.director.loadScene(sceneName);
    },

    //日期时间处理
    conver(s) {
        return s < 10 ? '0' + s : s;
    },

    //成绩导入排行榜
    ranking(curMode,curTime){
        let myDate=new Date();
        let year = myDate.getFullYear();//获取当前年
        let month = myDate.getMonth() + 1;//获取当前月
        let date = myDate.getDate();//获取当前日
        let hour = myDate.getHours();//得到小时
        let minu = myDate.getMinutes();//得到分钟
        let sec = myDate.getSeconds();//得到秒
        //获取当前时间
        let nowDate = year + '.' + this.conver(month) + "." + this.conver(date)+" "+this.conver(hour)+":"+this.conver(minu);
        let arrDt=cc.rankDt.arrData;

        let len=3;
        for(let i=0;i<len;i++){
            if(arrDt[i]===undefined){
                let data={
                    name:"SUSU",
                    mode:curMode,
                    time:curTime,
                    date:nowDate,
                };
                arrDt[i]=data;
                cc.rankDt.modifyData(arrDt);
                cc.log(cc.rankDt);
                //存储本地文件
                cc.sys.localStorage.setItem('rankDt', JSON.stringify(arrDt));
                break;
            }
            if(arrDt[i].time>curTime){
                arrDt.splice(len-1,1);
                let data={
                    name:"SUSU",
                    mode:curMode,
                    tiem:curTime,
                    date:nowDate
                };
                arrDt.splice(i,0,data);
                cc.rankDt.modifyData(arrDt);
                cc.log(cc.rankDt);
                //cc.globalDt.modifyData('curScore',0);
                //存储本地文件
                cc.sys.localStorage.setItem('rankDt', JSON.stringify(arrDt));
                break;
            }
        }  
    },

    //场景注销时将游戏场景注册的消息清空，消息管理者移除
    onDestroy(){
        if(this.isPass){
            this.curTime-=this.time;
            cc.log(this.curTime);
            this.ranking(this.mode,this.curTime);
        }
        
        let gameEmitter=cc.emitterCache.getEmitter('GameEmitter');
        gameEmitter.off();
        cc.emitterCache.removeEmitter('GameEmitter');
    },
});
