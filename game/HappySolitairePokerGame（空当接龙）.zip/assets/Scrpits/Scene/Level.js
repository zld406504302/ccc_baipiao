

cc.Class({
    extends: cc.Component,

    properties: {

    },

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start () {

    },

    //选择不同关卡进入游戏
    replaceScene(event,level){
        cc.globalDt.modifyData('level',level);//当前模式
        cc.director.loadScene("GameScene");
    },
    // update (dt) {},
});
