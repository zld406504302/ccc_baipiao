

cc.Class({
    extends: cc.Component,

    properties: {
        
    },

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start () {
        
        let levelID=cc.globalDt.getData('level');
        if(levelID>4){
            this.scheduleOnce(this.toLevelScene,1);
            return;
        }
        cc.globalDt.modifyData('level',levelID);
        this.scheduleOnce(this.toGameScene,1);
    },

    toLevelScene(){
        cc.director.loadScene('LevelScene');
    },
    
    toGameScene(){
        cc.director.loadScene('GameScene');
    },
    // update (dt) {},
});
