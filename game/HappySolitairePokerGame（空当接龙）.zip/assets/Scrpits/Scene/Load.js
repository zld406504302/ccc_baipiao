const Data=require('Data');
const ConfigDt=require('ConfigDt');
const EmitterCache=require('EmitterCache');
const AudioMgr=require('AudioMgr');

cc.Class({
    extends: cc.Component,

    properties: {
        audioMgr:AudioMgr,
    },

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start () {
        this.loadData();
        this.scheduleOnce(this.replaceScene,1);
    },

    loadData(){ 

        //读取本地文件
        let rankDt = JSON.parse(cc.sys.localStorage.getItem('rankDt'));
        //cc.sys.localStorage.removeItem('rankDt');
        cc.rankDt=new ConfigDt(rankDt);//用于存储排名数据
        let arrDt=cc.rankDt.arrData;


        // arrDt=null;//将初始数据置空
        //cc.sys.localStorage.clear();//清空本地数据

        if(arrDt===null){
            arrDt=[];
            if(arrDt[0]===undefined){
                let data={
                    name:"SUSU",
                    mode:"Puzzle",
                    time:480,
                    date:"2020.04.13 12:00"
                };
                arrDt[0]=data;
            }
            cc.rankDt.modifyData(arrDt);
            cc.log(cc.rankDt);  
            //存储本地文件
            cc.sys.localStorage.setItem('rankDt', JSON.stringify(arrDt));
        }


        cc.globalDt=new Data();//用于存储全局变量
        cc.emitterCache=new EmitterCache();//用于存储消息数据

        cc.globalDt.addData('musicState',1);//当前音乐状态
        cc.globalDt.addData('zIndex',0);//当前卡牌层级
        cc.globalDt.addData('mode',"Puzzle");//当前模式
        cc.globalDt.addData('level',1);//当前关卡
    },

    replaceScene(){
        cc.director.loadScene('MenuScene');
        //cc.director.loadScene('GameScene');
    },

    // update (dt) {},

    onDestroy(){
        this.audioMgr.playBgMusic();
    },
});
