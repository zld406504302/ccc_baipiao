"use strict";
cc._RF.push(module, '447efguoShFcImA56DLUmo8', 'Mode');
// Scrpits/Scene/Mode.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {},

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start: function start() {},


    //选择不同模式进入游戏
    replaceScene: function replaceScene(event, mode) {
        cc.globalDt.modifyData('mode', mode); //当前模式
        cc.director.loadScene("LevelScene");
    }
}

// update (dt) {},
);

cc._RF.pop();