"use strict";
cc._RF.push(module, 'b7a0cpIa1BLuqKTFt9uaN7I', 'Level');
// Scrpits/Scene/Level.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {},

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start: function start() {},


    //选择不同关卡进入游戏
    replaceScene: function replaceScene(event, level) {
        cc.globalDt.modifyData('level', level); //当前模式
        cc.director.loadScene("GameScene");
    }
}
// update (dt) {},
);

cc._RF.pop();