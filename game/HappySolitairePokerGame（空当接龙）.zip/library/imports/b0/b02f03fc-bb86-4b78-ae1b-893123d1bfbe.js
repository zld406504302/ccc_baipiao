"use strict";
cc._RF.push(module, 'b02f0P8u4ZLeK4biTEj0b++', 'RankMgr');
// Scrpits/Game/Manager/RankMgr.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        rankPfb: cc.Prefab
    },

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start: function start() {
        this.showRank();
    },


    //显示排行榜
    showRank: function showRank() {
        var arrDt = cc.rankDt.arrData;
        cc.log(arrDt);
        //cc.log(arrDt);
        var len = 3;
        var height = 40;
        for (var i = 0; i < len; i++) {
            var rankN = cc.instantiate(this.rankPfb);
            rankN.parent = this.node;
            rankN.position = cc.v2(-520, 40 - i * 140);
            var data = {};
            if (arrDt[i] === undefined) {
                data = {
                    num: "",
                    name: "",
                    mode: "",
                    time: "",
                    date: ""
                };
            } else {
                height += 140;
                data = {
                    num: "No.0" + (i + 1),
                    name: arrDt[i].name,
                    mode: arrDt[i].mode,
                    time: arrDt[i].time + "s",
                    date: arrDt[i].date
                };
            }

            var rankJs = rankN.getComponent('Rank');
            rankJs.initWithData(data);
            //cc.log(rankN.parent);
        }
        this.node.height = height;
        cc.log(arrDt);
    }
}

// update (dt) {},
);

cc._RF.pop();