"use strict";
cc._RF.push(module, 'bbd4eNag5xCkYeRnzNkscFe', 'ReplaceScene');
// Scrpits/Function/ReplaceScene.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {},

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start: function start() {},


    //通过名字更换场景
    replaceScene: function replaceScene(event, sceneName) {
        cc.director.loadScene(sceneName);
    }
}

// update (dt) {},
);

cc._RF.pop();