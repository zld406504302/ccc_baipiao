"use strict";
cc._RF.push(module, '7d67fYgCa1DILx3RbC4aum8', 'Rank');
// Scrpits/Game/Object/Rank.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        numLab: cc.Label,
        nameLab: cc.Label,
        modeLab: cc.Label,
        timeLab: cc.Label,
        dateLab: cc.Label
    },

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start: function start() {
        if (this.dt.num == "") {
            this.node.active = false;
        } else {
            this.numLab.string = this.dt.num;
            this.nameLab.string = this.dt.name;
            this.modeLab.string = this.dt.mode;
            this.timeLab.string = this.dt.time;
            this.dateLab.string = this.dt.date;
        }
    },
    initWithData: function initWithData(data) {
        this.dt = {
            num: data.num,
            name: data.name,
            mode: data.mode,
            time: data.time,
            date: data.date
        };
    }
}

// update (dt) {},
);

cc._RF.pop();