"use strict";
cc._RF.push(module, 'd5848gfPb5Hop77YxZwF9hN', 'Pass');
// Scrpits/Scene/Pass.js

'use strict';

cc.Class({
    extends: cc.Component,

    properties: {},

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start: function start() {

        var levelID = cc.globalDt.getData('level');
        if (levelID > 4) {
            this.scheduleOnce(this.toLevelScene, 1);
            return;
        }
        cc.globalDt.modifyData('level', levelID);
        this.scheduleOnce(this.toGameScene, 1);
    },
    toLevelScene: function toLevelScene() {
        cc.director.loadScene('LevelScene');
    },
    toGameScene: function toGameScene() {
        cc.director.loadScene('GameScene');
    }
}
// update (dt) {},
);

cc._RF.pop();