"use strict";
cc._RF.push(module, '28792oZRAFNTqcDMir/oLIl', 'Background');
// Scrpits/Function/Background.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        backgroundN: cc.Node,
        arrBackground: [cc.SpriteFrame]
    },

    // LIFE-CYCLE CALLBACKS:

    onLoad: function onLoad() {
        var sprite = this.backgroundN.getComponent(cc.Sprite);
        var ratio = cc.winSize.width / cc.winSize.height;
        cc.log(ratio);
        if (parseFloat(ratio) < parseFloat(2)) {
            sprite.spriteFrame = this.arrBackground[0];
            cc.log("1");
        } else {
            sprite.spriteFrame = this.arrBackground[1];
            cc.log("2");
        }
    },
    start: function start() {}
}

// update (dt) {},
);

cc._RF.pop();