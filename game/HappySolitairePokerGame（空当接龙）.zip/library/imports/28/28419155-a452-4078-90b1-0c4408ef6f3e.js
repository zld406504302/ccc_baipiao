"use strict";
cc._RF.push(module, '28419FVpFJAeJCxDEQI728+', 'ShowAndHide');
// Scrpits/Function/ShowAndHide.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        arrBoxN: [cc.Node]
    },

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start: function start() {
        this.audioMgr = cc.find("AudioMgr").getComponent("AudioMgr"); //获取音效管理者
        for (var i = 0, len = this.arrBoxN.length; i < len; i++) {
            this.arrBoxN[i].active = false;
        }
    },


    // update (dt) {},

    //显示弹框
    showBox: function showBox(event, boxID) {
        this.audioMgr.playBtnMusic();
        this.arrBoxN[boxID].active = true;
    },


    //隐藏弹框
    hideBox: function hideBox(event, boxID) {
        this.arrBoxN[boxID].active = false;
    }
});

cc._RF.pop();