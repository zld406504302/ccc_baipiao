"use strict";
cc._RF.push(module, '1e5a6Yt/QlG2aOXWc8qa0ZA', 'Utils');
// Scrpits/Common/Utils.js

'use strict';

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

var utils = {};
utils.deepClone = function (initalObj, finalObj) {
  var obj = finalObj || {};
  for (var i in initalObj) {
    var prop = initalObj[i]; // 避免相互引用对象导致死循环，如initalObj.a = initalObj的情况
    if (prop === obj) {
      continue;
    }
    if ((typeof prop === 'undefined' ? 'undefined' : _typeof(prop)) === 'object') {
      obj[i] = prop.constructor === Array ? [] : {};
      //arguments.callee(prop, obj[i]);
      utils.deepClone(prop, obj[i]);
    } else {
      obj[i] = prop;
    }
  }
  return obj;
};

utils.isInArr = function (value, arrValue) {
  for (var i = 0; i < arrValue.length; i++) {
    if (value === arrValue[i]) {
      return true;
    }
  }
  return false;
};

utils.contains = function (arrInfo, info, isEquals) {
  for (var i = 0; i < arrInfo.length; i++) {
    var infoTemp = arrInfo[i];
    if (isEquals(info, infoTemp)) {
      return infoTemp;
    }
  }
  return null;
};
module.exports = utils;

cc._RF.pop();