"use strict";
cc._RF.push(module, '5b0a9PDiJBOtLyaYFRhHqcn', 'FreeArea');
// Scrpits/Game/Object/FreeArea.js

'use strict';

cc.Class({
    extends: cc.Component,

    properties: {},

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start: function start() {
        this.rect = this.node.getBoundingBox();
        this.isExist = false;

        this.gameEmitter = cc.emitterCache.getEmitter('GameEmitter');
        this.gameEmitter.on('freeRect', this.isInRect.bind(this));

        //cc.log(this.dt.id);
    },
    initWithData: function initWithData(data) {
        //cc.log(data);
        if (!data) {
            //cc.log("data为空！");
            return;
        }
        this.dt = {
            id: data.id
        };
    },


    //判断是否在包围盒内
    isInRect: function isInRect(data) {
        var isInRect = this.rect.contains(data.pos);
        //cc.log(this.dt.id,this.isExist);
        if (isInRect && !this.isExist) {
            this.isExist = true;
            var fData = {
                id: data.id,
                pos: this.node.position,
                oldState: data.state,
                newState: "freeCard",
                oldStateID: data.stateID,
                newStateID: this.dt.id
            };
            this.gameEmitter.emit("setCardPos", fData);
        }
    }
}
// update (dt) {},
);

cc._RF.pop();