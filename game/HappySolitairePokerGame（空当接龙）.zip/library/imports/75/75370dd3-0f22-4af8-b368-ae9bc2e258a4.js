"use strict";
cc._RF.push(module, '753703TDyJK+LNorpvC4lik', 'Data');
// Scrpits/Data/Data.js

"use strict";

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var Data = function () {
    function Data() {
        _classCallCheck(this, Data);

        this.dataObj = {};
    }

    //添加数据


    _createClass(Data, [{
        key: "addData",
        value: function addData(key, value) {
            if (this.dataObj[key]) {
                return;
            }
            this.dataObj[key] = value;
        }

        //得到数据

    }, {
        key: "getData",
        value: function getData(key) {
            return this.dataObj[key];
        }

        //修改数据

    }, {
        key: "modifyData",
        value: function modifyData(key, value) {
            if (this.dataObj[key] !== undefined) {
                if (this.dataObj[key] === value) {
                    return;
                }
                this.dataObj[key] = value;
            }
        }
    }]);

    return Data;
}();

module.exports = Data;

cc._RF.pop();