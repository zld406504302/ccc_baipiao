"use strict";
cc._RF.push(module, '745f0rU8udBnIhJC86y4ni3', 'Menu');
// Scrpits/Scene/Menu.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        //goldLab:cc.Label,
        musicN: cc.Node,
        arrMusic: [cc.SpriteFrame]
    },

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start: function start() {
        this.audioMgr = cc.find("AudioMgr").getComponent("AudioMgr"); //获取音效管理者

        this.musicState = cc.globalDt.getData('musicState');
        // let gold=cc.globalDt.getData('gold');
        // this.goldLab.string=gold;
        this.musicSprite = this.musicN.getComponent(cc.Sprite);
        this.musicSprite.spriteFrame = this.arrMusic[this.musicState];
    },


    //改变背景音乐
    changeMusic: function changeMusic() {
        if (this.musicState) {
            this.musicState = 0;
            this.audioMgr.stopBgMusic();
        } else {
            this.musicState = 1;
            this.audioMgr.playBgMusic();
        }
        this.musicSprite.spriteFrame = this.arrMusic[this.musicState];
        cc.globalDt.modifyData('musicState', this.musicState);
    },


    //评分
    grade: function grade() {
        cc.log("评分");
        this.audioMgr.playBtnMusic();
        if (cc.sys.isNative && cc.sys.os == cc.sys.OS_IOS) {
            //判断是否是源生平台并且是否是iOS平台
            //调用APPController类中的Grade方法，并且传递参数
            jsb.reflection.callStaticMethod("AppController", "Grade:title:", "title", "message");
        }
    },


    //分享
    share: function share() {
        cc.log("分享");
        this.audioMgr.playBtnMusic();
        if (cc.sys.isNative && cc.sys.os == cc.sys.OS_IOS) {
            //判断是否是源生平台并且是否是iOS平台
            //调用APPController类中的Share方法，并且传递参数
            jsb.reflection.callStaticMethod("AppController", "Share:title:", "title", "message");
        }
    }
}
// update (dt) {},
);

cc._RF.pop();