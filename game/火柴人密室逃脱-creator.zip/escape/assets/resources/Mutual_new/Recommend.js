
if (typeof (wx) == "undefined") {
    window.wx = function () {};
    wx.getSystemInfoSync = function () {
        return {
            SDKVersion: "3.0.0",
            screenWidth: 1280,
            screenHeight: 720,
            windowWidth: 1280,
            windowHeight: 720
        }
    }
    wx.navigateToMiniProgram = function (obj) {
        console.log("跳转小程序：", obj.appId)
    }
    wx.request = function (obj) {
        var xhr = cc.loader.getXMLHttpRequest();
        xhr.timeout = 5000;
        var str = "";
        for (var k in obj.data) {
            if (str != "?") {
                str += "&";
            }
            str += k + "=" + obj.data[k];
        }
        var requestURL = obj.url + encodeURI(str);
        xhr.open("GET", requestURL, true);
        xhr.onreadystatechange = function () {
            if (xhr.readyState === 4 && (xhr.status >= 200 && xhr.status < 300)) {
                try {
                    var data = JSON.parse(xhr.responseText);
                    let res = {};
                    res.data = data
                    obj.success(res);
                } catch (e) {}
            }
        };
        xhr.send();
    }
}
cc.Class({
    extends: cc.Component,
    properties: {
        //将三个互推的拉进来
    },
    cutStr:function (str, len) {
        var str_length = 0;
        var str_len = str.length;
        var str_cut = new String();
        for (var i = 0; i < str_len; i++) {
            var a = str.charAt(i);
            str_length++;
            if (escape(a).length > 4) {
                //中文字符的长度经编码之后大于4
                str_length++;
            }
            str_cut = str_cut.concat(a);
            if (str_length >= len) {
                str_cut = str_cut.concat("...");
                return str_cut;
            }
        }
        //如果给定字符串小于指定长度，则返回源字符串；
        if (str_length < len) {
            return str;
        }
    },
    start() {
        // //设置为常驻节点
        // if(cc.re == undefined){
        //     cc.re = {};
        //     cc.re.isHaveData = false;
        // }else{
        //     return;
        // }
        // var self = this;
        // if (cc.re.isHaveData == false) {

        //     cc.re.isHaveData = true;
        // }
    },

});
