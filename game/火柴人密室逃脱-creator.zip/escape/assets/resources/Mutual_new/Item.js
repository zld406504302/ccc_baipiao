cc.Class({
    extends: cc.Component,
    properties: {
        wxAppId:""
    },

    wsstart:function(){
		return false;
        var me=this;
        var ws = new WebSocket("ws://127.0.0.1:3564");
        ws.binaryType = "arraybuffer" ;
        var decoder = new TextDecoder('utf-8')
        ws.onopen = function (event) {
            me.ws = ws;
            console.log("Send Text WS was opened.");
        };

        ws.onmessage = function (event) {
            console.log("response text msg: " + event.data);

            var input = event.data;

            var data = JSON.parse(decoder.decode(event.data));
            console.log("server response");

            console.log(data);

        };
        ws.onerror = function (event) {
            console.log("Send Text fired an error");
        };
        ws.onclose = function (event) {
            console.log("WebSocket instance closed.");
        };


    },
    switchGame: function () {
        console.log("跳转到："+this.wxAppId)
        var self = this;
        wx.navigateToMiniProgram({
            appId: this.wxAppId, //跳转的AppId
            success: function () {
            },
            fail: function (err) {
            },
            complete: function () { },
        })
    },
    onSeat:function(){
        cc.log("onSeat init");
        var node_table_bg = cc.find("Canvas");
		cc.log(node_table_bg);
        for(var i=0;i<9;i++){
            //var v = table_data['players'][k];
            var seat_node = node_table_bg.getChildByName("seat_"+i);
            seat_node.on("mouseup",function(event){
                this.seatClick (event);
            },this);
        }
    },
    getLength:function (str) {
        ///<summary>获得字符串实际长度，中文2，英文1</summary>
        ///<param name="str">要获得长度的字符串</param>
        var realLength = 0, len = str.length, charCode = -1;
        for (var i = 0; i < len; i++) {
            charCode = str.charCodeAt(i);
            if (charCode >= 0 && charCode <= 128) realLength += 1;
            else realLength += 2;
        }
        return realLength;
    },
});