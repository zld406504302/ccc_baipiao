

'use strict';
cc.Class({
    extends: cc.Component,
    properties: {
        targetNode: cc.Node,
        sprite: {
            default: null,
            type: cc.Sprite
        },
        _lastPosX: 0,
        _lastPosY: 0,
        _isShake:false,
    },

    start: function () {
        // let texture = new cc.RenderTexture();
        // texture.initWithSize(cc.visibleRect.width, cc.visibleRect.height);
        // let spriteFrame = new cc.SpriteFrame();
        // spriteFrame.setTexture(texture)
        // this.sprite.spriteFrame = spriteFrame;
    },
    update: function () {
        if(this._isShake){
            return;
        }
        var pos = this.targetNode.convertToWorldSpaceAR(cc.Vec2.ZERO);
        if (Math.abs(pos.x - this._lastPosX) > 0.5 || Math.abs(pos.y - this._lastPosY) > 0.5) {
            this.node.position = this.node.parent.convertToNodeSpaceAR(pos);
        }
        // this._lastPosX = pos.x;
        this._lastPosY = pos.y;
    },

    shake: function () {
        var self = this;
        this._isShake = true
        this.node.runAction(
            cc.repeatForever(
                cc.sequence(
                    cc.moveBy(0.02, cc.v2(2, 2)),
                    cc.moveBy(0.02, cc.v2(-4, 0)),
                    cc.moveBy(0.02, cc.v2(0, -4)),
                    cc.moveBy(0.02, cc.v2(4, 0)),
                    cc.moveBy(0.02, cc.v2(-2, 2)),
                )
            )
        );
        setTimeout(() => {
            this.node.stopAllActions();
            self._isShake = false
        }, 120);
    }
    // update (dt) {},
});