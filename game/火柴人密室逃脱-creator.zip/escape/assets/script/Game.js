window.Global = {
    level: 0
}
var Game = cc.Class({
    extends: cc.Component,
    properties: {
        logo: cc.Node,
        gameView: cc.Node,
        gameAgain: cc.Node,
        up: cc.Node,
        down: cc.Node,
        maskUp: cc.Mask,
        maskDown: cc.Mask,
        player: cc.Node,
        playerSpine: sp.Skeleton,
        banner:cc.Node,
        _isDown: false,
        _arr: [],
        _arr2: [],
        _playerIndex: 4,
    },

    start: function () {
        this.logo.active = true;
        this.gameView.active = false;
        this.gameAgain.active = false;
    },

    startClick: function () {
        // cc.re.mutualNode.active = false;
        // cc.re.centerNode.active = false;
        Global.level = 1;
        let lab = this.gameView.getChildByName("level").getComponent(cc.Label);
        lab.string = "关卡：" + Global.level;
        this.logo.active = false;
        this.gameView.active = true;
        this.gameAgain.active = false;
        this.player.active = true;
        this._posArr = [-325];
        for (let i = 1; i < 9; i++) {
            this._posArr.push(-325 + i * 93.75);
        }
        this.createPlatform();
    },
    createPlatform() {
        this.up.y = 0;
        this.down.x = 0;
        this._isDown = false;
        this._arr = []
        for (let i = 0; i < 9; i++) {
            let random = (Math.floor(Math.random() * 5) + 1);
            this._arr.push(random);
        }
        this._arr2 = [0, 0, 0, 0, 0, 0, 0, 0, 0]
        let randomEsc = Math.floor(Math.random() * 3) + 1
        for (let i = 0; i <= randomEsc; i++) {
            let random = Math.floor(Math.random() * 9);
            let random2 = Math.floor(Math.random() * 3) + 1
            this._arr2[random] = this._arr2[random] + random2;
        };
        this._playerIndex = 4;
        this.player.x = this._posArr[this._playerIndex];
        this.player.y = this._arr[this._playerIndex] * (40) - 155;
        this.updateUp();
        this.updateDown();
        let time = 2000 - Global.level * 250;
        time = time < 1000 ? 1000 : time;

        var self = this;
        var func = function () {
            self.startRunPlatform()
        }
        setTimeout(func, time)
        // setTimeout(function(){
        //     this.startRunPlatform()
        // }.bind(this), time);
    },

    updateUp: function () {
        this.maskUp.type = cc.Mask.Type.ELLIPSE;
        this.maskUp.inverted = true;
        var self = this;
        this.maskUp._updateGraphics = function () {
            var ctx = self.maskUp._graphics;
            ctx.clear()
            ctx.moveTo(375, 0)
            ctx.lineTo(-375, 0)
            let startX = -375;
            let lastRandomY = (self._arr[0]) * 40 + self._arr2[0] * 50 + 100;
            ctx.lineTo(-375, lastRandomY);
            let randomY = 0;
            for (let i = 1; i < 9; i++) {
                ctx.lineTo(startX + i * 93.75, lastRandomY);
                randomY = (self._arr[i]) * 40 + self._arr2[i] * 50 + 100;
                ctx.lineTo(startX + i * 93.75, randomY);
                lastRandomY = randomY;
            }
            ctx.lineTo(375, 0)
            ctx.fill()
        };
        //this.maskUp._updateGraphics = upfunc;
        this.maskUp._updateGraphics();
    },

    updateDown: function () {
        this.maskDown.type = cc.Mask.Type.ELLIPSE;
        this.maskDown.inverted = true;
        var self = this;
        this.maskDown._updateGraphics = function () {
            var ctx = self.maskDown._graphics;
            ctx.clear();
            let startX = -375;
            let lastRandomY = (self._arr[0]) * (40) - 200;
            let firRandomY = lastRandomY;
            ctx.moveTo(-375, lastRandomY)
            let randomY = 0;
            for (let i = 1; i < 9; i++) {
                ctx.lineTo(startX + i * 93.75, lastRandomY);
                randomY = (self._arr[i]) * (40) - 200;
                ctx.lineTo(startX + i * 93.75, randomY);
                lastRandomY = randomY;
            }
            ctx.lineTo(375, 0);
            ctx.lineTo(-375, 0);
            ctx.lineTo(-375, firRandomY);
            ctx.fill();
        };
        // this.maskDown._updateGraphics = downfunc;
        this.maskDown._updateGraphics();
    },

    startRunPlatform: function () {
        if (this._isDown) {
            return;
        }
        this._isDown = true;
        let index = 0;
        var self = this;
        this.schedule(function () {
            self.up.y -= 50;
            self.updateUp();
            if (index == 5) {
                self.gameOver();
            }
            index++;
        }, 0.05, 5, 0);
    },

    gameOver: function () {
        // if(cc.vv.ads.insert != undefined){
        //     let interstitialAd = wx.createInterstitialAd({
        //         adUnitId: cc.vv.ads.insert
        //     });
        //     interstitialAd.show().catch((err) => {
        //         console.error(err)
        //     })
        //     interstitialAd.onError(err => {
        //         console.log(err)
        //     })
        // }    
        var self = this;
        if (this._arr2[this._playerIndex] > 0) {
            let lab = this.gameView.getChildByName("level").getComponent(cc.Label);
            Global.level++;
            lab.string = "关卡：" + Global.level;
            setTimeout(function () {
                self.createPlatform();
            }, 1500);
        } else {
            this.logo.active = false;
            this.gameView.active = false;
            this.gameAgain.active = true;
        }
    },

    updateShow: function () {

    },


    RoleClick: function (event, data) {
        if (this._isDown) {
            return;
        }
        if (data == "1") {
            this._playerIndex++;
            this._playerIndex = this._playerIndex > 7 ? 7 : this._playerIndex;
        } else {
            this._playerIndex--;
            this._playerIndex = this._playerIndex < 0 ? 0 : this._playerIndex;
        }
        this.player.x = this._posArr[this._playerIndex];
        this.player.y = this._arr[this._playerIndex] * (40) - 155;
    },

    update(dt) {
        // this.maskUp._updateGraphics();
    },
});

module.exports = Game