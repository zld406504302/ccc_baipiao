cc.Class({
    extends: cc.Component,

    properties: {
        _timer:null,
        _canera:null
    },

    start () {
        this._canera = cc.find("Canvas/Main Camera"); 
    },
    onCollisionEnter: function (other, self) {
        if(this._timer != null){
            clearTimeout(this._timer);
        }
    },

    onCollisionStay: function (other, self) {
        if(this._timer != null){
            clearTimeout(this._timer);
        }
    },
    onCollisionExit: function (other, self) {
        Global.score++;
        clearTimeout(this._timer);
        this._timer = setTimeout(function() {
            console.log("gameover")
            this._canera.emit("gameover",{});
        }.bind(this), 200);
    }
});
