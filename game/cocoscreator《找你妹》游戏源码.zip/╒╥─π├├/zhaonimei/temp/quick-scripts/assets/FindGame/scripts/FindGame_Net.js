(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/FindGame/scripts/FindGame_Net.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '47d3fz+khhF5I2UZ7W0oC1e', 'FindGame_Net', __filename);
// FindGame/scripts/FindGame_Net.js

'use strict';

var gameProto = require('./message/games.message')['games'];
var msgdef = require('./message/msgdef');
var ByteBuffer = require("bytebuffer");

var CB = require("cb");

var Net = {};

Net.MID_GAME_START = 1;
Net.MID_SELECT_RET = 2;

var GAME_STATE_INIT = 0;
var GAME_STATE_CONNECT = 1;
var GAME_STATE_ENTER = 2;
var GAME_STATE_READY = 3;
var GAME_STATE_START = 4;

function getHttpParams(value) {
	var r = new RegExp("(\\?|#|&)" + value + "=([^&#]*)(&|#|$)");
	var m = location.href.match(r);
	return decodeURIComponent(!m ? "" : m[2]);
}

function handleGameData(cmd, data) {
	if (cmd == Net.MID_GAME_START && cc.g_Game.game_state == GAME_STATE_READY) {
		cc.g_Game.game_state = GAME_STATE_START;
		if (data == -1) {
			cc.g_Game.game_data = Math.floor(Math.random() * 10 + 1);
			Net.MsgRetweetData(Net.MID_GAME_START, cc.g_Game.game_data);
		} else {
			cc.g_Game.game_data = data;
		}
		cc.director.loadScene("FindGame_Main");
	}

	if (cmd == Net.MID_SELECT_RET) {
		CB.dispatchEvent("event_select", [data]);
	}
}

//--------请求测试--------
Net.Send = function (msgId, protobuff) {
	if (cc.g_Game.game_state == GAME_STATE_INIT) return;

	var sendBuffer;
	if (protobuff == null) {
		sendBuffer = new ByteBuffer(6, true);
		sendBuffer.writeUint32(0, 0);
		sendBuffer.writeUint16(msgId, 4);
	} else {
		var length = protobuff.byteLength;
		sendBuffer = new ByteBuffer(length + 6, true);
		sendBuffer.writeUint32(length, 0);
		sendBuffer.writeUint16(msgId, 4);
		//protobuff.copy(sendBuffer, 6);
		sendBuffer.append(protobuff, 6);
	}
	cc.g_Game.ws.send(sendBuffer.buffer);
	console.log("Send", msgId, sendBuffer.buffer.byteLength);
};

//转发数据
Net.MsgRetweetData = function (cmd, data) {
	if (cc.g_Game.game_state == GAME_STATE_INIT) return;

	var length = 6;
	var buffer = new ByteBuffer(12, true);
	var offset = 0;
	buffer.writeUint32(6, offset); //长度4
	offset += 4;
	buffer.writeUint16(12345, offset); //msgid12345
	offset += 2;
	buffer.writeUint16(cmd, offset);
	offset += 2;
	buffer.writeInt32(data, offset);
	console.log('send MsgRetweetData', cmd, data, buffer.buffer.byteLength);
	Net.Send(msgdef.GAME_MSG_RETWEET_DATA_REQ, buffer.buffer);
};

//更新玩家分数
Net.MsgUserScoreReq = function (userId, score) {
	if (cc.g_Game.game_state == GAME_STATE_INIT) return;

	var data = {
		userId: userId,
		score: score
	};
	console.log('send MsgUserScoreReq', data);
	var protobuff = new gameProto.MsgUserScoreReq(data);
	protobuff = protobuff.encode().toBuffer();
	Net.Send(msgdef.GAME_MSG_USER_SCORE_REQ, protobuff);
};

//结束游戏
Net.OverGame = function () {
	if (cc.g_Game.game_state == GAME_STATE_INIT) return;

	console.log('send OverGame');
	Net.Send(msgdef.GAME_MSG_OVER_GAME_REQ);
};

//-----------接收测试-----------------
Net.GAME_MSG_ENTER_ROOM_ACK = function (bufferData) {
	var data = gameProto.MsgEnterRoomAck.decode(bufferData);
	console.log("recv GAME_MSG_ENTER_ROOM_ACK", data);
	if (data.result == 0) {
		cc.g_Game.game_state = GAME_STATE_ENTER;
	}
};

Net.GAME_MSG_USER_LIST_ACK = function (bufferData) {
	var data = gameProto.MsgUserListAck.decode(bufferData);
	console.log("recv player data", data);

	if (data.userList.length == 1) {
		if (cc.g_Game.game_state == GAME_STATE_READY) {
			Net.OverGame();
			return;
		} else if (cc.g_Game.game_state >= GAME_STATE_START) {
			var that = cc.g_Game.that;
			that.onGameResultOpen();
			that.l_gameEndTime = -1;
			Net.OverGame();
			return;
		}
	}

	cc.g_Game.initData(data.userList);

	for (var i = 0; i < data.userList.length; i++) {
		var info = data.userList[i];
		console.log(info.name, info.userId, info.gender);
	}
	if (cc.g_Game.game_state != GAME_STATE_START) {
		cc.g_Game.game_state = GAME_STATE_READY;
		//发送准备好的消息
		Net.MsgRetweetData(Net.MID_GAME_START, -1);

		CB.dispatchEvent("event_ready", [0]);
	}
};

Net.GAME_MSG_USER_SCORE_REQ = function (bufferData) {
	var data = gameProto.MsgUserScoreReq.decode(bufferData);
	console.log('recv score data', data);

	CB.dispatchEvent("event_score_opp", [data.score]);
};

//转发自定义
Net.GAME_MSG_RETWEET_DATA = function (bufferData) {
	var cmd = bufferData.readUInt16(0);
	var data = bufferData.readInt32(2);
	console.log("recv retweet data", cmd, data);

	handleGameData(cmd, data);
};

Net.MsgEnterRoomReq = function () {
	if (cc.g_Game.game_state == GAME_STATE_INIT) return;

	var userId = '';
	var token = 'pvp';

	var token_id = getHttpParams("token");
	var user_id = getHttpParams("user");
	if (token_id != "" && user_id != "") {
		var user = [];
		token_id = parseInt(token_id);
		if (token_id == 1) user = ['kfzmeINV', 'jrsIQqyC'];
		if (token_id == 2) user = ['fTdap2Df', 'LTHzNtFm'];
		if (token_id == 3) user = ['L3ONEVav', 'nmeQN22v'];
		if (token_id == 4) user = ['a5BFnCeU', 'DjadROsE'];
		if (token_id == 5) user = ['07uu9E1W', '6utznI7O'];

		token = token + token_id;
		userId = user[parseInt(user_id)];
	} else {
		userId = 'mwdLdFS9';
		token = 'standalone1';
	}

	console.log("userId", token, userId);

	cc.g_Game.userId = userId;

	var data = {
		userId: userId,
		token: token,
		gameTypeId: 123
	};
	console.log('send MsgEnterRoomReq', data);
	var protobuff = new gameProto.MsgEnterRoomReq(data);
	protobuff = protobuff.encode().toBuffer();
	console.log("length", protobuff.byteLength);
	Net.Send(msgdef.GAME_MSG_ENTER_ROOM_REQ, protobuff);
};

Net.GAME_MSG_SERVER_PING = function (bufferData) {
	var data = gameProto.MsgServerPing.decode(bufferData);
	//console.log("recv Net.GAME_MSG_SERVER_PING", data.id);

	var msg = {
		id: data.id
		//console.log('send GAME_MSG_SERVER_PING', msg)
	};var protobuff = new gameProto.MsgServerPing(msg);
	protobuff = protobuff.encode().toBuffer();
	Net.Send(msgdef.GAME_MSG_SERVER_PING, protobuff);
	//Net.Send(msgdef.GAME_MSG_SERVER_PING, bufferData.buffer)
};

Net.CloseWebSocket = function () {
	if (cc.g_Game.game_state == GAME_STATE_INIT) return;

	if (cc.g_Game.ws == null) return;

	cc.g_Game.ws.close();
	cc.g_Game.ws = null;
};

Net.CreateWebSocket = function (urldata) {
	//url自己拼接
	var url = urldata.agreement + '://' + urldata.address + ':' + urldata.port;
	console.log('url', url);

	cc.g_Game.ws = new WebSocket(url);
	cc.g_Game.ws.binaryType = "arraybuffer";

	cc.g_Game.ws.onopen = function (evt) {
		console.log("connection open ...");

		cc.g_Game.game_state = GAME_STATE_CONNECT;
		Net.MsgEnterRoomReq();
	};

	cc.g_Game.ws.onmessage = function (message) {
		//console.log( "Received Message: ",message.data);
		var protobuff = message.data;
		var length = protobuff.byteLength;
		//console.log("message len", length);
		message = new ByteBuffer(length, true);
		message.append(protobuff, 0);
		var buffLen = message.readUInt32(0);
		var msgId = message.readUInt16(4);
		var messageBuffer = null;
		if (buffLen > 0) {
			messageBuffer = message.copy(6);
		}
		if (msgId > msgdef.GAME_MSG_SERVER_PING) {
			console.log('onmessage msgid', msgId, " len ", buffLen, "buffer", messageBuffer);
		}
		Net.msghandle[msgId](messageBuffer);
	};

	cc.g_Game.ws.onclose = function (evt) {
		console.log("Connection closed.");
		Net.CloseWebSocket();
		cc.g_Game.game_state = GAME_STATE_INIT;
	};
};

Net.msghandle = {};
Net.msghandle[msgdef.GAME_MSG_ENTER_ROOM_ACK] = Net.GAME_MSG_ENTER_ROOM_ACK;
Net.msghandle[msgdef.GAME_MSG_USER_LIST_ACK] = Net.GAME_MSG_USER_LIST_ACK;
Net.msghandle[msgdef.GAME_MSG_USER_SCORE_REQ] = Net.GAME_MSG_USER_SCORE_REQ;
Net.msghandle[msgdef.GAME_MSG_SERVER_PING] = Net.GAME_MSG_SERVER_PING;

//msgId 12345 自定义的消息号
Net.msghandle[12345] = Net.GAME_MSG_RETWEET_DATA;

module.exports = Net;

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=FindGame_Net.js.map
        