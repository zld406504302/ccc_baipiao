(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/FindGame/scripts/ItemCell.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '09fbcgCkxhAMY+iEkXooNJd', 'ItemCell', __filename);
// FindGame/scripts/ItemCell.js

'use strict';

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

cc.Class({
    extends: require('viewCell'),
    properties: {
        _num: null,
        _data: null,
        img_item: cc.Sprite,
        s_selected: cc.Sprite
    },

    // use this for initialization
    onLoad: function onLoad() {},
    init: function init(index, data, group) {
        this._init(data.array[index], data.target, group);
    },
    _init: function _init(data, target, group) {
        //当pagevie模式下group参数才有效
        this._target = target;
        var self = this;
        this._data = data;
        this.node.active = true;
        if (!data) {
            this.node.active = false;
            return;
        }
        var textures = cc.loader.getRes('FindGame/textures/' + data.itemId);
        //console.log(textures);
        this.img_item.getComponent(cc.Sprite).spriteFrame = new cc.SpriteFrame(textures);
        this._num = data.num;
        console.log(_typeof(data.select));
        if (data.select == '0') {
            this.s_selected.getComponent(cc.Sprite).node.active = false;
        } else if (data.select == '1') {
            this.s_selected.getComponent(cc.Sprite).node.active = true;
        }
    },
    clicked: function clicked() {
        //this.s_selected.getComponent(cc.Sprite).node.active=true;
        this._target.selectItem(this._data.num);
    }
});

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=ItemCell.js.map
        