var CB = (function(){
    function CB(){}

    var _cbmArr = [];
    var _pool = [];
    /**
     * 添加事件
     * @param   eventType 事件类型
     * @param   callBack  事件回调
     * @param   depth     事件深度 0<1 0先执行 1后执行
     */
    CB.addEvent = function(eventType, callBack, depth) {
        depth = arguments[2] != null?arguments[2]:100;

        if (!_cbmArr[eventType])_cbmArr[eventType] = [];

        var index = CB.getIndex(eventType, callBack)
        if (index != -1)_cbmArr[eventType][index].depth = depth?depth:index
        else {
            var handler = _pool.length?_pool.shift():new CBHandler()
            handler.func=callBack
            handler.depth=depth
            _cbmArr[eventType].push(handler)
        }
        _cbmArr[eventType].sort(paixu)
    }

    CB.removeEvent = function(eventType, callBack) {
        if (!_cbmArr[eventType] || !_cbmArr[eventType].length) return
        var index = CB.getIndex(eventType, callBack)
        if (index != -1)_pool.push(_cbmArr[eventType].splice(index, 1))
    }

    /**
     * 派发事件
     * @param   eventType      事件类型
     * @param   callBackParams 回调参数
     */
    CB.dispatchEvent = function(eventType, callBackParams) {
        callBackParams = arguments[1] != null?arguments[1]:null;
        if (_cbmArr[eventType]) {
            for (var i = _cbmArr[eventType].length - 1; i >= 0; i--) 
            {
                _cbmArr[eventType]&&_cbmArr[eventType][i]&&_cbmArr[eventType][i].func.apply(null, callBackParams)
            }
        }else { trace("[Warn] CBM没有对应的回调类型 - " + eventType) }
    }
    
    var paixu = function(a,b){return b.depth - a.depth}
    
    /**
     * 获取对应回调函数的下表
     * @param   eventType 类型
     * @param   func      回调函数
     * @return  没有返回 -1
     */
    CB.getIndex = function(eventType, func) {
        for (var i = 0, length = _cbmArr[eventType].length; i < length; i++) 
        {
            if (func == _cbmArr[eventType][i].func) {
                return i
            }
        }
        return -1
    }

    return CB
})();
var CBHandler = function(){
    var that = this
    /**回调方法*/
    this.func;
    /**深度*/
    this.depth;
}

module.exports = CB;
