cc.Class({
    extends: cc.Component,

    properties: {
      
    },

    // use this for initialization
    onLoad: function () {
         this.node.on(cc.Node.EventType.TOUCH_START,function(event){
            event.stopPropagation();
            console.log('TOUCH_STARTLayer');
        },this.node);
    },

    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});
