cc.g_Game = {}
cc.g_Game.initData = function(data)
{
	cc.g_Game.userList = data
	cc.g_Game.score = [0, 0]
	cc.g_Game.game_state = 0
    cc.g_Game.b_isAI = false
	cc.g_Game.game_data = -1
	cc.g_Game.seed = -1
}

var Net = require("FindGame_Net")
var CB  = require("cb")

cc.Class({
    extends: cc.Component,

    properties: {
         l_loading:cc.Label,
         s_loading:'',
         f_progress:0.0,
         b_isLoading:false,
    },

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start () {
		cc.director.setDisplayStats(false)

        var self=this;
        if(!cc.sys.isNative && cc.sys.isMobile){
            var cvs = this.node.getComponent(cc.Canvas);
            //cvs.fitWidth = true;
			cvs.fitWidth = true;
        }

        self.l_loading = cc.find("Canvas/l_loading");
        self.l_loading.getComponent(cc.Label).string=self.s_loading;
        self.startPreloading();
        this.initButtonHandler("Canvas/b_begin");
        this.initButtonHandler("Canvas/b_find");
		
		cc.g_Game.that = this
		cc.g_Game.initData([])

		CB.addEvent("event_ready", this.waitEnterGame);
		
    },
    startPreloading:function(){
        this.s_loading = "正在加载资源...";
        this.b_isLoading = true;
        var self = this;       
        cc.loader.loadResDir("FindGame/textures", function (err, assets) {
            //console.log(assets);
            self.onLoadComplete();
        });      
    },
    onLoadComplete:function(){
        console.log('onLoadComplete');
        this.b_isLoading = false;
        this.s_loading = "等待开始游戏...";
        cc.loader.onComplete = null;
    },
    initButtonHandler:function(btnPath){
        var btn = cc.find(btnPath);
        this.addClickEvent(btn,this.node,"FindGame_Start","onBtnClicked");        
    },
    addClickEvent:function(node,target,component,handler){
        console.log(component + ":" + handler);
        var eventHandler = new cc.Component.EventHandler();
        eventHandler.target = target;
        eventHandler.component = component;
        eventHandler.handler = handler;

        var clickEvents = node.getComponent(cc.Button).clickEvents;
        clickEvents.push(eventHandler);
    },    
    onBtnClicked:function(event){
        if(event.target.name == "b_begin"){
            console.log('b_begin');
            this.onGameBegin();
        }
        else if(event.target.name == "b_find")
        {
            console.log('b_find');
            this.onGameFindFriend();
        }
    }, 
    update: function (dt) {
        this.l_loading.getComponent(cc.Label).string = this.s_loading + ' ';
    },
    onGameBegin:function()
    {
        //初始化参数
        //跳转游戏场景,匹配AI用户进行对战
		cc.g_Game.userList = []
		cc.g_Game.b_isAI = true
        cc.director.loadScene("FindGame_Main");

    },
    onGameFindFriend:function()
    {
		if (cc.g_Game.ws != null)
			return;

        //跳转游戏场景,匹配真实用户进行对战
        console.log('onGameFindFriend');

		this.s_loading = "等待进入游戏...";
		
		var url = {"agreement":"ws","address":"47.96.144.235","port":"3300"};
		//var url = {"agreement":"ws","address":"115.239.196.59","port":"9000"};
		Net.CreateWebSocket(url)
    },

	waitEnterGame:function()
	{
		var self = cc.g_Game.that
		self.s_loading = "等待对方开始...";
	}
});
