module.exports = {
    //此文件外包方不可进行改动
    //服务器预留[0,1000)
    GAME_MSG_SERVER_PING: 101,         //服务器ping

    //游戏相关[1000,1200)
    GAME_MSG_ENTER_ROOM_REQ: 1000,      //请求进入房间
    GAME_MSG_ENTER_ROOM_ACK: 1001,      //进入房间结果
    GAME_MSG_USER_LIST_ACK: 1002,       //发送玩家列表
    GAME_MSG_RETWEET_DATA_REQ: 1003,    //转发数据
    GAME_MSG_USER_SCORE_REQ: 1004,      //跟新分数
    GAME_MSG_OVER_GAME_REQ: 1005,       //结束游戏
    GAME_MSG_NONSENSE_ACK: 1006,
}