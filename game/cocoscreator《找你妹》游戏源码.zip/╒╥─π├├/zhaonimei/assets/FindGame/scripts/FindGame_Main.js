var Net = require("FindGame_Net")
var CB  = require("cb")

var AI =  require("./ai/FindGame_AI")

function randomEx(max, min) 
{ 
	if (cc.g_Game.b_isAI)
		return Math.random()

	max = max || 1; min = min || 0; 
	cc.g_Game.seed = (cc.g_Game.seed * 9301 + 49297) % 233280; 
	var rnd = cc.g_Game.seed / 233280.0; 
	return min + rnd * (max - min); 
}

cc.Class({
    extends: cc.Component,

    properties: {
        canvasW:720,//屏幕宽度
        canvasH:1280,//屏幕宽度
        l_gameTime:cc.Label,
        n_gameResult:cc.Node,
        sv_item:cc.Node,
        l_gameEndTime:-1,//游戏每局时间
        isrun:false,//游戏是否在运行
        b_isAI:true,//是否是AI运行
        l_task:cc.Label,//任务指示栏
        l_myProgress:cc.Label,//本人任务完成进度
        l_oppositeProgress:cc.Label,//敌方任务完成进度
        i_myProgress:0,//本人任务完成进度数值
        i_oppositeProgress:0,//敌方任务完成数值
        s_itemData:null,//物品JOSN
        s_taskData:null,//任务JSON
        currentTaskId:null,//当前任务ID
        currentTaskName:'',//当前任务名字
        currentTaskClassID:'',//当前任务收集物品类别
        currentTaskClassName:'',//当前任务收集物品类别名字
        currentTaskNum:0,//当前任务收集物品当前数量
        currentTaskNeedNum:0,//当前任务收集物品当前需要数量
        gameRoundNum:5,//游戏回合数
        currentRound:1,//当前游戏回合
        currentProessUnit:0,//当前关卡进度计量单位
        s_lose:cc.Sprite,//输的图片
        s_win:cc.Sprite,//赢的图片
        s_deuce:cc.Sprite,
        i_myWin:0,//本人赢的回合
        i_oppositeWin:0,//敌方赢的回合
        l_myWin:cc.Label,//显示本人局分
        l_oppositeWin:cc.Label,//显示敌人局分
    },

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start () {
        var self=this;
        if(!cc.sys.isNative && cc.sys.isMobile){
            var cvs = this.node.getComponent(cc.Canvas);
            cvs.fitWidth = true;
        }
        //初始化游戏
        cc.game.setFrameRate(60);
        self.initGame();

		//CB.addEvent("event_score_opp", this.updateScoreOpp);
		CB.addEvent("event_select", this.selectItemAI);
    },
    initGame:function()
    {
        var self=this;
        self.isrun=true;

		cc.g_Game.that = this
		Math.seed = -1

        //初始化用户头像和用户名
        self.l_myName = cc.find("Canvas/l_myName");
        self.l_oppositeName = cc.find("Canvas/l_oppositeName");
        self.l_myName.getComponent(cc.Label).string='玩家1';
        self.l_oppositeName.getComponent(cc.Label).string='玩家2';

        //初始化局分

        self.l_myWin = cc.find("Canvas/l_myWin");
        self.l_oppositeWin = cc.find("Canvas/l_oppositeWin");

        //初始化游戏时间
        self.l_gameTime=cc.find("Canvas/l_gameTime");
        self.l_gameTime.getComponent(cc.Label).string='1:00';
        self.l_gameEndTime=Date.now()/1000 + 60*1;

        //初始化按钮
        this.initButtonHandler("Canvas/n_gameResult/b_again");
        this.initButtonHandler("Canvas/n_gameResult/b_return"); 
        
        
        //初始化结算窗口
        self.n_gameResult=cc.find("Canvas/n_gameResult");
        self.ongameResultClose();

        //初始化AI
        self.b_isAI=true;

        //初始化进度条和游戏初始数据

        //初始化任务指示栏和进度条
        self.l_task = cc.find("Canvas/l_task");
        self.l_myProgress = cc.find("Canvas/l_myProgress");
        self.l_oppositeProgress = cc.find("Canvas/l_oppositeProgress");
        self.l_task.getComponent(cc.Label).string='';
        self.i_myProgress=0;
        self.i_oppositeProgress=0;
        self.l_myProgress.getComponent(cc.Label).string='%'+self.i_myProgress;
        self.l_oppositeProgress.getComponent(cc.Label).string='%'+self.i_oppositeProgress;
        //读取物品配置表
        self.s_itemData=[
            {"itemId":"1","itemName":"大象","itemClass":"动物","itemClassID":"1","select":"0"},
            {"itemId":"2","itemName":"螃蟹","itemClass":"动物","itemClassID":"1","select":"0"},
            {"itemId":"3","itemName":"鲨鱼","itemClass":"动物","itemClassID":"1","select":"0"},
            {"itemId":"4","itemName":"兔子","itemClass":"动物","itemClassID":"1","select":"0"},
            {"itemId":"5","itemName":"熊","itemClass":"动物","itemClassID":"1","select":"0"},
            {"itemId":"6","itemName":"电车","itemClass":"交通工具","itemClassID":"2","select":"0"},
            {"itemId":"7","itemName":"飞机","itemClass":"交通工具","itemClassID":"2","select":"0"},
            {"itemId":"8","itemName":"警车","itemClass":"交通工具","itemClassID":"2","select":"0"},
            {"itemId":"9","itemName":"小货车","itemClass":"交通工具","itemClassID":"2","select":"0"},
            {"itemId":"10","itemName":"助力车","itemClass":"交通工具","itemClassID":"2","select":"0"},
            {"itemId":"11","itemName":"自行车","itemClass":"交通工具","itemClassID":"2","select":"0"},
            {"itemId":"12","itemName":"表1","itemClass":"时间","itemClassID":"3","select":"0"},
            {"itemId":"13","itemName":"表2","itemClass":"时间","itemClassID":"3","select":"0"},
            {"itemId":"14","itemName":"表3","itemClass":"时间","itemClassID":"3","select":"0"},
            {"itemId":"15","itemName":"钟1","itemClass":"时间","itemClassID":"3","select":"0"},
            {"itemId":"16","itemName":"钟2","itemClass":"时间","itemClassID":"3","select":"0"},
            {"itemId":"17","itemName":"放大镜","itemClass":"文具","itemClassID":"4","select":"0"},
            {"itemId":"18","itemName":"计算器","itemClass":"文具","itemClassID":"4","select":"0"},
            {"itemId":"19","itemName":"剪刀","itemClass":"文具","itemClassID":"4","select":"0"},
            {"itemId":"20","itemName":"铅笔","itemClass":"文具","itemClassID":"4","select":"0"},
            {"itemId":"21","itemName":"直尺","itemClass":"文具","itemClassID":"4","select":"0"},
            {"itemId":"22","itemName":"仙人掌1","itemClass":"植物","itemClassID":"5","select":"0"},
            {"itemId":"23","itemName":"仙人掌2","itemClass":"植物","itemClassID":"5","select":"0"},
            {"itemId":"24","itemName":"植物1","itemClass":"植物","itemClassID":"5","select":"0"},
            {"itemId":"25","itemName":"植物2","itemClass":"植物","itemClassID":"5","select":"0"},
            {"itemId":"26","itemName":"植物3","itemClass":"植物","itemClassID":"5","select":"0"},
        ]

        console.log(self.s_itemData[0].itemName);
        //读取任务配置表
        self.s_taskData=[
            {"taskId":"1","taskName":"动物*3","task1ClassID":"1","task1ClassName":"动物","task1Num":"3"},
            {"taskId":"2","taskName":"交通工具*3","task1ClassID":"2","task1ClassName":"交通工具","task1Num":"3"},
            {"taskId":"3","taskName":"时间*3","task1ClassID":"3","task1ClassName":"时间","task1Num":"3"},
            {"taskId":"4","taskName":"文具*5","task1ClassID":"4","task1ClassName":"文具","task1Num":"5"},
            {"taskId":"5","taskName":"植物*3","task1ClassID":"5","task1ClassName":"植物","task1Num":"3"},
            {"taskId":"6","taskName":"植物*1","task1ClassID":"5","task1ClassName":"植物","task1Num":"3"},
        ]


        
        console.log(self.s_taskData[0].taskName);     
        //初始化输赢
        self.s_lose = cc.find("Canvas/n_gameResult/s_lose").getComponent(cc.Sprite);
        self.s_win = cc.find("Canvas/n_gameResult/s_win").getComponent(cc.Sprite);
        self.s_deuce = cc.find("Canvas/n_gameResult/s_deuce").getComponent(cc.Sprite);

        self.s_lose.node.active=false;
        self.s_win.node.active=false;
        self.s_deuce.node.active=false;


        //初始化回合
        self.gameRoundNum=5;
        self.currentRound=1;
        self.initRound();
    },

	updateScoreOpp(score)
	{
		let self = cc.g_Game.that
		self.i_oppositeProgress = score
		cc.log("updateScoreOpp",score);
	},

    initRound:function()
    {
        var self=this;
        //初始化任务
        var i_length=self.s_taskData.length;
		if (cc.g_Game.seed == -1)
		{
			cc.g_Game.seed = cc.g_Game.game_data;
		}		
		console.log("initround", cc.g_Game.seed);
        var i_rand=Math.floor(randomEx()*i_length);//随机种子
        console.log(i_rand);
        console.log(self.s_taskData[i_rand].taskName);
        self.currentTaskId=self.s_taskData[i_rand].taskId;
        self.currentTaskName=self.s_taskData[i_rand].taskName;
        self.currentTaskClassID=self.s_taskData[i_rand].task1ClassID;
        self.currentTaskClassName=self.s_taskData[i_rand].task1ClassName;
        self.currentTaskNum=self.s_taskData[i_rand].task1Num;
        self.currentProessUnit=Math.ceil(100/self.currentTaskNum);
        console.log('currentProessUnit'+self.currentProessUnit);
        self.l_task.getComponent(cc.Label).string=self.currentTaskClassName+'x'+self.currentTaskNum;

        //初始化物品列表
        for (var i = 0; i < self.s_itemData.length; ++i) {
            self.s_itemData[i].select=0;
        }
                
        self.s_itemData.sort(function() {
            return (0.5-randomEx());
        })

        var data = self.getRoundData(self.s_itemData.length,self.s_itemData);
        self.sv_item=cc.find("Canvas/sv_item");
        self.sv_item.getComponent('tableview2').Type=1;
        self.sv_item.getComponent('tableview2').initTableView(data.length, { array: data, target: self });

		//Net.MsgUserScoreReq(cc.g_Game.userId, 0)
    },
    updateItemState:function()
    {

        var self=this;
        var data = self.getRoundData(self.s_itemData.length,self.s_itemData);
        self.sv_item=cc.find("Canvas/sv_item");
        self.sv_item.getComponent('tableview2').Type=1;
        self.sv_item.getComponent('tableview2').initTableView(data.length, { array: data, target: self });
    },
    getRoundData: function (num,s_itemData) {
        var array = [];
        for (var i = 0; i < num; ++i) {
            var obj = {};
            obj.num=i;
            obj.itemId = s_itemData[i].itemId;
            obj.itemName = s_itemData[i].itemName;
            obj.itemClass = s_itemData[i].itemClass;
            obj.itemClassID = s_itemData[i].itemClassID;
            obj.select = s_itemData[i].select;
            array.push(obj);
        }
        return array;
    },
    selectItem:function(num)
    {
        //console.log(this.s_itemData[num].itemName);
        //this.addTips('选中'+this.s_itemData[num].itemName);
        console.log(this.s_itemData[num].itemClassID);
        console.log(this.currentTaskClassID);
        if(this.s_itemData[num].itemClassID==this.currentTaskClassID)
        {
            if(this.s_itemData[num].select==0)
            {
                //物品选中状态
                this.addTips('选中'+this.s_itemData[num].itemName);
                //改变选中物品状态
                this.s_itemData[num].select=1;
                this.updateItemState();
                //改变当前任务完成度
                this.currentTaskNum=this.currentTaskNum-1;
                this.i_myProgress=this.i_myProgress+this.currentProessUnit;

				//Net.MsgUserScoreReq(cc.g_Game.userId, this.currentProessUnit)

				//转发结果
				Net.MsgRetweetData(Net.MID_SELECT_RET, num)
            }
        }
        else
        {
            //this.addTips('没选对');
        }

        //更新游戏进度
        console.log('currentTaskNum'+this.currentTaskNum);
        if(this.currentTaskNum<=0)
        {
              //开始新回合
              //this.addTips('开始新回合');
              this.addImageTips('FindGame/textures/dialoground');
              this.l_gameEndTime=Date.now()/1000 + 60*1;
              this.currentRound=this.currentRound+1;
              //计算本回合输赢
              if(this.i_myProgress>this.i_oppositeProgress)
              {
                  this.i_myWin=this.i_myWin+1;
              }
              else if(this.i_myProgress<this.i_oppositeProgress)
              {
                  this.i_oppositeWin=this.i_oppositeWin+1;
              } 
              this.i_myProgress=0;
              this.i_oppositeProgress=0;
            
              //重置关卡
              this.initRound();            
        } 
    },
    RoundTimeOut:function()
    {
		//开始新回合
        //this.addTips('开始新回合');
        this.addImageTips('FindGame/textures/dialoground');
		this.l_gameEndTime=Date.now()/1000 + 60*1;
		this.currentRound=this.currentRound+1;

		//计算本回合输赢
		if(this.i_myProgress>this.i_oppositeProgress)
		{
			  this.i_myWin=this.i_myWin+1;
		}
		else if(this.i_myProgress<this.i_oppositeProgress)
		{
			  this.i_oppositeWin=this.i_oppositeWin+1;
		}

		this.i_myProgress=0;
		this.i_oppositeProgress=0; 
		//重置关卡
		this.initRound(); 
    },
    initButtonHandler:function(btnPath){
        var btn = cc.find(btnPath);
        this.addClickEvent(btn,this.node,"FindGame_Main","onBtnClicked");        
    },
    onBtnClicked:function(event){
		if(event.target.name == "b_again"){
			console.log('b_again');

			if(!cc.g_Game.b_isAI)
			{
				//cc.g_Game.b_isAgain = true
				Net.CloseWebSocket();
				cc.director.loadScene("FindGame_Start");
			}
			else
			{
				this.ongameResultClose();
				this.initGame();
			}
			
		}
		else if(event.target.name == "b_return")
		{
			console.log('b_return');

			if(!cc.g_Game.b_isAI)
			{
				//cc.g_Game.b_isAgain = true
				Net.CloseWebSocket();
			}
			cc.director.loadScene("FindGame_Start");
		}
   
    },
    addClickEvent:function(node,target,component,handler){
        console.log(component + ":" + handler);
        var eventHandler = new cc.Component.EventHandler();
        eventHandler.target = target;
        eventHandler.component = component;
        eventHandler.handler = handler;

        var clickEvents = node.getComponent(cc.Button).clickEvents;
        clickEvents.push(eventHandler);
    },  
    addTips:function(tipsinfo)
    {
        var self=this;
        var tips = new cc.Node().addComponent(cc.Label); 
        tips.string = tipsinfo;
        tips.fontSize=40;

        var color = new cc.Color(0,0,0);
        tips.node.color = color;

        tips.node.parent = this.node;
        tips.node.setPosition(0,0);
        var action = cc.moveTo(1,cc.p(tips.node.x,tips.node.y+50));
        //tips.node.runAction(action);
        tips.node.runAction(cc.sequence(action, cc.callFunc(function(){
                tips.destroy();
        }))) 
        //tips.destroy();
    },
    addImageTips:function(imageUrl)
    {
        var self=this;
        var tips = new cc.Node().addComponent(cc.Sprite); 
        var textures=cc.loader.getRes(imageUrl);
        console.log(textures);
        tips.getComponent(cc.Sprite).spriteFrame=new cc.SpriteFrame(textures);    


        tips.node.parent = this.node;
        tips.node.setPosition(0,0);
        var action = cc.moveTo(1,cc.p(tips.node.x,tips.node.y+200));
        tips.node.runAction(cc.sequence(action, cc.callFunc(function(){
                tips.destroy();
        }))) 
    },
    ongameResultOpen()
    {
        //停止游戏
        this.isrun=false;
        this.n_gameResult.active=true;
        console.log('i_myProgress'+this.i_myProgress);
        console.log('i_oppositeProgress'+this.i_oppositeProgress);
        if(this.i_myWin>this.i_oppositeWin)
        {
            this.s_win.node.active=true; 
        }
        else if (this.i_myWin==this.i_oppositeWin)
        {
            this.s_deuce.node.active=true; 
        }
        else
        {
            this.s_lose.node.active=true; 
        }     

		Net.OverGame();
    },
    ongameResultClose()
    {
        this.n_gameResult.active=false;
    },

    selectItemAI:function(num)
    {
		var self = cc.g_Game.that;

        //console.log(this.s_itemData[num].itemName);
        //this.addTips('选中'+this.s_itemData[num].itemName);
        console.log(self.s_itemData[num].itemClassID);
        console.log(self.currentTaskClassID);
        if(self.s_itemData[num].itemClassID==self.currentTaskClassID)
        {
            if(self.s_itemData[num].select==0)
            {
                //物品选中状态
                self.addTips('对方选中'+self.s_itemData[num].itemName);
                //改变选中物品状态
                self.s_itemData[num].select=1;
                self.updateItemState();
                //改变当前任务完成度
                self.currentTaskNum=self.currentTaskNum-1;
                self.i_oppositeProgress=self.i_oppositeProgress+self.currentProessUnit;
            }
        }
        else
        {
            //self.addTips('对方没选对');
        }   

        //更新游戏进度
        console.log('currentTaskNum'+self.currentTaskNum);
        if(self.currentTaskNum<=0)
        {
              //开始新回合
              //self.addTips('开始新回合');
              this.addImageTips('FindGame/textures/dialoground');

              self.l_gameEndTime=Date.now()/1000 + 60*1;
              self.currentRound=self.currentRound+1;
              //计算本回合输赢
              if(self.i_myProgress>self.i_oppositeProgress)
              {
                  self.i_myWin=self.i_myWin+1;
              }
              else
              {
                  self.i_oppositeWin=self.i_oppositeWin+1;
              } 
              self.i_myProgress=0;
              self.i_oppositeProgress=0;
            
              //重置关卡
              self.initRound();            
        } 
    },

	runAI()
	{
		AI.runAI();
	},		

	updateEndTime()
	{
		if(!this.isrun)
			return

		//更新游戏时间
		if(this.l_gameEndTime> 0){
			var lastTime = this.l_gameEndTime - Date.now() / 1000;
			if(lastTime < 0){

				//this.ongameResultOpen();
				this.RoundTimeOut();
				//this.l_gameEndTime = -1;
			}

			if(this.currentRound>this.gameRoundNum)
			{
				this.ongameResultOpen();
				this.l_gameEndTime = -1;
			}
			
			var m = Math.floor(lastTime / 60);
			var s = Math.ceil(lastTime - m*60);
			
			var str = "";
			if(m > 0){
				str += m + ":"; 
			}
			
			this.l_gameTime.getComponent(cc.Label).string = str + s;
		}

		//更新任务完成情况和进度
		this.l_task.getComponent(cc.Label).string=this.currentTaskClassName+'x'+this.currentTaskNum;
		this.l_myProgress.getComponent(cc.Label).string='%'+this.i_myProgress;
        this.l_oppositeProgress.getComponent(cc.Label).string='%'+this.i_oppositeProgress;   
        this.l_myWin.getComponent(cc.Label).string='局分:'+this.i_myWin+'/'+this.gameRoundNum;
        this.l_oppositeWin.getComponent(cc.Label).string='局分:'+this.i_oppositeWin+'/'+this.gameRoundNum;
	},

    update (dt) {
		this.updateEndTime();
		this.runAI();
    },
});
