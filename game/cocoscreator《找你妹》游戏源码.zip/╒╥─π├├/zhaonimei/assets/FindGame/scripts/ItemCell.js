cc.Class({
    extends: require('viewCell'),
    properties: {
        _num:null,
        _data:null,  
        img_item:cc.Sprite,    
        s_selected:cc.Sprite,
    },

    // use this for initialization
    onLoad: function () {

    },
    init: function (index, data, group) {
        this._init(data.array[index], data.target, group);
    },
    _init: function (data, target, group) {//当pagevie模式下group参数才有效
        this._target = target;
        var self=this;        
        this._data=data;
        this.node.active=true;
        if (!data) {
            this.node.active=false;
            return;
        }    
        var textures=cc.loader.getRes('FindGame/textures/'+(data.itemId));
        //console.log(textures);
        this.img_item.getComponent(cc.Sprite).spriteFrame=new cc.SpriteFrame(textures);    
        this._num=data.num;        
        console.log(typeof (data.select));
        if(data.select=='0')
        {
            this.s_selected.getComponent(cc.Sprite).node.active=false;
        }
        else if(data.select=='1')
        {
            this.s_selected.getComponent(cc.Sprite).node.active=true;
        }
    },
    clicked: function () {
        //this.s_selected.getComponent(cc.Sprite).node.active=true;
        this._target.selectItem(this._data.num);
    }
});
