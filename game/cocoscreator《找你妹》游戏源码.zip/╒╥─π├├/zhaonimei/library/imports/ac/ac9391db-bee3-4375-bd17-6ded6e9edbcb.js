"use strict";
cc._RF.push(module, 'ac939HbvuNDdb0Xbe1untvL', 'Layer');
// FindGame/scripts/Layer.js

'use strict';

cc.Class({
    extends: cc.Component,

    properties: {},

    // use this for initialization
    onLoad: function onLoad() {
        this.node.on(cc.Node.EventType.TOUCH_START, function (event) {
            event.stopPropagation();
            console.log('TOUCH_STARTLayer');
        }, this.node);
    }

    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});

cc._RF.pop();