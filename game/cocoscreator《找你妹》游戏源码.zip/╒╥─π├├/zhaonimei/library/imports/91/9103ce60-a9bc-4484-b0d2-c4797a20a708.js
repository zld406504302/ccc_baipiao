"use strict";
cc._RF.push(module, '9103c5gqbxEhLDSxHl6IKcI', 'FindGame_AI');
// FindGame/scripts/ai/FindGame_AI.js

"use strict";

var AI = function () {

	function AI() {}

	AI.runAI = function () {
		if (!cc.g_Game.b_isAI) return;

		var that = cc.g_Game.that;

		if (that.l_gameEndTime < 0) return;

		var i_rand = Math.floor(Math.random() * 100 + 1); //随机种子
		//%3的概率出手
		if (i_rand < 2) {
			var num = Math.floor(Math.random() * that.s_itemData.length); //随机选择
			//console.log('num'+num);
			that.selectItemAI(num);
		}
	};
	return AI;
}();

module.exports = AI;

cc._RF.pop();