
cc.Class({
    extends: cc.Component,

    properties: {
        m_Toggle:[cc.Toggle],
        m_BottomItemPrefab:cc.Prefab,
        m_BottomItemParent:[cc.Node],
        m_SubWeaponContent:cc.Node,
        m_SubWeaponPrefab:cc.Prefab,
    },

    // LIFE-CYCLE CALLBACKS:

    onLoad () {
        window.gBottom = this;
        
        this.m_BottomItem = new Array();
        for (var i = 0; i < this.m_BottomItemParent.length; i++) {
            var node = cc.instantiate( this.m_BottomItemPrefab);
            this.m_BottomItemParent[i].addChild(node);
            node = node.getComponent("BottomItem");
            node.init(i);
            this.m_BottomItem[i] = node;
        }

        this.m_subWeaponItem = new Array();
        for (var i = 0; i < 6; i++) {
            var node = cc.instantiate( this.m_SubWeaponPrefab);
            this.m_SubWeaponContent.addChild(node);
            this.m_subWeaponItem = node.getComponent("subWeaponItem");
            this.m_subWeaponItem.init(i+1);
            
            if( i > 1){
                this.m_subWeaponItem.setDisable()
            }
        }


    },

    start () {

    },

    Reset(){

    },
    Play(){

    },
    MoveOut:function(){
        this.node.runAction(cc.moveTo(0.5,cc.v2(0,-894)).easing(cc.easeBackOut()));
        for (var i = 0; i < this.m_Toggle.length; i++) {
            this.m_Toggle[i].isChecked = false;
            
        }
    },
    MoveIn:function(){

        this.node.runAction(cc.moveTo(0.5,cc.v2(0,-725)).easing(cc.easeBackIn()));

    },

    onClickUpLevel:function(target,data){
        if( target.isChecked ){
            gAirPlane.MoveTo(0.3,cc.v2(0,-36))
        }else{
            gAirPlane.MoveTo(0.3,cc.v2(0,-385))
        }
        if( target.node.name = 'Weapon'){

        }else if( target.node.name = 'SubWeapon' ){

        }else if( target.node.name = 'Gold' ){

        }
        this.onUpdate();
    },
    onUpdate:function(){
        for (var i = 0; i < this.m_BottomItem.length; i++) {
            this.m_BottomItem[i].onUpdate();
        }
    },
    // update (dt) {},
});
