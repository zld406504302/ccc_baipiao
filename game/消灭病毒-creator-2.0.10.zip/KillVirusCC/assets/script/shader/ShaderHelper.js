let CustomMaterial = require("CustomMaterial");
cc.Class({
    extends: cc.Component,

    properties: {
    },

    // LIFE-CYCLE CALLBACKS:

    onLoad () {
        this.m_color = new cc.Color(109,255,109,255);
        this.sprite = this.getComponent(cc.Sprite);
        this.applyShader();
    },

    start () {

    },

    update(dt) {

        if (this._shaderObject && this._shaderObject.update) {
            this._shaderObject.update(this.sprite, this.material, dt);
        }
    },
    setColor:function(color){
        this.m_color = color;
    },
    applyShader() {
        this._shaderObject = CustomMaterial.getShader('wave');
        let sprite = this.sprite;
        let params = this._shaderObject.params;
        let defines = this._shaderObject.defines;
        let material = sprite.getMaterial(this._shaderObject.name);
        
        if (!material) {
            material = new CustomMaterial(this._shaderObject.name, params, defines || []);
            sprite.setMaterial(this._shaderObject.name, material);
        }
        this.material = material;

        sprite.activateMaterial(this._shaderObject.name);

        //设置Shader参数初值
        if (params) {
            params.forEach((item) => {
                if (item.defaultValue !== undefined) {
                    material.setParamValue(item.name, item.defaultValue);
                }
            });
        }

        if (this._shaderObject.start) {
            this._shaderObject.start(sprite, material);
        }
    },
    // update (dt) {},
});
