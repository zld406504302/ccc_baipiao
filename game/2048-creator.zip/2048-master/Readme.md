# 2048 by Cocos Creator

![img](./arts/61B9DA5E-3E13-4958-9FF1-2A75D41313E9.png)