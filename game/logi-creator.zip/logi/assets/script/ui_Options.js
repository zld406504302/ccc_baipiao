cc.Class({
    extends: cc.Component,

    properties: {
        btn_menu: cc.Node,
        btn_music: cc.Node,
        btn_sound: cc.Node,
    },

    onLoad() {
        this.node.onenter = this.onenter.bind(this)
    },

    onenter(is_menu, enterMode, func) {
        this.enterMode = enterMode
        this.btn_menu.active = !is_menu
        this.restart_func = func
        this.updateDisplay()
    },

    updateDisplay() {
        this.btn_music.getChildByName("on").active = gs.isMusicOpen()
        this.btn_music.getChildByName("off").active = !gs.isMusicOpen()
        this.btn_sound.getChildByName("on").active = gs.isSoundOpen()
        this.btn_sound.getChildByName("off").active = !gs.isSoundOpen()
    },

    onClose() {
        UIMgr.close(this)
    },

    onShare() {
        cc.log('share')
        wx.shareAppMessage({
            title: '史上最烧脑的游戏'
        })
    },

    onMusic(e) {
        gs.setMusicOpen(!gs.isMusicOpen())
        this.updateDisplay()
    },

    onSound() {
        gs.setSoundOpen(!gs.isSoundOpen())
        this.updateDisplay()
    },

    onMenu() {
        if (this.enterMode == 'custom') {
            sceneManager.pop()
        } else {
            sceneManager.show("Menu")
        }
        UIMgr.close(this)
    },

    onRestart() {
        this.restart_func()
        UIMgr.close(this)
    },

    onContinue() {
        UIMgr.close(this)
    },
});