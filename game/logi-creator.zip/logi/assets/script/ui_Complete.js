
cc.Class({
    extends: cc.Component,

    properties: {
        lb_time: cc.Node,
        lb_try: cc.Node,
    },


    onLoad () {
        this.node.onenter = this.onenter.bind(this)
    },

    onenter(time, tryCount, enterMode, restart_func) {
        this.restart_func = restart_func
        this.enterMode = enterMode
        this.lb_try.getComponent(cc.Label).string = tryCount
        time = Math.floor(time / 1000)

        if (time > 3600) {
            let min = time / 3600
            let sec = time % 3600
            this.lb_time.getComponent(cc.Label).string = min + "分" + sec + "秒"
        } else {
            this.lb_time.getComponent(cc.Label).string = time + "秒"
        }
    },

    on_Menu() {
        sceneManager.show("Menu")
        UIMgr.close(this)
    },
    on_Replay() {
        if (this.enterMode == 'custom') {
            this.restart_func()
        } else {
            gs.gotoLevel(window.currentEnterLevel)
        }
        UIMgr.close(this)
    },
    on_Next() {
        if (this.enterMode == 'custom') {
            sceneManager.pop()
        } else {
            gs.gotoLevel(window.currentEnterLevel+1)
        }
        UIMgr.close(this)
    },
    // update (dt) {},
});
