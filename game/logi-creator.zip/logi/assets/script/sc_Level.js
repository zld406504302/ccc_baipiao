cc.Class({
    extends: cc.Component,

    properties: {
        temp: cc.Node,
        per: cc.Node,
        pages: [cc.Node],
        left: cc.Node,
        right: cc.Node,
        pageView: cc.Node,
    },

    onLoad() {
        this.node.onenter = this.onenter.bind(this)
        this.temp.active = false
        this.levels = []
        for (let x = 0; x < this.pages.length; x++) {
            let parent = this.pages[x];

            for (let i = 1; i <= 25; i++) {
                if ((x * 25 + i) < level_data.length) {
                    let lv = cc.instantiate(this.temp)
                    lv.active = true
                    lv.parent = parent
                    lv.name = "" + (i + x * 25)
                    lv.getChildByName("value").getComponent(cc.Label).string = i + x * 25
                    this.levels.push(lv)
                }
            }
            let layout = parent.getComponent(cc.Layout)
            if (layout) {
                layout.updateLayout()
            }
        }
    },

    onenter() {
        if (window.wxRank) {
            wxRank.showBanner(false)
        }
        if (window.clubBtn) {
            window.clubBtn.hide()
        }
        this.per.getComponent(cc.Label).string = gs.currentLevel() + "/" + (level_data.length - 1)
        for (let i = 1; i <= this.levels.length; i++) {
            let lv = this.levels[i - 1]
            if (i <= gs.currentLevel()) {
                lv.getChildByName("dot").active = false
                lv.getChildByName("value").active = true
                lv.getChildByName("value").getComponent(cc.Label).string = i
            } else {
                lv.getChildByName("dot").active = true
                lv.getChildByName("value").active = false
            }
        }
        this.onPage()
    },

    onPage() {
        let pageview = this.pageView.getComponent(cc.PageView)
        let idx = pageview.getCurrentPageIndex()
        this.left.active = idx != 0;
        this.right.active = idx != pageview.getPages().length - 1;
    },
    onNext() {
        let pageview = this.pageView.getComponent(cc.PageView)
        pageview.setCurrentPageIndex(pageview.getCurrentPageIndex() + 1)
    },
    onPrev() {
        let pageview = this.pageView.getComponent(cc.PageView)
        pageview.setCurrentPageIndex(pageview.getCurrentPageIndex() - 1)
    },

    onClickBack() {
        sceneManager.show("Menu")
    },

    onClickLevel(ev) {
        let clicked = parseInt(ev.target.name)
        gs.gotoLevel(clicked)
    },

    on_hot() {
        sceneManager.show("Select", 'mostPlay')
    },

    on_rect() {
        sceneManager.show("Select", 'recently')
    },

    on_my() {
        sceneManager.show("Select", 'my')
    },

    on_editor() {
        sceneManager.show("Editor")
    },
});