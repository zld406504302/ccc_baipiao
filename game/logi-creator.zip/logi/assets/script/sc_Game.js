var Block = {
    Origin: 0,
    Destination: 1,
    Blue: 2,
    Red: 3,
    Green: 4,
    Gear: 5,
    Box: 6,
    BoxTemp: 7,
    BoxUp: 8,
    BoxDown: 9,
    BoxLeft: 10,
    BoxRight: 11,
    Triangle: 12,
    Hole: 13,
}

var T = 0
var D = 2
var L = 3
var R = 1

var DirMap = []
DirMap[Block.Blue] = []
DirMap[Block.Blue][1] = [
    [D, R],
    [R, D],
    [T, L],
    [L, T]
]
DirMap[Block.Blue][2] = [
    [D, L],
    [R, T],
    [T, R],
    [L, D]
]
DirMap[Block.Blue][3] = DirMap[Block.Blue][1]
DirMap[Block.Blue][4] = DirMap[Block.Blue][2]
DirMap[Block.Green] = []
DirMap[Block.Green][1] = [
    [D, R],
    [R, D],
    [T, D],
    [L, R]
]
DirMap[Block.Green][2] = [
    [D, L],
    [R, L],
    [T, D],
    [L, D]
]
DirMap[Block.Green][3] = [
    [D, T],
    [R, L],
    [T, L],
    [L, T]
]
DirMap[Block.Green][4] = [
    [D, T],
    [R, T],
    [T, R],
    [L, R]
]
DirMap[Block.Triangle] = []
DirMap[Block.Triangle][1] = [
    [D, D],
    [R, R],
    [L, T],
    [T, L]
]
DirMap[Block.Triangle][2] = [
    [D, D],
    [R, T],
    [L, L],
    [T, R]
]
DirMap[Block.Triangle][3] = [
    [D, R],
    [R, D],
    [L, L],
    [T, T]
]
DirMap[Block.Triangle][4] = [
    [D, L],
    [R, R],
    [L, D],
    [T, T]
]
DirMap[Block.Box] = []
DirMap[Block.Box][1] = [
    [T, T],
    [L, L],
    [R, R],
    [D, D]
]
DirMap[Block.Box][2] = DirMap[Block.Box][1]
DirMap[Block.Box][3] = DirMap[Block.Box][1]
DirMap[Block.Box][4] = DirMap[Block.Box][1]

DirMap[Block.Red] = DirMap[Block.Blue]
DirMap[Block.Gear] = DirMap[Block.Blue]
DirMap[Block.BoxTemp] = DirMap[Block.Box]
DirMap[Block.BoxUp] = DirMap[Block.Box]
DirMap[Block.BoxDown] = DirMap[Block.Box]
DirMap[Block.BoxLeft] = DirMap[Block.Box]
DirMap[Block.BoxRight] = DirMap[Block.Box]

var EventMap = []
EventMap[Block.Origin] = { touch: "fire" }
EventMap[Block.Destination] = { collision: "win" }
EventMap[Block.Blue] = { touch: "rotate", }
EventMap[Block.Red] = { touch: "rotate", collision: "killself", }
EventMap[Block.Green] = { touch: "rotate", }
EventMap[Block.Gear] = { collision: "rotate", }
EventMap[Block.Box] = {}
EventMap[Block.BoxTemp] = { collision: "killself", }
EventMap[Block.BoxUp] = { collision: "moveup", }
EventMap[Block.BoxDown] = { collision: "movedown", }
EventMap[Block.BoxLeft] = { collision: "moveleft", }
EventMap[Block.BoxRight] = { collision: "moveright", }
EventMap[Block.Triangle] = {}
EventMap[Block.Hole] = {}


cc.Class({
    extends: cc.Component,

    properties: {
        blocks: [cc.Node],
        ball: cc.Node,
        dot: cc.Node,
        lb_level: cc.Node,
        snd_failed: {
            default: null,
            type: cc.AudioClip
        },
        btn_options: cc.Node,
        btn_back: cc.Node,
        btn_tip: cc.Node,
    },

    onLoad() {
        this.node.onenter = this.onenter.bind(this)

        this.mapWidth = 5
        this.mapHeight = 11
        this.blockSize = cc.size(100, 100)

        this.node.on(cc.Node.EventType.TOUCH_START, this.onTouch, this)
        this.node.on(cc.Node.EventType.TOUCH_MOVE, this.onTouch, this)
    },
    saveMap() {
        this.saved_map = []
        this.collisioned_items = []
        for (let i = 0; i < this.items.length; i++) {
            let item = this.items[i]
            if (EventMap[item.type].touch) {
                this.saved_map[item.index] = item.rotation
            }
        }
        for (let i = 0; i < this.mapWidth * this.mapHeight; i++) {
            if (this.saved_map[i]) {
                let cfg = gs.ID2BlockMap[this.data.init[i]]
                let r = cfg.r || 1
                if (cfg.t == Block.Blue || cfg.t == Block.Red) {
                    if (this.saved_map[i] > 2)
                        this.saved_map[i] -= 2
                }
                /*if (this.saved_map[i] == r) {
                    this.saved_map[i] = 0
                }*/
            } else {
                this.saved_map[i] = 0
            }
        }
    },
    filterTips(item) {
        if (this.collisioned_items) {
            this.collisioned_items[item.index] = 1
        }
    },
    buildTipsArray() {
        let s = []
        for (let i = 0; i < this.saved_map.length; i++) {
            if (!this.collisioned_items[i]) {
                this.saved_map[i] = 0
            }
        }
        return this.saved_map

    },
    buildMapTips() {
        let s = ""
        for (let i = 0; i < this.saved_map.length; i++) {
            if (!this.collisioned_items[i]) {
                this.saved_map[i] = 0
            }
            s += "" + this.saved_map[i] + "_"
        }
        return s
    },

    reStart() {
        let tryCount = this.tryCount
        let startTime = this.startTime
        this.onenter(this.data, this.enterMode)
        this.tryCount = tryCount
        this.startTime = startTime
    },

    onenter(data, enterMode) {
        if (window.clubBtn) {
            window.clubBtn.hide()
        }

        this.startTime = new Date().getTime()
        this.tryCount = 0

        this.trigger_mark = []
        for (let i = 0; i < this.mapWidth * this.mapHeight; i++) {
            this.trigger_mark[i] = 0
        }

        this.is_start = false
        this.touch_enable = true
        this.ball.active = false

        if (gs.isFirstPlay()) {
            UIMgr.show("Help")
        }

        this.enterMode = enterMode
        if (enterMode == "level") {
            this.lb_level.active = true
            this.lb_level.getComponent(cc.Label).string = `第${data.enterLevel}关`
            
            this.btn_options.active = true
            this.btn_tip.active = true
            this.btn_back.active = false
            if(!data.converted) {
                data = {
                    init: gs.levelFromString(data.init),
                    tip : gs.levelFromString(data.tip),
                    converted : true,
                    _id: data._id,
                    enterLevel: data.enterLevel,
                    maxLevel: data.maxLevel,
                }
            }
        } else if (enterMode == "editor") {
            this.lb_level.active = true
            this.lb_level.getComponent(cc.Label).string = "编辑测试"
            this.btn_options.active = false
            this.btn_tip.active = false
            this.btn_back.active = true
        } else if (enterMode == 'custom') {
            this.lb_level.active = true
            this.lb_level.getComponent(cc.Label).string = "关卡ID:"+data.myid
            this.btn_options.active = true
            this.btn_tip.active = true
            this.btn_back.active = false
            if(!data.converted) {
                data = {
                    init: gs.levelFromString(data.init),
                    tip : gs.levelFromString(data.tip),
                    converted : true,
                    _id: data._id,
                    myid: data.myid,
                }
            }
        } else {
            this.lb_level.active = false
        }

        this.data = data //level_data[window.currentEnterLevel]
        this.buildMap()
    },

    onClickOptions() {
        UIMgr.show("Options", false, this.enterMode, ()=> {
            this.reStart()
        })
    },
    onClickBack() {
        sceneManager.pop()
    },

    clearTips() {
        if (this.tips_map) {
            for (let i = 0; i < this.tips_map.length; i++) {
                if (this.tips_map[i] != null) {
                    this.tips_map[i].node.parent = null
                }
            }
            this.tips_map = null
        }
    },

    doTip() {
        let tip = this.data.tip //level_tips[currentEnterLevel]
        this.clearTips()

        this.tips_map = []
        for (let i = 0; i < tip.length; i++) {
            if (tip[i] != 0) {
                if (this.items_map[i].rotation != tip[i]) {
                    this.tips_map[i] = cc.instantiate(this.items_map[i].node).getComponent("BlockScript")
                    this.tips_map[i].node.opacity = 100
                    this.tips_map[i].node.parent = this.items_map[i].node.parent
                    this.tips_map[i].node.zIndex = 1
                    this.tips_map[i].type = this.items_map[i].type
                    this.setBlockRotation(this.tips_map[i], tip[i], true)
                }
            }
        }
    },

    onClickTip() {
        if (!this.touch_enable) {
            return
        }

        if (wxRank && wxRank.ad_tip && wxRank.ad_tip.ok) {
            UIMgr.show("Msg", "观看广告视频，获得一次提示机会", (confirm) => {
                if (confirm) {
                    wxRank.ad_tip.show((ok)=> {
                        if (ok) {
                            UIMgr.show("Msg", "观看视频完成，您获得了提示机会", ()=> {
                                this.doTip()
                            }, "ok")

                        } else {
                            UIMgr.show("Msg", "您取消了播放，没有获得奖励", null, "ok")
                        }
                    })
                }
            })
        } else {
            UIMgr.show("Msg", "分享游戏给朋友，获得一次提示机会", (ok) => {
                if (ok) {
                    this.doTip()
                    if (cc.sys.browserType == cc.sys.BROWSER_TYPE_WECHAT_GAME) {
                        wx.shareAppMessage({
                            title: '这一关过不去了求大神帮助'
                        })
                    }
                }
            })
        }

    },

    testInTouch: function(cell, pos) {
        return (Math.abs(cell.x - pos.x) < this.blockSize.width / 2 && Math.abs(cell.y - pos.y) < this.blockSize.height / 2)
    },

    getTouchCell: function(pos) {
        for (let i = 0; i < this.items.length; i++) {
            let it = this.items[i].node
            if (it && this.testInTouch(it, pos)) {
                return this.items[i]
            }
        }

        return null
    },

    onTouch(ev) {
        if (!this.touch_enable) {
            return
        }
        if (ev.type == cc.Node.EventType.TOUCH_START) {
            let wpos = ev.getLocation()
            let pos = this.node.convertToNodeSpaceAR(wpos)

            let item = this.getTouchCell(pos)

            if (item != null) {
                this.emitBlockEvent(item, 'touch')
                if (this.tips_map && this.tips_map[item.index]) {
                    let r = item.rotation
                    if (item.type == Block.Blue || item.type == Block.Red) {
                        if (r > 2) {
                            r -= 2
                        }
                    }
                    if (r == this.tips_map[item.index].rotation) {
                        this.tips_map[item.index].node.parent = null
                        this.tips_map[item.index] = null
                    }
                }
            }

        }
    },

    emitBlockEvent(item, evt) {
        let eventMap = EventMap[item.type]
        let eventType = eventMap[evt]
        if (eventType == null) {
            return
        }

        switch (eventType) {
            case "fire":
                this.onFire(item);
                break;
            case "win":
                this.onGameWin(item);
                break;
            case "rotate":
                this.nextBlockRotation(item);
                break;
            case "killself":
                this.onKillBlock(item);
                break;
            case "moveup":
                this.onMoveBlock(item, 0, 1);
                break;
            case "movedown":
                this.onMoveBlock(item, 0, -1);
                break;
            case "moveleft":
                this.onMoveBlock(item, -1, 0);
                break;
            case "moveright":
                this.onMoveBlock(item, 1, 0);
                break;
        }

    },

    onMoveBlock(item, dx, dy) {
        item.gx += dx
        item.gy += dy
        item.node.runAction(
            cc.moveTo(0.4, this.toPos(cc.v2(item.gx, item.gy)))
        )
    },

    onKillBlock(item) {
        let index = this.items.indexOf(item)
        cc.log(index)
        this.items.splice(index, 1)
        this.items_map[item.index] = null

        item.node.runAction(cc.sequence(
            cc.delayTime(0.5),
            cc.removeSelf()
        ))
    },

    onGameLose() {
        cc.log("lose")
        this.is_start = false
        this.ball.active = false
        gs.playMp3(this.snd_failed)

        this.node.runAction(cc.sequence(
            cc.delayTime(1),
            cc.callFunc(() => {
                this.reStart()
            })
        ))
    },

    onGameWinCB() {
        let now = new Date().getTime()

        if (this.enterMode == 'level') {
            if (this.data.enterLevel + 1 >= this.data.maxLevel) {
                sceneManager.show("Menu")
            } else {
                UIMgr.show("Complete", now - this.startTime, this.tryCount, this.enterMode)
            }
        } else if (this.enterMode == 'editor') {
            let ok = this.data.ok
            let tip = this.buildTipsArray()
            sceneManager.pop()
            ok(tip)
        } else if (this.enterMode == 'custom') {
            wxRank.call("level_mark", {key:"passed", level:this.data._id}, 
                (ok, data)=>{
                    UIMgr.show("Complete", now - this.startTime, this.tryCount, this.enterMode, ()=>{
                        this.reStart()
                    })
                })
        }
    },

    onGameWin(item) {
        this.is_start = false
        this.ball.active = false

        if (this.enterMode == 'level') {
            gs.setCurrentLevelPass(this.data.enterLevel)

            if (window.wxRank) {
                window.wxRank.submit(gs.currentLevel() - 1)
            }
        }

        // var xhr = new XMLHttpRequest()
        // xhr.open('GET', 'http://192.168.1.107:8888?level=' + currentEnterLevel + '&d=' + this.buildMapTips(), true)
        // xhr.send(null)

        let ani = item.node.getComponent(cc.Animation)
        ani.on('finished', this.onGameWinCB, this);
    },

    nextBlockRotation(item) {
        if (item.rotation + 1 == 5) {
            this.setBlockRotation(item, 1)
        } else {
            this.setBlockRotation(item, item.rotation + 1)
        }
    },

    setBlockRotation(item, rotation, now) {
        item.rotation = rotation || 1

        let dest = (gs.RotationOffsetMap[item.type] || 0) + 90 * (rotation - 1)
        if (now) {
            item.node.rotation = dest
        } else {
            item.node.runAction(cc.rotateTo(0.3, dest))
        }
    },

    clearMap() {
        this.clearTips()

        if (this.items == null) {
            return
        }

        for (let i = 0; i < this.items.length; i++) {
            this.items[i].node.parent = null
        }
    },

    buildMap() {
        this.clearMap()

        let w = this.mapWidth
        let h = this.mapHeight

        this.items = []
        this.items_map = []

        for (let x = 0; x < w; x++) {
            for (let y = 0; y < h; y++) {
                let index = x + (h - y - 1) * w
                let id = this.data.init[index]
                if (id) {
                    let cfg = gs.ID2BlockMap[id]
                    let temp = cc.instantiate(this.blocks[cfg.t])
                    temp.active = true
                    temp.parent = this.node
                    let pos = this.toPos(x, y)
                    temp.setPosition(pos)
                    temp.zIndex = 2
                    let bs = temp.getComponent("BlockScript")
                    bs.type = cfg.t
                    bs.index = index
                    this.setBlockRotation(bs, cfg.r, true)
                        // bs.rotation = cfg.r
                    bs.gx = x
                    bs.gy = y
                    this.items.push(bs)
                    this.items_map[index] = bs
                }
            }
        }
    },

    onFire(item) {
        this.saveMap()

        this.ball.active = true
        this.ball.x = item.node.x
        this.ball.y = item.node.y

        this.touch_enable = false

        this.is_start = true
        this.timer = 0
        this.inteval = 0.2
        this.dotTimer = 0
        this.dotInteval = this.inteval / 3

        this.curPos = cc.v2(item.node.x, item.node.y)
        this.curGird = cc.v2(item.gx, item.gy)

        if (item.rotation == 1)  {
            this.curDir = cc.v2(0, 1)
        } else if(item.rotation == 2) {
            this.curDir = cc.v2(1, 0)
        } else if(item.rotation == 3) {
            this.curDir = cc.v2(0, -1)
        } else if(item.rotation == 4) {
            this.curDir = cc.v2(-1, 0)
        }


        this.nextGird = this.curGird.add(this.curDir)
        this.nextPos = this.toPos(this.nextGird)

        this.tryCount ++
    },

    toPos(x, y) {
        if (y == undefined || y == null) {
            y = x.y
            x = x.x
        }
        return cc.v2(-(this.mapWidth - 1) * this.blockSize.width / 2 + x * this.blockSize.width, -(this.mapHeight - 1) * this.blockSize.height / 2 + y * this.blockSize.height)
    },

    isOutScreen(ball) {
        let bottom = -cc.winSize.height / 2
        let top = bottom + cc.winSize.height
        let left = -cc.winSize.width / 2
        let right = left + cc.winSize.width
        return ball.x < left - 50 || ball.y < bottom - 50 || ball.x > right + 50 || ball.y > top + 50
    },

    makeDot() {
        let dot = cc.instantiate(this.dot)
        dot.position = this.ball.position
        dot.parent = this.node
        dot.active = true
        dot.runAction(cc.sequence(
            cc.fadeOut(0.8),
            cc.removeSelf()
        ))
    },

    update(dt) {
        if (!this.is_start) {
            return
        }

        this.timer += dt
        this.dotTimer += dt
        let ratio = Math.min(this.timer / this.inteval, 1)

        if (ratio > 1) {
            ratio = 1
        }

        if (this.dotTimer >= this.dotInteval) {
            this.dotTimer = 0
            this.makeDot()
        }

        this.ball.position = this.curPos.lerp(this.nextPos, ratio)

        if (this.isOutScreen(this.ball)) {
            this.onGameLose()
            return
        }

        if (ratio == 1) {
            this.timer = 0
            let item = this.getTouchCell(this.ball.position)
            this.curPos = this.ball.position
            this.curGird = this.nextGird

            if (item) {
                this.filterTips(item)
                if (item.audio) {
                    gs.playMp3(item.audio)
                }
                this.curDir = this.onCrossBlock(item)
                this.emitBlockEvent(item, "collision")
            }

            if (this.curDir) {
                this.nextGird = this.nextGird.add(this.curDir)
                this.nextPos = this.toPos(this.nextGird)
            }
        }
    },

    onCrossBlock(item) {

        if (item.type == Block.Hole) {
            for (let i = 0; i < this.items.length; i++) {
                let item1 = this.items[i]
                if (item1.type == item.type && item1 != item) {
                    this.nextGird = cc.v2(item1.gx, item1.gy)
                    this.curPos = this.toPos(item1.gx, item1.gy)
                    this.ball.position = this.curPos
                    return this.curDir
                }
            }
        } else {
            let ani = item.node.getComponent(cc.Animation)
            if (ani) {
                ani.play()
            }
        }

        let blockDirCvt = DirMap[item.type]
        if (!blockDirCvt) {
            return this.curDir
        }

        let dirCvt = blockDirCvt[item.rotation]

        let d = null
        if (this.curDir.x == 0) {
            if (this.curDir.y == 1) {
                d = D
            } else if (this.curDir.y == -1) {
                d = T
            }
        } else if (this.curDir.y == 0) {
            if (this.curDir.x == 1) {
                d = L
            } else if (this.curDir.x == -1) {
                d = R
            }
        }

        for (let i = 0; i < dirCvt.length; i++) {
            if (dirCvt[i][0] == d) {
                d = dirCvt[i][1]
                break
            }
        }

        if (d == T) {
            return cc.v2(0, 1)
        } else if (d == D) {
            return cc.v2(0, -1)
        } else if (d == R) {
            return cc.v2(1, 0)
        } else if (d == L) {
            return cc.v2(-1, 0)
        }
    }
});