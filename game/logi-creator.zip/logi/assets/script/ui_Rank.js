cc.Class({
    extends: cc.Component,

    properties: {
        scroll: cc.ScrollView,
        temp: cc.Node,
        content: cc.Node,

        sprites: [cc.SpriteFrame],

    },

    onLoad() {
        this.node.onenter = this.onenter.bind(this)
    },

    onenter() {
        this.updateRank()
    },

    updateRank() {
        gs.loading(true)
        wxRank.rankList((ok, list) => {
            gs.loading(false)
            if (ok) {
                this.content.removeAllChildren()
                for (let i = 0; i < list.length; i++) {
                    this.addOne(i, list[i].profile, list[i].score)
                }
            } else {
                UIMgr.show("Msg", "网络不给力，请重试", (isOk) => {
                    if (isOk) {
                        this.updateRank()
                    } else {
                        this.onClickClose()
                    }
                }, "ok")
            }
        })
    },

    onClickClose() {
        UIMgr.close(this)
    },

    addOne(index, profile, sc) {
        let node = cc.instantiate(this.temp)
        node.parent = this.content
        node.active = true
        node.getChildByName("lv").getComponent(cc.Label).string = "第" + sc + "关"

        if (index < this.sprites.length) {
            node.getChildByName("index_lb").active = false
            node.getChildByName("index_sp").active = true
            node.getChildByName("index_sp").getComponent(cc.Sprite).spriteFrame = this.sprites[index]
        } else {
            node.getChildByName("index_sp").active = false
            node.getChildByName("index_lb").active = true
            node.getChildByName("index_lb").getComponent(cc.Label).string = index + 1
        }

        if (profile) {

            node.getChildByName("name").getComponent(cc.Label).string = profile.nickName
            let image = wx.createImage();
            image.onload = () => {
                let texture = new cc.Texture2D();
                texture.initWithElement(image);
                texture.handleLoadedTexture();
                node.getChildByName("icon").getComponent(cc.Sprite).spriteFrame = new cc.SpriteFrame(texture);
            };
            image.src = profile.avatarUrl;
        } else {
            node.getChildByName("name").getComponent(cc.Label).string = "未授权玩家"
        }
    }

    // update (dt) {},
});