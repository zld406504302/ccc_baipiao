let Effects = {
    "NoEffect": { show: (layer) => { }, hide: (layer, finish) => { finish() }, },
    "MoveFromLeft": {
        show: (layer) => {
            layer.node.setPosition(cc.p(-cc.winSize.width * 1.5, 0))
            layer.node.runAction(cc.moveTo(0.2, cc.p(0, 0)))
        },

        hide: (layer, finish) => {
            layer.node.runAction(cc.sequence(
                cc.moveTo(0.2, cc.p(-cc.winSize.width * 1.5, 0)),
                cc.callFunc(finish),
            ))
        },
    },
    "MoveFromRight": {
        show: (layer) => {
            layer.node.setPosition(cc.p(cc.winSize.width * 1.5, 0))
            layer.node.runAction(cc.moveTo(0.2, cc.p(0, 0)))
        },

        hide: (layer, finish) => {
            layer.node.runAction(cc.sequence(
                cc.moveTo(0.2, cc.p(cc.winSize.width * 1.5, 0)),
                cc.callFunc(finish),
            ))
        },
    },
    "MoveFromTop": {
        show: (layer) => {
            layer.node.setPosition(cc.p(0, cc.winSize.height * 1.5))
            layer.node.runAction(cc.moveTo(0.2, cc.p(0, 0)))
        },

        hide: (layer, finish) => {
            layer.node.runAction(cc.sequence(
                cc.moveTo(0.2, cc.p(0, cc.winSize.height * 1.5)),
                cc.callFunc(finish),
            ))
        },
    },
    "MoveFromBottom": {
        show: (layer) => {
            layer.node.setPosition(cc.p(0, -cc.winSize.height * 1.5))
            layer.node.runAction(cc.moveTo(0.2, cc.p(0, 0)))
        },

        hide: (layer, finish) => {
            layer.node.runAction(cc.sequence(
                cc.moveTo(0.2, cc.p(0, -cc.winSize.height * 1.5)),
                cc.callFunc(finish),
            ))
        },
    }
}

cc.Class({
    extends: cc.Component,

    properties: {
        uiParent: cc.Node,
        mask: cc.Node, // 半透明屏蔽层
        tipTempNode: cc.Node,

        model: { // for MVC
            visible: false,
            get: function () {
                return this._model
            }
        }
    },

    onLoad: function () {
        window.UIMgr = this

        this._model = {
            prefabs: {},
            cache: {}, // layers cache
            stack: [], // layers stack
            lockCount: 0, // 等待服务器回调事件屏蔽层的相关计数器

            closeEvents: {},
        }

        if (this.waiting) {
            this.waiting.active = false
        }

        // let preloads = ["MessageBox"]
        // preloads.forEach((name) => {
        //     this.syncLoad(name)
        // })
    },

    checkIsLoaded: function (key) {
        return !!this.model.prefabs[key]
    },

    syncLoad: function (key, cb) {
        cb = cb || function () { }

        if (this.model.prefabs[key]) {
            cb()
        } else {
            // client.model.ready = false
            cc.loader.loadRes("prefabs/ui_" + key, (err, prefab) => {
                // client.model.ready = true
                if (err) {
                    return cc.log(err)
                }
                this.model.prefabs[key] = prefab
                cb()
            });
        }
    },

    // usage: UIMgr.show({multi:true, effect:'MoveFromLeft', name:"MessageBox"}, ...)
    // usage: UIMgr.show("MessageBox", ...)
    show: function (name) { // params: multi, effect
        if (!name) return;

        let args = Array.prototype.slice.call(arguments)
        let params = {}
        args.splice(0, 1)

        if (typeof (name) != 'string') {
            params = name || {}
            name = params.name
            if (!name) return;
        }

        this.syncLoad(name, () => {
            cc.log('show ', name)
            let setupLayer = (layer) => {
                let count = this.model.stack.push(layer)
                layer.node.zIndex = count * 2 + 2
                layer.node.parent = this.uiParent
                layer.effect = params['effect'] ? Effects[params['effect']] : Effects['NoEffect']
                layer.effect.show(layer)
                if (layer.node.onenter) {
                    layer.node.onenter.apply(null, args)
                }
            }

            if (params.multi || this.model.cache[name] == null) {
                let layer = {
                    name: name,
                    node: cc.instantiate(this.model.prefabs[name]),
                }
                this.model.cache[name] = layer
                setupLayer(layer)
            } else {
                let layer = this.bringToTop(name)
                if (layer) { // 单个实例且此实例已经在显示中
                    if (layer.node.onenter) {
                        layer.node.onenter.apply(null, args)
                    }
                } else {
                    layer = this.model.cache[name]
                    setupLayer(layer)
                }
            }

            this.resetMask()
        })
    },

    bringToTop: function (name) {
        for (let i = 0; i < this.model.stack.length; i++) {
            let layer = this.model.stack[i]
            if (layer.name == name) {
                this.model.stack.splice(i, 1)
                this.model.stack.push(layer)
                return layer
            }
        }
        return null
    },

    topName: function () {
        return this.model.stack.length == 0 ? "" : this.model.stack[this.model.stack.length - 1].name
    },

    topNode: function () {
        return this.model.stack.length == 0 ? "" : this.model.stack[this.model.stack.length - 1].node
    },

    pop: function () {
        if (this.model.stack.length > 0) {
            this.close(this.model.stack[this.model.stack.length - 1].node)
        }
    },

    addCloseEvents: function (name, cb) {
        if (this.model.closeEvents[name]) {
            this.model.closeEvents[name].push(cb)
        } else {
            this.model.closeEvents[name] = [cb]
        }
    },

    close: function (node, effect) {
        if (node instanceof cc.Component) {
            node = node.node
        } else if (typeof (node) == 'string') {
            if (this.model.cache[node]) {
                node = this.model.cache[node].node
            } else {
                return
            }
        }

        let found = null
        for (let i = 0; i < this.model.stack.length; i++) {
            let layer = this.model.stack[i]
            if (layer.node == node) {
                this.model.stack.splice(i, 1)[0]
                found = layer
                break
            }
        }

        if (!found) {
            // cc.log("not found", node)
            return
        }
        //ut.playMp3("click_button")
        let ff = Effects[effect] || found.effect

        ff.hide(found, () => {
            found.node.parent = null
            this.resetMask()

            let cbs = this.model.closeEvents[found.name] || []
            this.model.closeEvents[found.name] = null

            cbs.forEach((cb) => {
                cb()
            })
        })
    },

    clear: function () {
        this.model.stack.forEach((layer) => {
            layer.node.parent = null
        })
        this.model.stack.length = 0
        this.model.cache = {}
        this.model.closeEvents = {}

        this.resetMask()
    },

    resetMask: function () {
        let count = this.model.stack.length
        this.mask.active = (count != 0)
        this.mask.zIndex = count * 2 + 1

        if (window.wxRank) {
            wxRank.showBanner(count != 0) 
        }
    },

    showTip: function (text) {
        let node = cc.instantiate(this.tipTempNode)
        node.active = true;
        node.parent = this.tipTempNode.parent
        node.getChildByName('label').getComponent(cc.Label).string = text;

        node.runAction(cc.sequence(
            cc.moveBy(0.5, cc.v2(0, -100)),
            cc.delayTime(2),
            // cc.fadeOut(0.5),
            cc.moveBy(0.5, cc.v2(0, 100)),
            cc.callFunc(() => {
                node.parent = null
            })
        ))
    },

    showLoading: function(data){
        this.show("Loading", data)
    },

    dismissLoading: function(){
        this.close("Loading")
    },

    delayDismissLoading: function(){
        if (this.topName() == "Loading"){
            this.topNode().getComponent("Loading").delayClose()
        }
    },
});
