cc.Class({
    extends: cc.Component,

    properties: {
        bgm: {
            default: null,
            type: cc.AudioClip
        }
    },

    onLoad() {
        this.node.onenter = this.onenter.bind(this)
    },

    onenter(first) {
        gs.playBgMp3(this.bgm)

        if (window.clubBtn) {
            window.clubBtn.show()
        }

        if (window.wxRank) {
            if (first) {
                window.wxRank.auth()
            }
        }
    },

    onClick1() {
        sceneManager.show('Level')
    },

    onClickOpt() {
        UIMgr.show("Options", true)
    },

    onClickRank() {
        UIMgr.show("Rank")
    }

});