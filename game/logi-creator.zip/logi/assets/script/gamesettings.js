var Block = {
    Origin: 0,
    Destination: 1,
    Blue: 2,
    Red: 3,
    Green: 4,
    Gear: 5,
    Box: 6,
    BoxTemp: 7,
    BoxUp: 8,
    BoxDown: 9,
    BoxLeft: 10,
    BoxRight: 11,
    Triangle: 12,
    Hole: 13,
}

var RotationOffsetMap = []
RotationOffsetMap[Block.Triangle] = 180
RotationOffsetMap[Block.Blue] = 45
RotationOffsetMap[Block.Red] = 45
RotationOffsetMap[Block.Green] = 45
RotationOffsetMap[Block.Gear] = 45

var ID2BlockMap = []

ID2BlockMap[1] = { t: Block.Origin,r:1 }
ID2BlockMap[2] = { t: Block.Destination }
ID2BlockMap[3] = { t: Block.Green, r: 1 }
ID2BlockMap[4] = { t: Block.Green, r: 2 }
ID2BlockMap[5] = { t: Block.Green, r: 4 }
ID2BlockMap[6] = { t: Block.Green, r: 3 }
ID2BlockMap[7] = { t: Block.Gear, r: 1 }
ID2BlockMap[8] = { t: Block.Gear, r: 2 }
ID2BlockMap[9] = { t: Block.Blue, r: 2 }
ID2BlockMap[10] = { t: Block.Blue, r: 1 }
ID2BlockMap[11] = { t: Block.Red, r: 2 }
ID2BlockMap[12] = { t: Block.Red, r: 1 }
ID2BlockMap[13] = { t: Block.Box, }
ID2BlockMap[14] = { t: Block.BoxTemp, }
ID2BlockMap[15] = { t: Block.BoxRight, }
ID2BlockMap[16] = { t: Block.BoxUp, }
ID2BlockMap[17] = { t: Block.BoxDown, }
ID2BlockMap[18] = { t: Block.BoxLeft, }
ID2BlockMap[19] = { t: Block.Triangle, r: 1 }
ID2BlockMap[20] = { t: Block.Triangle, r: 4 }
ID2BlockMap[21] = { t: Block.Triangle, r: 2 }
ID2BlockMap[22] = { t: Block.Triangle, r: 3 }
ID2BlockMap[23] = { t: Block.Hole, }
ID2BlockMap[24] = { t: Block.Origin,r:2 }
ID2BlockMap[25] = { t: Block.Origin,r:3 }
ID2BlockMap[26] = { t: Block.Origin,r:4 }

class _GS {
  
    share(msg, query) {
        wx.shareAppMessage({
            title: msg,
            query: query 
        })
    }

    levelToString(arr) {
        let s = ""
        for (let i = 0; i < arr.length; i++) {
            let v = arr[i]
            if (v < 10) {
                s += v;
            } else {
                s += String.fromCharCode(65 + v - 10);
            }
        }
        return s
    }

    levelFromString(s) {
        let arr = []
        for (let i = 0; i < s.length; i++) {
            arr[i] = s.charCodeAt(i)

            if (arr[i] >= 65) {
                arr[i] = arr[i] - 65 + 10
            } else if (arr[i] >= 48) {
                arr[i] -= 48
            }
        }
        return arr
    }

    showMsg(msg, cb) {
        UIMgr.show("Msg", msg, cb)
    }

    loading(show) {
        if (show) {
            UIMgr.show("Loading")
        } else {
            UIMgr.close("Loading")
        }
    }

    gotoCustomLevel(lv_data) {
        sceneManager.push("Game", lv_data, "custom")
    }

    gotoLevel(lv) {
        if (lv <= gs.currentLevel()) {
            window.currentEnterLevel = lv
            let data = {
                init: level_data[lv].init,
                tip: level_data[lv].tip,
                maxLevel: level_data.length - 1,
                enterLevel: lv,
            }
            sceneManager.forceShow("Game", data, "level")
        }
    }

    setCurrentLevelPass(lv) {
        if (lv == gs.currentLevel()) {
            cc.sys.localStorage.setItem("level", lv + 1)
        }
    }

    currentLevel() {
        let level = cc.sys.localStorage.getItem('level')
        if (!level) {
            level = 1
            cc.sys.localStorage.setItem("level", level)
        }
        return level
    }

    getTipCount() {
        let level = cc.sys.localStorage.getItem('tip')
        if (!level) {
            level = 1
            cc.sys.localStorage.setItem("tip", level)
        }
        return level
    }

    useOneTip() {
        if (this.getTipCount() > 0) {
            cc.sys.localStorage.setItem("tip", this.getTipCount() - 1)
            return true
        } else {
            return false
        }
    }

    playMp3(file) {
        if (file && gs.isSoundOpen()) {
            cc.audioEngine.play(file, false, 1)
        }
    }

    playBgMp3(file) {
        if (gs.isMusicOpen()) {

            if (this._curBGM && this._curBGM == file && this.__bgID)
                return

            if (this.__bgID != null) {
                cc.audioEngine.stop(this.__bgID)
                this.__bgID = null
            }

            this._curBGM = file
            this.__bgID = cc.audioEngine.play(file, true, 1)
        } else {
            this._curBGM = file
        }
    }

    isFirstPlay() {
        let s = cc.sys.localStorage.getItem('isFirstPlay')
        if (s === null || s === "") {
            cc.sys.localStorage.setItem('isFirstPlay', "false")
            return true
        }
        return false
    }

    isMusicOpen() {
        let s = cc.sys.localStorage.getItem('is_bg_on')
        return (s === null || s === 'true' || s === true || s === "")
    }

    isSoundOpen() {
        let s = cc.sys.localStorage.getItem('is_sound_on')
        return (s === null || s === 'true' || s === true || s === "")
    }

    setMusicOpen(open) {
        cc.sys.localStorage.setItem('is_bg_on', open)
        if (!open) {
            if (this.__bgID != null) {
                cc.audioEngine.stop(this.__bgID)
                this.__bgID = null
            }
        } else {
            this.playBgMp3(this._curBGM)
        }
    }

    setSoundOpen(open) {
        cc.sys.localStorage.setItem('is_sound_on', open)
    }
}


window.gs = new _GS()
window.gs.Block = Block
window.gs.RotationOffsetMap = RotationOffsetMap 
window.gs.ID2BlockMap = ID2BlockMap   
