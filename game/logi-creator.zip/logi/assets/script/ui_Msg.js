cc.Class({
    extends: cc.Component,

    properties: {
        lb_content: cc.Label,
        btn_ok: cc.Node,
        btn_cancel: cc.Node,
    },

    // LIFE-CYCLE CALLBACKS:

    onLoad() {
        this.node.onenter = this.onenter.bind(this)
    },

    onenter(msg, cb, type) {
        this.cb = cb
        this.lb_content.string = msg

        if (type) {
            let arr = type.split("|")
            this.btn_ok.active = false
            this.btn_cancel.active = false

            for (let i = 0; i < arr.length; i++) {
                if (arr[i] == "ok") {
                    this.btn_ok.active = true
                } else if (arr[i] == 'cancel') {
                    this.btn_cancel = true
                }
            }
        } else {
            this.btn_ok.active = true
            this.btn_cancel.active = true 
        }
    },

    onClickOK() {
        let cb = this.cb
        UIMgr.close(this)
        if (cb) {
            cb(true)
        }
    },
    onClickClose() {
        let cb = this.cb
        UIMgr.close(this)
        if (cb) {
            cb(false)
        }
    }
});