cc.Class({
    extends: cc.Component,

    properties: {
        graphics: cc.Graphics,
        bottom: cc.Node,
        content: cc.Node,

        trash: cc.Node,
    },

    onLoad() {
        this.node.onenter = this.onenter.bind(this)
        this.makeGrid()

        this.block_temp = []
        let child = this.content.children
        for (let i = 0; i < child.length; i++) {
            let c = child[i].getChildByName("temp")
            c.blockType = gs.Block[c.parent.name]
            this.block_temp[c.blockType] = c
        }
    },

    onenter(lv_data) {
        if (window.clubBtn) {
            window.clubBtn.hide()
        }

        this.blocks = []
        this.trash.active = false
        this.isOK = false
        this.lv_data = null
        if (lv_data) {
            this.lv_data = lv_data
            this.build()
        }
    },

    build() {
        let data = gs.levelFromString(this.lv_data.init)

        let w = this.mapWidth
        let h = this.mapHeight

        for (let x = 0; x < w; x++) {
            for (let y = 0; y < h; y++) {
                let index = x + y* w
                let id = data[index]
                if (id) {
                    let cfg = gs.ID2BlockMap[id]
                    let temp = cc.instantiate(this.block_temp[cfg.t])
                    temp.active = true
                    temp.parent = this.graphics.node
                    temp.blockType = cfg.t
                    this.setBlockRotation(temp, cfg.r, true)
                    this.placeAt(temp, cc.v2(x,y), true)
                }
            }
        }
    },


    onClickOptions() {
        sceneManager.show("Level")
    },
    onClickPlay() {
        let arr = this.toArray()
        if (this.checkMap(arr)) {
            let data = { 
                init: arr, 
                ok: (tipArr)=>{
                    this.isOK = true
                    this.tip = gs.levelToString(tipArr);
                    // cc.log(this.tip)
                    UIMgr.show("Msg", "测试成功，是否立即发布", (ok)=> {
                        if (ok) {
                            this.onClickSave()
                        }
                    })
                }
            }
            sceneManager.push('Game', data, 'editor')
        }
    },
    onClickSave() {
        if (!this.isOK) {
            UIMgr.show("Msg", "您必须先测试成功，确保您创作的关卡能通关才能发布。", null, "ok")
            return
        }
        let str = gs.levelToString(this.toArray())
        cc.log(str)
        cc.log(this.tip)

        let arg = {
            tip:this.tip, 
            init:str,
        }

        if (this.lv_data) {
            arg.level = this.lv_data._id
        }

        if (wxRank.ad_publish && wxRank.ad_publish.ok) {

            UIMgr.show("Msg", "观看一个视频，才能发布关卡。", (confirm)=> {
                if (!confirm) {
                    return
                }

                wxRank.ad_publish.show((isEnd)=> {
                    if (!isEnd) {
                        UIMgr.show("Msg", "视频观看未完成，不能发布关卡")
                        return
                    }
                    this.doPublish(arg);
                })

            })
        } else {
            this.doPublish(arg);
        }
    },

    doPublish(arg) {
        wxRank.call('level_publish', arg, (ok, data)=>{
            if (!ok) {
                UIMgr.show("Msg", "网络不给力，请重试", null, "ok")
                return
            }

            if (data.status == 1) {
                UIMgr.show("Msg", data.msg)
                return
            }

            cc.log(data.msg)

            UIMgr.show("Msg", "发布成功，是否立即分享给朋友？", (isShare)=>{
                if (isShare) {
                    gs.share("我创作了一个游戏关卡，快来玩玩鸭。", "sharetype=mylevel&id="+data.id)
                }
                sceneManager.show("Level")
            })
        })

    },

    blockToID(block) {
        let r = block.blockRotation
        if (block.blockType == gs.Block.Gear || block.blockType == gs.Block.Red || block.blockType == gs.Block.Blue) {
            if (r > 2) {
                r -= 2
            }
        }
        for (let i = 1; i < gs.ID2BlockMap.length; i++) {
            let v = gs.ID2BlockMap[i]
            if (v.t == block.blockType) {
                if (v.r) {
                    if (v.r == r) {
                        return i
                    }
                } else {
                    return i
                }
            }
        }
        return null
    },

    checkMap(arr) {
        let typeCnt = []
        for (let i=0; i<15;i++) {
            typeCnt[i]= 0
        }
        for (let i = 0; i < arr.length; i++) {
            if (arr[i] != 0) {
                typeCnt[gs.ID2BlockMap[arr[i]].t] ++
            }
        }

        let msg = ""
        if (typeCnt[gs.Block.Destination] == 0) {
            msg = "缺少终点"
        } else if (typeCnt[gs.Block.Origin] == 0) {
            msg = "缺少起点"
        } else if (typeCnt[gs.Block.Hole] != 2 && typeCnt[gs.Block.Hole] != 0) {
            msg = "黑洞个数不能为"+typeCnt[gs.Block.Hole]+"个"
        } else {
            return true
        }

        UIMgr.show("Msg", msg, null, "ok")
    },

    toArray() {
        let map = []
        for (let i = 0; i < this.mapHeight * this.mapWidth; i++) {
            map[i] = 0
        }

        for (let i = 0; i < this.blocks.length; i++) {
            let block = this.blocks[i]
            map[block.index] = this.blockToID(block)
        }

        return map
    },

    makeGrid() {
        this.mapWidth = 5
        this.mapHeight = 11
        this.blockSize = cc.size(80, 80)

        let h = this.mapHeight * this.blockSize.height
        let w = this.mapWidth * this.blockSize.width

        let cx = 0
        let cy = 200

        let sx = cx - w / 2
        let sy = cy + h / 2

        this.startX = sx
        this.startY = sy

        for (let x = 0; x <= this.mapWidth; x++) {
            this.graphics.moveTo(sx + x * this.blockSize.width, sy)
            this.graphics.lineTo(sx + x * this.blockSize.width, sy - h)
        }
        for (let y = 0; y <= this.mapHeight; y++) {
            this.graphics.moveTo(sx, sy - y * this.blockSize.height)
            this.graphics.lineTo(sx + w, sy - y * this.blockSize.height)
        }
        this.graphics.stroke()

        this.graphics.node.on(cc.Node.EventType.TOUCH_START, this.onTouch, this)
        this.graphics.node.on(cc.Node.EventType.TOUCH_MOVE, this.onTouch, this)
        this.graphics.node.on(cc.Node.EventType.TOUCH_END, this.onTouch, this)
    },

    onTouch(ev) {
        let wpos = ev.getLocation()
        let pos = this.graphics.node.convertToNodeSpaceAR(wpos)
        this.isOK = false

        if (ev.type == cc.Node.EventType.TOUCH_START) {
            let ok = false
            let pos1 = this.content.convertToNodeSpaceAR(wpos)
            let child = this.content.children
            for (let i = 0; i < child.length; i++) {
                let c = child[i]
                if (pos1.fuzzyEquals(c.position, 60)) {
                    let select = c.getChildByName("temp")

                    let one = cc.instantiate(select)
                    one.blockType = select.blockType
                    one.parent = this.graphics.node
                    one.blockRotation = 1
                    one.position = pos

                    this.dragBlock = one
                    ok = true
                    break
                }
            }

            this.touchStartPos = pos
            this.isMoved = false

            if (!ok) {
                let grid = this.toGrid(pos.x, pos.y);
                this.dragBlock = this.getAtGrid(grid)
            }
        } else if (ev.type == cc.Node.EventType.TOUCH_MOVE) {
            this.isMoved = true
            this.trash.active = true
            if (this.dragBlock) {
                this.dragBlock.position = this.dragBlock.position.add(pos.sub(this.lastPos))
            }
        } else if (ev.type == cc.Node.EventType.TOUCH_END) {
            this.trash.active = false

            if (!this.isMoved) {
                if (this.dragBlock && !this.dragBlock.gx && !this.dragBlock.gy) {
                    this.dragBlock.removeFromParent()
                    this.dragBlock = null
                    return
                }

                if (this.posInMap(pos) && pos.fuzzyEquals(this.touchStartPos, 2)) {
                    let block = this.getAtGrid(this.toGrid(pos))
                    this.rotateBlock(block)
                }
            } else if (this.dragBlock) {
                if (this.posInMap(pos) && pos.fuzzyEquals(this.touchStartPos, 2)) {
                    let block = this.getAtGrid(this.toGrid(pos))
                    this.rotateBlock(block)
                    return
                }

                if (this.posInMap(pos)) {
                    let grid = this.toGrid(pos.x, pos.y)
                    this.placeAt(this.dragBlock, grid, false)
                } else {
                    if (!this.dragBlock.gx && !this.dragBlock.gy) {
                        this.dragBlock.removeFromParent()
                        this.dragBlock = null
                    } else if (pos.fuzzyEquals(this.trash.position, 50)) {
                        this.removeBlock(this.dragBlock)
                    } else {
                        this.dragBlock.position = this.toPos(this.dragBlock.gx, this.dragBlock.gy)
                    }
                }
            }
        }
        this.lastPos = pos
    },

    rotateBlock(block) {
        if (!(
            block.blockType == gs.Block.Green ||
            block.blockType == gs.Block.Gear || 
            block.blockType == gs.Block.Red || 
            block.blockType == gs.Block.Blue ||
            block.blockType == gs.Block.Triangle ||
            block.blockType == gs.Block.Origin
        )) {
            return
        }

        this.nextBlockRotation(block)
    },

    removeBlock(block) {
        let i = this.blocks.indexOf(block)
        this.blocks.splice(i, 1)
        block.removeFromParent()
    },

    nextBlockRotation(block) {
        if (block.blockRotation + 1 == 5) {
            this.setBlockRotation(block, 1)
        } else {
            this.setBlockRotation(block, block.blockRotation + 1)
        }
    },

    setBlockRotation(block, rotation, now) {
        block.blockRotation = rotation || 1

        let dest = (gs.RotationOffsetMap[block.blockType] || 0) + 90 * (rotation - 1)
        if (now) {
            block.rotation = dest
        } else {
            block.runAction(cc.rotateTo(0.3, dest))
        }
    },

    posInMap(pos) {
        return (pos.x >= this.startX &&
            pos.x <= this.startX + this.blockSize.width * this.mapWidth &&
            pos.y <= this.startY &&
            pos.y >= this.startY - this.blockSize.height * this.mapHeight)
    },

    placeAt(block, grid, remove) {
        let old = this.getAtGrid(grid)
        if (old == block) {
            block.position = this.toPos(grid)
            return
        }

        if (old) {
            if (remove) {
                this.removeBlock(old)
            } else {
                if (block.gx && block.gy) {
                    old.gx = block.gx
                    old.gy = block.gy
                    old.index = block.index
                    old.position = this.toPos(old.gx, old.gy)
                } else {
                    this.removeBlock(old)
                }
            }
        }

        if (!block.gx && !block.gy) {
            this.blocks.push(block)
        }

        block.gx = grid.x
        block.gy = grid.y
        block.index = grid.x + grid.y * this.mapWidth
        block.position = this.toPos(grid)
    },

    getAtGrid(grid) {
        for (let i = 0; i < this.blocks.length; i++) {
            let b = this.blocks[i]
            if (b.gx == grid.x && b.gy == grid.y) {
                return b
            }
        }
        return null
    },

    toGrid(x, y) {
        if (y == undefined || y == null) {
            y = x.y
            x = x.x
        }

        let gx = Math.floor((x - this.startX) / this.blockSize.width)
        let gy = Math.floor((-y + this.startY) / this.blockSize.height)

        return cc.v2(gx, gy)
    },

    toPos(x, y) {
        if (y == undefined || y == null) {
            y = x.y
            x = x.x
        }
        return cc.v2(this.startX + x * this.blockSize.width + this.blockSize.width / 2,
            this.startY - y * this.blockSize.height - this.blockSize.height / 2)
    },

    onToggle(e) {
        this.selectBlock = e.node.getChildByName('temp')
        cc.log(this.selectBlock.blockType)
    },
});