cc.Class({
    extends: cc.Component,

    properties: {
        pageview: cc.Node,
    },

    start() {
        this.cur = 0
    },

    btn_next() {
        this.cur++;
        this.pageview.getComponent(cc.PageView).scrollToPage(this.cur)
        if (this.cur == 3) {
            UIMgr.close(this)
        }
    }
});