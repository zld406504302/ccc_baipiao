
cc.Class({
    extends: cc.Component,

    properties: {
        lb_page: cc.Node,
        items : [cc.Node],
        page_next: cc.Node,
        page_prev: cc.Node,
        editbox: cc.Node,

        lb_nothing: cc.Node,
        content: cc.Node,
        temps: cc.Node,
    },

    onLoad () {
        this.node.onenter = this.onenter.bind(this)

        this.temps.active = false
        this.block_temp = []
        let child = this.temps.children
        for (let i = 0; i < child.length; i++) {
            let c = child[i]
            c.blockType = gs.Block[c.name]
            this.block_temp[c.blockType] = c
        }
        this.mapHeight = 11
        this.mapWidth = 5
        this.blockSize = cc.size(40, 40)
    },

    onenter(type) {
        if (window.clubBtn) {
            window.clubBtn.hide()
        }
        this.showType = type
        this.page = 1
        if (!window.wxRank) {
            return
        }
        this.lb_nothing.active = false
        this.content.active = false
        this.page_prev.active = false
        this.page_next.active = false
        this.lb_page.active = false

        this.doShow()
    },
    toPos(x, y) {
        if (y == undefined || y == null) {
            y = x.y
            x = x.x
        }
        return cc.v2(-(this.mapWidth - 1) * this.blockSize.width / 2 + x * this.blockSize.width, -(this.mapHeight - 1) * this.blockSize.height / 2 + y * this.blockSize.height)
    },

    setBlockRotation(item, rotation) {
        rotation = rotation || 1

        let dest = (gs.RotationOffsetMap[item.blockType] || 0) + 90 * (rotation - 1)
        item.rotation = dest
    },

    buildTo(content, level) {
        let data = gs.levelFromString(level.init)
        content.removeAllChildren()

        let w = this.mapWidth
        let h = this.mapHeight

        for (let x = 0; x < w; x++) {
            for (let y = 0; y < h; y++) {
                let index = x + (h - y - 1) * w
                let id = data[index]
                if (id) {
                    let cfg = gs.ID2BlockMap[id]
                    let temp = cc.instantiate(this.block_temp[cfg.t])
                    temp.active = true
                    temp.parent = content
                    temp.blockType = cfg.t
                    let pos = this.toPos(x, y)
                    temp.setPosition(pos)
                    temp.setScale(temp.getScale() * 0.4)
                    this.setBlockRotation(temp, cfg.r, true)
                }
            }
        }
    },

    doShow() {

        wxRank.call('level_list', 
        {
            key:this.showType, 
            count:4, 
            page:this.page,
            myid: this.myid,
        }, 
        (ok, data)=>{
            cc.log(data)
            if (!data.data || data.data.length == 0) {
                this.lb_nothing.active = true
                this.content.active = false
                return 
            }

            this.maxPage = data.maxPage
            this.lb_nothing.active = false
            this.content.active = true

            this.showWithData(data.data)
        })
    },

    showWithData(data) {
        this.lb_page.active = true
        this.lb_page.getComponent(cc.Label).string = this.page +" / " +this.maxPage
        this.page_prev.active = this.page != 1
        this.page_next.active = this.page != this.maxPage

        this.data = data

        for (let i = 0; i < 4; i++) {
            let item = this.items[i]
            if (i < data.length) {
                item.active = true
                let d = data[i]
                let bar = item.getChildByName("bar")
                bar.getChildByName("count").getComponent(cc.Label).string = "通关人数："+d.passed + "/"+ d.played;
                bar.getChildByName("time").getComponent(cc.Label).string = DateFormat("yyyy/mm/dd")
                this.buildTo(item.getChildByName("content"), d)
                item.getChildByName("remove").active = this.showType == 'my'
                item.getChildByName("modify").active = this.showType == 'my'

                wxRank.call("getUserInfo", {target: d.openid}, 
                (ok, data)=>{

                    this.showUser(bar, data)
                    cc.log(data)
                })
            } else {
                item.active = false
            }
        }
    },

    showUser(bar, profile) {
        if (profile == null) {
            return 
        }

        bar.getChildByName("name").getComponent(cc.Label).string = profile.nickName

        let image = wx.createImage();
        image.onload = () => {
            let texture = new cc.Texture2D();
            texture.initWithElement(image);
            texture.handleLoadedTexture();
            bar.getChildByName("mask").getChildByName("icon").getComponent(cc.Sprite).spriteFrame = new cc.SpriteFrame(texture);
        };
        image.src = profile.avatarUrl;
    },

    on_Search() {
        this.showType = "search"
        this.page = 1
        this.myid = parseInt(this.editbox.getComponent(cc.EditBox).string)
        this.doShow()
    },

    on_Back() {
        sceneManager.show("Level")
    },

    on_Level(e) {
       let index = parseInt(e.target.name) - 1
       let lv_data = this.data[index]
       wxRank.call('level_mark', 
       {key:'played',level:lv_data._id}, 
       (ok, data)=>{
            if (!ok) {
                UIMgr.show("Msg", "网络不给力，请重试")
                return
            }

            gs.gotoCustomLevel(lv_data)
       })
    },

    on_Remove(e) {
        let index = parseInt(e.target.parent.name) - 1
        let lv_data = this.data[index]

        UIMgr.show("Msg", '你确定删除这个关卡吗？', (confirm) => {
            if (confirm) {
                wxRank.call("level_remove", 
                {level:lv_data._id},
                (ok, data)=> {
                    if (!ok) {
                        UIMgr.show("Msg", '网络不给力，请重试')
                        return
                    }
                    UIMgr.show("Msg", data.msg, ()=> {
                        this.doShow()
                    })
                })
            }
        })
    },

    on_Modify(e) {
        let index = parseInt(e.target.parent.name) - 1
        let lv_data = this.data[index]

        sceneManager.show("Editor", lv_data)
    },

    on_Next() {
        this.page ++;
        if (this.page >= this.maxPage) {
            this.page = this.maxPage
        }
        this.doShow()
    },

    on_Prev() {
        this.page --;
        if (this.page <= 1) {
            this.page = 1
        }
        this.doShow()
    },

});
