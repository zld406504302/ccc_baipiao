
cc.Node.prototype.Run = function () {
	let actions = Array.prototype.slice.call(arguments)
	if (actions.length == 1) {
		this.runAction(actions[0])
	} else if (actions.length >= 2) {
		this.runAction(new cc.Sequence(actions))
	} else {
		// do nothing
	}
}

cc.Node.prototype.PathChild = function (path, componentName) {
	let names = path.split('/')
	let nd = null

	for (let i = 0; i < names.length; i++) {
		if (nd) {
			nd = nd.getChildByName(names[i])
		} else {
			nd = this.getChildByName(names[i])
		}
	}

	if (componentName) {
		return nd.getComponent(componentName)
	} else {
		return nd
	}
}

cc.Node.prototype.Component = function (name) {
	return this.getComponent(name)
}

cc.Node.prototype.EachChild = function (cb) {
	this.children.forEach((child) => {
		cb(child)
	})
}

cc.Node.prototype.Play = function (idx) {
	let ani = this.getComponent(cc.Animation)
	let clips = ani.getClips()
	if (clips.length == 0) {
		cc.error("There's no clip in node", this.node)
	}
	ani.play(clips[idx].name)
}

cc.Node.prototype.GotoAnimateTime = function (aniName, time) {
	let ani = this.getComponent(cc.Animation)

	if (!aniName) {
		let clips = ani.getClips()
		if (clips.length == 0) {
			cc.error("There's no clip in node", this.node)
		}
		aniName = clips[0].name
	}
	ani.play(aniName)
	ani.pause()

	if (time < 0) {
		time = ani.getAnimationState(aniName).duration
	}

	ani.setCurrentTime(time)
}