class Client {
	constructor() {
		this.latestMessages = []
		this.cbs = []
		this.cbIdx = 1

		this.user = null
		this.passwd = null
	}

	onMessage(data) {
		if (data.cbId) {
			let cb = this.peekCb(data.cbId)
			cb(data.args, data.err)
			return
		}

		if (data.route) {
			let arr = data.route.split('.')
			cc.assert(arr.length == 2)

			let handler = require(arr[0])

			if (handler.prototype.runnable && !handler.prototype.runnable()) {
				return
			}

			let cb = handler.prototype[arr[1]]
			if (!cb)
				return
			cb(data.args, data.err)
		}
	}

	login(args) {
		this.user = args.user
		this.passwd = args.passwd
		this.createWS(`${globalCfg.gameServer}/login?username=${this.user}&passwd=${this.passwd}`)
	}

	guestLogin() {
		this.createWS(`${globalCfg.gameServer}/loginYK`)
	}

	reLogin() {
		this.createWS(`${globalCfg.gameServer}/login?username=${this.user}&passwd=${this.passwd}`)
	}

	/*
	CONNECTING	0	连接还没开启。
	OPEN	1	连接已开启并准备好进行通信。
	CLOSING	2	连接正在关闭的过程中。
	CLOSED	3	连接已经关闭，或者连接无法建立
	*/
	createWS(url) {
		cc.log("createWS start...")
		if (this._socket) {
			this._socket.close()
			cc.log("close old socket")
		}

		this.cbs = []

		cc.info("websocket connect:", url)
		let ws = new WebSocket(url)
		this._socket = ws
		ws.binaryType = "arraybuffer"
		ws.onopen = (event) => {
			cc.log("onopen")
			if (ws != this._socket) {
				return
			}

			connMgr.elapsed = 0
		}

		ws.onmessage = (event) => {
			if (ws == this._socket) {
				let data = JSON.parse(event.data)
				if (data.route != 'MsgHandlers.ping') {
					cc.log("response text msg: " + event.data)

					this.latestMessages.push(data)
					if (this.latestMessages.length > 20) {
						this.latestMessages.shift()
					}
				}
				connMgr.elapsed = 0

				try {
					this.onMessage(data)
				} catch (err) {
					if (ut.isBrowser()) {
						cc.error(err)
					} else {
						ut.httpRequest({
							url: globalCfg.logServer,
							method: 'POST',
							params: {
								username: me.nickname || 'empty',
								msg: err.message || '',
								name: err.name || '',
								pkg: data,
								latestPKGs: this.latestMessages || '',
								stack: err.stack || '',
								err: err,
							},
						})
					}
				}
			}
		}

		ws.onerror = (event) => {
			// ut.tip("网络出错,请检查你的网络!")
			cc.log("ws error", event)
			cc.log("onerror", event)
		}

		ws.onclose = (event) => {
			cc.log("onclose", event)
			if (ws == this._socket) {
				cc.log("onclose cur")
				cc.log("ws close", event)
				this._socket = null
				if (connMgr.logined) {
					// connMgr.reConnectBox()
				}
			}
		}
	}

	pushCb(cb) {
		this.cbs[this.cbIdx++] = cb
		return this.cbIdx - 1
	}

	peekCb(cbId) {
		let cbItem = this.cbs[cbId]
		cc.assert(cbItem)
		delete this.cbs[cbId]

		return cbItem
	}

	send(svr, route, args, cb) {
		if (this._socket == null) {
			return
		}

		if (this._socket.readyState != 1) {
			return
		}

		let arg = {
			svr: svr,
			route: route,
			args: args,
		}

		if (cb) {
			let cbId = this.pushCb(cb)
			arg.cbId = cbId
		}

		let msgStr = JSON.stringify(arg)
		if (arg.route != 'pong') {
			cc.log('send: ', msgStr)
		}
		this._socket.send(msgStr)
	}

	close() {
		if (this._socket) {
			this._socket.close()
		}
		this._socket = null
	}
}

window.client = new Client()
