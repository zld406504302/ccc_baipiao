'use strict'

class Me {
	constructor() {
		this.id = 0
		this.gold = 0
		this.nickname = ''
		this.gender = 0
	}
}

// module.exports = new Me()
window.me = new Me()