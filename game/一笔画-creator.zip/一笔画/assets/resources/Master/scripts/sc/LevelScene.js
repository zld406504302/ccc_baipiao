cc.Class({
    extends: cc.Component,

    properties: {
        cloneInst: cc.Node,

        info: cc.Node,
        scrollview: cc.ScrollView,

        passColor: cc.Color,
        validColor: cc.Color,
        lockColor: cc.Color,

        passTextColor: cc.Color,
        validTextColor: cc.Color,
        lockTextColor: cc.Color,
    },

    onLoad: function () {
        this.model = {
            group: 0,
            mode: 0,
            modeName: '',
        }

        this.cloneInst.active = false

        this.node.onenter = this.onenter.bind(this)
    },

    onenter: function (mode, group, modeName) {
        this.model.mode = mode
        this.model.group = group
        this.model.modeName = modeName

        this.info.PathChild('mode', cc.Label).string = modeName
        this.info.PathChild('level', cc.Label).string = `Level ${group + 1}`

        let pass = 0
        let levels = globalCfg.setting.levels[mode]

        for (let i = 0; i < levels.length; i++) {
            if (levels[i] >= group * 100 && levels[i] < (group + 1) * 100 && pass < levels[i]) {
                pass = levels[i]
            }
        }

        pass = pass % 100

        cc.log('pass', pass)

        for (let i = 0; i < 100; i++) {
            let it = cc.instantiate(this.cloneInst)
            it.active = true
            it.parent = this.scrollview.node.PathChild('view/content')
            it.SubLevel = i

            it.PathChild('level', cc.Label).string = i + 1

            if (levels.indexOf(group * 100 + i) >= 0) {
                it.PathChild('light').color = this.passColor
                it.PathChild('star', 'MultiFrame').setFrame(1)
                it.PathChild('level').color = this.validTextColor
                it.CanEnter = true
            } else if (i < pass + 3) {
                it.PathChild('light').color = this.validColor
                it.PathChild('star', 'MultiFrame').setFrame(0)
                it.PathChild('level').color = this.validTextColor
                it.CanEnter = true
            } else {
                it.PathChild('light').color = this.lockColor
                it.PathChild('star').active = false
                it.PathChild('level').color = this.lockTextColor
                it.CanEnter = false
            }
        }
    },

    btnEnter: function (event) {
        let target = event.currentTarget

        if (target.CanEnter) {
            audioMgr.playSound('se_select', 'LB')

            sceneManager.show('LB:LB', {
                mode: this.model.mode,
                group: this.model.group,
                modeName: this.model.modeName,
                subLevel: target.SubLevel,
            })
        }
    },

    btnClose: function () {
        sceneManager.show('Main', this.model.mode)
    },
});
