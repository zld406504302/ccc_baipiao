cc.Class({
    extends: cc.Component,

    properties: {
        pageInst: cc.Node,
        levelInst: cc.Node,

        info: cc.Node,
        pageview: cc.PageView,

        colors: [cc.Color],
    },

    onLoad: function () {
        this.model = {
            alllock: [],
        }

        this.ModeNames = ['简单模式', '普通模式', '困难模式', '大师模式']

        this.pageInst.active = false
        this.levelInst.active = false

        cc.loader.loadRes('SubModules/LB/data/puzzles', (v1, v2) => {
            globalCfg.AllLevelData = v2
            // cc.log(v1, v2)
        })

        this.node.onenter = this.onenter.bind(this)
    },

    onenter: function (idx) {
        idx = idx || 0

        for (let i = 0; i < 4; i++) {
            let page = cc.instantiate(this.pageInst)
            page.active = true

            page.PathChild('lock').active = !(i == 0 || globalCfg.setting.unlock)

            this.model.alllock.push(page.PathChild('lock'))

            this.pageview.addPage(page)

            for (let j = 0; j < 5; j++) {
                let it = cc.instantiate(this.levelInst)
                it.parent = page.PathChild('holder')
                it.active = true

                let levels = globalCfg.setting.levels[i]
                let total = 0
                for (let k = 0; k < levels.length; k++) {
                    if (levels[k] > j * 100 && levels[k] <= (j + 1) * 100) {
                        total++
                    }
                }

                it.PathChild('bg').color = this.colors[i * 5 + j]
                it.PathChild('pass', cc.Label).string = `${total} / 100`
                it.PathChild('level', cc.Label).string = `Level ${j + 1}`
                it.Group = j
                it.Mode = i
            }
        }

        this.pageview.scrollToPage(idx, 0)
        this.refresh(idx)

        this.info.PathChild('sound/image', 'MultiFrame').setFrame(audioMgr.soundEnable ? 1 : 0)
        audioMgr.playMusic('bgm_top', 'LB')
    },

    refresh: function (idx) {
        this.info.PathChild('mode', cc.Label).string = this.ModeNames[idx]
        this.info.PathChild('layout/level', cc.Label).string = `${globalCfg.setting.levels[idx].length} / 500`
    },

    onPageChange: function () {
        this.refresh(this.pageview.getCurrentPageIndex())
        audioMgr.playSound('se_slide', 'LB')
    },

    btnSelectLevel: function (event) {
        let target = event.currentTarget
        cc.log('level', target.Mode, target.Group)

        audioMgr.playSound('se_select', 'LB')

        sceneManager.show('Level', target.Mode, target.Group, this.ModeNames[target.Mode])
    },

    btnSwitchSound: function () {
        audioMgr.soundEnable = !audioMgr.soundEnable
        audioMgr.musicEnable = !audioMgr.musicEnable
        this.info.PathChild('sound/image', 'MultiFrame').setFrame(audioMgr.soundEnable ? 1 : 0)

        globalCfg.saveSetting()
    },

    btnUnlock: function () {
        this.node.runAction(cc.sequence(
            cc.delayTime(0.5),
            cc.callFunc(() => {
                globalCfg.setting.unlock = true
                globalCfg.saveSetting()

                this.model.alllock.forEach((it) => {
                    it.active = false
                })
            })
        ))

        nativeApi.appstoreProductView()
    },
});
