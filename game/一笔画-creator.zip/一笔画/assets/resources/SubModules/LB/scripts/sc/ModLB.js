cc.Class({
    extends: cc.Component,

    properties: {
        info: cc.Node,
    },

    onLoad: function () {
        globalSceneVarManager.register('lb2', this)

        this.model = {
            mode: 0,
            group: 0,
            subLevel: 0,
            modeName: '',
        }

        this.node.onenter = this.onenter.bind(this)
        this.node.onleave = this.onleave.bind(this)
    },

    onenter: function (info) {
        this.model.mode = info.mode
        this.model.group = info.group
        this.model.modeName = info.modeName
        this.model.subLevel = info.subLevel

        this.info.PathChild('mode', cc.Label).string = info.modeName
        this.info.PathChild('level', cc.Label).string = `Level ${info.group + 1}-${info.subLevel + 1}`
        this.info.PathChild('hint/val', cc.Label).string = globalCfg.setting.hintCount
        this.info.PathChild('sound/image', 'MultiFrame').setFrame(audioMgr.soundEnable ? 1 : 0)

        lb2.gameCtrl.reload(info.subLevel)
    },

    onleave: function () {
        globalSceneVarManager.unregister('lb2')
    },

    nextLevel: function () {
        if (this.model.subLevel < 99) {
            this.model.subLevel++
            this.info.PathChild('level', cc.Label).string = `Level ${this.model.group + 1}-${this.model.subLevel + 1}`
            this.gameCtrl.reload(this.model.subLevel)
        } else {
            sceneManager.show('Level', this.model.mode, this.model.group, this.model.modeName)
        }
    },

    addTip: function (val) {
        globalCfg.setting.hintCount += val
        globalCfg.saveSetting()
        this.info.PathChild('hint/val', cc.Label).string = globalCfg.setting.hintCount
    },

    btnClose: function () {
        sceneManager.show('Level', this.model.mode, this.model.group, this.model.modeName)
    },

    btnShowTip: function () {
        if (globalCfg.setting.hintCount > 0) {
            globalCfg.setting.hintCount--
            globalCfg.saveSetting()

            this.info.PathChild('hint/val', cc.Label).string = globalCfg.setting.hintCount
            lb2.gameCtrl.showTip()
            audioMgr.playSound('se_button_hint', 'LB')
        } else {
            audioMgr.playSound('se_button_no_hint', 'LB')
            UIMgr.show('LB:Ad')
        }
    },

    btnSwitchSound: function () {
        audioMgr.soundEnable = !audioMgr.soundEnable
        audioMgr.musicEnable = !audioMgr.musicEnable
        this.info.PathChild('sound/image', 'MultiFrame').setFrame(audioMgr.soundEnable ? 1 : 0)

        globalCfg.saveSetting()
    },
});
