cc.Class({
    extends: cc.Component,

    properties: {
        form: cc.Node,
    },

    onLoad: function () {
        this.node.onenter = this.onenter.bind(this)

        this.form.OriginPos = this.form.position
    },

    onenter: function () {
        this.form.x = -1000
        this.form.runAction(cc.moveTo(0.5, this.form.OriginPos))
    },

    btnShowAd: function () {
        audioMgr.pauseMusic()

        nativeApi.startRewardVideo((msg) => {
            switch (msg) {
                case 'COMPLETED':
                    audioMgr.resumeMusic()

                    UIMgr.close(this)
                    lb2.addTip(1)
                    break
                case 'NOTREADY':
                    ut.tip('视频准备中请稍后再来')
                    break
            }
        })
    },

    btnClose: function () {
        UIMgr.close(this)
    },
});
