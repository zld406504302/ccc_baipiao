cc.Class({
    extends: cc.Component,

    properties: {

    },

    // use this for initialization
    onLoad: function () {
        lb2.puzzleCtrl = this
    },

    getLevelData: function (subLevel) {
        let level = 500 * lb2.model.mode + 100 * lb2.model.group + subLevel
        let info = globalCfg.AllLevelData[level]
        let width = info[0][0]
        let height = info[0][1]
        let grid = []

        for (let i = 0; i < width; i++) {
            for (let j = 0; j < height; j++) {
                grid.push(1)
            }
        }

        let emptyArr = info[2]
        for (let i = 0; i < emptyArr.length; i++) {
            grid[emptyArr[i]] = 0
        }

        let startIdx = info[1]
        let sx = startIdx % width
        let sy = Math.floor(startIdx / width)

        return {
            w: width,
            h: height,
            start: { x: sx, y: sy },
            grid: grid,
            answer: info[3],
        }
    },
});
