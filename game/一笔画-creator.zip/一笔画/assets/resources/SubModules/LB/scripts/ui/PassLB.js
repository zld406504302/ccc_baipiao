cc.Class({
    extends: cc.Component,

    properties: {
        form: cc.Node,
    },

    onLoad: function () {
        this.node.onenter = this.onenter.bind(this)

        this.form.OriginPos = this.form.position
    },

    onenter: function () {
        this.form.x = -1000
        this.form.runAction(cc.moveTo(0.5, this.form.OriginPos))

        this.form.PathChild('mode', cc.Label).string = lb2.model.modeName
        this.form.PathChild('level', cc.Label).string = `Level ${lb2.model.group + 1}-${lb2.model.subLevel + 1}`

        let level = lb2.model.group * 100 + lb2.model.subLevel
        if (globalCfg.setting.levels[lb2.model.mode].indexOf(level) < 0) {
            globalCfg.setting.levels[lb2.model.mode].push(level)
        }

        globalCfg.saveSetting()
    },

    btnNext: function () {
        UIMgr.close(this)
        lb2.nextLevel()
    },
});
