cc.Class({
    extends: cc.Component,

    properties: {
        drawer: cc.Node,
        holder: cc.Node,
        cloneInst: cc.Node,

        fillColor: cc.Color,
    },

    onLoad: function () {
        lb2.gameCtrl = this

        this.model = {
            tipData: [1, 2, 3, 7, 6],
            choosed: [],
            items: [],
            cache: [],
            totalCell: 0,
            done: true,
        }

        this.TestData = {
            w: 4,
            h: 5,
            start: { x: 0, y: 3 },
            grid: [
                1, 1, 1, 1,
                0, 1, 1, 1,
                1, 1, 1, 1,
                1, 1, 1, 0,
                0, 1, 1, 0,
            ],
        }

        this.drawer.position = this.holder.position

        this.Space = 10
        this.CellWidth = this.cloneInst.width

        this.cloneInst.active = false

        this.holder.on(cc.Node.EventType.TOUCH_START, this.onTouch, this)
        this.holder.on(cc.Node.EventType.TOUCH_MOVE, this.onTouch, this)
    },

    reload: function (subLevel) {
        audioMgr.playMusic(`bgm_game_${ut.randInt(4) + 1}`, 'LB')

        let data = lb2.puzzleCtrl.getLevelData(subLevel)

        this.model.choosed.length = 0
        this.model.items.length = 0
        this.model.tipData = data.answer

        let totalx = this.CellWidth * data.w + this.Space * (data.w - 1)
        let totaly = this.CellWidth * data.h + this.Space * (data.h - 1)
        let ox = -totalx / 2 + this.CellWidth / 2
        let oy = totaly / 2 - this.CellWidth / 2
        let ncell = 0

        for (let j = 0; j < data.h; j++) {
            for (let i = 0; i < data.w; i++) {
                let idx = i + j * data.w
                let val = data.grid[idx]

                if (val > 0) {
                    let it = cc.instantiate(this.cloneInst)
                    it.parent = this.holder
                    it.active = true
                    it.x = ox + (i * this.CellWidth + i * this.Space)
                    it.y = oy - (j * this.CellWidth + j * this.Space)

                    it.PathChild('light').active = false
                    it.PathChild('tip').active = false
                    it.Idx = idx
                    it.CellX = i
                    it.CellY = j

                    ncell++

                    this.model.items.push(it)
                } else {
                    this.model.items.push(null)
                }
            }
        }

        this.model.totalCell = ncell
        this.model.choosed.push(data.start.x + data.start.y * data.w)
        this.refreshView()
        this.playStartAnimate()
    },

    showTip: function () {
        for (let i = 0; i < this.model.tipData.length; i++) {
            let it = this.model.items[this.model.tipData[i]]
            it.PathChild('tip').active = true
            it.PathChild('tip', cc.Label).string = i + 1
        }
    },

    calcOffset: function (pos, dst) {
        if (pos.x < dst.x) {
            return cc.p(pos.x - this.CellWidth / 2, pos.y)
        } else if (pos.x > dst.x) {
            return cc.p(pos.x + this.CellWidth / 2, pos.y)
        } else if (pos.y < dst.y) {
            return cc.p(pos.x, pos.y - this.CellWidth / 2)
        } else if (pos.y > dst.y) {
            return cc.p(pos.x, pos.y + this.CellWidth / 2)
        }
    },

    playStartAnimate: function () {
        this.model.items.forEach((it) => {
            if (!it) {
                return
            }

            this.drawer.Component(cc.Graphics).clear()

            it.PathChild('frame').scale = 0.03
            it.PathChild('frame').runAction(cc.sequence(
                cc.delayTime(0.01),
                cc.scaleTo(0.5, 1),
            ))

            if (it.PathChild('light').active) {
                it.PathChild('light').scale = 0.03
                it.PathChild('light').runAction(cc.sequence(
                    cc.delayTime(0.6),
                    cc.scaleTo(0.25, 1),
                ))
            }
        })

        this.holder.runAction(cc.sequence(
            cc.delayTime(1),
            cc.callFunc(() => {
                this.model.done = false
            }),
        ))
    },

    testInTouch: function (cell, pos) {
        return (Math.abs(cell.x - pos.x) < cell.width / 2 && Math.abs(cell.y - pos.y) < cell.height / 2)
    },

    onTouch: function (ev) {
        if (this.model.done) {
            return
        }

        let wpos = ev.getLocation()
        let pos = this.holder.convertToNodeSpaceAR(wpos)

        let it = this.getTouchCell(pos)
        let last = this.model.items[this.model.choosed[this.model.choosed.length - 1]]

        if (!it) {
            return
        }

        let idx = this.model.choosed.indexOf(it.Idx)
        if (idx >= 0) {
            if (idx < this.model.choosed.length - 1) {
                let cnt = this.model.choosed.length - idx - 1
                for (let i = 0; i < cnt; i++) {
                    this.model.choosed.pop()
                }
                this.refreshView()
            }
        } else if (Math.abs(it.CellX - last.CellX) + Math.abs(it.CellY - last.CellY) == 1) {
            audioMgr.playSound('se_color_fill', 'LB')

            this.model.choosed.push(it.Idx)
            this.refreshView()
            this.checkPassLevel()
        }
    },

    refreshView: function () {
        for (let i = 0; i < this.model.items.length; i++) {
            let it = this.model.items[i]
            if (it) {
                it.PathChild('light').active = (this.model.choosed.indexOf(it.Idx) >= 0)
                it.PathChild('light').color = this.fillColor
            }
        }

        let posArr = []
        for (let i = 0; i < this.model.choosed.length; i++) {
            let it = this.model.items[this.model.choosed[i]]
            posArr.push(it.position)
        }

        let ctx = this.drawer.Component(cc.Graphics)
        ctx.clear()
        ctx.lineWidth = 80
        ctx.strokeColor = this.fillColor
        for (let i = 0; i < posArr.length; i++) {
            let pos = posArr[i]
            if (i == 0) {
                ctx.moveTo(pos.x, pos.y)
            } else {
                ctx.lineTo(pos.x, pos.y)
            }
        }

        ctx.stroke()

        ctx.lineWidth = 3
        ctx.strokeColor = cc.Color.WHITE
        for (let i = 0; i < posArr.length; i++) {
            let pos = posArr[i]
            if (i == 0) {
                ctx.moveTo(pos.x, pos.y)
            } else {
                ctx.lineTo(pos.x, pos.y)
            }
        }
        ctx.stroke()
    },

    checkPassLevel: function () {
        if (this.model.totalCell == this.model.choosed.length) {
            this.model.done = true

            audioMgr.stopMusic()
            audioMgr.playSound('se_clear', 'LB')

            this.drawer.Component(cc.Graphics).clear()

            this.model.items.forEach((it) => {
                if (!it) {
                    return
                }

                it.PathChild('light').runAction(cc.sequence(
                    cc.delayTime(0.01),
                    cc.scaleTo(0.5, 0.03)),
                )

                it.PathChild('frame').runAction(cc.sequence(
                    cc.delayTime(0.1),
                    cc.scaleTo(0.5, 0.03)),
                )
            })

            this.holder.runAction(cc.sequence(
                cc.delayTime(0.5),
                cc.callFunc(() => {
                    this.holder.removeAllChildren()
                }),
                cc.delayTime(0.3),
                cc.callFunc(() => {
                    UIMgr.show('LB:Pass')
                })
            ))
        }
    },

    getTouchCell: function (pos) {
        for (let i = 0, items = this.model.items; i < items.length; i++) {
            let it = items[i]
            if (it && this.testInTouch(it, pos)) {
                return it
            }
        }

        return null
    },
});
