cc.Class({
    extends: cc.Component,

    properties: {
    },

    onLoad: function () {
        window.debugMgr = this
    },
});
