cc.Class({
    extends: cc.Component,

    properties: {
        tip: cc.Node,
    },

    onLoad: function () {
        window.connMgr = this

        this.logined = false
        this.tries = 0
        this.asking = false
        this.elapsed = 0

        this.tip.active = false
        
        let n = 0

        this.schedule((dt) => {
            this.checkOffline(dt)
            if (this.tip.active) {
                this.tip.PathChild('val', cc.Label).string = '网络中断，拼命连接中 ' + ".".repeat(++n % 6)
            }
        }, 0.5, 1e7, 0)
    },

    checkOffline: function (dt) {
        if (!this.logined) {
            return
        }

        if (this.asking) {
            return
        }

        this.elapsed += Math.min(0.5, dt)
        if (this.elapsed < 5) {
            return
        }

        cc.log("掉线了,马上重连", this.elapsed)

        this.elapsed = 0

        if (this.tries < 3) {
            cc.log("网络中断,拼命连接中.....", this.tries)
            this.tip.active = true
            // ut.tip("网络中断,拼命连接中.....")
            this.tries++
            client.reLogin()
        } else {
            cc.log("弹出重连ui", this.tries)
            this.reConnectBox()
        }
    },

    reset(logined) {
        this.tip.active = false

        this.elapsed = 0
        this.logined = logined
        this.tries = 0
        cc.log("reset", this.tries)
        if (logined) {
            client.send(null, "pong", null)
        }
    },

    reConnectBox() {
        if (this.asking) {
            return
        }

        this.asking = true
        this.tip.active = false

        UIMgr.show("MessageBox", "游戏已断开连接 请重新连接", 'ok', (what) => {
            this.asking = false
            if (what == "ok") {
                this.tip.active = true
                cc.log("点击确定重连按钮")
                this.elapsed = 0
                client.reLogin()
            } else if (what == "cancel") {
                this.tip.active = false
                this.reset(false)
            }
        })
    },
});
