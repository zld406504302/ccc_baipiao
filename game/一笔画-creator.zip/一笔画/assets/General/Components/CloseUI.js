cc.Class({
    extends: cc.Component,

    properties: {

    },

    onLoad: function () {

    },

    btnCloseUI: function () {
        UIMgr.close(this)
    }
});
