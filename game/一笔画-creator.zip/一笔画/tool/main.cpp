
#include <sstream>
#include <fstream>
#include <iostream>
#include <vector>
#include <set>
#include <ctime>


struct Set {

    Set() {
        _count = 0;
        memset(_mark, 0, sizeof(_mark));
    }

    void insert(int value) {
        _count++;
        _mark[value]++;
    }

    void erase(int value) {
        _count--;
        _mark[value] = 0;
    }

    int count(int value) {
        return _mark[value];
    }

    int size() {
        return _count;
    }

    std::string tostring() {
        std::stringstream ss;
        int c = _count;
        for (int i = 0; i < 256; i++) {
            if (_mark[i]) {
                ss << i << ",";
                c--;
                if (c == 0) {
                    break;
                }
            }
        }

        return ss.str();
    }

protected:
    int _count;
    int _mark[256];
};

struct Info {
    int w, h;
    int start;
    Set takes;
    //std::set<int> takes;
    std::vector<int> way;

    std::string tostring() {
        std::stringstream ss;
        
        ss << "[\n";
        ss << "\t[" << w << "," << h << "],\n";
        ss << "\t" << start << ",\n";

        ss << "\t[" << takes.tostring() << "],\n";
        ss << "\t[";
        for (int i : way) {
            ss << i << ",";
        }
        ss << "],\n";


        ss << "],\n";

        return ss.str();

    }
};

struct Generator {

    int width;
    int height;
    int minTake;
    int total;

    clock_t starttime;

    Generator(int w, int h, int min, int c) : width(w), height(h), minTake(min), total(c) {
    }

    static void combine(int data[], int n, int m, int temp[], const int M, std::vector<Set> &vec_res) {
        for (int i = n; i >= m; i--)
        {
            temp[m - 1] = i - 1;
            if (m > 1)
                combine(data, i - 1, m - 1, temp, M, vec_res);
            else
            {
                Set vec_temp;
                for (int j = M - 1; j >= 0; j--) {
                    vec_temp.insert(data[temp[j]]);
                }

                vec_res.push_back(vec_temp);
            }
        }
    }

    static std::vector<Set> count(int data[], int n, int m) {
        std::vector<Set> ret;

        int* temp = new int[m];
        combine(data, n, m, temp, m, ret);
        delete[] temp;

        return ret;
    }

    void printProgress(float pro) {
        clock_t stop = clock();
        printf("%d%% %fs\r", (int)(pro * 100.0f), (double)(stop - starttime) / CLOCKS_PER_SEC);
    }

    std::vector<Info> getAll() {

        starttime = clock();

        int* grid = new int[width * height];
        for (int i = 0; i < width*height;i++) {
            grid[i] = i;
        }

        std::vector<Set> all = count(grid, width* height, minTake);
        std::vector<Info> ret;

        int n = 0;
        for (int i = 0; i < all.size() && n < total; i++) {
            Info info = prossesOne(grid, all[i]);
            printProgress((float)n / (float)total);
            if (info.way.size() > 0) {
                n++;
                ret.push_back(info);
            }
        }

        delete[] grid;

        return ret;
    }

    void indexToXY(int idx, int* x, int * y) {
        *x = idx % width;
        *y = (int)((float)idx / (float)width);
    }

    int xyToIndex(int x, int y) {
        return y * width + x;
    }

    int calc(int s, int dx, int dy) {
        int x, y;
        indexToXY(s, &x, &y);
        x += dx;
        y += dy;
        if (x < 0 || x >= width)
            return -1;
        if (y < 0 || y >= height)
            return -1;

        return xyToIndex(x, y);
    }

    bool search(std::vector<int>& way, Set& used, int left, int pos, int dx, int dy) {

        pos = calc(pos, dx, dy);

        if (pos == -1)
            return false;

        if (used.count(pos) > 0)
            return false;

        used.insert(pos);
        way.push_back(pos);

        if (left == 0)
            return true;

        if (search(way, used, left - 1, pos, 0, 1))
            return true;
        if (search(way, used, left - 1, pos, 0, -1))
            return true;
        if (search(way, used, left - 1, pos, -1, 0))
            return true;
        if (search(way, used, left - 1, pos, 1, 0))
            return true;

        way.pop_back();
        used.erase(pos);

        return false;
    }

    bool findWay(Info& info) {
        Set used = info.takes;
        int left = info.h * info.w - info.takes.size();

        if (search(info.way, used, left - 1, info.start, 0, 0))
            return true;

        info.way.clear();
        return false;
    }

    Info prossesOne(int* grid, const Set& toke) {
        Info info;
        info.w = width;
        info.h = height;
        info.takes = toke;

        int n = width * height;

        Set mark;

        for (int i = 0; i < n; i++) {

            while (true) {
                info.start = rand() % n;
                if (!mark.count(info.start)) {
                    break;
                }
                else {
                    bool all = true;
                    for (int j = 0; j < n; j++) {
                        if (!mark.count(info.start)) {
                            all = false;
                            break;
                        }
                    }
                    if (all) {
                        info.way.clear();
                        return info;
                    }
                }
            }
            mark.insert(info.start);
            if (findWay(info)) {
                return info;
            }
        }

        return info;
    }
};

void useage() {
    std::cout << "fill.exe w,h,rm_count,gen_count" << std::endl;
}

int main(int argc, char*argv[]) {

    if (argc != 2) {
        useage();
        return 0;
    }

    int w, h, t, n;

    if (sscanf(argv[1], "%d,%d,%d,%d", &w, &h, &t, &n) == 0) {
        useage();
        return 0;
    }

    clock_t start = clock();

    char buf[256];
    sprintf(buf, "%d_%d_%d_%d.json", w, h, t, n);
    
    std::string name(buf);

    std::ofstream of(name);
    of << "[\n";
    Generator g(w, h, t, n);

    std::vector<Info> infolist = g.getAll();
    for (Info& info : infolist) {
        of << info.tostring();
    }
    of << "]\n";
    of.close();

    clock_t stop = clock();
    std::cout << name << " takes:" << (double)(stop - start) / CLOCKS_PER_SEC << "seconds" << " count:" << infolist.size() <<std::endl;

    return 0;
}
