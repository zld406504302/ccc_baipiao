"use strict";
cc._RF.push(module, '04b9318wOZBRa5lG5T1nQLd', 'Home');
// script/Home.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        numsprite: cc.Sprite,
        pannel: cc.Node,
        scoreLabel: {
            default: null,
            type: cc.Label
        }
    },

    start: function start() {
        var self = this;

        this.hidePannel();
        this.initZhuan();
    },

    initZhuan: function initZhuan() {

        if (cc.sys.localStorage.getItem("bestScore" + getWeekOfYear()) == null || cc.sys.localStorage.getItem("bestScore" + getWeekOfYear()) == "") {
            cc.sys.localStorage.setItem("bestScore" + getWeekOfYear(), 0);
        }
        if (cc.sys.localStorage.getItem("bestScore") == null || cc.sys.localStorage.getItem("bestScore") == "") {
            cc.sys.localStorage.setItem("bestScore", 0);
        }
        if (cc.sys.localStorage.getItem("bignum") == null || cc.sys.localStorage.getItem("bignum") == "") {
            cc.sys.localStorage.setItem("bignum", 1);
        } else {
            if (cc.sys.localStorage.getItem("bignum") > 5) {
                this.numsprite.spriteFrame = new cc.SpriteFrame(cc.url.raw('resources/num/num' + cc.sys.localStorage.getItem("bignum") + '.png'));
                this.scoreLabel.string = "历史最高分：" + cc.sys.localStorage.getItem("bestScore");
            }
        }
    },
    showPannel: function showPannel() {
        this.pannel.active = true;
    },
    hidePannel: function hidePannel() {
        this.pannel.active = false;
    },

    enterRankviewScene: function enterRankviewScene() {
        cc.director.loadScene("RankingView");
    },
    enterGameScene: function enterGameScene() {
        cc.director.loadScene("tenGameScene");
    }

});
function getWeekOfYear() {
    //以周一为每周的第一天。
    var today = new Date();
    var firstDay = new Date(today.getFullYear(), 0, 1);
    var dayOfWeek = firstDay.getDay();
    var spendDay = 1;
    if (dayOfWeek != 0) {
        spendDay = 7 - dayOfWeek + 1;
    }
    firstDay = new Date(today.getFullYear(), 0, 1 + spendDay);
    var d = Math.ceil((today.valueOf() - firstDay.valueOf()) / 86400000);
    var result = Math.ceil(d / 7);
    cc.log("第" + result + "周");
    return result + 1;
};
//0-a-1
function getRandom(a) {
    return Math.floor(Math.random() * a);
}

cc._RF.pop();