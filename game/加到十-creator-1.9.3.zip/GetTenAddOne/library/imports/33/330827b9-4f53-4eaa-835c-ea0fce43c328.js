"use strict";
cc._RF.push(module, '33082e5T1NOqoNc6g/OQ8Mo', 'Global');
// script/Global.js

"use strict";

module.exports = {
    score: 0,
    combo: 0
};

cc._RF.pop();