"use strict";
cc._RF.push(module, 'f9058+VW2lPyJd6Kd4IBe8v', 'Yao');
// script/Yao.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {},

    start: function start() {
        var rotateBy1 = cc.rotateBy(0.5, 20, 20);
        var rotateBy2 = cc.rotateBy(0.5, -20, -20);
        var sequence = cc.sequence(rotateBy1, rotateBy2);
        var repeat = cc.repeatForever(sequence);
        this.node.runAction(repeat);
    }
});

cc._RF.pop();