"use strict";
cc._RF.push(module, '84ec6tLs7xEmqlkcfNBUj5F', 'closeself');
// script/getten/closeself.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {},

    start: function start() {},

    close: function close() {
        this.node.destroy();
    }
});

cc._RF.pop();