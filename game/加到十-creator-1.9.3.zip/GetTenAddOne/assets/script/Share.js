var title=["2048新玩法，99%的人不能达到2048的成就，快来挑战吧"
,"合到2048可以领取红包，快来交智商税吧",""];
var sharaUrl=["http://bmob-cdn-20146.b0.upaiyun.com/2018/07/07/20a2e3cd400c1be580c3d6541abfcf32.png",
"http://bmob-cdn-20146.b0.upaiyun.com/2018/07/07/85249a4240c30b0780fd124679ce024a.png"];
cc.Class({
    extends: cc.Component,

    properties: {
       
    },
    start () {
        if (window.wx != undefined) {//隐藏游戏圈
            this.getUserInfo()
            var random=getRandom(1)
            window.wx.showShareMenu({withShareTicket: true});//设置分享按钮，方便获取群id展示群排行榜
            wx.onShareAppMessage(function () {
                return {
                    title: title[random],
                    imageUrl:  sharaUrl[random],
                    query:  "channel=share"
                 }
            });

            wx.onShow(function (res) {
                console.log("onshow:", res);
                   if(res.query!=undefined){
                    if(res.query.channel!=undefined){
                       cc.sys.localStorage.setItem("channel",res.query.channel)
                   }
                 }
               });

            }     
                
    },
    getUserInfo: function() {//微信授权
        wx.getUserInfo({
            success: function(res) {
                var userInfo = res.userInfo
                var nickName = userInfo.nickName
                var avatarUrl = userInfo.avatarUrl
                var gender = userInfo.gender //性别 0：未知、1：男、2：女
                var province = userInfo.province
                var city = userInfo.city
                var country = userInfo.country
                 
                cc.sys.localStorage.setItem("nickName",nickName)//保存到本地
                cc.sys.localStorage.setItem("avatarUrl",avatarUrl)
                cc.sys.localStorage.setItem("gender",gender)
                cc.sys.localStorage.setItem("province",province)
                cc.sys.localStorage.setItem("city",city)
                cc.sys.localStorage.setItem("country",country)

                var Bmob = require('Bmob');
                Bmob.initialize("2f2073d717f2462a670ccbc1f1c1aa13", "dda33270989bc8ba12b5caca421e2c7b");
                var query = Bmob.Query('get2048_auth');//授权用户  新增
                if( cc.sys.localStorage.getItem("authId")!=""&&cc.sys.localStorage.getItem("authId")!=null){
                    query.set('id', cc.sys.localStorage.getItem("authId"))//更新
                }
                query.set("gamename","合到2048")
                query.set("nickName",nickName)
                query.set("avatarUrl",avatarUrl)
                query.set("gender",gender)
                query.set("province",province)
                query.set("city",city)
                query.set("country",country)
                query.set("channel",cc.sys.localStorage.getItem("channel"))
                query.set("bestScore",cc.sys.localStorage.getItem("bestScore"))
                query.set("bignum",cc.sys.localStorage.getItem("bignum"))
                query.save().then(res => {
                    cc.sys.localStorage.setItem("authId",res.objectId)//保存到本地
                console.log(res)
                }).catch(err => {
                console.log(err)
                cc.sys.localStorage.setItem("authId","")//保存到本地
                })
            }
          })
    },
    share: function() {
        var random=getRandom(1)
        wx.shareAppMessage({
            title: title[random],
            imageUrl:  sharaUrl[random],
            query:  "channel=share" });
    },
    showMoreGame: function() {
        var imgsurl=["https://bmob-cdn-20146.b0.upaiyun.com/2018/06/23/4a44fb0c400345c88015e8e0b57c45ba.jpg",
        "https://bmob-cdn-20146.b0.upaiyun.com/2018/06/23/97cb775340a01c4080ec0db4ae716735.jpg",
        "http://bmob-cdn-20146.b0.upaiyun.com/2018/06/23/d4b40ecd4054c8ec80ce929ae1d89419.jpg"];  
           wx.previewImage({  
               current:imgsurl,  
               urls: imgsurl ,
        });  
    },
    

});
function getRandom(a)
{
    return Math.floor(Math.random()*a);
}