module.exports = {
    score: 0,
    combo:0,
};