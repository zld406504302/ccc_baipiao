

cc.Class({
    extends: cc.Component,

    properties: {
    },

  

    start () {

    },
    close: function() {
        this.node.destroy()
    },
});
