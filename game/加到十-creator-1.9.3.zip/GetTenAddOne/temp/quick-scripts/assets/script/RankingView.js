(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/script/RankingView.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '197fd50+fNB56Q9VOnxl9BN', 'RankingView', __filename);
// script/RankingView.js

"use strict";

function getWeekOfYear() {
    //以周一为每周的第一天。
    var today = new Date();
    var firstDay = new Date(today.getFullYear(), 0, 1);
    var dayOfWeek = firstDay.getDay();
    var spendDay = 1;
    if (dayOfWeek != 0) {
        spendDay = 7 - dayOfWeek + 1;
    }
    firstDay = new Date(today.getFullYear(), 0, 1 + spendDay);
    var d = Math.ceil((today.valueOf() - firstDay.valueOf()) / 86400000);
    var result = Math.ceil(d / 7);
    cc.log("第" + result + "周");
    return result + 1;
};

cc.Class({
    extends: cc.Component,
    name: "RankingView",
    properties: {
        // groupFriendButton: cc.Node,
        // friendButton: cc.Node,
        // gameOverButton: cc.Node,
        rankingScrollView: cc.Sprite, //显示排行榜
        _key: "x1"
    },
    onLoad: function onLoad() {},
    start: function start() {
        this._key = "score" + getWeekOfYear();
        if (getWeekOfYear() == 23) {
            this._key = "x1";
        }
        if (window.wx != undefined) {
            window.wx.showShareMenu({ withShareTicket: true }); //设置分享按钮，方便获取群id展示群排行榜
            this.tex = new cc.Texture2D();
            window.sharedCanvas.width = 720;
            window.sharedCanvas.height = 1280;
            this.setWeek();
            this.submitScoreButtonFunc();
            window.wx.postMessage({
                messageType: 1,
                MAIN_MENU_NUM: this._key
            });
        }
    },
    setWeek: function setWeek() {
        if (cc.sys.localStorage.getItem("week") == null || cc.sys.localStorage.getItem("week") == "") {
            cc.sys.localStorage.setItem("week", 0);
        }
        var thisWeek = getWeekOfYear();
        var saveWeek = parseInt(cc.sys.localStorage.getItem("week"));
        if (thisWeek != saveWeek) {
            var key = "score" + saveWeek;
            this.removeWeekCloudStorage(key);
        }
        if (getWeekOfYear() == 24) {
            this.removeWeekCloudStorage("x1");
        }
        cc.sys.localStorage.setItem("week", thisWeek);
    },
    friendButtonFunc: function friendButtonFunc(event) {
        if (window.wx != undefined) {
            // 发消息给子域
            window.wx.postMessage({
                messageType: 1,
                MAIN_MENU_NUM: this._key
            });
        } else {
            cc.log("获取好友排行榜数据。x1");
        }
    },


    groupFriendButtonFunc: function groupFriendButtonFunc(event) {
        var _this = this;

        if (window.wx != undefined) {
            window.wx.shareAppMessage({
                success: function success(res) {
                    if (res.shareTickets != undefined && res.shareTickets.length > 0) {
                        window.wx.postMessage({
                            messageType: 5,
                            MAIN_MENU_NUM: _this._key,
                            shareTicket: res.shareTickets[0]
                        });
                    }
                }
            });
        } else {
            cc.log("获取群排行榜数据。x1");
        }
    },

    gameOverButtonFunc: function gameOverButtonFunc(event) {
        if (window.wx != undefined) {
            window.wx.postMessage({ // 发消息给子域
                messageType: 4,
                MAIN_MENU_NUM: this._key
            });
        } else {
            cc.log("获取横向展示排行榜数据。x1");
        }
    },

    submitScoreButtonFunc: function submitScoreButtonFunc() {
        // let score = 123;
        if (window.wx != undefined) {
            window.wx.postMessage({
                messageType: 3,
                MAIN_MENU_NUM: this._key,
                score: cc.sys.localStorage.getItem("bestScore" + getWeekOfYear())
            });
        } else {
            cc.log("提交得分: x1 : " + cc.sys.localStorage.getItem("bestScore" + getWeekOfYear()));
        }
    },
    removeWeekCloudStorage: function removeWeekCloudStorage(key) {
        // let score = 123;
        if (window.wx != undefined) {
            window.wx.postMessage({
                messageType: 6,
                MAIN_MENU_NUM: key
            });
        } else {
            cc.log("清除排行榜得分");
        }
    },

    returnButtonFunc: function returnButtonFunc(event) {
        cc.director.loadScene("Home");
    },

    // 刷新子域的纹理
    _updateSubDomainCanvas: function _updateSubDomainCanvas() {
        if (window.sharedCanvas != undefined) {
            this.tex.initWithElement(window.sharedCanvas);
            this.tex.handleLoadedTexture();
            this.rankingScrollView.spriteFrame = new cc.SpriteFrame(this.tex);
        }
    },
    update: function update() {
        this._updateSubDomainCanvas();
    }
});

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=RankingView.js.map
        