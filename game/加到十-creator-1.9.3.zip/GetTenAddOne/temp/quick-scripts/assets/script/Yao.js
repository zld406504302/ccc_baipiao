(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/script/Yao.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, 'f9058+VW2lPyJd6Kd4IBe8v', 'Yao', __filename);
// script/Yao.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {},

    start: function start() {
        var rotateBy1 = cc.rotateBy(0.5, 20, 20);
        var rotateBy2 = cc.rotateBy(0.5, -20, -20);
        var sequence = cc.sequence(rotateBy1, rotateBy2);
        var repeat = cc.repeatForever(sequence);
        this.node.runAction(repeat);
    }
});

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=Yao.js.map
        