(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/script/Colors.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, 'e9e05xFVUZMZJxSkDzATeiN', 'Colors', __filename);
// script/Colors.js

"use strict";

module.exports = {
    startBg: new cc.color(89, 69, 61, 255),
    overBg: new cc.color(89, 69, 61, 255),
    gameBg: new cc.color(89, 69, 61, 255),
    topBg: new cc.color(166, 137, 124, 255),
    tileBg: new cc.color(166, 137, 124, 255),
    powerBarBg: new cc.color(166, 137, 124, 255),
    power: new cc.color(100, 107, 48, 255),
    num1: new cc.color(217, 202, 184, 255),
    num2: new cc.color(191, 177, 159, 255),
    num3: new cc.color(166, 133, 104, 255),
    num4: new cc.color(115, 86, 69, 255),
    num5: new cc.color(64, 40, 32, 255),
    num6: new cc.color(115, 100, 56, 255),
    num7: new cc.color(140, 89, 70, 255),
    num8: new cc.color(115, 56, 50, 255),
    num9: new cc.color(115, 32, 32, 255),
    num10: new cc.color(115, 103, 88, 255),
    num11: new cc.color(140, 121, 97, 255),
    num12: new cc.color(191, 146, 107, 255),
    num13: new cc.color(191, 140, 11, 255),
    num14: new cc.color(213, 185, 112, 255),
    num15: new cc.color(174, 122, 98, 255),
    num16: new cc.color(181, 91, 82, 255),
    num17: new cc.color(107, 86, 85, 255),
    num18: new cc.color(73, 58, 61, 255),
    num19: new cc.color(176, 125, 98, 255),
    num20: new cc.color(232, 171, 127, 255),
    nums: new cc.color(222, 153, 36, 255)
};

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=Colors.js.map
        