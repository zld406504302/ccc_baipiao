(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/script/Start.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '34814nzs3pO+a9mpV/mWE6Q', 'Start', __filename);
// script/Start.js

"use strict";

var Colors = require("Colors");

cc.Class({
    extends: cc.Component,

    properties: {
        gameName: {
            default: null,
            type: cc.Node
        },
        bg: {
            default: null,
            type: cc.Node
        },
        startBtn: {
            default: null,
            type: cc.Node
        },
        btnEffect: cc.AudioClip
    },

    // use this for initialization
    onLoad: function onLoad() {
        // 背景铺平
        this.bg.width = cc.winSize.width;
        this.bg.height = cc.winSize.height;
        this.bg.setPosition(this.bg.width / 2, this.bg.height / 2);
        this.bg.color = Colors.startBg;
        // 设置文字
        var action = cc.repeatForever(cc.sequence(cc.scaleTo(1, 1.5), cc.scaleTo(1, 1)));
        this.gameName.runAction(action);
        this.gameName.setPosition(cc.winSize.width / 2, cc.winSize.height / 2);
        // 设置按钮
        this.startBtn.setPosition(this.gameName.getPositionX(), this.gameName.getPositionY() - 210);
    },

    startGame: function startGame() {
        cc.audioEngine.playEffect(this.btnEffect);
        cc.director.loadScene("gameScene");
    }

    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=Start.js.map
        