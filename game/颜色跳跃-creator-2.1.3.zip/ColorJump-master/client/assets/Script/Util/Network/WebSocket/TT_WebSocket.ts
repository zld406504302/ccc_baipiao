
/**
 * tt websocket 
 */
export class TT_WebSocket {

    private static socketOpen: boolean = false;
    private static socketCount:number=0;

    private static socketMsgQueue = [];

    private static ttSocketTask;

    public static open(url: string) {
        if(TT_WebSocket.socketCount>0) return;
        TT_WebSocket.socketCount++;
        
        this.ttSocketTask= tt.connectSocket({
            url: url,
            // header: {
            //     'content-type': 'arraybuffer'
            //   },
            //protocols: ['protocol1'],
        });

        this.ttSocketTask.onOpen(res=> {
            TT_WebSocket.socketOpen = true;
            for (let i = 0; i < TT_WebSocket.socketMsgQueue.length; i++) {
                TT_WebSocket.send(TT_WebSocket.socketMsgQueue[i]);
            }
            TT_WebSocket.socketMsgQueue = [];
        });

        this.ttSocketTask.onClose(res=> {
            if(TT_WebSocket.onClose){
                TT_WebSocket.onClose(res);
                TT_WebSocket.clear();
            }
        });

        this.ttSocketTask.onError(error=> {
          
            if(TT_WebSocket.onError){
                TT_WebSocket.onError(error);
                TT_WebSocket.clear();
            }
        });

        this.ttSocketTask.onMessage(res=>{
            if(TT_WebSocket.onMessage){
                TT_WebSocket.onMessage(res.data);
            }
        });

    }

    public static send(msg: string | ArrayBuffer) {
      
        if (TT_WebSocket.socketOpen) {
            this.ttSocketTask.send({
                data: msg
            })
        } else {
            TT_WebSocket.socketMsgQueue.push(msg)
        }

    }

    public static close() {
        if(TT_WebSocket.socketOpen){
            TT_WebSocket.clear();
            this.ttSocketTask.close(null);
        }
    }
    private static clear(){
        TT_WebSocket.socketOpen = false;
        TT_WebSocket.onClose=null;
        TT_WebSocket.onMessage=null;
        TT_WebSocket.onError=null;
        TT_WebSocket.socketMsgQueue=[];
        TT_WebSocket.socketCount=0;
    }

    public static onMessage: (data: string | ArrayBuffer) => void;

    public static onClose: (error?: Error) => void;

    public static onError:(error?: Error) => void;

    public static onOpen:() => void;
}