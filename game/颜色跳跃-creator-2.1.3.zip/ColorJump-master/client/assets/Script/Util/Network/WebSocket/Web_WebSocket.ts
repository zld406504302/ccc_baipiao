import { ProtocolType, GameConfig } from "../../../Core/GameConfig";



/**
 * web socket
 */
export class Web_WebSocket{

    private static webSocket: WebSocket;
   
    private static socketOpen: boolean = false;

    private static socketMsgQueue = [];

    public static open(url: string) {
      
        let _webSocket = new WebSocket(url);
        if(GameConfig.ProtocolType==ProtocolType.ByteBuffer){
            _webSocket.binaryType = "arraybuffer";
        }
        _webSocket.onopen = (event: Event) => {
            Web_WebSocket.socketOpen=true;
            Web_WebSocket.webSocket = _webSocket;

            for (let i = 0; i < Web_WebSocket.socketMsgQueue.length; i++) {
                Web_WebSocket.send(Web_WebSocket.socketMsgQueue[i]);
            }
            Web_WebSocket.socketMsgQueue = [];
            Web_WebSocket.onOpen();
        };

        _webSocket.onerror = (event: Event) => {
            Web_WebSocket.socketOpen = false;
            if(Web_WebSocket.onError){
                Web_WebSocket.onError(event);
            }
        };

        _webSocket.onmessage = (message: MessageEvent) => {
            if(Web_WebSocket.onMessage){
                Web_WebSocket.onMessage(message.data);
            }
        };

        _webSocket.onclose = (event: CloseEvent) => {
            Web_WebSocket.socketOpen = false;
            if (Web_WebSocket.onClose) {
                if (event.wasClean === false || event.code !== 1000) {
                    Web_WebSocket.onClose(event);
                } else {
                    Web_WebSocket.onClose(event);
                }
            }
        };


    }

    public static send(msg: string | ArrayBuffer) {
      
        if (Web_WebSocket.socketOpen) {
            Web_WebSocket.webSocket.send(msg);
        } else {
            Web_WebSocket.socketMsgQueue.push(msg)
        }

    }

    public static close() {
        Web_WebSocket.socketOpen = false;
        Web_WebSocket.webSocket.close();
    }

    public static onMessage: (data: string | ArrayBuffer) => void;

    public static onClose: (error?: any) => void;

    public static onError:(error?: any) => void;
  
    public static onOpen:() => void;

}