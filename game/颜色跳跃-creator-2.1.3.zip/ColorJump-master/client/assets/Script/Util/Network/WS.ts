import { WX_WebSocket } from "./WebSocket/WX_WebSocket";
import { Web_WebSocket } from "./WebSocket/Web_WebSocket";

import { TT_WebSocket } from "./WebSocket/TT_WebSocket";
import { GameConfig, PlatformType } from "../../Core/GameConfig";


/**
 * ws websocket
 */
export interface IWS {

    open(url: string);
    send(msg: string | ArrayBuffer);
    close();

    onOpen();
    onMessage(data: string | ArrayBuffer);
    onClose(error?: any);
    onError(error?: any);

}


export class WSCreater {
    public static createInstance(): IWS {
        switch (GameConfig.PlatformType) {
            case PlatformType.Web:
                return Web_WebSocket;
            case PlatformType.WX:
                return WX_WebSocket;
            case PlatformType.TT:
                return TT_WebSocket;
            default:
                return Web_WebSocket;
        }
    }
}