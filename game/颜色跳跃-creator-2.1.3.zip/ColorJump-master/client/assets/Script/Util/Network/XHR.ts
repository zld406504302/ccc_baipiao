import { Web_XHR } from "./XHR/Web_XHR";
import { WX_XHR } from "./XHR/WX_XHR";

import { TT_XHR } from './XHR/TT_XHR';
import { GameConfig, PlatformType } from "../../Core/GameConfig";


export interface IXHR {

    getJSON(url: string, success: Function, fail: Function);
    getJSON_Async(url: string): Promise<string>;

    post(url: string,data:object, success: Function, fail: Function);
    post_Async(url: string,data:object): Promise<string>;
}


export class XHRCreater {

    public static createInstance(): IXHR {
        switch (GameConfig.PlatformType) {
            case PlatformType.Web:
                return Web_XHR;
            case PlatformType.WX:
                return WX_XHR;
            case PlatformType.TT:
                return TT_XHR;
            default:
                return Web_XHR;
        }
    }

}
