
export class TT_XHR {

    /**
     * wx get json
     * @param url 
     * @param success 
     * @param fail 
     */
    public static getJSON(url: string, success: Function, fail: Function) {
        tt.request({
            url: url,
            method: "GET",
            responseType: "text",
            success: function (res) {
                if (success) success(res.data);
            },
            fail: function (res) {
                //console.error('wx get json fail');
                if (fail) fail(res);
            },
        })
    }

    public static post(url: string,data:object, success: Function, fail: Function) {
        tt.request({
            url: url,
            method: "Post",
            responseType: "text",
            data:data,
            success: function (res) {
                if (success) success(res.data);
            },
            fail: function (res) {
                //console.error('wx get json fail');
                if (fail) fail(res);
            },
        })
    }

    public static post_Async(url:string,data:object):Promise<string>{
        return new Promise<string>((resolve,reject)=>{
            tt.request({
                url: url,
                method: "Post",
                responseType: "text",
                data:data,
                success: function (res) {
                    if (resolve) resolve(res.data);
                },
                fail: function (res) {
                    //console.error('wx get json fail');
                    if (reject) reject(res);
                },
            })
        });
    }

    /**
     * wx get json 使用 Promise
     * @param url 
     */
    public static getJSON_Async(url: string): Promise<string> {
        return new Promise<string>((resolve, reject) => {
            tt.request({
                url: url,
                method: "GET",
                responseType: "text",
                success: function (res) {
                    resolve(res.data.toString());
                },
                fail: function (res) {
                    //console.error('wx get json fail');
                    reject(res);
                },
            })
        });

    }

}