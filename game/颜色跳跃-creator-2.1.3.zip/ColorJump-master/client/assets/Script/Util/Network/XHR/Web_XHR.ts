

export class Web_XHR {

    /**
     * get json
     * @param url 地址
     * @param success 成功执行
     * @param fail  失败执行
     */
    public static getJSON(url: string, success: Function, fail: Function) {
        var xhr = new XMLHttpRequest();
        xhr.responseType = 'json';
        xhr.open('GET', url, true);
        xhr.onload = function () {
            if (xhr.status >= 200 && xhr.status < 300) {
                if (success) success(xhr.response);
            } else {
                if (fail) fail(xhr.statusText);
                console.error(xhr.statusText, xhr.status)
            }
        };
        xhr.onerror = (ev:any) => {
            console.error(`Error from HTTP request url=:${url} ${xhr.status}: ${xhr.statusText}`);
            fail(ev);
        };
        xhr.ontimeout = (ev:any) => {
            console.error(`Timeout from HTTP request.`);
            fail(ev);
        };
        xhr.send();
    }


   /**
     * get json
     * @param url 地址
     * @param success 成功执行
     * @param fail  失败执行
     */
    public static post(url: string,data:object, success: Function, fail: Function) {
        var xhr = new XMLHttpRequest();
        xhr.responseType = 'json';
        xhr.setRequestHeader("Content-Type", "application/json");
        xhr.open('post', url, true);
        xhr.onload = function () {
            if (xhr.status >= 200 && xhr.status < 300) {
                if (success) success(xhr.response);
            } else {
                if (fail) fail(xhr.statusText);
                console.error(xhr.statusText, xhr.status)
            }
        };
        xhr.onerror = (ev:any) => {
            console.error(`Error from HTTP request url=:${url} ${xhr.status}: ${xhr.statusText}`);
            fail(ev);
        };
        xhr.ontimeout = (ev:any) => {
            console.error(`Timeout from HTTP request.`);
            fail(ev);
        };
        xhr.send(JSON.stringify(data));
    }
   
    public static post_Async(url: string,data:object) :Promise<string>{
        return new Promise<string>((resolve, reject)=>{
            var xhr = new XMLHttpRequest();
            xhr.responseType = 'json';
            xhr.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
            xhr.open('post', url, true);
            xhr.onload = function () {
                if (xhr.status >= 200 && xhr.status < 300) {
                    if (resolve) resolve(xhr.response);
                } else {
                    if (reject) reject(xhr.statusText);
                    console.error(xhr.statusText, xhr.status)
                }
            };
            xhr.onerror = (ev:any) => {
                console.error(`Error from HTTP request url=:${url} ${xhr.status}: ${xhr.statusText}`);
                reject(ev);
            };
            xhr.ontimeout = (ev:any) => {
                console.error(`Timeout from HTTP request.`);
                reject(ev);
            };
            xhr.send(JSON.stringify(data));
        });
       
    }



    /**
     *  get json 使用 Promise 方式
     * @param url 
     */
    public static getJSON_Async(url: string): Promise<string> {
        return new Promise<string>((resolve, reject) => {
            var xhr = new XMLHttpRequest();
            xhr.responseType = 'text';
            xhr.open('GET', url, true);
            xhr.onload = () => {
                if (xhr.status >= 200 && xhr.status < 300) {
                    resolve(xhr.responseText);
                } else {
                    console.error(xhr.statusText, xhr.status);
                    reject(xhr);
                }
            };
            xhr.onerror = () => {
                console.log(`Error from HTTP request. ${xhr.status}: ${xhr.statusText}`);
                reject(xhr);
            };
            xhr.ontimeout = () => {
                console.log(`Timeout from HTTP request.`);
                reject(xhr);
            };
            xhr.send();
        });
   }
}

