
/**
 * wx websocket 
 */
export class WX_WebSocket {

    private static socketOpen: boolean = false;
    private static socketCount:number=0;

    private static socketMsgQueue = [];

    public static open(url: string) {
        if(this.socketCount>0) return;
        this.socketCount++;
      
        wx.connectSocket({
            url: url,
            tcpNoDelay:true,
            //protocols: ['protocol1'],
        });

        wx.onSocketOpen(function (res) {
            WX_WebSocket.socketOpen = true;
            for (let i = 0; i < WX_WebSocket.socketMsgQueue.length; i++) {
                WX_WebSocket.send(WX_WebSocket.socketMsgQueue[i]);
            }
            WX_WebSocket.socketMsgQueue = [];
            WX_WebSocket.onOpen();
        });

        wx.onSocketClose(function (res) {
            if(WX_WebSocket.onClose){
                WX_WebSocket.onClose(res);
                WX_WebSocket.clear();
            }
        });

        wx.onSocketError(function (res) {
           
            if(WX_WebSocket.onError){
                WX_WebSocket.onError(res);
                WX_WebSocket.clear();
            }
        });

        wx.onSocketMessage((res)=>{
            if(WX_WebSocket.onMessage){
                WX_WebSocket.onMessage(res.data);
            }
        });

    }

    public static send(msg: string | ArrayBuffer) {
      
        if (WX_WebSocket.socketOpen) {
            wx.sendSocketMessage({
                data: msg
            })
        } else {
            WX_WebSocket.socketMsgQueue.push(msg)
        }

    }

    public static close() {
        if(WX_WebSocket.socketOpen){
            WX_WebSocket.clear();
            wx.closeSocket();
        }
       
    }
  
    private static clear(){
        WX_WebSocket.socketOpen = false;
        WX_WebSocket.onClose=null;
        WX_WebSocket.onMessage=null;
        WX_WebSocket.onError=null;
        WX_WebSocket.socketMsgQueue=[];
        WX_WebSocket.socketCount=0;
    }
   

    public static onMessage: (data: string | ArrayBuffer) => void;

    public static onClose: (error?: Error) => void;

    public static onError:(error?: Error) => void;

    public static onOpen:() => void;
}