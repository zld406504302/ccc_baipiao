import { XHRCreater } from "./Network/XHR";

export class Http{
    public static get(url:string):Promise<any>{
        return XHRCreater.createInstance().getJSON_Async(url);
    }
    public static post(url:string,data:Object):Promise<any>{
        return XHRCreater.createInstance().post_Async(url,data);
    }
}