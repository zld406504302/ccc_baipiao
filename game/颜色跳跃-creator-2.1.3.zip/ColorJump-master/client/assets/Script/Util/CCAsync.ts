export class CCAsync {

    public static load(url): Promise<any> {
        return new Promise<any>((resolve, reject) => {
            cc.loader.load(url, function (err, texture) {
                if (err) {
                    reject(err);
                } else {
                    resolve(texture);
                }
            });
        });
    }

}