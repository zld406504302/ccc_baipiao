import { XHRCreater } from "./Network/XHR";
import { CommonResult } from './CommonResult';

declare let tt:any;
// declare let asyncWrap:asyncWrap;


export function asyncWrap<T, U = any>(promise: Promise<T>): Promise<[U | null, T | null]> {
    return promise
        .then<[null, T]>((data: T) => [null, data])
        .catch<[U, null]>(err => [err, null])
}

export async function get<T>(url:string):Promise<CommonResult<T>>{
     var str=await XHRCreater.createInstance().getJSON_Async(url);
     var json=<CommonResult<T>>JSON.parse(str)
     return json
}

export async function post<T>(url:string,data:object):Promise<CommonResult<T>>{
    var str=await XHRCreater.createInstance().post_Async(url,data);
    var json=<CommonResult<T>>JSON.parse(str)
    return json
}

/**
 * 对 tt 中 api 异步的封装
 */
export class TTAsync{

    public static loginAsync():Promise<any>{
        return new Promise<any>((resolve,reject)=>{
            tt.login({
                success(res) {
                    resolve(res);
                },
            });
        });
    }
   
    public static getgetSettingAsync():Promise<any>{
        return new Promise<any>((resolve,reject)=>{
            tt.getSetting({
                success(res) {
                    resolve(res);
                },
            })
        });
    }

    public static getUserInfoAsync():Promise<any>{
        return new Promise<any>((resolve,reject)=>{
            tt.getUserInfo({
                withCredentials: true,
                success(res) {
                    resolve(res);
                },
            })
        });
    }


    public static getSession(clientInfo:any):Promise<any>{
        return new Promise<any>((resolve,reject)=>{
            var url='https://developer.toutiao.com/api/apps/jscode2session?appid='+clientInfo.appid+'&secret='+clientInfo.secret+'&js_code='+clientInfo.code+'&grant_type=authorization_code';  
            tt.request({  
                url: url,  
                data: {},  
                method: 'GET', 
                success: function(res){ 
                    resolve(res);
                }  
            });
        });
    }

}