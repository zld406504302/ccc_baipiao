export class CommonResult<T>{
    public data: T
    public code:CodeStauts
    public msg:String
}

export enum CodeStauts{
    SUCCESS=0,
    ERROR=1,
    NO_DATA=2,
    No_Authorize=3,
}