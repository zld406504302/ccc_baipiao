
export class LocationStorage{
    
    public static get<T>(key:string):T{
        return <T>new Object();
    }

    public static set(key:string,obj:object){

    }



   
}

export class Web_LocalStorage{
    public static get<T>(key:string):T{
       let obj=  localStorage.getItem(key);
       if(!obj) return null;
       return <T>JSON.parse(obj);
    }

    public static set(key:string,obj:object){
        localStorage.setItem(key,JSON.stringify(obj));
    }
}