
/**方便子节点查找 */
cc.Node.prototype.find = function (value) {
  return cc.find(value, this);
}

cc.Node.prototype.find=function (path,typeOrName=null):any {
  if(typeOrName){
    return cc.find(path, this).getComponent(typeOrName);
  }else{
    return cc.find(path, this);
  }
}
/**加载图片
 * url:
 * origin:是否远程
 */
cc.SpriteFrame.prototype.load = function (url: string, isOrigin: boolean = false) {
  let self = this;
  if (isOrigin) {
    cc.loader.load(url, function (err, texture) {
      self = new cc.SpriteFrame(texture);
    });

  } else {
    cc.loader.loadRes(url, cc.SpriteFrame, function (err, spriteFrame) {
      self = spriteFrame
    });
  }
}