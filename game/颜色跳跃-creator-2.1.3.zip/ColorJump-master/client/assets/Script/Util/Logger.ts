import { GameConfig, EnvironmentType } from "../Core/GameConfig";


export class Logger {
    public static info(...any) {
        if (GameConfig.EnvironmentType != EnvironmentType.Produce) {
            console.info(any);
        }
    }
}