
export enum ColorType{
     red="red",
     blue="blue",
     green="green",
     yellow="yellow",
     violet="violet",
     dyellow="dyellow",
}