import { HoomEventCenter } from "./HoomEventCenter";
import { EventType } from "./Model.RoomEvent";
import { ColorType } from './Model.ShadowType';
import { ColorPolicy } from "./ChangeColorPolicy";
import DataSprite from "./Data.Sprite";
import { AudioResource } from "../Core/Resource.Audio";
import { AudioType } from "../Core/AudioType";

const { ccclass, property } = cc._decorator;

@ccclass
export default class BallView extends cc.Component {

    // 主角跳跃高度
    private jumpHeight: number = 320;
    // 主角跳跃持续时间
    private jumpDuration: number = 0.75;
    private currentColor:ColorType=ColorType.violet;
    private ballBgNode:cc.Node;
    onLoad() {
        this.node.runAction(this.setJumpAction());
        this.ballBgNode=this.node.find("background");
    }

    private setJumpAction() {
        var jumpUpFinished = cc.callFunc(this.onHighest, this);
        var jumpUp = cc.sequence(cc.moveBy(this.jumpDuration, cc.v2(0, this.jumpHeight)).easing(cc.easeCubicActionOut()),jumpUpFinished);
        // 下落
        var jumpDownFinished = cc.callFunc(this.onLowest, this);
        var jumpDown =cc.sequence( cc.moveBy(this.jumpDuration, cc.v2(0, -this.jumpHeight)).easing(cc.easeCubicActionIn()),jumpDownFinished);
        // 不断重复
        return cc.repeatForever(cc.sequence(jumpUp, jumpDown));
    }


    private onHighest() {
        HoomEventCenter.emit(EventType.ballHighest,this.currentColor);

      
         //Logger.info("onHighest")
    }

    private onLowest() {
        AudioResource.playByAudioType(AudioType.jump);
        HoomEventCenter.emit(EventType.ballLowest,this.currentColor);
        //change color
        this.currentColor=ColorPolicy.getColorType();

        HoomEventCenter.emit(EventType.ballColorChange, this.currentColor);
        this.ballBgNode.getComponent(cc.Sprite).spriteFrame=DataSprite.getSpriteFrame(this.currentColor);
    }
  
    //产生阴影
    private intervalTime=0;
    update(dt){
        this.intervalTime+=dt;
        if(this.intervalTime<0.04) return;
        this.intervalTime=0;
        HoomEventCenter.emit(EventType.createBallShadow,this.node.position,this.currentColor);
    }


}
