import BallShadow from "./View.BallShadow";
import { HoomEventCenter } from "./HoomEventCenter";
import { EventType } from "./Model.RoomEvent";
import { ColorType } from "./Model.ShadowType";

const {ccclass, property} = cc._decorator;

@ccclass
export default class BallShadowManager extends cc.Component {

    private shadowNode: cc.Node;
    private shadowNodePool: cc.NodePool=new cc.NodePool(BallShadow);

    onLoad () {
        HoomEventCenter.on(EventType.createBallShadow, this.onCreateShadow, this);
        HoomEventCenter.on(EventType.recycleBallShadow, this.onRecycleShadow, this);

        this.shadowNode= this.node.find("shadow");
        this.shadowNodePool=new cc.NodePool(BallShadow);
    }
   
    private onRecycleShadow(node: cc.Node) {
        this.shadowNodePool.put(node);
    }

    private onCreateShadow(position:cc.Vec2,colorType:ColorType){
        let node:cc.Node;
        if(this.shadowNodePool.size()>0) {
            node=this.shadowNodePool.get(BallShadow);
        }else{
           node= cc.instantiate(this.shadowNode);
        }
        node.getComponent(BallShadow).init(position,colorType);
        node.active=true;
        node.setParent(this.node);
    }
 
   
}
