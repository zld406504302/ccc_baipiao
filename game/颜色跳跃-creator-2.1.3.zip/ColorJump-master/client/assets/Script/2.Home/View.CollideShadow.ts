import { ColorType } from "./Model.ShadowType";
import { HoomEventCenter } from "./HoomEventCenter";
import { EventType } from "./Model.RoomEvent";
import DataSprite from "./Data.Sprite";

const { ccclass, property } = cc._decorator;

@ccclass
export default class CollideShadow extends cc.Component {


  public init(colorType: ColorType) {

    this.node.getComponent(cc.Sprite).spriteFrame=DataSprite.getSpriteFrame(colorType);
    
    this.node.setPosition(cc.v2(0,0));
    this.node.scale = 0.6 + (Math.random()) * 0.4;
    this.node.opacity = 100 + (Math.random()) * 150;

    let x = (Math.random() - 0.5) * 250;
    let y = (Math.random() - 0.5) * 250;
    let v2 = cc.v2(x, y);

    let duration = 0.75;

    cc.tween(this.node)
      .by(duration, { scale: 0.1, position: v2 })
      .start();

    cc.tween(this.node)
      .to(duration + 0.1, { opacity: 0 }).call((dt) => this.destroyShadow())
      .start();

  }

  private destroyShadow() {
    HoomEventCenter.emit(EventType.recycleCollideShadow, this.node);
  }

  //重新使用时
  reuse(data: any) {
    // this.node.scale=0.3+(Math.random())*0.4;
    // this.node.opacity=150;
  }
  //回收时
  unuse(data: any) {

  }
}
