import { ColorType } from './Model.ShadowType';
import { Logger } from '../Util/Logger';
export class ColorPolicy {
    public static getColorType() {
        var random = Math.floor(1 + (Math.random()) * 6);
        if (random == 1) return ColorType.yellow;
        if (random == 2) return ColorType.red;
        if (random == 3) return ColorType.blue;
        if (random == 4) return ColorType.dyellow;
        if (random == 5) return ColorType.violet;
        if (random == 6) return ColorType.green;
    }
}

export class RingPolicy {

    public static defaultColorList: Array<ColorType> = [
        ColorType.violet,
        ColorType.dyellow,
        ColorType.blue,
        ColorType.red,
        ColorType.yellow,
        ColorType.green,
    ];

    public static colorList: Array<ColorType> = [
        ColorType.violet,
        ColorType.dyellow,
        ColorType.blue,
        ColorType.red,
        ColorType.yellow,
        ColorType.green,
    ];


    public static setDeafult(){
        this.colorList=this.defaultColorList;
    }

    public static getAngle(colorType: ColorType) {
        let index = RingPolicy.colorList.indexOf(colorType);
        //Logger.info("更改前"+RingPolicy.colorList)
        let angle = RingPolicy.getAngleByIndex(index);
        //重新放置
        let isContinue = true;
        while (isContinue) {
            let type = RingPolicy.colorList.shift();
            if (type == colorType) {
                isContinue = false;
                RingPolicy.colorList.unshift(type);
            } else {
                RingPolicy.colorList.push(type);
            }
        }
        // Logger.info("更改后"+RingPolicy.colorList)
        // Logger.info(angle);
        return angle;
    }

    public static getAngleByIndex(index: number) {

        if (index == 0) return 0;
        if (index == 1) return 60;
        if (index == 2) return 120;
        if (index == 3) return -180;
        if (index == 4) return -120;
        if (index == 5) return -60;
    }


    /*根据颜色得到淡出
    的坐标位置*/
    public static getPositionByColorType(colorType: ColorType) {
        let index = RingPolicy.defaultColorList.indexOf(colorType);
       
        //普通坐标系下
        let angle = 0
        if (index == 0) angle = -90;
        if (index == 1) angle = -150;
        if (index == 2) angle = 150;
        if (index == 3) angle = 90;
        if (index == 4) angle = 30;
        if (index == 5) angle = -30;
        let y=Math.sin(angle*Math.PI/180);
        let x=Math.cos(angle*Math.PI/180);
        return cc.v2(x,y);
    }
}