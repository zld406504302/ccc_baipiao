import { HoomEventCenter } from "./HoomEventCenter";
import { EventType } from "./Model.RoomEvent";
import { ColorType } from './Model.ShadowType';
import { RingPolicy } from "./ChangeColorPolicy";
import { Logger } from '../Util/Logger';

const { ccclass, property } = cc._decorator;

@ccclass
export default class HomeRingView extends cc.Component {

    private currentColorType:ColorType=ColorType.violet;

    onLoad() {
        HoomEventCenter.on(EventType.ballHighest, this.onColorChange, this);
        HoomEventCenter.on(EventType.ballLowest, this.onScaleRing, this);
        //HoomEventCenter.on(EventType.ballHighest, this.onScaleRing, this);
    }

    private onColorChange(nextColorType: ColorType) {
         let angle= RingPolicy.getAngle(nextColorType);
         this.currentColorType=nextColorType;
         cc.tween(this.node).by(0.2, {angle: angle},{easing: "easeOutBounce"})// 
         .delay(0.175)
         .start();
    }

    private onScaleRing() {
        cc.tween(this.node)
            .to(0.075, { scale: 1.2 },{easing: "circInOut"})
            .to(0.075, { scale: 1 },{easing: "circInOut"})//circInOut 
            .start();
    }

}
