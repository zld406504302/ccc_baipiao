import { ColorType } from "./Model.ShadowType";
import { HoomEventCenter } from "./HoomEventCenter";
import { EventType } from "./Model.RoomEvent";
import DataSprite from "./Data.Sprite";


const { ccclass, property } = cc._decorator;

@ccclass
export default class BallShadow extends cc.Component {
    public init(position:cc.Vec2,color: ColorType) {
       
        this.node.getComponent(cc.Sprite).spriteFrame=DataSprite.getSpriteFrame(color);
        
        this.node.setPosition(position);
        this.node.scale=0.3+(Math.random())*0.4;
        this.node.opacity=50+ (Math.random())*200;

        let x= (Math.random()-0.5)*50;
        let y=20+ (Math.random())*50;
        let v2=cc.v2(x,y);

        let duration=0.75+ (Math.random())*0.25;
        
        cc.tween(this.node)
        .by(duration, { scale: 0.1, position: v2 })
        .start();

        cc.tween(this.node)
        .to(duration+0.1, { opacity:0 }).call((dt)=>this.destroyShadow())
        .start();
        
    }

    private destroyShadow() {
        HoomEventCenter.emit(EventType.recycleBallShadow, this.node);
    }

    //重新使用时
    reuse(data: any) {
        // this.node.scale=0.3+(Math.random())*0.4;
        // this.node.opacity=150;
    }
    //回收时
    unuse(data: any) {

    }
   
}
