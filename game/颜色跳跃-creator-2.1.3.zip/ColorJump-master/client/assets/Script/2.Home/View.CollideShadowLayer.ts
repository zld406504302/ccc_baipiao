import CollideShadow from "./View.CollideShadow";
import { HoomEventCenter } from "./HoomEventCenter";
import { EventType } from "./Model.RoomEvent";
import { ColorType } from "./Model.ShadowType";

const {ccclass, property} = cc._decorator;

@ccclass
export default class CollideShadowManager extends cc.Component {


    private shadowNode: cc.Node;
    private shadowNodePool: cc.NodePool=new cc.NodePool(CollideShadow);

    onLoad () {
        HoomEventCenter.on(EventType.ballLowest, this.onCreateShadow, this);
        // HoomEventCenter.on(EventType.createCollideShadow, this.onCreateShadow, this);
        HoomEventCenter.on(EventType.recycleCollideShadow, this.onRecycleShadow, this);

        this.shadowNode= this.node.find("shadow");
        this.shadowNodePool=new cc.NodePool(CollideShadow);
    }
   
    private onRecycleShadow(node: cc.Node) {
        this.shadowNodePool.put(node);
    }

    private onCreateShadow(colorType:ColorType){
        for(let i=0;i<30;i++){
            let node:cc.Node;
            if(this.shadowNodePool.size()>0) {
                node=this.shadowNodePool.get(CollideShadow);
            }else{
               node= cc.instantiate(this.shadowNode);
            }
            node.getComponent(CollideShadow).init(colorType);
            node.active=true;
           
            node.setParent(this.node);
        }
    }
}
