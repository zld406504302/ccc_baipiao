export enum EventType {
    sys_ws_error = "ws_error",
    sys_ws_message = "ws_message",
    sys_ws_close = "ws_close",
    sys_ws_send = "ws_send",
    //设置缩放
    zoom = "onZoom",
    ballHighest = "ballHighest",
    ballLowest = "balllowest",
    createBallShadow = "createBallShadow",
    recycleBallShadow = "recycleBallShadow",
    recycleCollideShadow = "recycleCollideShadow",
    createCollideShadow = "createCollideShadow",
    ballColorChange = "ballColorChange",
    ringColorChage = "ringColorChage",
    playLeft = "playLeft",
    playRight = "playRight",
    gainScore = "gainScore",
    jumpFail = "jumpFail"
}
