import { ColorType } from './Model.ShadowType';

const { ccclass, property } = cc._decorator;

@ccclass
export default class DataSprite extends cc.Component {

    private static Sprites: DataSprite;
    onLoad() {
        DataSprite.Sprites = this;
    }

    public static getSpriteFrame(colorType: ColorType) {
        if (colorType == ColorType.blue) return this.Sprites.blueBall;
        if (colorType == ColorType.dyellow) return this.Sprites.dyellowBall;
        if (colorType == ColorType.green) return this.Sprites.greenBall;
        if (colorType == ColorType.red) return this.Sprites.redBall;
        if (colorType == ColorType.violet) return this.Sprites.violetBall;
        if (colorType == ColorType.yellow) return this.Sprites.yellowBall;
    }

    @property(cc.SpriteFrame)
    redBall: cc.SpriteFrame = null;

    @property(cc.SpriteFrame)
    blueBall: cc.SpriteFrame = null;

    @property(cc.SpriteFrame)
    yellowBall: cc.SpriteFrame = null;

    @property(cc.SpriteFrame)
    violetBall: cc.SpriteFrame = null;

    @property(cc.SpriteFrame)
    dyellowBall: cc.SpriteFrame = null;

    @property(cc.SpriteFrame)
    greenBall: cc.SpriteFrame = null;

    @property(cc.AudioClip)
    jump: cc.AudioClip = null;

    @property(cc.AudioClip)
    btn: cc.AudioClip = null;

    @property(cc.AudioClip)
    fail: cc.AudioClip = null;
}
