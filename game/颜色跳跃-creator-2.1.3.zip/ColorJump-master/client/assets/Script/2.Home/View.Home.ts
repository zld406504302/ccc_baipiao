import { HoomEventCenter } from "./HoomEventCenter";
import { EventType } from "./Model.RoomEvent";
import { RingPolicy } from "./ChangeColorPolicy";
import { ColorType } from './Model.ShadowType';
import { Logger } from '../Util/Logger';
import { AudioResource } from "../Core/Resource.Audio";
import { AudioType } from "../Core/AudioType";

const { ccclass, property } = cc._decorator;

@ccclass
export default class HomeView extends cc.Component {

   private playBtn: cc.Node;
   private sideNode: cc.Node;
   private ringNode: cc.Node;
   onLoad() {
      this.sideNode = this.node.find("content/side");
      this.ringNode = this.node.find("content/ring");
      this.playBtn = this.node.find("buttom/playButton");
      this.playBtn.on("click", this.onPlay, this);
      this.loadResource();

   }
   private onPlay() {
      AudioResource.playByAudioType(AudioType.btn);
      cc.director.preloadScene("3.Room");
      this.sideNode.active = true;
      this.ringNode.active = false;

      //动画
      for (let item of this.sideNode.children) {
         let newPosition = item.position.mulSelf(5);
         cc.tween(item).to(0.5, { position: newPosition }, { easing: "circInOut" }).start();
      }
      //btn
      cc.tween(this.playBtn).by(0.5, { position: cc.v2(0, -400) }, { easing: "circInOut" }).start();

      this.scheduleOnce((dt) => {
         RingPolicy.setDeafult();
         HoomEventCenter.offAll();
         cc.director.loadScene("3.Room");
      }, 0.55);
      //
   }



   /**加载音频 */
   private loadResource() {
      cc.loader.loadResDir("/audio", cc.AudioClip, this.audioProgress.bind(this), this.audioComplete.bind(this));
   }

   private audioComplete(err, textures) {
      Logger.info(textures.name);
      AudioResource.cacheAudioClip(textures);
   }

   private audioProgress(completeCount: number, totalCount: number, res) {
      Logger.info("completeCount:" + completeCount, "totalCount:" + totalCount);
   }

}
