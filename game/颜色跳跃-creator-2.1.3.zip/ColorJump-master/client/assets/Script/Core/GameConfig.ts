
/**
 * 传输协议
 * ttbfc8c97520e23911
 * wx1bc779bbca1f3d17
 * 952466986@qq.com
 */
export enum ProtocolType {
    Json = 1,
    ByteBuffer = 2,
}

/**
 * 环境
 */
export enum EnvironmentType {
    Develop = 1,
    Test = 2,
    Produce = 3,
}
export enum PlatformType
{
    WX = 1,
    TT = 2,
    Web=3,
}

export class GameConfig {

    public static Move_FrameInterval=0.1;
    public static ProtocolType: ProtocolType = ProtocolType.Json;

    public static PlatformType: PlatformType = PlatformType.Web;

    public static EnvironmentType: EnvironmentType = EnvironmentType.Test;
  
    public static OpenId="test";
    
    public static VersionStr="1.0.2";

    /**移动速度 */
    public static SpeedMax = 500;
    public static SpeedDefault = 400;
    public static Speedmin = 200;

    /**地图边界 */
    public static MinX = -1000;
    public static MinY = -1000;
    public static MaxX = 1000;
    public static MaxY = 1000;
    /**top 半径 */
    public static TopRadius = 60;


    public static get_Game_WS_Url() {
        if (this.EnvironmentType == EnvironmentType.Develop) {
            return this.game_url_develop_ws;
        }
        if (this.EnvironmentType == EnvironmentType.Test) {
            return this.game_url_test_ws;
        }
        if (GameConfig.EnvironmentType == EnvironmentType.Produce) {
            return this.game_url_produce_wss;
        }
    }

    public static get_Game_Http_Url(): string {
        if (this.EnvironmentType == EnvironmentType.Develop) {
            return this.game_url_develop_http;
        }
        if (GameConfig.EnvironmentType == EnvironmentType.Test) {
            return this.game_url_test_http;
        }
        if (GameConfig.EnvironmentType == EnvironmentType.Produce) {
            return this.game_url_produce_https;
        }

    };

    public static get_Apply_Room(): string {
        return this.get_Game_Http_Url() + "Game/ApplyRoom"+"?versionStr="+this.VersionStr;
    }

    private static game_url_develop_http = "http://127.0.0.1:8081/";
    private static game_url_test_http = "http://47.107.173.220:8081/";
    private static game_url_produce_https = "https://www.ws-go.com/";

    private static game_url_develop_ws = "ws://127.0.0.1:8082/ws?roomId=1";
    private static game_url_test_ws = "ws://47.107.173.220:8082/ws?roomId=1";
    private static game_url_produce_wss = "wss://www.ws-go.com/ws?roomId=1";
}



