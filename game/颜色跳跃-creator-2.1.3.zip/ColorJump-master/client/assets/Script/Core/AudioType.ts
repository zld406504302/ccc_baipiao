export enum AudioType{
    btn="btn",
    jump="jump",
    fail="fail",
}