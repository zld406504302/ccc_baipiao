import { GameConfig } from "./GameConfig";
import { GlobalStatic } from "./GlobalStatic";
import { Logger } from "../Util/Logger";



/**或许信息可能是异步的：注意 */
export class PlatformPlayerInfo {

    private static userInfoKey="user_Info_Key";

    /**获取本地数据 */
    public static getUserFromStorage() {
        switch (GameConfig.PlatformType) {
            case PlatformType.WX:
                wx.getStorage({
                    key: this.userInfoKey,
                    success(res) {
                        GlobalStatic.UserInfo = <PlayerInfo>res.data;
                        Logger.info("用户信息" + JSON.stringify(res.data))
                    }
                })
                break;
            case PlatformType.TT:
                tt.getStorage({
                    key: this.userInfoKey,
                    success(res) {
                        GlobalStatic.UserInfo = <PlayerInfo>res.data;
                        Logger.info("用户信息" + JSON.stringify(res.data))
                    },
                });
                break;
            default:
                GlobalStatic.UserInfo = GlobalStatic.get_Defualt_PlayerInfo();
                break;
        }
    }

    /**
     * 存储用户数据
     * @param userinfo 
     */
    public static setUserToStorage(userinfo: PlayerInfo) {
        switch (GameConfig.PlatformType) {
            case PlatformType.WX:
                wx.setStorage({
                    key: this.userInfoKey,
                    data: userinfo,
                    success(res) {
                        Logger.info("设置成功" + JSON.stringify(res))
                    }
                })
                break;
            case PlatformType.TT:
                tt.setStorage({
                    key: this.userInfoKey,
                    data: userinfo,
                    success(res) {
                        Logger.info("设置成功" + JSON.stringify(res))
                    }
                });
                break;
            default:
                break;
        }
    }

}