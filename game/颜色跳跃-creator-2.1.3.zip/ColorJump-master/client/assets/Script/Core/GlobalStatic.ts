import { PlatformType } from "./GameConfig";



// /**
//  * 本地存储一下数据
//  */
// export class LocationStorage {

//     constructor() {

//     }

//     public setObject(key: string, value: object) {

//     }

//     public getObjext(key: string) {

//     }
// }

export class PlayerSelectTop{
     public static  topSpriteIndex:number=1;
     public static  playerTopIndex:number=1;
     public static  IsPhoto:boolean=false;
     public static  photoSpriteFrame:cc.SpriteFrame;
}

export enum GenderType{
    male=1,
    female=2
}

export class PlayerInfo
{
    public  ID :string;

    public  Name :string;

    public  Adress :string;

    public GenderType: GenderType

    //public LevelType:LevelType
   
    public PlatformType: PlatformType
  
    public TopIndex:number;
    public UserPhotoUrl:string;
    public Province:string;
    public City:string;
}

/**全局 变量名*/
export class GlobalStatic {

    public static IsExit:boolean=false;
    public static UserInfo:PlayerInfo =null;

    public static ClientId: number;

    public static RoomId: number;

    public static PlayerTopIndex = 1;

    /**是否加速状态 */
    public static IsAccelerated=false;

    /**默认的用户 */
    public static get_Defualt_PlayerInfo(): PlayerInfo {
        var info = new PlayerInfo();
        info.Name = "匿名";
        info.Adress = "北京";
        info.GenderType = GenderType.male;
        info.ID = "01";
        info.PlatformType = PlatformType.Web;
        return info;
    }

    /**用户名字处理 */
    public static UserNamePolice(name:string):string{
        if (name.length <= 6) return name;
        let _name= name[0]+name[1]+"*"+name[name.length-2]+name[name.length-1]
        return _name;
    }
}

