import { GlobalStatic, PlayerInfo } from "./GlobalStatic";
import { GameConfig, PlatformType } from "./GameConfig";
import { Logger } from "../Util/Logger";



const { ccclass, property } = cc._decorator;
@ccclass
export default class PlatformAuthorize extends cc.Component {

    private static userInfoKey="user_Info_Key";

    private wxBtnAuthorize: UserInfoButton;
  
    onLoad() {
        this.getUserFromStorage();
        if (GlobalStatic.UserInfo == null) {
            this.initAuthorize(this.node)
        } else {
            this.node.destroy();
        }
    }

    /**获取本地数据 */
    private getUserFromStorage() {
        let self=this;
        if(GlobalStatic.UserInfo != null) return;
        if (GameConfig.PlatformType == PlatformType.WX) {
            wx.getStorage({
                key: PlatformAuthorize.userInfoKey,
                success (res) {
                    GlobalStatic.UserInfo=  <PlayerInfo>res.data;
                    self.wxBtnAuthorize.destroy();
                    self.node.destroy();
                }
              })
        }
        if (GameConfig.PlatformType == PlatformType.TT) {
            tt.getStorage({
                key: PlatformAuthorize.userInfoKey,
                success (res) {
                  GlobalStatic.UserInfo=  <PlayerInfo>res.data;

                  self.node.destroy();
                },
            });
        }
    }
   
    /**
     * 存储用户数据
     * @param userinfo 
     */
    private setUserToStorage(userinfo:PlayerInfo){
        if (GameConfig.PlatformType == PlatformType.WX) {
            wx.setStorage({
                key: PlatformAuthorize.userInfoKey,
                data: userinfo,
                success(res){
                    //console.info("设置成功"+JSON.stringify(res))
                }
              })
        }
        if (GameConfig.PlatformType == PlatformType.TT) {
            tt.setStorage({
                key: PlatformAuthorize.userInfoKey,
                data: userinfo,
                success(res){
                   // console.info("设置成功"+JSON.stringify(res))
                }
            });
        }
    }

    private initAuthorize(btnNode: cc.Node = null) {
        this.web_get_palyerInfo();
        if (GameConfig.PlatformType == PlatformType.WX) {
            this.createAuthorizeBtn(this.node);
        }
        if (GameConfig.PlatformType == PlatformType.Web) {
            this.node.destroy();
        }
        if (GameConfig.PlatformType == PlatformType.TT) {
            this.createAuthorize_tt()
            this.node.destroy();
        }
    }

    private web_get_palyerInfo() {
        GlobalStatic.UserInfo = GlobalStatic.get_Defualt_PlayerInfo();
    }

    /**真的很绕啊 */
    private createAuthorize_tt() {
        let self=this;
        tt.login({
            success(res) {
                tt.getSetting({
                    success(res) {
                        tt.getUserInfo({
                            withCredentials: true,
                            success(res) {
                                let userInfo = new PlayerInfo();
                                userInfo.Name = GlobalStatic.UserNamePolice(res.userInfo.nickName);
                                //userInfo.GenderType = Number.parseInt(res.userInfo.gender);
                                userInfo.Adress = res.userInfo.city;
                                userInfo.PlatformType = PlatformType.WX;
                                userInfo.ID = "tt没有"
                                GlobalStatic.UserInfo = userInfo;
                                self.setUserToStorage(userInfo);
                            },
                            fail(res) {
                                //console.log(`getUserInfo调用失败${res}`);
                            }
                        })
                    }
                })

            },
            fail(res) {
                //console.log(`login调用失败`);
            }
        });

    }

    private createAuthorizeBtn(btnNode: cc.Node) {
        let self=this;
        let btnSize = cc.size(btnNode.width + 10, btnNode.height + 10);
        let frameSize = cc.view.getFrameSize();
        let winSize = cc.winSize;

        //适配不同机型来创建微信授权按钮
        let left = (winSize.width * 0.5 + btnNode.x - btnSize.width * 0.5) / winSize.width * frameSize.width;
        let top = (winSize.height * 0.5 - btnNode.y - btnSize.height * 0.5) / winSize.height * frameSize.height;
        let width = btnSize.width / winSize.width * frameSize.width;
        let height = btnSize.height / winSize.height * frameSize.height;

        this.wxBtnAuthorize = wx.createUserInfoButton({
            type: 'text',
            text: '',
            style: {
                left: left,
                top: top,
                width: width,
                height: height,
                lineHeight: 0,
                backgroundColor: '',
                color: '#ffffff',
                textAlign: 'center',
                fontSize: 16,
                borderRadius: 4
            }
        })

        this.wxBtnAuthorize.onTap((res) => {
          
            if (res.userInfo) {
                Logger.info("用户信息" + JSON.stringify(res.userInfo))
                let userInfo = new PlayerInfo();
                userInfo.Name = GlobalStatic.UserNamePolice(res.userInfo.nickName);
                userInfo.GenderType = res.userInfo.gender;
                userInfo.Adress = res.userInfo.city;
                userInfo.PlatformType = PlatformType.WX;
                userInfo.UserPhotoUrl=res.userInfo.avatarUrl;
                userInfo.Province=res.userInfo.province;
                userInfo.City=res.userInfo.city;
                userInfo.ID = "wx没有"
                GlobalStatic.UserInfo = userInfo;
                self.setUserToStorage(userInfo);
            }
            this.wxBtnAuthorize.destroy();
            this.node.destroy();
        });
    }
}
