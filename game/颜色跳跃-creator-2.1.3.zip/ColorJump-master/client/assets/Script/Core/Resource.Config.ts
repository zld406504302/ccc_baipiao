import { CCAsync } from '../Util/CCAsync';
import { asyncWrap } from '../Util/TTAsync';
export class ConfigController {


    public  static async loadConfig(){
        let url=  cc.url.raw('resources/test.json');
        let [err,asset] =await asyncWrap(CCAsync.load(url)) ;
        //let areaList = <Area[]>asset.json;
    }


    private test() {
        cc.loader.loadRes("fishconfig", (err, jsonAsset) => {
            //let areaList = <Area[]>jsonAsset.json;
        });
    }
}