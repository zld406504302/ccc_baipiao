import { SpriteType } from './SpriteType';
export class SpriteRes{
   
    
    private static SpriteFrameMap: Map<string, cc.SpriteFrame>=new Map<string, cc.SpriteFrame>();

    public static cacheSpriteFrame(clipArray: Array<cc.SpriteFrame>) {
        for (let index = 0; index < clipArray.length; index++) {
            const clip = clipArray[index];
            this.SpriteFrameMap.set(clip.name, clip);
        }
    }


    public static getByNameKey(key: string):cc.SpriteFrame {
        return this.SpriteFrameMap.get(key);
    }


    public static getByType(type: SpriteType):cc.SpriteFrame {
        return this.SpriteFrameMap.get(type.toString());
    }

}