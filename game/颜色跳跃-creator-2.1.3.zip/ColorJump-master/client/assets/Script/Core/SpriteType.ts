
export enum SpriteType{

     state_busy="state_busy",
     state_defualt="state_deafualt",
     state_disabled="state_disabled",

    gender_female="gender_female",
    gender_Fame="gender_Fame",
  
}