import { RingPolicy } from "../2.Home/ChangeColorPolicy";
import { HoomEventCenter } from "../2.Home/HoomEventCenter";
import { RoomController } from "../3.Room/Controller.Room";
import { AudioResource } from "../Core/Resource.Audio";
import { AudioType } from "../Core/AudioType";

const {ccclass, property} = cc._decorator;

@ccclass
export default class DataView extends cc.Component {

    private homeButton:cc.Node;
    private restartButton:cc.Node;
    private shareButton:cc.Node;

    private scoreLabel:cc.Label;
    private bestScoreLabel:cc.Label;


    onLoad () {
        this.homeButton=this.node.find("buttom/homeButton");
        this.homeButton.on("click",this.onGoHome,this);
        this.restartButton=this.node.find("buttom/restartButton");
        this.restartButton.on("click",this.onRestrart,this);

        this.shareButton=this.node.find("buttom/shareButton");
        this.scoreLabel= this.node.find("Content/score/label").getComponent(cc.Label);
        this.bestScoreLabel=this.node.find("Content/bestscore/label").getComponent(cc.Label);
        this.startAnim();
        
        //set socre
        this.scoreLabel.string=RoomController.score.toString();
        this.bestScoreLabel.string=RoomController.bestScore.toString();
    }

    private onGoHome(){
      
        this.endAnim();
        this.scheduleOnce(() => {
            RingPolicy.setDeafult();
            HoomEventCenter.offAll();
            cc.director.loadScene("2.Home");
        }, 0.51);
    }  
 
    private onRestrart(){
        this.endAnim()
        this.scheduleOnce(() => {
            RingPolicy.setDeafult();
            HoomEventCenter.offAll();
            cc.director.loadScene("3.Room");
        }, 0.51);
    }  
   
    private startAnim() {

        let btnList=new Array<cc.Node>();
        btnList.push(this.homeButton)
        btnList.push(this.shareButton)
        btnList.push(this.restartButton);

        for (let item of btnList) {
            let position = item.getPosition();
             item.setPosition(position.mul(10));
            cc.tween(item).to(0.5, { position: position }, { easing: "circInOut" }).start();
        }

    }

    private endAnim() {
        let btnList=new Array<cc.Node>();
        btnList.push(this.homeButton)
        btnList.push(this.shareButton)
        btnList.push(this.restartButton);
        for (let item of btnList) {
            let position = item.getPosition().mulSelf(10);
            cc.tween(item).to(0.5, { position: position }, { easing: "circInOut" }).start();
        }

    }
  
}
