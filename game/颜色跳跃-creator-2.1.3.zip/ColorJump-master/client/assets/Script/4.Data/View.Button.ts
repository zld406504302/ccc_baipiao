import { Logger } from '../Util/Logger';
import { AudioResource } from '../Core/Resource.Audio';
import { AudioType } from '../Core/AudioType';

const { ccclass, property } = cc._decorator;

@ccclass
export default class ButtonView extends cc.Component {
    onLoad() {
        cc.tween(this.node)
            .repeatForever(
                cc.tween().to(1, { scale: 1.2 })
                    .to(1, { scale: 1 })
            ).start()

        this.node.on("click", () => {
            AudioResource.playByAudioType(AudioType.btn)
        },this)
    }

}
