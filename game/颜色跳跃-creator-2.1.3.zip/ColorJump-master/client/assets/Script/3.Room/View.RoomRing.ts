
import { Logger } from '../Util/Logger';
import { ColorType } from '../2.Home/Model.ShadowType';
import { HoomEventCenter } from '../2.Home/HoomEventCenter';
import { EventType } from '../2.Home/Model.RoomEvent';
import { RingPolicy } from '../2.Home/ChangeColorPolicy';

const { ccclass, property } = cc._decorator;

@ccclass
export default class RoomRingView extends cc.Component {

    private targetAngle:number=0;
    private curentAngle:number=0;
    private angleSpeel:number=0;
    private secondSpeel:number=0.125;
    private ringColorType: ColorType = ColorType.violet;
    private ballColorType: ColorType=ColorType.violet;
  
    onLoad() {

        this.targetAngle= this.node.angle;
        this.curentAngle=this.node.angle;
      
        HoomEventCenter.on(EventType.ballLowest, this.onBallLowest, this);
        //HoomEventCenter.on(EventType.ballLowest, this.onScaleRing, this);

        HoomEventCenter.on(EventType.playLeft, this.onPlayLeft, this);
        HoomEventCenter.on(EventType.playRight, this.onPlayRight, this);
        HoomEventCenter.on(EventType.ballLowest, this.onScaleRing, this);
    }

    private onPlayLeft(nextColorType: ColorType) {
        this.targetAngle+=60;
        let _angle=this.targetAngle-this.curentAngle;
        this.angleSpeel=_angle/this.secondSpeel;

        let index= RingPolicy.defaultColorList.indexOf(this.ringColorType);
        if(index==RingPolicy.defaultColorList.length-1) {
              //最后一位
            this.ringColorType=RingPolicy.defaultColorList[0]
        }else{
            this.ringColorType=RingPolicy.defaultColorList[index+1];
        }
      
    }

    private onPlayRight(colorType: ColorType) {
        this.targetAngle-=60;
        let _angle=this.targetAngle-this.curentAngle;
        this.angleSpeel=_angle/this.secondSpeel;

        let index= RingPolicy.defaultColorList.indexOf(this.ringColorType);
        if(index==0) {
          
            this.ringColorType=RingPolicy.defaultColorList[RingPolicy.defaultColorList.length-1]
        }else{
            this.ringColorType=RingPolicy.defaultColorList[index-1];
        }
      
    }


    private onBallLowest(colorType: ColorType) {
        this.ballColorType = colorType;
        // Logger.info("ring:"+this.ringColorType)
        // Logger.info("ball:"+ this.ballColorType)
        if(this.ballColorType==this.ringColorType){
            HoomEventCenter.emit(EventType.gainScore, 1);
        }else{
            HoomEventCenter.emit(EventType.jumpFail);
        }
    }

    private onScaleRing() {
        cc.tween(this.node)
            // .by(0.075, { scale: 0.2 }, { easing: "circInOut" })
            // .by(0.075, { scale: -0.2 }, { easing: "circInOut" })//circInOut 
            .by(0.075, { scale: 0.1 }, { easing: "circInOut" })
            .by(0.075, { scale: -0.1 }, { easing: "circInOut" })
            .delay(0.1)
            .start();
    }
   
 
    update(dt){

       if(this.angleSpeel==0) return;

       let differAngle=this.targetAngle-this.curentAngle;
       let _angle=this.angleSpeel*dt;

       if(Math.abs(differAngle)<Math.abs(_angle)) {
           this.angleSpeel=0;
           this.node.angle+=differAngle;  
           this.curentAngle=this.node.angle;
           return;
        }
        this.node.angle+=_angle;
        this.curentAngle=this.node.angle;
    }
}
