import { HoomEventCenter } from "../2.Home/HoomEventCenter";
import { EventType } from "../2.Home/Model.RoomEvent";
import { Logger } from '../Util/Logger';
import { RingPolicy } from "../2.Home/ChangeColorPolicy";
import { RoomController } from "./Controller.Room";
import { AudioResource } from "../Core/Resource.Audio";
import { AudioType } from "../Core/AudioType";

const { ccclass, property } = cc._decorator;

@ccclass
export default class RoomView extends cc.Component {


    private sideNode: cc.Node;
    private ringNode: cc.Node;
    private leftBtn: cc.Node;
    private rightBtn: cc.Node;
    private scoreLable: cc.Label;
    private currentSocore: number = 0;

    onLoad() {

        HoomEventCenter.on(EventType.gainScore, this.onGainScore, this);
        HoomEventCenter.on(EventType.jumpFail, this.onJumpFail, this);

        this.sideNode = this.node.find("content/side");
        this.ringNode = this.node.find("content/ring");
        this.leftBtn = this.node.find("/bottom/leftBtn");
        this.rightBtn = this.node.find("/bottom/rightBtn");
        this.scoreLable = this.node.find("/content/score/label").getComponent(cc.Label);


        this.leftBtn.on("click", this.onPlayLeft, this);
        this.rightBtn.on("click", this.onPlayRight, this);

        this.startAnim();
    }

    private onPlayLeft() {
        HoomEventCenter.emit(EventType.playLeft);
    }

    private onPlayRight() {
        HoomEventCenter.emit(EventType.playRight);
    }

    private onGainScore(scroe: number = 1) {
        this.currentSocore += scroe;
        this.scoreLable.string = this.currentSocore.toString();
    }

    private onJumpFail() {
        Logger.info("onJumpFail");
        AudioResource.playByAudioType(AudioType.fail);
        this.endAnim();
    }

    private startAnim() {

        this.sideNode.active = true;
        this.ringNode.active = false;
        //动画
        for (let item of this.sideNode.children) {
            let oldPosition = item.position;
            let newPosition = oldPosition.mul(5);
            item.position = newPosition;
            cc.tween(item).to(0.5, { position: oldPosition }, { easing: "circInOut" }).start();
        }
        //btn
        let leftPosition = this.leftBtn.getPosition();
        this.leftBtn.setPosition(leftPosition.mul(5));
        cc.tween(this.leftBtn).to(0.5, { position: leftPosition }, { easing: "circInOut" }).start();

        let rightPosition = this.rightBtn.getPosition();
        this.rightBtn.setPosition(rightPosition.mul(5))
        cc.tween(this.rightBtn).to(0.5, { position: rightPosition }, { easing: "circInOut" }).start();

        this.scheduleOnce(() => {
            this.sideNode.active = false;
            this.ringNode.active = true;
        }, 0.51);

    }

    private endAnim() {
        this.ringNode.active = false;
        this.sideNode.active = true;
        //动画
        for (let item of this.sideNode.children) {
            let position = item.position.mulSelf(5);
            cc.tween(item).to(0.5, { position: position }, { easing: "circInOut" }).start();
        }
        //btn
        let leftPosition = this.leftBtn.getPosition().mulSelf(5);
        cc.tween(this.leftBtn).to(0.5, { position: leftPosition }, { easing: "circInOut" }).start();

        let rightPosition = this.rightBtn.getPosition().mulSelf(5);;
        cc.tween(this.rightBtn).to(0.5, { position: rightPosition }, { easing: "circInOut" }).start();

        this.scheduleOnce(() => {
            RingPolicy.setDeafult();
            HoomEventCenter.offAll();
            RoomController.score=this.currentSocore;
            cc.director.loadScene("4.Data");
        }, 0.51);


    }

}
