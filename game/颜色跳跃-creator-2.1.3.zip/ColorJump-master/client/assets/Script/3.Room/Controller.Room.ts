
export class RoomController{

    public static score:number=0;
    public static bestScore:number=120;
    
}