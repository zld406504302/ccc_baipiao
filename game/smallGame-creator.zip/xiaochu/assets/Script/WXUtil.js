
var WXUtil = {
    

    //分享
    shareAppMessage: function () {
        wx.shareAppMessage({
            title: '又失败了，可以帮我过一关吗',
            imageUrl: cc.url.raw("resources/fenxiang.png")
        })
    },
    //添加广告
    createBannerAd:function(){
        let bannerAd = wx.createBannerAd({
            adUnitId: 'wxf24e821685027c73',
            adIntervals: 30,
            style: {
              left: 10,
              top: 76,
              width: 320
            }
          })
          
          bannerAd.show()

    },
    //开启上方分享功能
    openShare:function(){
        if (typeof wx === 'undefined') {
            return;
        }
        wx.showShareMenu() 
        wx.onShareAppMessage(function () {
        return {
            title: '又失败了，可以帮我过一关吗',
            imageUrl: cc.url.raw("resources/fenxiang.png")
        }
        })
        
    }

}

module.exports = WXUtil