

//var wxUtil = require("WXUtil");
const WXData = require('WXUtil')
cc.Class({
    extends: cc.Component,

    properties: {
        startGame:cc.Node,
        share:cc.Node,
        rank:cc.Node,
        rankPage:cc.Node,
        colseRank:cc.Node,
        display: cc.Sprite,
        pk:cc.Node,

    },

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start () {


        this.startGame.on(cc.Node.EventType.TOUCH_START,(event)=> {
            cc.director.loadScene("mainScene")
               
        });
        this.share.on(cc.Node.EventType.TOUCH_START,(event)=>{
            WXData.shareAppMessage()
         });
         this.rank.on(cc.Node.EventType.TOUCH_START,(event)=>{
             this.rankPage.active=true
         });
         this.colseRank.on(cc.Node.EventType.TOUCH_START,(event)=>{
            this.rankPage.active=false         
        });
        this.pk.on(cc.Node.EventType.TOUCH_START,(event)=>{
            cc.director.loadScene("pk")
        });
        var seq = cc.repeatForever(
            cc.sequence(
                cc.scaleTo(1, 1.3, 1.3),
                cc.scaleTo(1, 1, 1)
            ));
        this.startGame.runAction(seq)
    },

    // update () {
    // },
});
