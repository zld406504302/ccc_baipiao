
const WXData = require('WXUtil')

cc.Class({
    extends: cc.Component,

    properties: {
        //5种方块
        red:cc.Prefab,
        green:cc.Prefab,
        pink:cc.Prefab,
        blue:cc.Prefab,
        yellow:cc.Prefab,
        blockNull:cc.Prefab,
        background:cc.Node,//背景
        blockBackground:cc.Node,//背景
        ground:cc.Node,//背景
        fail:cc.Node,//失败页面
        success:cc.Node,//成功页面
        next:cc.Node,//下一关
        success_share:cc.Node,//成功页面分享
        fail_share:cc.Node,//失败页面分享
        restart:cc.Node,//重新开始
        home:cc.Node,//主页
        surplusTime:cc.Label,//剩余时间
        good:cc.Prefab,//good效果
        great:cc.Prefab,//great效果
        
        desEffect:cc.Prefab,//消失特效
        sorce:cc.Prefab,//分数字
        tips:cc.Node,//提示信息

        //对战信息
        selfName:cc.Label,
        enemyName:cc.Label,
        selfIcon:cc.Sprite,
        enemyIcon:cc.Sprite,
        selfSorce:cc.Label,
        enemySorce:cc.Label,
        enemyNameJson:cc.JsonAsset,
        pipei_selfName:cc.Label,
        pipei_selfIcon:cc.Sprite,
        pipei_enemyName:cc.Label,
        pipei_enemyIcon:cc.Sprite,
        pipei:cc.Node,
        daojishi:cc.Label,


        audio_Dianji:{//点击音效
            type:cc.AudioClip,
            default:null,
        }


        
    },

    // LIFE-CYCLE CALLBACKS:

    onLoad () {


        this.AllSorce=0//当前总分数
        //this.reload()//初始化场景
        this.loadIocn()//初始化对战信息

    },

    initBlock:function(){
        this.a=new Array()
        this.b=new Array()
        for(var i=0;i<10;i++){
            this.a[i]=new Array()
            this.b[i]=new Array()

            for(var j=0;j<10;j++){
                this.a[i][j]=Math.ceil(Math.random()*5)
                var blockNull=cc.instantiate(this.blockNull)
                blockNull.parent = this.blockBackground || this.node
                blockNull.setPosition(this.ToXY(i,j))

                switch (this.a[i][j]) {
                    case 1:
                        var node=cc.instantiate(this.red)
                        node.parent = this.background || this.node
                        node.setPosition(this.ToXY(i,j))
                        break;
                    case 2:
                        var node=cc.instantiate(this.green)
                        node.parent = this.background || this.node
                        node.setPosition(this.ToXY(i,j))
                         break;
                    case 3:
                        var node=cc.instantiate(this.pink)
                        node.parent = this.background || this.node
                        node.setPosition(this.ToXY(i,j))
                         break;
                    case 4:
                        var node=cc.instantiate(this.blue)
                        node.parent = this.background || this.node
                        node.setPosition(this.ToXY(i,j))
                         break;
                    case 5:
                        var node=cc.instantiate(this.yellow)
                        node.parent = this.background || this.node
                        node.setPosition(this.ToXY(i,j))
        
                }
                this.b[i][j]=node
            }    
 
        }
    },

    start () {

        this.ground.on(cc.Node.EventType.TOUCH_START,(event)=> {
            var windowSize=cc.winSize;
            var x = event.getLocationX()
            var y = event.getLocationY()
            this.Delete_num=0
            
            if(y>windowSize.height/2-370 && y<windowSize.height/2+370){
                 var i=this.ToIJ(x,y).x
                 var j=this.ToIJ(x,y).y
                 this.Touch_block(i,j,this.a[i][j])
                 this.Delete_block()
                 this.goodFunction(this.Delete_num)

            }   
        });
        this.next.on(cc.Node.EventType.TOUCH_START,(event)=>{
            cc.audioEngine.play(this.audio_Dianji, false, 1)
            this.success.active=false
            this.onLoad()
        })
        this.success_share.on(cc.Node.EventType.TOUCH_START,(event)=>{
            cc.audioEngine.play(this.audio_Dianji, false, 1)
            WXData.shareAppMessage()
        })
        this.restart.on(cc.Node.EventType.TOUCH_START,(event)=>{
            cc.audioEngine.play(this.audio_Dianji, false, 1)
            this.fail.active=false
            this.onLoad()

        })
        this.fail_share.on(cc.Node.EventType.TOUCH_START,(event)=>{
            cc.audioEngine.play(this.audio_Dianji, false, 1)
            WXData.shareAppMessage()
        })
        this.home.on(cc.Node.EventType.TOUCH_START,(event)=>{
            cc.audioEngine.play(this.audio_Dianji, false, 1)
            cc.director.loadScene("mainIndex")
        })


    },

    reload:function(){
        this.blockNum=100
        this.allTime=30
        this.enemySorceNum=0
        this.background.destroyAllChildren()
        this.blockBackground.destroyAllChildren()
        this.tips.active = false
        
        this.schedule(()=> {
            this.allTime-=1
            this.surplusTime.string=this.allTime
            this.enemySorceNum=this.enemySorceNum + Math.ceil(Math.floor(Math.random()*100)/10)*10
            this.enemySorce.string = "分数:" + this.enemySorceNum
            if(this.allTime<=0){
                this.endGame()
            }
        }, 1, 29, 1);

    },

    //判定游戏是否结束函数
    endGame:function(){
        //如果剩余数量为0则判断为结束
        if(this.AllSorce>this.enemySorceNum){
            this.success.active=true
        }else{
            this.fail.active=true
        }
    },



    Touch_block:function(i,j,k){

        if(this.a[i][j]==k && k>0){
            this.a[i][j]=0
            this.Delete_num++
            //创建特效
            var node=cc.instantiate(this.desEffect)
            node.parent=this.background || this.node
            node.setPosition(this.ToXY(i,j))
            var CustomParticle = node.getComponent(cc.ParticleSystem);
            CustomParticle.resetSystem();
            //创建分数
            var sorce=cc.instantiate(this.sorce)
            sorce.parent=this.background || this.sorce
            sorce.setPosition(this.ToXY(i,j))
            sorce.getComponent(cc.Label).string=this.Delete_num*10-5
            this.AllSorce+=this.Delete_num*10-5
            //移动分数
            
            var action=cc.moveTo(1,-150,450)
            sorce.runAction(cc.sequence(action,cc.callFunc(()=>{
                sorce.destroy()
                this.selfSorce.string="分数:" + this.AllSorce
            })))


            this.b[i][j].destroy()
            this.b[i][j]=null
            this.blockNum-=1
            cc.log(this.blockNum)
            if(this.blockNum<=0){
                this.tips.active=true
            }            
            if(i!=0){
                this.Touch_block(i-1,j,k)
            }
            if(i!=9){
                this.Touch_block(i+1,j,k)
            }
            if(j!=0){
                this.Touch_block(i,j-1,k)
            }
            if(j!=9){
                this.Touch_block(i,j+1,k)
            }

        }
    },

    Delete_block:function(){

        for (var j=0;j<10;j++){
            var num=0
            for (var i=9;i>=0;i--){
                if(this.a[i][j]>0 && num>0){
                    var action=cc.moveBy(0.3,0,-num*74)
                    this.b[i][j].runAction(action)
                    this.a[i+num][j]=this.a[i][j]
                    this.a[i][j]=0
                    this.b[i+num][j]=this.b[i][j]
                    this.b[i][j]=null
                    continue
                }
                if(this.a[i][j]==0){
                    num=num+1
                }

            }
        }

        var count=0
        for (var j=0;j<10;j++){

            if(this.a[9][j]>0 && count>0){

                for (var i=0;i<10;i++){
                    if(this.a[i][j]>0){
                        var action=cc.moveBy(0.3,-count*74,0)
                        this.b[i][j].runAction(action)
                        this.a[i][j-count]=this.a[i][j]
                        this.a[i][j]=0
                        this.b[i][j-count]=this.b[i][j]
                        this.b[i][j]=null
                    }

                }
                continue
            }
            if(this.a[9][j]==0){
                count++
            }
        }


    },

    ToIJ:function(i,j){
        var windowSize=cc.winSize;
        if(j<windowSize.height/2-370 || j>windowSize.height/2+370){
            return
        }
        else{

            i=Math.floor((i-5)/74)
            j=Math.floor((windowSize.height/2+375-j)/74)
            return{
                x:j,
                y:i
            } 
        }
    },
    ToXY:function(x,y){
        return cc.v2(-(370-(36+y*74)),370-(36+x*74))
    },
    goodFunction:function(num){
        if(num>=5 && num<7){

            var good=cc.instantiate(this.good)
            good.parent=this.background || this.great
            good.runAction(cc.sequence(cc.scaleTo(0.1, 0.5, 0.5),cc.scaleTo(0.5, 0.6, 0.6),cc.callFunc(()=>{
                good.destroy()
            })))
        }
        if(num>=7){
            var great=cc.instantiate(this.great)
            great.parent=this.background || this.gerat
            great.runAction(cc.sequence(cc.scaleTo(0.1, 0.5, 0.5),cc.scaleTo(0.5, 0.6, 0.6),cc.callFunc(()=>{
                great.destroy()
            })))


        }

    },
    loadIocn:function(){
        this.pipei.active=true

        var count=0
        this.schedule(()=> {
        count+=1
        var i=Math.floor(Math.random()*50)+1
        var enemyIcon="head"+i
        var enemyName=this.enemyNameJson.json[i-1].q_name
        cc.loader.loadRes(enemyIcon, cc.SpriteFrame, (err, spriteFrame)=> {
            this.enemyIcon.spriteFrame=spriteFrame;
            this.enemyName.string=enemyName;
            this.pipei_enemyIcon.spriteFrame=spriteFrame
            this.pipei_enemyName.string=enemyName
        });
        this.daojishi.string="已等待" + Math.floor(count/2) + "秒"
        if(count>=8){
            this.pipei.active=false
            this.reload()
            this.initBlock()  
        }
        cc.log(count)
            
        }, 0.5, 7, 0.5);

        

        if (typeof wx === 'undefined') {
            return;
        }
        wx.getUserInfo({
            success:(res)=>{
            
            this.pipei_selfName.string = res.userInfo.nickName
            cc.loader.load({ url: res.userInfo.avatarUrl, type: 'png' }, (err, texture) => {
            if (err) return
            this.pipei_selfIcon.spriteFrame = new cc.SpriteFrame(texture);
            })


            this.selfName.string = res.userInfo.nickName
            cc.loader.load({ url: res.userInfo.avatarUrl, type: 'png' }, (err, texture) => {
            if (err) return
            this.selfIcon.spriteFrame = new cc.SpriteFrame(texture);
            })

            }
        })


    },

    // update (dt) {},
});
