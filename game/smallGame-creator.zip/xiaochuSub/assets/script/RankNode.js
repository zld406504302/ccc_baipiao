﻿cc.Class({
    extends: cc.Component,

    properties: {
        rankLabel: cc.Label,
        head: cc.Sprite,
        nameLabel: cc.Label,
        levelLabel: cc.Label
    },

    load: function (index, info) {
        this.rankLabel.string = index
        this.nameLabel.string = info.nickname
        this.levelLabel.string = info.KVDataList[0].value + '关'
        cc.loader.load({ url: info.avatarUrl, type: 'png' }, (err, texture) => {
            if (err) return
            this.head.spriteFrame = new cc.SpriteFrame(texture);
        })
    }
});
