//
// api: https://developers.weixin.qq.com/minigame/dev/document/open-api/data/wx.getUserInfo.html
//
cc.Class({
    extends: cc.Component,

    properties: {

        content: cc.Node,
        prefab: cc.Prefab,

    },

    start () {

        if (typeof wx === 'undefined') {
            return;
        }

        wx.onMessage( data => {
            if (data.message) {
                console.log(data.message);
            }
        });

        this.initTips();
        this.initFriendInfo();
    },

    initTips () {
        let renderTypeStr = 'Canvas';
        if (cc.game.renderType === cc.game.RENDER_TYPE_WEBGL) {
            renderTypeStr = 'WEBGL';
        }
    },

    initFriendInfo () {
	console.log("friedn info ")
        wx.getFriendCloudStorage({
            keyList: ['level'],
            success: (res) => {
                cc.log(res)
                for (let i = 0; i < res.data.length; ++i) {
                    var node=cc.instantiate(this.prefab)
                    node.parent=this.content
                    node.x=0
                    node.getComponent('RankNode').load(i+1,res.data[i])
                }
            },
            fail: (res) => {
                console.error(res);
            }
        });
    },
});
