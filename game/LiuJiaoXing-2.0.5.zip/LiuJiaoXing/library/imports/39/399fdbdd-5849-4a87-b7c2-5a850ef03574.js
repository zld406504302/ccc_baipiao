"use strict";
cc._RF.push(module, '399fdvdWElKh7fCWoUO8DV0', 'Cube');
// Script/gameplay/Cube.js

"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.Cube = exports.CubeType = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _dec, _class, _desc, _value, _class2, _descriptor;

var _MRes = require("../framework/MRes");

var _MRes2 = _interopRequireDefault(_MRes);

var _Global = require("../framework/Global");

var _GamePlay = require("./GamePlay");

var _GamePlay2 = _interopRequireDefault(_GamePlay);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _initDefineProp(target, property, descriptor, context) {
    if (!descriptor) return;
    Object.defineProperty(target, property, {
        enumerable: descriptor.enumerable,
        configurable: descriptor.configurable,
        writable: descriptor.writable,
        value: descriptor.initializer ? descriptor.initializer.call(context) : void 0
    });
}

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) {
    var desc = {};
    Object['ke' + 'ys'](descriptor).forEach(function (key) {
        desc[key] = descriptor[key];
    });
    desc.enumerable = !!desc.enumerable;
    desc.configurable = !!desc.configurable;

    if ('value' in desc || desc.initializer) {
        desc.writable = true;
    }

    desc = decorators.slice().reverse().reduce(function (desc, decorator) {
        return decorator(target, property, desc) || desc;
    }, desc);

    if (context && desc.initializer !== void 0) {
        desc.value = desc.initializer ? desc.initializer.call(context) : void 0;
        desc.initializer = undefined;
    }

    if (desc.initializer === void 0) {
        Object['define' + 'Property'](target, property, desc);
        desc = null;
    }

    return desc;
}

function _initializerWarningHelper(descriptor, context) {
    throw new Error('Decorating class property failed. Please ensure that transform-class-properties is enabled.');
}

var _cc$_decorator = cc._decorator,
    ccclass = _cc$_decorator.ccclass,
    property = _cc$_decorator.property;

/** 配置函数 */

var C = {
    /** 单个cube的碰撞器位置 */
    CL_SINGLE: cc.v2(0, 0),
    /** 横向cube的碰撞器位置 */
    CL_HOR: cc.v2(-37.5, 0),
    /** 左斜cube的碰撞器位置 */
    CL_LEFT: cc.v2(-21.75, 36),
    /** 右斜cube的碰撞器位置 */
    CL_RIGHT: cc.v2(21.75, 36),
    /** 旋转动画时间 */
    TIME_ROTATION: 0.2,
    /** 随机概率 */
    PROBABILITY: {
        // type
        T_SINGLE: 0.1,
        T_HOR: 0.3,
        T_LEFT: 0.3,
        T_RIGHT: 0.3,
        // value
        V_1: 0.3,
        V_2: 0.3,
        V_3: 0.15,
        V_4: 0.15,
        V_5: 0.05,
        V_6: 0.05
    }
};

var CubeType = exports.CubeType = {
    /** 单个 */
    SINGLE: Symbol("SINGLE"),
    /** 横向 */
    HOR: Symbol("HOR"),
    /** 顶部向左倾斜 */
    LEFT: Symbol("LEFT"),
    /** 顶部向右倾斜 */
    RIGHT: Symbol("RIGHT")

    /**
     * 单个cube的数据
     */
};var Cube = exports.Cube = (_dec = property(cc.Node), ccclass(_class = (_class2 = function (_cc$Component) {
    _inherits(Cube, _cc$Component);

    function Cube() {
        var _ref;

        var _temp, _this, _ret;

        _classCallCheck(this, Cube);

        for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
        }

        return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = Cube.__proto__ || Object.getPrototypeOf(Cube)).call.apply(_ref, [this].concat(args))), _this), _initDefineProp(_this, "cube_node_array", _descriptor, _this), _temp), _possibleConstructorReturn(_this, _ret);
    }

    /** @type {Cube} */


    /** @type {[cc.Node]} */


    _createClass(Cube, [{
        key: "onLoad",
        value: function onLoad() {
            /** cube形状 */
            this.type;
            /** cube方向；true表示正向，false表示反向；默认为true */
            this.direction = true;
            /** @type {boolean} 如果有副点，副点的值是否与主点相同 */
            this.is_same = false;
            /** cube主点的value */
            this.v;
            /** cube副点的value */
            this.next_v;
            /** 碰撞器 */
            this.cl = this.node.getComponent(cc.CircleCollider);
            /** @type {[CubeType]} 可行type数组 */
            this.type_array;
            /** @type {[number]} 可行value数组 */
            this.value_array;

            Cube.ins = this;
        }

        /** 更新cube的随机信息
         * @returns {boolean}
         */

    }, {
        key: "update_cube_info",
        value: function update_cube_info() {
            this.type_array = [];
            this.value_array = [];

            this.type_array = Array.from(_GamePlay2.default.ins.game.empty_type());
            this.value_array = Array.from(_GamePlay2.default.ins.game.empty_value());

            // 无法创建，则调用游戏失败
            if (this.type_array.length === 0) {
                _GamePlay2.default.ins.game_fail();
                return false;
            }
            // 创建成功
            return true;
        }

        /** 获取一个随机type
         * - 先按照概率计算一次
         * - 如果没有当前的type，则按照平均概率再计算一次
         */

    }, {
        key: "random_type",
        value: function random_type() {
            var r = Math.random();
            var type = void 0;
            if (r < C.PROBABILITY.T_SINGLE) {
                type = CubeType.SINGLE;
            } else if (r < C.PROBABILITY.T_SINGLE + C.PROBABILITY.T_HOR) {
                type = CubeType.HOR;
            } else if (r < C.PROBABILITY.T_SINGLE + C.PROBABILITY.T_HOR + C.PROBABILITY.T_LEFT) {
                type = CubeType.LEFT;
            } else {
                type = CubeType.RIGHT;
            }
            ///!!! 重点注意：Array.include()方法，由于微信小游戏未支持，所以不要使用！
            if (!new Set(this.type_array).has(type)) {
                return _Global.G.random_item_form_array(this.type_array);
            } else {
                return type;
            }
        }

        /** 获取一个随机value
         * - 算法同random_type()
         */

    }, {
        key: "random_value",
        value: function random_value() {
            var r = Math.random();
            var value = void 0;
            if (r < C.PROBABILITY.V_1) {
                value = 1;
            } else if (r < C.PROBABILITY.V_1 + C.PROBABILITY.V_2) {
                value = 2;
            } else if (r < C.PROBABILITY.V_1 + C.PROBABILITY.V_2 + C.PROBABILITY.V_3) {
                value = 3;
            } else if (r < C.PROBABILITY.V_1 + C.PROBABILITY.V_2 + C.PROBABILITY.V_3 + C.PROBABILITY.V_4) {
                value = 4;
            } else if (r < C.PROBABILITY.V_1 + C.PROBABILITY.V_2 + C.PROBABILITY.V_3 + C.PROBABILITY.V_4 + C.PROBABILITY.V_5) {
                value = 5;
            } else {
                value = 6;
            }
            ///!!! 同random_type()
            if (!new Set(this.value_array).has(value)) {
                return _Global.G.random_item_form_array(this.value_array);
            } else {
                return value;
            }
        }

        /**
         * 创建一个随机cube
         */

    }, {
        key: "create_random_cube",
        value: function create_random_cube() {
            // 获取随机信息失败
            if (!this.update_cube_info()) {
                return;
            }

            var type = this.random_type();
            // test
            // let type = CubeType.HOR
            switch (type) {
                case CubeType.SINGLE:
                    this.create_random_single_cube();
                    break;
                case CubeType.HOR:
                    this.create_random_hor_cube();
                    break;
                case CubeType.LEFT:
                    this.create_random_left_cube();
                    break;
                case CubeType.RIGHT:
                    this.create_random_right_cube();
                    break;
                default:
                    break;
            }
            // 构建is_same
            if (this.next_v === this.v) {
                this.is_same = true;
            } else {
                this.is_same = false;
            }
        }

        /** 创建一个随机cube，并且与当前的cube不同 */

    }, {
        key: "create_different_random_cube",
        value: function create_different_random_cube() {
            var _this2 = this;

            var old_cube = {
                type: this.type,
                v: this.v,
                next_v: this.next_v
            };
            return new Promise(function (resolve, reject) {
                var f = function f() {
                    _this2.create_random_cube();
                    if (_this2.type === old_cube.type && _this2.v === old_cube.v && _this2.next_v === old_cube.next_v) {
                        return f();
                    } else {
                        resolve();
                    }
                };
                f();
            });
        }

        /** 创建一个单个cube */

    }, {
        key: "create_random_single_cube",
        value: function create_random_single_cube() {
            // 数据
            this.type = CubeType.SINGLE;
            this.v = this.random_value();
            this.next_v = null;
            // 样式
            this.un_active_all_children_cube();
            this.cube_node_array[0].active = true;
            this.cube_node_array[0].getComponent(cc.Sprite).spriteFrame = this.sf;
            // 碰撞器
            this.cl.offset = C.CL_SINGLE;
        }

        /** 创建一个横向cube */

    }, {
        key: "create_random_hor_cube",
        value: function create_random_hor_cube() {
            // 数据
            this.type = CubeType.HOR;
            this.v = this.random_value();
            this.next_v = this.random_value();
            // 样式
            this.un_active_all_children_cube();
            this.cube_node_array[1].active = true;
            this.cube_node_array[2].active = true;
            this.cube_node_array[1].getComponent(cc.Sprite).spriteFrame = this.sf;
            this.cube_node_array[2].getComponent(cc.Sprite).spriteFrame = this.next_sf;
            // 碰撞器
            this.cl.offset = C.CL_HOR;
        }

        /** 创建一个左斜cube */

    }, {
        key: "create_random_left_cube",
        value: function create_random_left_cube() {
            // 数据
            this.type = CubeType.LEFT;
            this.v = this.random_value();
            this.next_v = this.random_value();
            // 样式
            this.un_active_all_children_cube();
            this.cube_node_array[3].active = true;
            this.cube_node_array[4].active = true;
            this.cube_node_array[3].getComponent(cc.Sprite).spriteFrame = this.sf;
            this.cube_node_array[4].getComponent(cc.Sprite).spriteFrame = this.next_sf;
            // 碰撞器
            this.cl.offset = C.CL_LEFT;
        }

        /** 创建一个右斜cube */

    }, {
        key: "create_random_right_cube",
        value: function create_random_right_cube() {
            // 数据
            this.type = CubeType.RIGHT;
            this.v = this.random_value();
            this.next_v = this.random_value();
            // 样式
            this.un_active_all_children_cube();
            this.cube_node_array[5].active = true;
            this.cube_node_array[6].active = true;
            this.cube_node_array[5].getComponent(cc.Sprite).spriteFrame = this.sf;
            this.cube_node_array[6].getComponent(cc.Sprite).spriteFrame = this.next_sf;
            // 碰撞器
            this.cl.offset = C.CL_RIGHT;
        }

        /** active=false所有的子node */

    }, {
        key: "un_active_all_children_cube",
        value: function un_active_all_children_cube() {
            this.cube_node_array.forEach(function (e) {
                e.active = false;
            });
        }

        /** 旋转180度 */

    }, {
        key: "rotate",
        value: function rotate() {
            if (this.rotate_count === undefined) {
                // 旋转次数
                this.rotate_count = 0;
            }
            this.rotate_count++;
            if (this.rotate_count === 1) {
                this.rotate_180();
            }
        }

        /** 
         * 旋转动作列表
         * - 不要改动，我也不知道为啥能实现！
         */

    }, {
        key: "rotate_180",
        value: function rotate_180() {
            var _this3 = this;

            return new Promise(function (resolve, reject) {
                if (_this3.rotate_count === 0) {
                    resolve();
                    return;
                }
                var action = cc.sequence(cc.rotateBy(C.TIME_ROTATION, 180), cc.callFunc(function () {
                    Cube.ins.direction = !Cube.ins.direction;
                    _this3.rotate_count--;
                    if (_this3.rotate_count >= 1) {
                        _this3.rotate_count = 1;
                    }
                    _this3.rotate_180();
                }));
                _this3.node.runAction(action);
            });
        }
    }, {
        key: "sf",


        /** @type {cc.SpriteFrame} 主点spriteframe */
        get: function get() {
            return _MRes2.default.ins.array_cube[this.v];
        }

        /** @type {cc.SpriteFrame} 副点spriteframe */

    }, {
        key: "next_sf",
        get: function get() {
            return _MRes2.default.ins.array_cube[this.next_v];
        }

        /** @type {cc.Vec2} 当前node的position */

    }, {
        key: "position",
        set: function set(pos) {
            this.node.position = pos;
        },
        get: function get() {
            return this.node.position;
        }

        /** @type {number} 当前node的rotation */

    }, {
        key: "rotation",
        set: function set(roa) {
            this.node.rotation = roa;
        },
        get: function get() {
            return this.node.rotation;
        }

        /** @type {number} 当前node的scale */

    }, {
        key: "scale",
        set: function set(scale) {
            this.node.scale = scale;
        },
        get: function get() {
            return this.node.scale;
        }
    }]);

    return Cube;
}(cc.Component), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "cube_node_array", [_dec], {
    enumerable: true,
    initializer: function initializer() {
        return [];
    }
})), _class2)) || _class);

cc._RF.pop();