"use strict";
cc._RF.push(module, '58f71XSqcBMgpJi0aO3OKZT', 'GameDraw');
// Script/gameplay/GameDraw.js

"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.default = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _dec, _dec2, _dec3, _dec4, _class, _desc, _value, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4;

var _GamePlay = require("./GamePlay");

var _GamePlay2 = _interopRequireDefault(_GamePlay);

var _MRes = require("../framework/MRes");

var _MRes2 = _interopRequireDefault(_MRes);

var _LocalData = require("../framework/LocalData");

var _Game = require("./Game");

var _Game2 = _interopRequireDefault(_Game);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _initDefineProp(target, property, descriptor, context) {
    if (!descriptor) return;
    Object.defineProperty(target, property, {
        enumerable: descriptor.enumerable,
        configurable: descriptor.configurable,
        writable: descriptor.writable,
        value: descriptor.initializer ? descriptor.initializer.call(context) : void 0
    });
}

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) {
    var desc = {};
    Object['ke' + 'ys'](descriptor).forEach(function (key) {
        desc[key] = descriptor[key];
    });
    desc.enumerable = !!desc.enumerable;
    desc.configurable = !!desc.configurable;

    if ('value' in desc || desc.initializer) {
        desc.writable = true;
    }

    desc = decorators.slice().reverse().reduce(function (desc, decorator) {
        return decorator(target, property, desc) || desc;
    }, desc);

    if (context && desc.initializer !== void 0) {
        desc.value = desc.initializer ? desc.initializer.call(context) : void 0;
        desc.initializer = undefined;
    }

    if (desc.initializer === void 0) {
        Object['define' + 'Property'](target, property, desc);
        desc = null;
    }

    return desc;
}

function _initializerWarningHelper(descriptor, context) {
    throw new Error('Decorating class property failed. Please ensure that transform-class-properties is enabled.');
}

var _cc$_decorator = cc._decorator,
    ccclass = _cc$_decorator.ccclass,
    property = _cc$_decorator.property;

/** 配置参数 */

var C = {
    /** 每一行的偏移量 */
    CUBELINE_OFFSET: { X: 43.5, Y: 72 },
    /** 每一行的间隔 */
    LATOUT_SPACE: 10,
    /** cubeshadow动画时间 */
    SHADOW_TIME: 0.5,
    /** 行数 */
    ROW: 7,
    /** 列数 */
    COL: 7

    /**
     * 游戏绘制封装类
     */
};var GameDraw = (_dec = property(cc.Prefab), _dec2 = property(cc.Node), _dec3 = property(cc.Node), _dec4 = property(cc.Prefab), ccclass(_class = (_class2 = function (_cc$Component) {
    _inherits(GameDraw, _cc$Component);

    function GameDraw() {
        var _ref;

        var _temp, _this, _ret;

        _classCallCheck(this, GameDraw);

        for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
        }

        return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = GameDraw.__proto__ || Object.getPrototypeOf(GameDraw)).call.apply(_ref, [this].concat(args))), _this), _initDefineProp(_this, "cube_bg_prefab", _descriptor, _this), _initDefineProp(_this, "cube_bg_parent", _descriptor2, _this), _initDefineProp(_this, "shadow_parent", _descriptor3, _this), _initDefineProp(_this, "shadow_prefab", _descriptor4, _this), _temp), _possibleConstructorReturn(_this, _ret);
    }
    /** @type {GameDraw} */


    /** @type {cc.Prefab} */


    /** @type {cc.Node} */


    /** @type {cc.Node} 影子父节点 */


    /** @type {cc.Prefab} 影子prefab */


    _createClass(GameDraw, [{
        key: "onLoad",
        value: function onLoad() {
            /** cube节点数组 */
            this.cube_array = Array.of();

            // 初始化所有的cube
            this.draw_cube_bg();

            GameDraw.ins = this;
        }

        /**
         * 获取某一个cube
         * @param {cc.Vec2} p
         * @returns {cc.Node} 
         */

    }, {
        key: "get_cube",
        value: function get_cube(p) {
            try {
                return this.cube_array[p.x][p.y];
            } catch (error) {
                // 注意此处只能return undefined
                // 因为array[m][-1]=undefined
                return;
            }
        }

        /** 
         * 绘制所有的cube背景
         * - 每一行为一个layout（配置为：）
         * - 每一行均有7个点
         * - 单数行向右偏移半个格子
         */

    }, {
        key: "draw_cube_bg",
        value: function draw_cube_bg() {
            for (var x = 0; x < C.ROW; x++) {
                // 新建存储
                this.cube_array.push(Array.of());
                // 配置node
                var cube_line = new cc.Node("cube_line");
                cube_line.parent = this.cube_bg_parent;
                cube_line.y = C.CUBELINE_OFFSET.Y * (3 - x);
                if (x % 2 === 0) {
                    cube_line.x = C.CUBELINE_OFFSET.X;
                }
                // 配置layout
                var layout = cube_line.addComponent(cc.Layout);
                layout.type = cc.Layout.Type.HORIZONTAL;
                layout.resizeMode = cc.Layout.ResizeMode.CONTAINER;
                layout.spacingX = C.LATOUT_SPACE;
                // 创建7个子cube
                for (var y = 0; y < C.COL; y++) {
                    var cube_bg = cc.instantiate(this.cube_bg_prefab);
                    cube_bg.parent = cube_line;
                    // 存储每一个小cube
                    this.cube_array[x].push(cube_bg);
                    // 在node上存储p
                    ///! （感觉并不应该这样写！）
                    cube_bg.p = cc.v2(x, y);
                }
            }
        }

        /** 
         * 根据数据刷新所有的cube背景
         * - 请紧接着draw_cube_bg()后调用
         */

    }, {
        key: "update_cube_bg",
        value: function update_cube_bg() {
            var game = _GamePlay2.default.ins.game;
            for (var x = 0; x < game.map_array.length; x++) {
                for (var y = 0; y < game.map_array[x].length; y++) {
                    var p = cc.v2(x, y);
                    if (game.get_p_value(p) === -1) {
                        // 不能使用active，否则会打乱layout中其他节点的顺序
                        // this.get_cube(p).active = false
                        // 通过删除sprite的方式隐藏
                        this.change_cube_sprite(p, null);
                        continue;
                    }
                    this.change_cube_sprite(p, _MRes2.default.ins.array_cube[game.get_p_value(p)]);
                }
            }
        }
    }, {
        key: "pMult",
        value: function pMult(point, floatVar) {
            return cc.v2(point.x * floatVar, point.y * floatVar);
        }
    }, {
        key: "pDot",
        value: function pDot(v1, v2) {
            return v1.x * v2.x + v1.y * v2.y;
        }
    }, {
        key: "pLengthSQ",
        value: function pLengthSQ(v) {
            return this.pDot(v, v);
        }
    }, {
        key: "pLength",
        value: function pLength(v) {
            return Math.sqrt(this.pLengthSQ(v));
        }
    }, {
        key: "pNormalize",
        value: function pNormalize(v) {
            var n = this.pLength(v);
            return n === 0 ? cc.v2(v) : this.pMult(v, 1.0 / n);
        }
    }, {
        key: "pAngleSigned",
        value: function pAngleSigned(a, b) {
            var POINT_EPSILON = parseFloat('1.192092896e-07F');
            var a2 = this.pNormalize(a);
            var b2 = this.pNormalize(b);
            var angle = Math.atan2(a2.x * b2.y - a2.y * b2.x, this.pDot(a2, b2));
            if (Math.abs(angle) < POINT_EPSILON) return 0.0;
            return angle;
        }

        /**
         * 单点合并的动画（1次）
         * @param {cc.Vec2} p 合并的主点
         * @param {[cc.Vec2]} m_array 合并的其他点
         */

    }, {
        key: "merge_animation",
        value: function merge_animation(p, m_array) {
            var _this2 = this;

            /** 合并主点的position（相对于cc.Vec2.ZERO） */
            var p0 = this.get_cube(p).position.add(this.get_cube(p).parent.position);
            /** 影子的spriteframe */
            var shadow_sf = _MRes2.default.ins.array_cube_shadow[_GamePlay2.default.ins.game.get_p_value(p)];
            // 根据合并数组合并所有的点
            m_array.forEach(function (e) {
                // 获取当前点的信息
                var e_node = _this2.get_cube(e);
                if (e_node === undefined) {
                    return;
                }
                var e_sp = e_node.getComponent(cc.Sprite);
                if (e_sp.spriteFrame === null) {
                    return;
                }
                // 注意上面两个特殊情况的return：不合并不存在的点；不合并值为-1的点
                // 修改当前点的sf
                e_sp.spriteFrame = _MRes2.default.ins.array_cube[0];
                // 新建一个影子
                var s = cc.instantiate(_this2.shadow_prefab);
                s.parent = _this2.shadow_parent;
                s.position = e_node.position.add(e_node.parent.position);
                s.getComponent(cc.Sprite).spriteFrame = shadow_sf;
                /** 其中一个副点的position */
                var p1 = s.position;
                // 计算影子角度
                var a = _this2.pAngleSigned(cc.v2(1, 0), p0.sub(p1));
                s.rotation = -a * 180 / Math.PI;
                // 影子动作
                var action = cc.sequence(cc.spawn(cc.moveTo(C.SHADOW_TIME, p0), cc.fadeOut(C.SHADOW_TIME)), cc.callFunc(function () {
                    // 移除影子
                    s.removeFromParent();
                }));
                s.runAction(action);
            });
            // 动画结束后修改数据
            // 使用Promise进行包装
            return new Promise(function (resolve, reject) {
                _this2.scheduleOnce(function () {
                    // // 动画结束后再调整数据
                    // // 判定8的特殊情况
                    // if (GamePlay.ins.game.get_p_value(p) === 7) {
                    //     let m_array = GamePlay.ins.game.merge_all_around(p)
                    //     this.merge_cube_bg(p, m_array)
                    //     this.get_cube(p).getComponent(cc.Sprite).spriteFrame = MRes.ins.array_cube[0]
                    //     GamePlay.ins.score += 100
                    // } else if (GamePlay.ins.game.get_p_value(p) < 7) {
                    //     GamePlay.ins.game.merge(p)
                    //     this.get_cube(p).getComponent(cc.Sprite).spriteFrame = MRes.ins.array_cube[GamePlay.ins.game.get_p_value(p)]
                    // } else {
                    //     //
                    // }
                    // // 加分
                    // if (GamePlay.ins.game.get_p_value(p) === 0) {
                    //     ///! 可以预见的一个bug是，get_p_value(p)=0的情况下，分数异常；即全消除的情况下，分数异常
                    //     /// 通过这个方式解决
                    //     return
                    // }
                    // GamePlay.ins.score += (m_array.length + 1) * (GamePlay.ins.game.get_p_value(p) - 1)
                    if (_GamePlay2.default.ins.game.get_p_value(p) >= 7) {
                        _this2.change_cube_sprite(p, _MRes2.default.ins.array_cube[0]);
                    } else {
                        _this2.change_cube_sprite(p, _MRes2.default.ins.array_cube[_GamePlay2.default.ins.game.get_p_value(p) + 1]);
                    }
                    resolve();
                    // 并不在绘制过程中修改数据，而是在外部显式调用then()去修改数据
                }, C.SHADOW_TIME);
            });
        }

        /**
         * 更改cube的spriteframe
         * @param {cc.Vec2} p 
         * @param {cc.SpriteFrame} sf 
         */

    }, {
        key: "change_cube_sprite",
        value: function change_cube_sprite(p, sf) {
            this.get_cube(p).getComponent(cc.Sprite).spriteFrame = sf;
        }
    }]);

    return GameDraw;
}(cc.Component), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "cube_bg_prefab", [_dec], {
    enumerable: true,
    initializer: function initializer() {
        return null;
    }
}), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "cube_bg_parent", [_dec2], {
    enumerable: true,
    initializer: function initializer() {
        return null;
    }
}), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "shadow_parent", [_dec3], {
    enumerable: true,
    initializer: function initializer() {
        return null;
    }
}), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "shadow_prefab", [_dec4], {
    enumerable: true,
    initializer: function initializer() {
        return null;
    }
})), _class2)) || _class);
exports.default = GameDraw;
module.exports = exports["default"];

cc._RF.pop();