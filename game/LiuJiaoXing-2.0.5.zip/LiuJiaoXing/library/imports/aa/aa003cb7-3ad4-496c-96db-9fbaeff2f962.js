"use strict";
cc._RF.push(module, 'aa003y3OtRJbJbbn7rv8vli', 'PanelBase');
// Script/framework/PanelBase.js

"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

/** 配置参数 */
var C = {
    /** 默认动作时间 */
    DEFAULT_TIME: 0.2

    /**
     * 框架文件：游戏窗口的方法封装类
     * @author fengyong
     * @class
     */
};
var PanelBase = function () {

    /**
     * 构造函数：传入窗口的根节点
     * @param {cc.Node} node 窗口根节点
     */
    function PanelBase(node) {
        _classCallCheck(this, PanelBase);

        this.node = node;
    }

    /** 
     * 窗口节点
     * @type {cc.Node}
     */


    _createClass(PanelBase, [{
        key: "show",


        /**
         * 封装方法：显示窗口
         * - 为了统一窗口显示方式，在外部调用时尽量只通过这个方法
         */
        value: function show() {
            this.node.stopAllActions();
            // 特别要注意这里
            // 可能会出现多次调用hide()方法，但是当第一个hide()方法执行成功后，节点隐藏，其余的hide()方法为静默状态
            // 下次show()的时候，则会继续执行静默的hide()方法，导致界面异常隐藏掉

            // 设置默认的显示方式
            this.show_with_scale();
        }

        /**
         * 封装方法：隐藏窗口
         * - 为了统一窗口隐藏方式，在外部调用时尽量只通过这个方法
         */

    }, {
        key: "hide",
        value: function hide() {
            this.hide_with_scale();
        }

        //////////
        // 以下方法为具体show和hide实现方法
        //////////

        /** 显示窗口：没有任何动画 */

    }, {
        key: "show_with_nothing",
        value: function show_with_nothing() {
            this.node.active = true;
        }

        /** 隐藏窗口：没有任何动画 */

    }, {
        key: "hide_with_nothing",
        value: function hide_with_nothing() {
            this.node.active = false;
        }

        /** 
         * 显示窗口：放大缩小动画
         * @returns {number} action time
         */

    }, {
        key: "show_with_scale",
        value: function show_with_scale() {
            var time = C.DEFAULT_TIME;
            var action = cc.scaleTo(time, 1);

            // 前摇
            // 特别注意：只有当node.active为true时，才可以执行动作；因此在前摇结束后需要保证node.active为true
            this.node.scale = 0;
            this.show_with_nothing();
            // 动作
            this.node.runAction(action);

            return time;
        }

        /** 隐藏窗口：放大缩小动画
         * @returns {number} action time
         */

    }, {
        key: "hide_with_scale",
        value: function hide_with_scale() {
            var _this = this;

            var time = C.DEFAULT_TIME;
            var action = cc.sequence(cc.scaleTo(time, 0), cc.callFunc(function () {
                _this.hide_with_nothing();
            }));

            // 前摇
            // 动作
            this.node.runAction(action);

            return time;
        }
    }, {
        key: "node",
        get: function get() {
            return this._node;
        },
        set: function set(node) {
            this._node = node;
        }
    }]);

    return PanelBase;
}();

exports.default = PanelBase;
module.exports = exports["default"];

cc._RF.pop();