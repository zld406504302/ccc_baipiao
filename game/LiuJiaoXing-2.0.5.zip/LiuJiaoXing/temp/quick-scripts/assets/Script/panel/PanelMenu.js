(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/Script/panel/PanelMenu.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '986ec4NP1lLPKD6VhFA+H/6', 'PanelMenu', __filename);
// Script/panel/PanelMenu.js

"use strict";

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _dec, _dec2, _class, _desc, _value, _class2, _descriptor, _descriptor2;

var _MPanel = require("../framework/MPanel");

var _MPanel2 = _interopRequireDefault(_MPanel);

var _Global = require("../framework/Global");

var _GamePlay = require("../gameplay/GamePlay");

var _GamePlay2 = _interopRequireDefault(_GamePlay);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _initDefineProp(target, property, descriptor, context) {
    if (!descriptor) return;
    Object.defineProperty(target, property, {
        enumerable: descriptor.enumerable,
        configurable: descriptor.configurable,
        writable: descriptor.writable,
        value: descriptor.initializer ? descriptor.initializer.call(context) : void 0
    });
}

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) {
    var desc = {};
    Object['ke' + 'ys'](descriptor).forEach(function (key) {
        desc[key] = descriptor[key];
    });
    desc.enumerable = !!desc.enumerable;
    desc.configurable = !!desc.configurable;

    if ('value' in desc || desc.initializer) {
        desc.writable = true;
    }

    desc = decorators.slice().reverse().reduce(function (desc, decorator) {
        return decorator(target, property, desc) || desc;
    }, desc);

    if (context && desc.initializer !== void 0) {
        desc.value = desc.initializer ? desc.initializer.call(context) : void 0;
        desc.initializer = undefined;
    }

    if (desc.initializer === void 0) {
        Object['define' + 'Property'](target, property, desc);
        desc = null;
    }

    return desc;
}

function _initializerWarningHelper(descriptor, context) {
    throw new Error('Decorating class property failed. Please ensure that transform-class-properties is enabled.');
}

var _cc$_decorator = cc._decorator,
    ccclass = _cc$_decorator.ccclass,
    property = _cc$_decorator.property;

/** 配置参数 */

var C = {
    /** 旋转一圈的时间 */
    CIRCLE_TIME: 15

    /**
     * Menu界面
     */
};var PanelMenu = (_dec = property(cc.Node), _dec2 = property(cc.Node), ccclass(_class = (_class2 = function (_cc$Component) {
    _inherits(PanelMenu, _cc$Component);

    function PanelMenu() {
        var _ref;

        var _temp, _this, _ret;

        _classCallCheck(this, PanelMenu);

        for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
        }

        return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = PanelMenu.__proto__ || Object.getPrototypeOf(PanelMenu)).call.apply(_ref, [this].concat(args))), _this), _initDefineProp(_this, "start_btn", _descriptor, _this), _initDefineProp(_this, "rank_btn", _descriptor2, _this), _temp), _possibleConstructorReturn(_this, _ret);
    }

    /** @type {cc.Node} rank_btn */


    _createClass(PanelMenu, [{
        key: "onLoad",
        value: function onLoad() {
            /** 得到封装的UIPanel方法 */
            // this.ui = new PanelBase(this.node)
        }
    }, {
        key: "start",
        value: function start() {
            this.set_event_start();
        }

        /** 开始按钮的点击处理 */

    }, {
        key: "set_event_start",
        value: function set_event_start() {
            var _this2 = this;

            _Global.G.set_event(this.start_btn, true, function () {
                cc.log("[点击事件]", _this2.name, _this2.start_btn.name);
                _MPanel2.default.ins.panel_hide("PanelMenu");
                _MPanel2.default.ins.panel_show("PanelGame");
            });
        }
    }]);

    return PanelMenu;
}(cc.Component), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "start_btn", [_dec], {
    enumerable: true,
    initializer: function initializer() {
        return null;
    }
}), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "rank_btn", [_dec2], {
    enumerable: true,
    initializer: function initializer() {
        return null;
    }
})), _class2)) || _class);

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=PanelMenu.js.map
        