(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/Script/panel/PanelScore.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '8e1beQgRQRDC5vaLWjh+zd0', 'PanelScore', __filename);
// Script/panel/PanelScore.js

"use strict";

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _dec, _dec2, _dec3, _dec4, _dec5, _class, _desc, _value, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4, _descriptor5;

var _MPanel = require("../framework/MPanel");

var _MPanel2 = _interopRequireDefault(_MPanel);

var _Global = require("../framework/Global");

var _GamePlay = require("../gameplay/GamePlay");

var _GamePlay2 = _interopRequireDefault(_GamePlay);

var _LocalData = require("../framework/LocalData");

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _initDefineProp(target, property, descriptor, context) {
    if (!descriptor) return;
    Object.defineProperty(target, property, {
        enumerable: descriptor.enumerable,
        configurable: descriptor.configurable,
        writable: descriptor.writable,
        value: descriptor.initializer ? descriptor.initializer.call(context) : void 0
    });
}

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) {
    var desc = {};
    Object['ke' + 'ys'](descriptor).forEach(function (key) {
        desc[key] = descriptor[key];
    });
    desc.enumerable = !!desc.enumerable;
    desc.configurable = !!desc.configurable;

    if ('value' in desc || desc.initializer) {
        desc.writable = true;
    }

    desc = decorators.slice().reverse().reduce(function (desc, decorator) {
        return decorator(target, property, desc) || desc;
    }, desc);

    if (context && desc.initializer !== void 0) {
        desc.value = desc.initializer ? desc.initializer.call(context) : void 0;
        desc.initializer = undefined;
    }

    if (desc.initializer === void 0) {
        Object['define' + 'Property'](target, property, desc);
        desc = null;
    }

    return desc;
}

function _initializerWarningHelper(descriptor, context) {
    throw new Error('Decorating class property failed. Please ensure that transform-class-properties is enabled.');
}

var _cc$_decorator = cc._decorator,
    ccclass = _cc$_decorator.ccclass,
    property = _cc$_decorator.property;

/** 配置参数 */

var C = {};

/**
 * Score界面
 */
var PanelScore = (_dec = property(cc.Node), _dec2 = property(cc.Node), _dec3 = property(cc.Node), _dec4 = property(cc.Label), _dec5 = property(cc.Label), ccclass(_class = (_class2 = function (_cc$Component) {
    _inherits(PanelScore, _cc$Component);

    function PanelScore() {
        var _ref;

        var _temp, _this, _ret;

        _classCallCheck(this, PanelScore);

        for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
        }

        return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = PanelScore.__proto__ || Object.getPrototypeOf(PanelScore)).call.apply(_ref, [this].concat(args))), _this), _initDefineProp(_this, "btn_restart", _descriptor, _this), _initDefineProp(_this, "btn_back", _descriptor2, _this), _initDefineProp(_this, "btn_share", _descriptor3, _this), _initDefineProp(_this, "score_label", _descriptor4, _this), _initDefineProp(_this, "max_score_label", _descriptor5, _this), _temp), _possibleConstructorReturn(_this, _ret);
    }

    /** @type {cc.Node} */


    /** @type {cc.Node} */


    /** @type {cc.Label} 分数label */


    /** @type {cc.Label} 最高分数label */


    _createClass(PanelScore, [{
        key: "onLoad",
        value: function onLoad() {
            /** 得到封装的UIPanel方法 */
            // this.ui = new PanelBase(this.node)

            this.set_event_restart();
            this.set_event_back();
            this.set_event_share();

            this.is_first = true;
        }
    }, {
        key: "onEnable",
        value: function onEnable() {
            if (this.is_first) {
                this.is_first = false;
                return;
            }
            this.update_score();
        }

        /** 更新两个分数 */

    }, {
        key: "update_score",
        value: function update_score() {
            this.score_label.string = _GamePlay2.default.ins.score;
            this.max_score_label.string = _LocalData.L.max_score;
        }

        /** restart按钮的点击事件 */

    }, {
        key: "set_event_restart",
        value: function set_event_restart() {
            var _this2 = this;

            _Global.G.set_event(this.btn_restart, true, function () {
                cc.log("[点击事件]", _this2.name, _this2.btn_restart.name);
                _GamePlay2.default.ins.game_restart();
                _MPanel2.default.ins.panel_hide("PanelScore");
            });
        }

        /** back按钮的点击事件 */

    }, {
        key: "set_event_back",
        value: function set_event_back() {
            var _this3 = this;

            _Global.G.set_event(this.btn_back, true, function () {
                cc.log("[点击事件]", _this3.name, _this3.btn_back.name);
                _MPanel2.default.ins.panel_hide("PanelScore");
                _MPanel2.default.ins.panel_hide("PanelGame");
                _MPanel2.default.ins.panel_show("PanelMenu");
            });
        }

        /** share按钮的点击事件 */

    }, {
        key: "set_event_share",
        value: function set_event_share() {
            var _this4 = this;

            _Global.G.set_event(this.btn_share, true, function () {
                cc.log("[点击事件]", _this4.name, _this4.btn_share.name);
            });
        }
    }]);

    return PanelScore;
}(cc.Component), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "btn_restart", [_dec], {
    enumerable: true,
    initializer: function initializer() {
        return null;
    }
}), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "btn_back", [_dec2], {
    enumerable: true,
    initializer: function initializer() {
        return null;
    }
}), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "btn_share", [_dec3], {
    enumerable: true,
    initializer: function initializer() {
        return null;
    }
}), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "score_label", [_dec4], {
    enumerable: true,
    initializer: function initializer() {
        return null;
    }
}), _descriptor5 = _applyDecoratedDescriptor(_class2.prototype, "max_score_label", [_dec5], {
    enumerable: true,
    initializer: function initializer() {
        return null;
    }
})), _class2)) || _class);

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=PanelScore.js.map
        