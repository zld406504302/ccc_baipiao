(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/Script/panel/PanelPause.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '8ed35PuV/pJgKnsb8S4LGdI', 'PanelPause', __filename);
// Script/panel/PanelPause.js

"use strict";

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _dec, _dec2, _dec3, _dec4, _class, _desc, _value, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4;

var _MPanel = require("../framework/MPanel");

var _MPanel2 = _interopRequireDefault(_MPanel);

var _Global = require("../framework/Global");

var _GamePlay = require("../gameplay/GamePlay");

var _GamePlay2 = _interopRequireDefault(_GamePlay);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _initDefineProp(target, property, descriptor, context) {
    if (!descriptor) return;
    Object.defineProperty(target, property, {
        enumerable: descriptor.enumerable,
        configurable: descriptor.configurable,
        writable: descriptor.writable,
        value: descriptor.initializer ? descriptor.initializer.call(context) : void 0
    });
}

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) {
    var desc = {};
    Object['ke' + 'ys'](descriptor).forEach(function (key) {
        desc[key] = descriptor[key];
    });
    desc.enumerable = !!desc.enumerable;
    desc.configurable = !!desc.configurable;

    if ('value' in desc || desc.initializer) {
        desc.writable = true;
    }

    desc = decorators.slice().reverse().reduce(function (desc, decorator) {
        return decorator(target, property, desc) || desc;
    }, desc);

    if (context && desc.initializer !== void 0) {
        desc.value = desc.initializer ? desc.initializer.call(context) : void 0;
        desc.initializer = undefined;
    }

    if (desc.initializer === void 0) {
        Object['define' + 'Property'](target, property, desc);
        desc = null;
    }

    return desc;
}

function _initializerWarningHelper(descriptor, context) {
    throw new Error('Decorating class property failed. Please ensure that transform-class-properties is enabled.');
}

var _cc$_decorator = cc._decorator,
    ccclass = _cc$_decorator.ccclass,
    property = _cc$_decorator.property;

/** 配置参数 */

var C = {};

/**
 * Pause界面
 */
var PanelPause = (_dec = property(cc.Node), _dec2 = property(cc.Node), _dec3 = property(cc.Node), _dec4 = property(cc.Node), ccclass(_class = (_class2 = function (_cc$Component) {
    _inherits(PanelPause, _cc$Component);

    function PanelPause() {
        var _ref;

        var _temp, _this, _ret;

        _classCallCheck(this, PanelPause);

        for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
        }

        return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = PanelPause.__proto__ || Object.getPrototypeOf(PanelPause)).call.apply(_ref, [this].concat(args))), _this), _initDefineProp(_this, "btn_continue", _descriptor, _this), _initDefineProp(_this, "btn_restart", _descriptor2, _this), _initDefineProp(_this, "btn_score", _descriptor3, _this), _initDefineProp(_this, "btn_back", _descriptor4, _this), _temp), _possibleConstructorReturn(_this, _ret);
    }

    /** @type {cc.Node} */


    /** @type {cc.Node} */


    /** @type {cc.Node} */


    _createClass(PanelPause, [{
        key: "onLoad",
        value: function onLoad() {
            /** 得到封装的UIPanel方法 */
            // this.ui = new PanelBase(this.node)
        }
    }, {
        key: "start",
        value: function start() {
            this.set_event_continue();
            this.set_event_restart();
            this.set_event_score();
            this.set_event_back();
        }

        /** continue按钮的点击事件 */

    }, {
        key: "set_event_continue",
        value: function set_event_continue() {
            var _this2 = this;

            _Global.G.set_event(this.btn_continue, true, function () {
                cc.log("[点击事件]", _this2.name, _this2.btn_continue.name);
                _MPanel2.default.ins.panel_hide("PanelPause");
            });
        }

        /** restart按钮的点击事件 */

    }, {
        key: "set_event_restart",
        value: function set_event_restart() {
            var _this3 = this;

            _Global.G.set_event(this.btn_restart, true, function () {
                cc.log("[点击事件]", _this3.name, _this3.btn_restart.name);
                _GamePlay2.default.ins.game_restart();
                _MPanel2.default.ins.panel_hide("PanelPause");
            });
        }

        /** 结算按钮的点击事件 */

    }, {
        key: "set_event_score",
        value: function set_event_score() {
            var _this4 = this;

            _Global.G.set_event(this.btn_score, true, function () {
                cc.log("[点击事件]", _this4.name, _this4.btn_score.name);
                _MPanel2.default.ins.panel_hide("PanelPause");
                _MPanel2.default.ins.panel_show("PanelScore");
            });
        }

        /** back按钮的点击事件 */

    }, {
        key: "set_event_back",
        value: function set_event_back() {
            var _this5 = this;

            _Global.G.set_event(this.btn_back, true, function () {
                cc.log("[点击事件]", _this5.name, _this5.btn_back.name);
                _MPanel2.default.ins.panel_hide("PanelPause");
                _MPanel2.default.ins.panel_hide("PanelGame");
                _MPanel2.default.ins.panel_show("PanelMenu");
            });
        }
    }]);

    return PanelPause;
}(cc.Component), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "btn_continue", [_dec], {
    enumerable: true,
    initializer: function initializer() {
        return null;
    }
}), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "btn_restart", [_dec2], {
    enumerable: true,
    initializer: function initializer() {
        return null;
    }
}), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "btn_score", [_dec3], {
    enumerable: true,
    initializer: function initializer() {
        return null;
    }
}), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "btn_back", [_dec4], {
    enumerable: true,
    initializer: function initializer() {
        return null;
    }
})), _class2)) || _class);

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=PanelPause.js.map
        