(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/Script/gameplay/GamePlay.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, 'b33afVSrHBLPr+1l8c/xcSj', 'GamePlay', __filename);
// Script/gameplay/GamePlay.js

"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.default = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _dec, _dec2, _class, _desc, _value, _class2, _descriptor, _descriptor2;

var _Game = require("./Game");

var _Game2 = _interopRequireDefault(_Game);

var _LocalData = require("../framework/LocalData");

var _GameDraw = require("./GameDraw");

var _GameDraw2 = _interopRequireDefault(_GameDraw);

var _CubeCollision = require("./CubeCollision");

var _CubeCollision2 = _interopRequireDefault(_CubeCollision);

var _Cube = require("./Cube");

var _PanelGame = require("../panel/PanelGame");

var _PanelGame2 = _interopRequireDefault(_PanelGame);

var _MPanel = require("../framework/MPanel");

var _MPanel2 = _interopRequireDefault(_MPanel);

var _Global = require("../framework/Global");

var _MRes = require("../framework/MRes");

var _MRes2 = _interopRequireDefault(_MRes);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _initDefineProp(target, property, descriptor, context) {
    if (!descriptor) return;
    Object.defineProperty(target, property, {
        enumerable: descriptor.enumerable,
        configurable: descriptor.configurable,
        writable: descriptor.writable,
        value: descriptor.initializer ? descriptor.initializer.call(context) : void 0
    });
}

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) {
    var desc = {};
    Object['ke' + 'ys'](descriptor).forEach(function (key) {
        desc[key] = descriptor[key];
    });
    desc.enumerable = !!desc.enumerable;
    desc.configurable = !!desc.configurable;

    if ('value' in desc || desc.initializer) {
        desc.writable = true;
    }

    desc = decorators.slice().reverse().reduce(function (desc, decorator) {
        return decorator(target, property, desc) || desc;
    }, desc);

    if (context && desc.initializer !== void 0) {
        desc.value = desc.initializer ? desc.initializer.call(context) : void 0;
        desc.initializer = undefined;
    }

    if (desc.initializer === void 0) {
        Object['define' + 'Property'](target, property, desc);
        desc = null;
    }

    return desc;
}

function _initializerWarningHelper(descriptor, context) {
    throw new Error('Decorating class property failed. Please ensure that transform-class-properties is enabled.');
}

var _cc$_decorator = cc._decorator,
    ccclass = _cc$_decorator.ccclass,
    property = _cc$_decorator.property;

/** 配置参数 */

var C = {
    /** 道具-换一换初始次数 */
    PROP_CHANGE_COUNT: 3,
    /** 道具-单点消除初始次数 */
    PROP_REMOVE_COUNT: 3

    /**
     * 游戏主逻辑
     */
};var GamePlay = (_dec = property(cc.Node), _dec2 = property(cc.Node), ccclass(_class = (_class2 = function (_cc$Component) {
    _inherits(GamePlay, _cc$Component);

    function GamePlay() {
        var _ref;

        var _temp, _this, _ret;

        _classCallCheck(this, GamePlay);

        for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
        }

        return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = GamePlay.__proto__ || Object.getPrototypeOf(GamePlay)).call.apply(_ref, [this].concat(args))), _this), _initDefineProp(_this, "new_cube", _descriptor, _this), _initDefineProp(_this, "new_cube_bg", _descriptor2, _this), _temp), _possibleConstructorReturn(_this, _ret);
    }

    /** @type {GamePlay} 运行实例 */


    /** @type {cc.Node} 新cube */


    /** @type {cc.Node} 新cube的背景 */


    _createClass(GamePlay, [{
        key: "onLoad",
        value: function onLoad() {
            /** 游戏数据 */
            this.game = new _Game2.default();
            this.game.init();
            this._score = 0;

            /** 道具-change动画是否完成 */
            this.is_prop_change_done = false;
            /** 道具-remove动画是否完成 */
            this.is_prop_remove_done = false;

            this.open_collider_manager();
            this.set_touch_event();

            // 保存运行实例
            GamePlay.ins = this;
        }

        /** 游戏初始化 */

    }, {
        key: "game_init",
        value: function game_init() {
            this.game.init();
            this.score = 0;

            this.is_prop_change_done = true;
            this.prop_change_count = C.PROP_CHANGE_COUNT;
            this.is_prop_remove_done = true;
            this.prop_remove_count = C.PROP_REMOVE_COUNT;
        }

        /** 游戏开始 */

    }, {
        key: "game_start",
        value: function game_start() {
            cc.log("[GamePlay.start] 游戏开始");
            this.game_init();
            _Cube.Cube.ins.create_random_cube();
        }

        /** 游戏重新开始 */

    }, {
        key: "game_restart",
        value: function game_restart() {
            cc.log("[GamePlay.restart] 游戏重新开始");
            this.game_init();
            _GameDraw2.default.ins.update_cube_bg();
            _Cube.Cube.ins.create_random_cube();
        }

        /** 游戏结束 */

    }, {
        key: "game_fail",
        value: function game_fail() {
            cc.log("[GamePlay.fail] 游戏结束");
            _MPanel2.default.ins.panel_show("PanelScore");
        }

        /** 设置touch事件 */

    }, {
        key: "set_touch_event",
        value: function set_touch_event() {
            var _this2 = this;

            // 设置音效
            this.new_cube.on(cc.Node.EventType.TOUCH_START, function () {
                // Audio
            });
            // 设置旋转
            this.new_cube.on(cc.Node.EventType.TOUCH_END,
            /** @param {cc.Touch} event */
            function (event) {
                if (event.getDelta().equals(cc.Vec2.ZERO) && event.getLocationX() === event.getStartLocation().x && event.getLocationY() === event.getStartLocation().y) {
                    // 旋转
                    cc.log("旋转");
                    _Cube.Cube.ins.rotate();
                }
            });
            // 设置移动
            this.new_cube.on(cc.Node.EventType.TOUCH_MOVE,
            /** @param {cc.Touch} event */
            function (event) {
                if (!event.getDelta().equals(cc.Vec2.ZERO)) {
                    cc.log("移动");
                    _this2.new_cube.position = _this2.node.convertTouchToNodeSpaceAR(event); //.add(cc.v2(0, 100))
                }
            });
            // 设置放置
            this.new_cube.on(cc.Node.EventType.TOUCH_END,
            /** @param {cc.Touch} event */
            function (event) {
                cc.log("放置（不论放置成功与否）");
                _CubeCollision2.default.ins.put();
            });
            // 设置放置失败（超出屏幕）
            this.new_cube.on(cc.Node.EventType.TOUCH_CANCEL,
            /** @param {cc.Touch} event */
            function (event) {
                cc.log("放置失败");
                _Cube.Cube.ins.position = cc.v2(0, -400);
            });
        }

        /** 打开碰撞检测 */

    }, {
        key: "open_collider_manager",
        value: function open_collider_manager() {
            var manager = cc.director.getCollisionManager();
            manager.enabled = true;
            // 测试绘制
            // manager.enabledDebugDraw = true
        }

        /**
         * 道具事件-换一换
         */

    }, {
        key: "prop_change",
        value: function prop_change() {
            var _this3 = this;

            cc.log("[GamePlay.prop.change]");
            if (!this.is_prop_change_done) {
                return;
            }
            if (this.prop_change_count < 1) {
                return;
            }
            this.is_prop_change_done = false;
            var action = cc.sequence(cc.scaleTo(0.2, 0), cc.callFunc(function () {
                _Cube.Cube.ins.create_different_random_cube().then(function () {
                    _Cube.Cube.ins.rotation = 0;
                    _Cube.Cube.ins.direction = true;
                    _Cube.Cube.ins.cl.enabled = true;
                });
            }), cc.scaleTo(0.2, 1), cc.callFunc(function () {
                _this3.is_prop_change_done = true;
                _this3.prop_change_count--;
            }));
            _Cube.Cube.ins.node.runAction(action);
        }

        /**
         * 道具事件-消除单点
         */

    }, {
        key: "prop_remove",
        value: function prop_remove() {
            var _this4 = this;

            cc.log("[GamePlay.prop.remove]");

            this.is_able_to_remove = true;

            // 第一次点击则注册事件
            if (this.is_first_set === undefined) {
                this.is_first_set = 0;
            } // 0!=undefined
            else {
                    return;
                }
            for (var x = 0; x < _GameDraw2.default.ins.cube_array.length; x++) {
                var _loop = function _loop(y) {
                    var n = _GameDraw2.default.ins.get_cube(cc.v2(x, y));
                    _Global.G.set_event(n, false, function () {
                        if (!_this4.is_prop_remove_done) {
                            return;
                        }
                        if (_this4.prop_remove_count < 1) {
                            return;
                        }
                        if (_this4.game.get_p_value(n.p) <= 0) {
                            return;
                        }
                        if (!_this4.is_able_to_remove) {
                            return;
                        }
                        _this4.is_prop_remove_done = false;
                        var action = cc.sequence(cc.fadeOut(0.2), cc.callFunc(function () {
                            // 数据
                            _this4.game.set_p_value(n.p, 0);
                            // 样式
                            _GameDraw2.default.ins.change_cube_sprite(n.p, _MRes2.default.ins.array_cube[0]);
                        }), cc.fadeIn(0.2), cc.callFunc(function () {
                            _this4.is_prop_remove_done = true;
                            _this4.prop_remove_count--;
                            _this4.is_able_to_remove = false;
                        }));
                        n.runAction(action);
                    });
                };

                for (var y = 0; y < _GameDraw2.default.ins.cube_array[x].length; y++) {
                    _loop(y);
                }
            }
        }
    }, {
        key: "score",


        /** 分数 */
        set: function set(s) {
            this._score = s;
            // 更新score显示
            _PanelGame2.default.ins.update_score();
        },
        get: function get() {
            return this._score;
        }

        /** 道具-换一换可行次数 */

    }, {
        key: "prop_change_count",
        set: function set(c) {
            this._prop_change_count = c;
            _PanelGame2.default.ins.update_prop_change_count();
        },
        get: function get() {
            return this._prop_change_count;
        }

        /** 道具-remove可行次数 */

    }, {
        key: "prop_remove_count",
        set: function set(c) {
            this._prop_remove_count = c;
            _PanelGame2.default.ins.update_prop_remove_count();
        },
        get: function get() {
            return this._prop_remove_count;
        }
    }]);

    return GamePlay;
}(cc.Component), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "new_cube", [_dec], {
    enumerable: true,
    initializer: function initializer() {
        return null;
    }
}), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "new_cube_bg", [_dec2], {
    enumerable: true,
    initializer: function initializer() {
        return null;
    }
})), _class2)) || _class);
exports.default = GamePlay;
module.exports = exports["default"];

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=GamePlay.js.map
        