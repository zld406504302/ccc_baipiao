(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/Script/framework/LocalData.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, 'a2f52DB/E5GA4HbIoCAAma2', 'LocalData', __filename);
// Script/framework/LocalData.js

"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

/**
 * 框架文件：本地数据存储类
 */
var LocalData = function () {
    function LocalData() {
        _classCallCheck(this, LocalData);
    }

    _createClass(LocalData, [{
        key: "set_item",


        /** 封装设置item */
        value: function set_item(key, value) {
            cc.sys.localStorage.setItem(key, value);
        }

        /** 封装获取item */

    }, {
        key: "get_item",
        value: function get_item(key) {
            return cc.sys.localStorage.getItem(key);
        }

        /** 是否初始化 */

    }, {
        key: "is_init",
        set: function set(value) {
            this.set_item("is_init", value);
        },
        get: function get() {
            return this.get_item("is_init");
        }

        /** 音乐 */

    }, {
        key: "music",
        set: function set(value) {
            this.set_item("music", value);
        },
        get: function get() {
            return this.get_item("music");
        }

        /** 音效 */

    }, {
        key: "sound",
        set: function set(value) {
            this.set_item("sound", value);
        },
        get: function get() {
            return this.get_item("sound");
        }

        //////////
        // 下面的内容需要添加每个游戏自身的本地存储
        //////////

        /** 最高分 */

    }, {
        key: "max_score",
        set: function set(value) {
            this.set_item("max_score", value);
        },
        get: function get() {
            // 默认值
            if (this.get_item("max_score") === null) {
                this.set_item("max_score", 0);
            }
            return Number(this.get_item("max_score"));
        }
    }]);

    return LocalData;
}();

/** 本地存储实例 */


var L = exports.L = new LocalData();

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=LocalData.js.map
        