(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/Script/framework/MRes.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '3d629PEsTtI4oCo2rwK6HYq', 'MRes', __filename);
// Script/framework/MRes.js

"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _class;

function _toConsumableArray(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = Array(arr.length); i < arr.length; i++) { arr2[i] = arr[i]; } return arr2; } else { return Array.from(arr); } }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var _cc$_decorator = cc._decorator,
    ccclass = _cc$_decorator.ccclass,
    property = _cc$_decorator.property;
/** 配置参数 */

var C = {
    /** panel资源路径参数 */
    PATH_PANEL: "panel",
    /** audio资源路径参数 */
    PATH_AUDIO: "audio",
    /** cube资源路径参数 */
    PATH_CUBE: "cube",
    /** cube_shadow资源路径参数 */
    PATH_CUBE_SHADOW: "cube_shadow"

    /**
     * 框架文件：资源管理器
     * - 针对变动的动态文件
     * - 资源路径写在模块开头的C中
     * - 资源路径需要在resource文件夹下
     * - 脚本需要挂载在尽量靠前的位置
     * @class
     */
};
var MRes = ccclass(_class = function (_cc$Component) {
    _inherits(MRes, _cc$Component);

    function MRes() {
        _classCallCheck(this, MRes);

        return _possibleConstructorReturn(this, (MRes.__proto__ || Object.getPrototypeOf(MRes)).apply(this, arguments));
    }

    _createClass(MRes, [{
        key: "onLoad",
        value: function onLoad() {
            // 初始化
            this.load_count = 0;
            this.total_count = 0;

            // 初始化存储
            /** panel数组 */
            this.array_panel = Array.of();
            /** audio数组 */
            this.array_audio = Array.of();
            /** @type {[cc.SpriteFrame]} cube数组 */
            this.array_cube = Array.of();
            /** @type {[cc.SpriteFrame]} cube_shadow数组 */
            this.array_cube_shadow = Array.of();

            // 链式加载
            // 在AppMain中显式加载
            // this.load_chain()

            // 保存实例
            MRes.instance = this;
        }

        /** @type {MRes} 脚本实例 */

    }, {
        key: "load_chain",


        /** 
         * 资源加载链
         * - 实际上是链式加载，嵌套写法，需要使用aysnc/await进行进一步优化
         */
        value: function load_chain() {
            var _this2 = this;

            return new Promise(function (resolve, reject) {
                _this2.load_res(C.PATH_AUDIO, cc.AudioClip, _this2.array_audio).then(function (v) {
                    var _cc;

                    (_cc = cc).log.apply(_cc, _toConsumableArray(v));
                    _this2.load_res(C.PATH_PANEL, cc.Prefab, _this2.array_panel).then(function (v) {
                        var _cc2;

                        (_cc2 = cc).log.apply(_cc2, _toConsumableArray(v));
                        _this2.load_res(C.PATH_CUBE, cc.SpriteFrame, _this2.array_cube).then(function (v) {
                            var _cc3;

                            (_cc3 = cc).log.apply(_cc3, _toConsumableArray(v));
                            _this2.load_res(C.PATH_CUBE_SHADOW, cc.SpriteFrame, _this2.array_cube_shadow).then(function (v) {
                                var _cc4;

                                (_cc4 = cc).log.apply(_cc4, _toConsumableArray(v));
                                // 载入链完成
                                resolve();
                            });
                        });
                    });
                });
            });
        }

        /**
         * 载入资源
         * @param {string} path 路径
         * @param {typeof cc.Asset} type 类型
         * @param {[]} array 资源数组
         */

    }, {
        key: "load_res",
        value: function load_res(path, type, array) {
            var _this3 = this;

            return new Promise(function (resolve, reject) {
                cc.loader.loadResDir(
                // 路径
                path,
                // 格式
                type,
                // 载入全部资源后的回调函数
                function (err, res) {
                    // 载入失败
                    if (err) {
                        reject(Array.of("载入资源失败，path&type=", path, type.toString(), "err=", err));
                        return;
                    }
                    // 写入数据
                    // 其中两个count并非是在载入过程中写入，而是在最后统计过程中写入；原因是载入过程机制不明
                    _this3.total_count += res.length;
                    var _iteratorNormalCompletion = true;
                    var _didIteratorError = false;
                    var _iteratorError = undefined;

                    try {
                        for (var _iterator = res[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
                            var r = _step.value;

                            array.push(r);
                            _this3.load_count += 1;
                        }
                        // 载入成功
                    } catch (err) {
                        _didIteratorError = true;
                        _iteratorError = err;
                    } finally {
                        try {
                            if (!_iteratorNormalCompletion && _iterator.return) {
                                _iterator.return();
                            }
                        } finally {
                            if (_didIteratorError) {
                                throw _iteratorError;
                            }
                        }
                    }

                    resolve(Array.of("资源载入成功，path=", path));
                });
            });
        }
    }, {
        key: "total_count",


        /** @type {number} 总计数 */
        get: function get() {
            return this._total_count;
        },
        set: function set(count) {
            this._total_count = count;
        }

        /** @type {number} 载入计数 */

    }, {
        key: "load_count",
        get: function get() {
            return this._load_count;
        },
        set: function set(count) {
            this._load_count = count;
        }
    }], [{
        key: "ins",
        get: function get() {
            return MRes.instance;
        }
    }]);

    return MRes;
}(cc.Component)) || _class;

exports.default = MRes;
module.exports = exports["default"];

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=MRes.js.map
        