(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/Script/framework/Global.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, 'dc582NdJf9FLrIRw0MnInZl', 'Global', __filename);
// Script/framework/Global.js

"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

/**
 * 框架文件：全局类
 * - 封装一些重要的方法
 */
var Global = function () {
    function Global() {
        _classCallCheck(this, Global);
    }

    _createClass(Global, [{
        key: "random_int",

        /**
         * 获取一个随机整数
         * - 范围 [min,max)
         * @param {number} min 左边界
         * @param {number} max 右边界
         * @returns {number} rn 随机数
         */
        value: function random_int(min, max) {
            var rn = Math.floor(Math.random() * (max - min) + min);
            return rn;
        }

        /**
         * 获取一个随机小数
         * - 范围 [min,max)
         * @param {number} min 
         * @param {number} max 
         * @returns {number} rn
         */

    }, {
        key: "random_float",
        value: function random_float(min, max) {
            var rn = Math.random() * (max - min) + min;
            return rn;
        }

        /**
         * 从数组中获取一个随机值（概率相等）
         * @param {[]} array 
         */

    }, {
        key: "random_item_form_array",
        value: function random_item_form_array(array) {
            if (array.length === 0) {
                return;
            }
            var rn = this.random_int(0, array.length);
            return array[rn];
        }

        /**
         * 将此节点设置为btn_like节点
         * - 包含：放大缩小效果，按钮点击音效
         * - 特别注意：由于引擎load顺序的关系，尽量将audio的节点放在前面，UI节点放在后面，否则会有一些莫名其妙的bug
         * @param {cc.Node} node 传入节点
         */

    }, {
        key: "set_as_btn_like",
        value: function set_as_btn_like(node) {
            // 添加一个button组件
            if (node.getComponent(cc.Button) === null) {
                var btn = node.addComponent(cc.Button);
                btn.transition = cc.Button.Transition.SCALE;
                btn.duration = 0.05;
                btn.zoomScale = 0.9;
            }
            // 添加点击音效
            // node.on(cc.Node.EventType.TOUCH_END, () => {

            // }, node)
        }

        /**
         * 设置node节点的标准点击事件
         * @param {cc.Node} node 节点
         * @param {boolean} is_btn_like 是否有点击效果
         * @param {Function} f 点击处理函数
         */

    }, {
        key: "set_event",
        value: function set_event(node, is_btn_like, f) {
            node.on(cc.Node.EventType.TOUCH_END, f);
            if (is_btn_like) {
                this.set_as_btn_like(node);
            }
        }
    }]);

    return Global;
}();

/** 
 * Global全局类实例
 */


var G = exports.G = new Global();

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=Global.js.map
        