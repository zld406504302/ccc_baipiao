(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/Script/framework/MPanel.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '6dc19Xe9PVP8ZgwdrYKs6Uw', 'MPanel', __filename);
// Script/framework/MPanel.js

"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.default = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _dec, _dec2, _class, _desc, _value, _class2, _descriptor, _descriptor2;

var _PanelBase = require("./PanelBase");

var _PanelBase2 = _interopRequireDefault(_PanelBase);

var _MRes = require("./MRes");

var _MRes2 = _interopRequireDefault(_MRes);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _initDefineProp(target, property, descriptor, context) {
    if (!descriptor) return;
    Object.defineProperty(target, property, {
        enumerable: descriptor.enumerable,
        configurable: descriptor.configurable,
        writable: descriptor.writable,
        value: descriptor.initializer ? descriptor.initializer.call(context) : void 0
    });
}

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) {
    var desc = {};
    Object['ke' + 'ys'](descriptor).forEach(function (key) {
        desc[key] = descriptor[key];
    });
    desc.enumerable = !!desc.enumerable;
    desc.configurable = !!desc.configurable;

    if ('value' in desc || desc.initializer) {
        desc.writable = true;
    }

    desc = decorators.slice().reverse().reduce(function (desc, decorator) {
        return decorator(target, property, desc) || desc;
    }, desc);

    if (context && desc.initializer !== void 0) {
        desc.value = desc.initializer ? desc.initializer.call(context) : void 0;
        desc.initializer = undefined;
    }

    if (desc.initializer === void 0) {
        Object['define' + 'Property'](target, property, desc);
        desc = null;
    }

    return desc;
}

function _initializerWarningHelper(descriptor, context) {
    throw new Error('Decorating class property failed. Please ensure that transform-class-properties is enabled.');
}

var _cc$_decorator = cc._decorator,
    ccclass = _cc$_decorator.ccclass,
    property = _cc$_decorator.property;

/**
 * 框架文件：游戏panel管理类
 * - 封装load，show，hide的外部接口
 * - 将所有的panel prefab资源创建为node，并保存在传入的父节点下
 * - 游戏窗口有多种打开方式：默认打开方式、其他规定的打开方式，规定之外的自定义打开方式
 */

var MPanel = (_dec = property(cc.Node), _dec2 = property(cc.Node), ccclass(_class = (_class2 = function (_cc$Component) {
    _inherits(MPanel, _cc$Component);

    function MPanel() {
        var _ref;

        var _temp, _this, _ret;

        _classCallCheck(this, MPanel);

        for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
        }

        return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = MPanel.__proto__ || Object.getPrototypeOf(MPanel)).call.apply(_ref, [this].concat(args))), _this), _initDefineProp(_this, "panel_parent", _descriptor, _this), _initDefineProp(_this, "panel_loading", _descriptor2, _this), _temp), _possibleConstructorReturn(_this, _ret);
    }

    /** @type {cc.Node} panel_loading */


    _createClass(MPanel, [{
        key: "onLoad",
        value: function onLoad() {
            // 初始化
            /** 当前的渲染 */
            this.now_z_index = 0;

            // 初始化存储
            /** panel数组 */
            this.panel_array = {};

            // 保存脚本运行实例
            MPanel.instance = this;
        }

        /**
         * 脚本运行实例
         * @type {MPanel} MPanel.instance
         */

    }, {
        key: "create_all_panel",


        /** 创建所有的panel */
        value: function create_all_panel() {
            var _iteratorNormalCompletion = true;
            var _didIteratorError = false;
            var _iteratorError = undefined;

            try {
                for (var _iterator = _MRes2.default.ins.array_panel[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
                    var prefab = _step.value;

                    // 创建node并写入
                    var node = cc.instantiate(prefab);
                    node.parent = this.panel_parent;
                    node.active = false;
                    this.panel_array[prefab.name] = new _PanelBase2.default(node);
                }
                // 匹配loadingpanel
            } catch (err) {
                _didIteratorError = true;
                _iteratorError = err;
            } finally {
                try {
                    if (!_iteratorNormalCompletion && _iterator.return) {
                        _iterator.return();
                    }
                } finally {
                    if (_didIteratorError) {
                        throw _iteratorError;
                    }
                }
            }

            this.panel_array["PanelLoading"] = new _PanelBase2.default(this.panel_loading);
            cc.log("创建所有UI节点成功", this.panel_array);
        }

        /**
         * 显示panel
         * @param {string} panel_name 窗口名
         */

    }, {
        key: "panel_show",
        value: function panel_show(panel_name) {
            var panel = this.check_panel(panel_name);
            if (panel === false) {
                return;
            }
            // 优先采用窗口自带的显示方式
            try {
                panel.node.getComponent(panel_name).show();
            } catch (error) {
                panel.show();
            }
            // 修改渲染深度，使其置于顶部
            this.now_z_index += 1;
            panel.node.zIndex = this.now_z_index;
        }

        /**
         * 隐藏panel
         * @param {string} panel_name 窗口名
         */

    }, {
        key: "panel_hide",
        value: function panel_hide(panel_name) {
            var panel = this.check_panel(panel_name);
            if (panel === false) {
                return;
            }
            // 优先采用窗口自带的关闭方式
            try {
                panel.node.getComponent(panel_name).hide();
            } catch (error) {
                panel.hide();
            }
            // 要么就在hide()动作结束后改深度，要么就干脆不改深度，2选1
            // panel.zIndex = 0
        }

        /**
         * 检查窗口名称
         * @param {string} panel_name 窗口名称
         * @returns {false | PanelBase}
         */

    }, {
        key: "check_panel",
        value: function check_panel(panel_name) {
            var panel = this.panel_array[panel_name];
            if (panel === undefined) {
                cc.error("查找的panel不存在，panel_name=", panel_name);
                return false;
            }
            return panel;
        }
    }], [{
        key: "ins",
        get: function get() {
            return MPanel.instance;
        }
    }]);

    return MPanel;
}(cc.Component), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "panel_parent", [_dec], {
    enumerable: true,
    initializer: function initializer() {
        return null;
    }
}), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "panel_loading", [_dec2], {
    enumerable: true,
    initializer: function initializer() {
        return null;
    }
})), _class2)) || _class);
exports.default = MPanel;
module.exports = exports["default"];

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=MPanel.js.map
        