require=(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({"closeScene":[function(require,module,exports){
"use strict";
cc._RFpush(module, '33ce8eeju5EWJFMEf/wRFCj', 'closeScene');
// Script\closeScene.js

cc.Class({
    'extends': cc.Component,

    properties: {
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...

        rewardParent: cc.Node,
        myLayer: cc.Node,
        rewardLayer: cc.Node,
        msgLayer: cc.Node,

        itemDesc: cc.Label,
        label: cc.Node,
        btn: cc.Node
    },

    // use this for initialization
    onLoad: function onLoad() {
        this.myLayer.active = false;
        this.rewardLayer.active = false;

        this.rewards = [];
        for (var i = 0; i < 12; i++) {
            var re = this.rewardParent.getChildByName('p' + (i + 1));
            re.label = re.getChildByName('c').getComponent(cc.Label);
            this.rewards.push(re);
        }

        // 高亮拥有的奖品
        for (var i = 0; i < 12; i++) {
            var re = this.rewards[i];
            if (i < window.data.rewards.length) {
                if (window.data.userinfo.rewards[i]) {
                    re.color = new cc.Color(255, 255, 255);
                    re.label.string = 1;
                } else {
                    re.color = new cc.Color(124, 124, 124);
                }
            } else {
                re.active = false;
            }
        }

        this.updateDisplay();
    },

    updateDisplay: function updateDisplay(got) {
        if (window.data.userinfo.status == 2) {
            this.label.active = true;
            this.btn.active = false;
        } else {
            this.label.active = false;
            this.btn.active = true;
        }
    },

    btnMyReward: function btnMyReward() {
        this.myLayer.active = true;
    },

    btnCloseLayer: function btnCloseLayer() {
        this.myLayer.active = false;
    },

    showMsg: function showMsg(msg) {
        this.msgLayer.active = true;
        this.msgLayer.getChildByName('Label').getComponent(cc.Label).string = msg;
    },

    btnGetReward: function btnGetReward() {
        var thiz = this;
        $.ajax({
            type: 'GET',
            url: "getReward",
            dataType: "json",
            data: {},
            success: function success(data) {
                if (data.code == 1) {
                    //
                    window.data.userinfo.isGot = true;
                    thiz.myLayer.active = false;
                    thiz.showMsg('您已经领取过奖品了');
                } else if (data.code == 0) {
                    window.data.userinfo.isGot = true;
                    thiz.myLayer.active = false;
                    thiz.showMsg('兑奖成功');
                }

                thiz.updateDisplay();
            },
            error: function error(data) {}
        });
    },

    //奖品被点击
    btnReq: function btnReq(evt) {
        var name = evt.target.name;
        var rewardIndex = parseInt(name.substring(1)) - 1;

        this.myLayer.active = false;
        this.rewardLayer.active = true;
        var info = window.data.rewards[rewardIndex];
        this.rewardLayer.getChildByName('name').getComponent(cc.Label).string = info.name;
        this.itemDesc.string = info.desc || "没有说明";
        this.rewardLayer.rewardIndex = rewardIndex;

        var own = evt.target.color.r != 124;
        this.rewardLayer.isgot = own;

        this.rewardLayer.getChildByName('req').active = own;

        if (own) {
            this.rewardLayer.getChildByName('stmp').active = window.data.userinfo.rewardIndex == rewardIndex;
            this.rewardLayer.getChildByName('stmp').getComponent(cc.Label).string = '已申请';
        } else {
            this.rewardLayer.getChildByName('stmp').active = true;
            this.rewardLayer.getChildByName('stmp').getComponent(cc.Label).string = '未获得';
        }
    },

    //申请按钮
    btnDoReq: function btnDoReq() {

        $.ajax({
            type: 'GET',
            url: 'requestReward',
            dataType: "json",
            data: {
                rewardIndex: this.rewardLayer.rewardIndex
            },
            success: function success(data) {
                window.data.userinfo.rewardIndex = this.rewardLayer.rewardIndex;
                this.rewardLayer.getChildByName('stmp').active = true;
                this.rewardLayer.getChildByName('stmp').getComponent(cc.Label).string = '已申请';
                this.showMsg('成功');
            },
            error: function error(data) {}
        });
    },

    btnOkInfo: function btnOkInfo() {
        this.rewardLayer.active = false;
    }

});
// called every frame, uncomment this function to activate update callback
// update: function (dt) {

// },

cc._RFpop();
},{}],"helpLayer":[function(require,module,exports){
"use strict";
cc._RFpush(module, 'fee5eBxtZFPRKw8+q//J0+r', 'helpLayer');
// Script\helpLayer.js

cc.Class({
    "extends": cc.Component,

    properties: {
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...
        label: cc.Label
    },

    // use this for initialization
    onLoad: function onLoad() {
        if (window.data) {
            console.log(this.label);
            console.log(window.data.help);
            this.label.string = window.data.help;
        }
    },

    btnIKnow: function btnIKnow() {
        this.node.active = false;
    }

});
// called every frame, uncomment this function to activate update callback
// update: function (dt) {

// },

cc._RFpop();
},{}],"menuScene":[function(require,module,exports){
"use strict";
cc._RFpush(module, '280c3rsZJJKnZ9RqbALVwtK', 'menuScene');
// Script\menuScene.js

cc.Class({
    "extends": cc.Component,

    properties: {
        infoLayer: cc.Node,
        inputLayer: cc.Node,

        nameEdit: cc.EditBox,
        phoneEdit: cc.EditBox
    },

    // use this for initialization
    onLoad: function onLoad() {
        this.infoLayer.active = false;
        this.inputLayer.active = false;
        this.doReq();
    },

    _gotoGame: function _gotoGame() {
        if (this.phone && this.realName) {
            cc.director.loadScene('playScene');
        } else {
            this.inputLayer.active = true;
        }
    },

    btnDoStart: function btnDoStart() {
        if (this.nameEdit.string == "" || this.phoneEdit.string == "") {
            cc.log('kong');
        } else {
            this.phone = this.phoneEdit.string;
            this.realName = this.nameEdit.string;
            cc.log(this.phone, this.realName);
            var thiz = this;
            $.ajax({
                type: 'GET',
                url: "setPhone",
                dataType: "json",
                data: {
                    phone: this.phone,
                    realName: this.realName
                },
                success: function success(ret) {
                    cc.log(ret);
                    if (ret.ok) thiz.inputLayer.active = false;
                },
                error: function error(data) {}
            });
        }
    },

    doReq: function doReq() {
        if (this.loading) return;
        this.loading = true;
        var thiz = this;
        $.ajax({
            type: 'GET',
            url: "getInfo",
            dataType: "json",
            data: {
                userid: "test1"
            },
            success: function success(ret) {
                window.data = ret;
                thiz.loading = false;
                console.log(ret);
                if (!ret.enable) {
                    cc.director.loadScene('close');
                } else {
                    if (ret.userinfo.phone != null && ret.userinfo.phone != undefined) thiz.phone = ret.userinfo.phone;
                    if (ret.userinfo.realName != null && ret.userinfo.realName != undefined) thiz.realName = ret.userinfo.realName;

                    if (thiz.action == 'game') thiz._gotoGame();else if (thiz.action == 'help') thiz.infoLayer.active = true;
                }
            },
            error: function error(data) {
                thiz.loading = false;
            }
        });
    },

    btnStart: function btnStart() {
        this.action = 'game';

        if (!this.loading) this._gotoGame();
    },
    btnInfo: function btnInfo() {
        this.action = 'help';
        if (!this.loading) this.infoLayer.active = true;
    }
});

cc._RFpop();
},{}],"playScene":[function(require,module,exports){
"use strict";
cc._RFpush(module, '52267vv1zdP2ZzM5R+J52OI', 'playScene');
// Script\playScene.js

cc.Class({
    'extends': cc.Component,

    properties: {
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...
        hammer: cc.Node,
        egg: cc.Node,

        winLayer: cc.Node,
        lostLayer: cc.Node,
        infoLayer: cc.Node,
        msgLayer: cc.Node,
        shareLayer: cc.Node,
        rewardLayer: cc.Node,

        eggParent: cc.Node,

        itemDesc: cc.Label,

        countLabel: cc.Label,
        rewardParent: cc.Node,

        frameTop: [cc.SpriteFrame],
        frameDown: [cc.SpriteFrame]
    },

    // use this for initialization
    onLoad: function onLoad() {
        this.infoLayer.active = false;
        this.lostLayer.active = false;
        this.winLayer.active = false;
        this.shareLayer.active = false;
        this.msgLayer.active = false;
        this.rewardLayer.active = false;

        this.hammer.zIndex = 1;
        this.hammerAni = this.hammer.getComponent(cc.Animation);

        this.hammerAni.on('finished', this._onPlay, this);
        this.hammer.active = false;
        this.egg.active = false;

        this.rewards = [];
        for (var i = 0; i < 12; i++) {
            var re = this.rewardParent.getChildByName('p' + (i + 1));
            re.label = re.getChildByName('c').getComponent(cc.Label);
            this.rewards.push(re);
        }

        window.play = this;
        this._updateLabel();

        // 高亮拥有的奖品
        for (var i = 0; i < 12; i++) {
            var re = this.rewards[i];
            if (i < window.data.rewards.length) {
                if (window.data.userinfo.rewards[i]) {
                    re.color = new cc.Color(255, 255, 255);
                    re.label.string = 1;
                } else {
                    re.color = new cc.Color(124, 124, 124);
                }
            } else {
                re.active = false;
            }
        }
    },

    _updateLabel: function _updateLabel() {
        if (window.data) this.countLabel.string = '你还剩' + window.data.userinfo.count + '次机会';
    },

    showMsg: function showMsg(msg) {
        this.msgLayer.active = true;
        this.msgLayer.getChildByName('Label').getComponent(cc.Label).string = msg;
    },

    _showduiJiang: function _showduiJiang(rewardIndex) {
        this.rewardLayer.active = true;
        var info = window.data.rewards[rewardIndex];
        this.rewardLayer.getChildByName('name').getComponent(cc.Label).string = info.name;
        this.rewardLayer.getChildByName('stmp').active = window.data.userinfo.rewardIndex == rewardIndex;

        this.itemDesc.string = info.desc || "没有说明";
        this.rewardLayer.rewardIndex = rewardIndex;
    },

    request: function request(req, arg, f) {
        var cb = f.bind(this);
        this.loading = true;
        $.ajax({
            type: 'GET',
            url: req,
            dataType: "json",
            data: arg || {},
            success: function success(data) {
                this.loading = false;
                cb(data);
            },
            error: function error(data) {
                this.loading = false;
            }
        });
    },

    btnShengqin: function btnShengqin(evt) {
        this.request('requestReward', {
            rewardIndex: this.rewardLayer.rewardIndex
        }, function (data) {
            window.data.userinfo.rewardIndex = this.rewardLayer.rewardIndex;
            this.rewardLayer.getChildByName('stmp').active = true;
        });
    },

    btnGuanBiDuiJiang: function btnGuanBiDuiJiang() {
        this.rewardLayer.active = false;
    },

    onShare: function onShare() {
        this.request('userShared', {}, function (data) {
            // 分享成功
            window.data.userinfo.count = data.addcount;
            thiz._updateLabel();
            thiz.shareLayer.active = false;
            thiz.showMsg("分享成功");
        });
    },

    rewardPress: function rewardPress(evt) {
        var name = evt.target.name;
        var idx = parseInt(name.substring(1)) - 1;

        if (!window.data) return;

        if (evt.target.color.r == 124) {
            this.showMsg(window.data.rewards[idx].name + " （未获得）");
        } else {
            this._showduiJiang(idx);
        }
    },

    eggPress: function eggPress(evt) {
        this.hammerAni.stop();
        this.hammer.active = true;

        this.hammer.x = evt.target.x;
        this.hammer.y = evt.target.y;

        this.hammerAni.play();
        this.hammer.getComponent(cc.AudioSource).play();

        var thiz = this;
        var eggIndex = parseInt(evt.target.name) - 1;

        if (this.loading && !window.data) {
            cc.log(this.loading);
            return;
        }

        if (window.data.userinfo.count <= 0) {
            // 次数不足
            this.shareLayer.active = true;

            return;
        }

        this.request('hitEgg', {
            eggIndex: eggIndex
        }, function (data) {
            thiz.loading = false;
            window.data.userinfo.count--;
            thiz._updateLabel();
            thiz._breakEgg(evt);

            // 标记鸡蛋被打碎
            window.data.userinfo.eggs[eggIndex] = true;

            var rewardIndex = data.reward;
            if (rewardIndex != null || rewardIndex != undefined) {
                // 高亮奖品
                thiz.rewards[rewardIndex].color = new cc.Color(255, 255, 255);
                window.data.userinfo.reward = rewardIndex;
                thiz.rewards[rewardIndex].label.string = '1';

                thiz.winLayer.active = true;
                thiz.winLayer.rewardIndex = rewardIndex;
                thiz.winLayer.getChildByName('name').getComponent(cc.Label).string = window.data.rewards[rewardIndex].name;
            } else {
                thiz.lostLayer.active = true;
            }
        });
    },

    _setEggBreak: function _setEggBreak(index) {
        var old_egg = this.eggParent.getChildByName('' + (index + 1));
        old_egg.active = false;

        this.breakedEGG = old_egg;

        var egg = cc.instantiate(this.egg);
        old_egg.breaker = egg;

        egg.parent = this.eggParent;
        egg.active = true;
        egg.position = old_egg.position;

        egg.getChildByName('top').opacity = 0;
        egg.getChildByName('top').getComponent(cc.Sprite).spriteFrame = this.frameTop[index];
        egg.getChildByName('down').getComponent(cc.Sprite).spriteFrame = this.frameDown[index];

        return egg;
    },

    _breakEgg: function _breakEgg(evt) {
        var idx = parseInt(evt.target.name) - 1;
        var egg = this._setEggBreak(idx);
        egg.getChildByName('top').opacity = 255;
        egg.getComponent(cc.Animation).play();
    },

    restoreEggs: function restoreEggs() {
        if (!this.breakedEGG) return;
        this.breakedEGG.active = true;
        this.breakedEGG.breaker.parent = null;
        this.breakedEGG = null;
    },

    _onPlay: function _onPlay() {
        this.hammer.active = false;
    },

    btnInfo: function btnInfo() {
        this.infoLayer.active = true;
    },

    btnCheckInfo: function btnCheckInfo() {
        this.winLayer.active = false;
        this.restoreEggs();
        this._showduiJiang(this.winLayer.rewardIndex);
    },

    btnContinueGame: function btnContinueGame() {
        this.restoreEggs();
        this.winLayer.active = false;
    },

    btnContinueGameMsg: function btnContinueGameMsg() {
        this.msgLayer.active = false;
    },

    btnAgain: function btnAgain() {
        this.restoreEggs();
        this.lostLayer.active = false;
    },

    btnBack: function btnBack() {
        cc.director.loadScene('menuScene');
    }

});
// called every frame, uncomment this function to activate update callback
// update: function (dt) {

// },

cc._RFpop();
},{}]},{},["menuScene","closeScene","playScene","helpLayer"])
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL0NvY29zQ3JlYXRvci9yZXNvdXJjZXMvYXBwLmFzYXIvbm9kZV9tb2R1bGVzL2Jyb3dzZXItcGFjay9fcHJlbHVkZS5qcyIsIlNjcmlwdC9jbG9zZVNjZW5lLmpzIiwiU2NyaXB0L2hlbHBMYXllci5qcyIsIlNjcmlwdC9tZW51U2NlbmUuanMiLCJTY3JpcHQvcGxheVNjZW5lLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0FDQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUNuS0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUN4Q0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDaEdBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSIsImZpbGUiOiJnZW5lcmF0ZWQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlc0NvbnRlbnQiOlsiKGZ1bmN0aW9uIGUodCxuLHIpe2Z1bmN0aW9uIHMobyx1KXtpZighbltvXSl7aWYoIXRbb10pe3ZhciBhPXR5cGVvZiByZXF1aXJlPT1cImZ1bmN0aW9uXCImJnJlcXVpcmU7aWYoIXUmJmEpcmV0dXJuIGEobywhMCk7aWYoaSlyZXR1cm4gaShvLCEwKTt2YXIgZj1uZXcgRXJyb3IoXCJDYW5ub3QgZmluZCBtb2R1bGUgJ1wiK28rXCInXCIpO3Rocm93IGYuY29kZT1cIk1PRFVMRV9OT1RfRk9VTkRcIixmfXZhciBsPW5bb109e2V4cG9ydHM6e319O3Rbb11bMF0uY2FsbChsLmV4cG9ydHMsZnVuY3Rpb24oZSl7dmFyIG49dFtvXVsxXVtlXTtyZXR1cm4gcyhuP246ZSl9LGwsbC5leHBvcnRzLGUsdCxuLHIpfXJldHVybiBuW29dLmV4cG9ydHN9dmFyIGk9dHlwZW9mIHJlcXVpcmU9PVwiZnVuY3Rpb25cIiYmcmVxdWlyZTtmb3IodmFyIG89MDtvPHIubGVuZ3RoO28rKylzKHJbb10pO3JldHVybiBzfSkiLCJcInVzZSBzdHJpY3RcIjtcbmNjLl9SRnB1c2gobW9kdWxlLCAnMzNjZThlZWp1NUVXSkZNRWYvd1JGQ2onLCAnY2xvc2VTY2VuZScpO1xuLy8gU2NyaXB0XFxjbG9zZVNjZW5lLmpzXG5cbmNjLkNsYXNzKHtcbiAgICAnZXh0ZW5kcyc6IGNjLkNvbXBvbmVudCxcblxuICAgIHByb3BlcnRpZXM6IHtcbiAgICAgICAgLy8gZm9vOiB7XG4gICAgICAgIC8vICAgIGRlZmF1bHQ6IG51bGwsICAgICAgLy8gVGhlIGRlZmF1bHQgdmFsdWUgd2lsbCBiZSB1c2VkIG9ubHkgd2hlbiB0aGUgY29tcG9uZW50IGF0dGFjaGluZ1xuICAgICAgICAvLyAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvIGEgbm9kZSBmb3IgdGhlIGZpcnN0IHRpbWVcbiAgICAgICAgLy8gICAgdXJsOiBjYy5UZXh0dXJlMkQsICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0eXBlb2YgZGVmYXVsdFxuICAgICAgICAvLyAgICBzZXJpYWxpemFibGU6IHRydWUsIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHRydWVcbiAgICAgICAgLy8gICAgdmlzaWJsZTogdHJ1ZSwgICAgICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0cnVlXG4gICAgICAgIC8vICAgIGRpc3BsYXlOYW1lOiAnRm9vJywgLy8gb3B0aW9uYWxcbiAgICAgICAgLy8gICAgcmVhZG9ubHk6IGZhbHNlLCAgICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyBmYWxzZVxuICAgICAgICAvLyB9LFxuICAgICAgICAvLyAuLi5cblxuICAgICAgICByZXdhcmRQYXJlbnQ6IGNjLk5vZGUsXG4gICAgICAgIG15TGF5ZXI6IGNjLk5vZGUsXG4gICAgICAgIHJld2FyZExheWVyOiBjYy5Ob2RlLFxuICAgICAgICBtc2dMYXllcjogY2MuTm9kZSxcblxuICAgICAgICBpdGVtRGVzYzogY2MuTGFiZWwsXG4gICAgICAgIGxhYmVsOiBjYy5Ob2RlLFxuICAgICAgICBidG46IGNjLk5vZGVcbiAgICB9LFxuXG4gICAgLy8gdXNlIHRoaXMgZm9yIGluaXRpYWxpemF0aW9uXG4gICAgb25Mb2FkOiBmdW5jdGlvbiBvbkxvYWQoKSB7XG4gICAgICAgIHRoaXMubXlMYXllci5hY3RpdmUgPSBmYWxzZTtcbiAgICAgICAgdGhpcy5yZXdhcmRMYXllci5hY3RpdmUgPSBmYWxzZTtcblxuICAgICAgICB0aGlzLnJld2FyZHMgPSBbXTtcbiAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCAxMjsgaSsrKSB7XG4gICAgICAgICAgICB2YXIgcmUgPSB0aGlzLnJld2FyZFBhcmVudC5nZXRDaGlsZEJ5TmFtZSgncCcgKyAoaSArIDEpKTtcbiAgICAgICAgICAgIHJlLmxhYmVsID0gcmUuZ2V0Q2hpbGRCeU5hbWUoJ2MnKS5nZXRDb21wb25lbnQoY2MuTGFiZWwpO1xuICAgICAgICAgICAgdGhpcy5yZXdhcmRzLnB1c2gocmUpO1xuICAgICAgICB9XG5cbiAgICAgICAgLy8g6auY5Lqu5oul5pyJ55qE5aWW5ZOBXG4gICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgMTI7IGkrKykge1xuICAgICAgICAgICAgdmFyIHJlID0gdGhpcy5yZXdhcmRzW2ldO1xuICAgICAgICAgICAgaWYgKGkgPCB3aW5kb3cuZGF0YS5yZXdhcmRzLmxlbmd0aCkge1xuICAgICAgICAgICAgICAgIGlmICh3aW5kb3cuZGF0YS51c2VyaW5mby5yZXdhcmRzW2ldKSB7XG4gICAgICAgICAgICAgICAgICAgIHJlLmNvbG9yID0gbmV3IGNjLkNvbG9yKDI1NSwgMjU1LCAyNTUpO1xuICAgICAgICAgICAgICAgICAgICByZS5sYWJlbC5zdHJpbmcgPSAxO1xuICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIHJlLmNvbG9yID0gbmV3IGNjLkNvbG9yKDEyNCwgMTI0LCAxMjQpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgcmUuYWN0aXZlID0gZmFsc2U7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICB0aGlzLnVwZGF0ZURpc3BsYXkoKTtcbiAgICB9LFxuXG4gICAgdXBkYXRlRGlzcGxheTogZnVuY3Rpb24gdXBkYXRlRGlzcGxheShnb3QpIHtcbiAgICAgICAgaWYgKHdpbmRvdy5kYXRhLnVzZXJpbmZvLnN0YXR1cyA9PSAyKSB7XG4gICAgICAgICAgICB0aGlzLmxhYmVsLmFjdGl2ZSA9IHRydWU7XG4gICAgICAgICAgICB0aGlzLmJ0bi5hY3RpdmUgPSBmYWxzZTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHRoaXMubGFiZWwuYWN0aXZlID0gZmFsc2U7XG4gICAgICAgICAgICB0aGlzLmJ0bi5hY3RpdmUgPSB0cnVlO1xuICAgICAgICB9XG4gICAgfSxcblxuICAgIGJ0bk15UmV3YXJkOiBmdW5jdGlvbiBidG5NeVJld2FyZCgpIHtcbiAgICAgICAgdGhpcy5teUxheWVyLmFjdGl2ZSA9IHRydWU7XG4gICAgfSxcblxuICAgIGJ0bkNsb3NlTGF5ZXI6IGZ1bmN0aW9uIGJ0bkNsb3NlTGF5ZXIoKSB7XG4gICAgICAgIHRoaXMubXlMYXllci5hY3RpdmUgPSBmYWxzZTtcbiAgICB9LFxuXG4gICAgc2hvd01zZzogZnVuY3Rpb24gc2hvd01zZyhtc2cpIHtcbiAgICAgICAgdGhpcy5tc2dMYXllci5hY3RpdmUgPSB0cnVlO1xuICAgICAgICB0aGlzLm1zZ0xheWVyLmdldENoaWxkQnlOYW1lKCdMYWJlbCcpLmdldENvbXBvbmVudChjYy5MYWJlbCkuc3RyaW5nID0gbXNnO1xuICAgIH0sXG5cbiAgICBidG5HZXRSZXdhcmQ6IGZ1bmN0aW9uIGJ0bkdldFJld2FyZCgpIHtcbiAgICAgICAgdmFyIHRoaXogPSB0aGlzO1xuICAgICAgICAkLmFqYXgoe1xuICAgICAgICAgICAgdHlwZTogJ0dFVCcsXG4gICAgICAgICAgICB1cmw6IFwiZ2V0UmV3YXJkXCIsXG4gICAgICAgICAgICBkYXRhVHlwZTogXCJqc29uXCIsXG4gICAgICAgICAgICBkYXRhOiB7fSxcbiAgICAgICAgICAgIHN1Y2Nlc3M6IGZ1bmN0aW9uIHN1Y2Nlc3MoZGF0YSkge1xuICAgICAgICAgICAgICAgIGlmIChkYXRhLmNvZGUgPT0gMSkge1xuICAgICAgICAgICAgICAgICAgICAvL1xuICAgICAgICAgICAgICAgICAgICB3aW5kb3cuZGF0YS51c2VyaW5mby5pc0dvdCA9IHRydWU7XG4gICAgICAgICAgICAgICAgICAgIHRoaXoubXlMYXllci5hY3RpdmUgPSBmYWxzZTtcbiAgICAgICAgICAgICAgICAgICAgdGhpei5zaG93TXNnKCfmgqjlt7Lnu4/pooblj5bov4flpZblk4HkuoYnKTtcbiAgICAgICAgICAgICAgICB9IGVsc2UgaWYgKGRhdGEuY29kZSA9PSAwKSB7XG4gICAgICAgICAgICAgICAgICAgIHdpbmRvdy5kYXRhLnVzZXJpbmZvLmlzR290ID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICAgICAgdGhpei5teUxheWVyLmFjdGl2ZSA9IGZhbHNlO1xuICAgICAgICAgICAgICAgICAgICB0aGl6LnNob3dNc2coJ+WFkeWlluaIkOWKnycpO1xuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIHRoaXoudXBkYXRlRGlzcGxheSgpO1xuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIGVycm9yOiBmdW5jdGlvbiBlcnJvcihkYXRhKSB7fVxuICAgICAgICB9KTtcbiAgICB9LFxuXG4gICAgLy/lpZblk4Hooqvngrnlh7tcbiAgICBidG5SZXE6IGZ1bmN0aW9uIGJ0blJlcShldnQpIHtcbiAgICAgICAgdmFyIG5hbWUgPSBldnQudGFyZ2V0Lm5hbWU7XG4gICAgICAgIHZhciByZXdhcmRJbmRleCA9IHBhcnNlSW50KG5hbWUuc3Vic3RyaW5nKDEpKSAtIDE7XG5cbiAgICAgICAgdGhpcy5teUxheWVyLmFjdGl2ZSA9IGZhbHNlO1xuICAgICAgICB0aGlzLnJld2FyZExheWVyLmFjdGl2ZSA9IHRydWU7XG4gICAgICAgIHZhciBpbmZvID0gd2luZG93LmRhdGEucmV3YXJkc1tyZXdhcmRJbmRleF07XG4gICAgICAgIHRoaXMucmV3YXJkTGF5ZXIuZ2V0Q2hpbGRCeU5hbWUoJ25hbWUnKS5nZXRDb21wb25lbnQoY2MuTGFiZWwpLnN0cmluZyA9IGluZm8ubmFtZTtcbiAgICAgICAgdGhpcy5pdGVtRGVzYy5zdHJpbmcgPSBpbmZvLmRlc2MgfHwgXCLmsqHmnInor7TmmI5cIjtcbiAgICAgICAgdGhpcy5yZXdhcmRMYXllci5yZXdhcmRJbmRleCA9IHJld2FyZEluZGV4O1xuXG4gICAgICAgIHZhciBvd24gPSBldnQudGFyZ2V0LmNvbG9yLnIgIT0gMTI0O1xuICAgICAgICB0aGlzLnJld2FyZExheWVyLmlzZ290ID0gb3duO1xuXG4gICAgICAgIHRoaXMucmV3YXJkTGF5ZXIuZ2V0Q2hpbGRCeU5hbWUoJ3JlcScpLmFjdGl2ZSA9IG93bjtcblxuICAgICAgICBpZiAob3duKSB7XG4gICAgICAgICAgICB0aGlzLnJld2FyZExheWVyLmdldENoaWxkQnlOYW1lKCdzdG1wJykuYWN0aXZlID0gd2luZG93LmRhdGEudXNlcmluZm8ucmV3YXJkSW5kZXggPT0gcmV3YXJkSW5kZXg7XG4gICAgICAgICAgICB0aGlzLnJld2FyZExheWVyLmdldENoaWxkQnlOYW1lKCdzdG1wJykuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKS5zdHJpbmcgPSAn5bey55Sz6K+3JztcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHRoaXMucmV3YXJkTGF5ZXIuZ2V0Q2hpbGRCeU5hbWUoJ3N0bXAnKS5hY3RpdmUgPSB0cnVlO1xuICAgICAgICAgICAgdGhpcy5yZXdhcmRMYXllci5nZXRDaGlsZEJ5TmFtZSgnc3RtcCcpLmdldENvbXBvbmVudChjYy5MYWJlbCkuc3RyaW5nID0gJ+acquiOt+W+lyc7XG4gICAgICAgIH1cbiAgICB9LFxuXG4gICAgLy/nlLPor7fmjInpkq5cbiAgICBidG5Eb1JlcTogZnVuY3Rpb24gYnRuRG9SZXEoKSB7XG5cbiAgICAgICAgJC5hamF4KHtcbiAgICAgICAgICAgIHR5cGU6ICdHRVQnLFxuICAgICAgICAgICAgdXJsOiAncmVxdWVzdFJld2FyZCcsXG4gICAgICAgICAgICBkYXRhVHlwZTogXCJqc29uXCIsXG4gICAgICAgICAgICBkYXRhOiB7XG4gICAgICAgICAgICAgICAgcmV3YXJkSW5kZXg6IHRoaXMucmV3YXJkTGF5ZXIucmV3YXJkSW5kZXhcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBzdWNjZXNzOiBmdW5jdGlvbiBzdWNjZXNzKGRhdGEpIHtcbiAgICAgICAgICAgICAgICB3aW5kb3cuZGF0YS51c2VyaW5mby5yZXdhcmRJbmRleCA9IHRoaXMucmV3YXJkTGF5ZXIucmV3YXJkSW5kZXg7XG4gICAgICAgICAgICAgICAgdGhpcy5yZXdhcmRMYXllci5nZXRDaGlsZEJ5TmFtZSgnc3RtcCcpLmFjdGl2ZSA9IHRydWU7XG4gICAgICAgICAgICAgICAgdGhpcy5yZXdhcmRMYXllci5nZXRDaGlsZEJ5TmFtZSgnc3RtcCcpLmdldENvbXBvbmVudChjYy5MYWJlbCkuc3RyaW5nID0gJ+W3sueUs+ivtyc7XG4gICAgICAgICAgICAgICAgdGhpcy5zaG93TXNnKCfmiJDlip8nKTtcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBlcnJvcjogZnVuY3Rpb24gZXJyb3IoZGF0YSkge31cbiAgICAgICAgfSk7XG4gICAgfSxcblxuICAgIGJ0bk9rSW5mbzogZnVuY3Rpb24gYnRuT2tJbmZvKCkge1xuICAgICAgICB0aGlzLnJld2FyZExheWVyLmFjdGl2ZSA9IGZhbHNlO1xuICAgIH1cblxufSk7XG4vLyBjYWxsZWQgZXZlcnkgZnJhbWUsIHVuY29tbWVudCB0aGlzIGZ1bmN0aW9uIHRvIGFjdGl2YXRlIHVwZGF0ZSBjYWxsYmFja1xuLy8gdXBkYXRlOiBmdW5jdGlvbiAoZHQpIHtcblxuLy8gfSxcblxuY2MuX1JGcG9wKCk7IiwiXCJ1c2Ugc3RyaWN0XCI7XG5jYy5fUkZwdXNoKG1vZHVsZSwgJ2ZlZTVlQnh0WkZQUkt3OCtxLy9KMCtyJywgJ2hlbHBMYXllcicpO1xuLy8gU2NyaXB0XFxoZWxwTGF5ZXIuanNcblxuY2MuQ2xhc3Moe1xuICAgIFwiZXh0ZW5kc1wiOiBjYy5Db21wb25lbnQsXG5cbiAgICBwcm9wZXJ0aWVzOiB7XG4gICAgICAgIC8vIGZvbzoge1xuICAgICAgICAvLyAgICBkZWZhdWx0OiBudWxsLCAgICAgIC8vIFRoZSBkZWZhdWx0IHZhbHVlIHdpbGwgYmUgdXNlZCBvbmx5IHdoZW4gdGhlIGNvbXBvbmVudCBhdHRhY2hpbmdcbiAgICAgICAgLy8gICAgICAgICAgICAgICAgICAgICAgICAgICB0byBhIG5vZGUgZm9yIHRoZSBmaXJzdCB0aW1lXG4gICAgICAgIC8vICAgIHVybDogY2MuVGV4dHVyZTJELCAgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgdHlwZW9mIGRlZmF1bHRcbiAgICAgICAgLy8gICAgc2VyaWFsaXphYmxlOiB0cnVlLCAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0cnVlXG4gICAgICAgIC8vICAgIHZpc2libGU6IHRydWUsICAgICAgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgdHJ1ZVxuICAgICAgICAvLyAgICBkaXNwbGF5TmFtZTogJ0ZvbycsIC8vIG9wdGlvbmFsXG4gICAgICAgIC8vICAgIHJlYWRvbmx5OiBmYWxzZSwgICAgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgZmFsc2VcbiAgICAgICAgLy8gfSxcbiAgICAgICAgLy8gLi4uXG4gICAgICAgIGxhYmVsOiBjYy5MYWJlbFxuICAgIH0sXG5cbiAgICAvLyB1c2UgdGhpcyBmb3IgaW5pdGlhbGl6YXRpb25cbiAgICBvbkxvYWQ6IGZ1bmN0aW9uIG9uTG9hZCgpIHtcbiAgICAgICAgaWYgKHdpbmRvdy5kYXRhKSB7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyh0aGlzLmxhYmVsKTtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKHdpbmRvdy5kYXRhLmhlbHApO1xuICAgICAgICAgICAgdGhpcy5sYWJlbC5zdHJpbmcgPSB3aW5kb3cuZGF0YS5oZWxwO1xuICAgICAgICB9XG4gICAgfSxcblxuICAgIGJ0bklLbm93OiBmdW5jdGlvbiBidG5JS25vdygpIHtcbiAgICAgICAgdGhpcy5ub2RlLmFjdGl2ZSA9IGZhbHNlO1xuICAgIH1cblxufSk7XG4vLyBjYWxsZWQgZXZlcnkgZnJhbWUsIHVuY29tbWVudCB0aGlzIGZ1bmN0aW9uIHRvIGFjdGl2YXRlIHVwZGF0ZSBjYWxsYmFja1xuLy8gdXBkYXRlOiBmdW5jdGlvbiAoZHQpIHtcblxuLy8gfSxcblxuY2MuX1JGcG9wKCk7IiwiXCJ1c2Ugc3RyaWN0XCI7XG5jYy5fUkZwdXNoKG1vZHVsZSwgJzI4MGMzcnNaSkpLblo5UnFiQUxWd3RLJywgJ21lbnVTY2VuZScpO1xuLy8gU2NyaXB0XFxtZW51U2NlbmUuanNcblxuY2MuQ2xhc3Moe1xuICAgIFwiZXh0ZW5kc1wiOiBjYy5Db21wb25lbnQsXG5cbiAgICBwcm9wZXJ0aWVzOiB7XG4gICAgICAgIGluZm9MYXllcjogY2MuTm9kZSxcbiAgICAgICAgaW5wdXRMYXllcjogY2MuTm9kZSxcblxuICAgICAgICBuYW1lRWRpdDogY2MuRWRpdEJveCxcbiAgICAgICAgcGhvbmVFZGl0OiBjYy5FZGl0Qm94XG4gICAgfSxcblxuICAgIC8vIHVzZSB0aGlzIGZvciBpbml0aWFsaXphdGlvblxuICAgIG9uTG9hZDogZnVuY3Rpb24gb25Mb2FkKCkge1xuICAgICAgICB0aGlzLmluZm9MYXllci5hY3RpdmUgPSBmYWxzZTtcbiAgICAgICAgdGhpcy5pbnB1dExheWVyLmFjdGl2ZSA9IGZhbHNlO1xuICAgICAgICB0aGlzLmRvUmVxKCk7XG4gICAgfSxcblxuICAgIF9nb3RvR2FtZTogZnVuY3Rpb24gX2dvdG9HYW1lKCkge1xuICAgICAgICBpZiAodGhpcy5waG9uZSAmJiB0aGlzLnJlYWxOYW1lKSB7XG4gICAgICAgICAgICBjYy5kaXJlY3Rvci5sb2FkU2NlbmUoJ3BsYXlTY2VuZScpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgdGhpcy5pbnB1dExheWVyLmFjdGl2ZSA9IHRydWU7XG4gICAgICAgIH1cbiAgICB9LFxuXG4gICAgYnRuRG9TdGFydDogZnVuY3Rpb24gYnRuRG9TdGFydCgpIHtcbiAgICAgICAgaWYgKHRoaXMubmFtZUVkaXQuc3RyaW5nID09IFwiXCIgfHwgdGhpcy5waG9uZUVkaXQuc3RyaW5nID09IFwiXCIpIHtcbiAgICAgICAgICAgIGNjLmxvZygna29uZycpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgdGhpcy5waG9uZSA9IHRoaXMucGhvbmVFZGl0LnN0cmluZztcbiAgICAgICAgICAgIHRoaXMucmVhbE5hbWUgPSB0aGlzLm5hbWVFZGl0LnN0cmluZztcbiAgICAgICAgICAgIGNjLmxvZyh0aGlzLnBob25lLCB0aGlzLnJlYWxOYW1lKTtcbiAgICAgICAgICAgIHZhciB0aGl6ID0gdGhpcztcbiAgICAgICAgICAgICQuYWpheCh7XG4gICAgICAgICAgICAgICAgdHlwZTogJ0dFVCcsXG4gICAgICAgICAgICAgICAgdXJsOiBcInNldFBob25lXCIsXG4gICAgICAgICAgICAgICAgZGF0YVR5cGU6IFwianNvblwiLFxuICAgICAgICAgICAgICAgIGRhdGE6IHtcbiAgICAgICAgICAgICAgICAgICAgcGhvbmU6IHRoaXMucGhvbmUsXG4gICAgICAgICAgICAgICAgICAgIHJlYWxOYW1lOiB0aGlzLnJlYWxOYW1lXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICBzdWNjZXNzOiBmdW5jdGlvbiBzdWNjZXNzKHJldCkge1xuICAgICAgICAgICAgICAgICAgICBjYy5sb2cocmV0KTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHJldC5vaykgdGhpei5pbnB1dExheWVyLmFjdGl2ZSA9IGZhbHNlO1xuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgZXJyb3I6IGZ1bmN0aW9uIGVycm9yKGRhdGEpIHt9XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgIH0sXG5cbiAgICBkb1JlcTogZnVuY3Rpb24gZG9SZXEoKSB7XG4gICAgICAgIGlmICh0aGlzLmxvYWRpbmcpIHJldHVybjtcbiAgICAgICAgdGhpcy5sb2FkaW5nID0gdHJ1ZTtcbiAgICAgICAgdmFyIHRoaXogPSB0aGlzO1xuICAgICAgICAkLmFqYXgoe1xuICAgICAgICAgICAgdHlwZTogJ0dFVCcsXG4gICAgICAgICAgICB1cmw6IFwiZ2V0SW5mb1wiLFxuICAgICAgICAgICAgZGF0YVR5cGU6IFwianNvblwiLFxuICAgICAgICAgICAgZGF0YToge1xuICAgICAgICAgICAgICAgIHVzZXJpZDogXCJ0ZXN0MVwiXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgc3VjY2VzczogZnVuY3Rpb24gc3VjY2VzcyhyZXQpIHtcbiAgICAgICAgICAgICAgICB3aW5kb3cuZGF0YSA9IHJldDtcbiAgICAgICAgICAgICAgICB0aGl6LmxvYWRpbmcgPSBmYWxzZTtcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhyZXQpO1xuICAgICAgICAgICAgICAgIGlmICghcmV0LmVuYWJsZSkge1xuICAgICAgICAgICAgICAgICAgICBjYy5kaXJlY3Rvci5sb2FkU2NlbmUoJ2Nsb3NlJyk7XG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHJldC51c2VyaW5mby5waG9uZSAhPSBudWxsICYmIHJldC51c2VyaW5mby5waG9uZSAhPSB1bmRlZmluZWQpIHRoaXoucGhvbmUgPSByZXQudXNlcmluZm8ucGhvbmU7XG4gICAgICAgICAgICAgICAgICAgIGlmIChyZXQudXNlcmluZm8ucmVhbE5hbWUgIT0gbnVsbCAmJiByZXQudXNlcmluZm8ucmVhbE5hbWUgIT0gdW5kZWZpbmVkKSB0aGl6LnJlYWxOYW1lID0gcmV0LnVzZXJpbmZvLnJlYWxOYW1lO1xuXG4gICAgICAgICAgICAgICAgICAgIGlmICh0aGl6LmFjdGlvbiA9PSAnZ2FtZScpIHRoaXouX2dvdG9HYW1lKCk7ZWxzZSBpZiAodGhpei5hY3Rpb24gPT0gJ2hlbHAnKSB0aGl6LmluZm9MYXllci5hY3RpdmUgPSB0cnVlO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBlcnJvcjogZnVuY3Rpb24gZXJyb3IoZGF0YSkge1xuICAgICAgICAgICAgICAgIHRoaXoubG9hZGluZyA9IGZhbHNlO1xuICAgICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICB9LFxuXG4gICAgYnRuU3RhcnQ6IGZ1bmN0aW9uIGJ0blN0YXJ0KCkge1xuICAgICAgICB0aGlzLmFjdGlvbiA9ICdnYW1lJztcblxuICAgICAgICBpZiAoIXRoaXMubG9hZGluZykgdGhpcy5fZ290b0dhbWUoKTtcbiAgICB9LFxuICAgIGJ0bkluZm86IGZ1bmN0aW9uIGJ0bkluZm8oKSB7XG4gICAgICAgIHRoaXMuYWN0aW9uID0gJ2hlbHAnO1xuICAgICAgICBpZiAoIXRoaXMubG9hZGluZykgdGhpcy5pbmZvTGF5ZXIuYWN0aXZlID0gdHJ1ZTtcbiAgICB9XG59KTtcblxuY2MuX1JGcG9wKCk7IiwiXCJ1c2Ugc3RyaWN0XCI7XG5jYy5fUkZwdXNoKG1vZHVsZSwgJzUyMjY3dnYxemRQMlp6TTVSK0o1Mk9JJywgJ3BsYXlTY2VuZScpO1xuLy8gU2NyaXB0XFxwbGF5U2NlbmUuanNcblxuY2MuQ2xhc3Moe1xuICAgICdleHRlbmRzJzogY2MuQ29tcG9uZW50LFxuXG4gICAgcHJvcGVydGllczoge1xuICAgICAgICAvLyBmb286IHtcbiAgICAgICAgLy8gICAgZGVmYXVsdDogbnVsbCwgICAgICAvLyBUaGUgZGVmYXVsdCB2YWx1ZSB3aWxsIGJlIHVzZWQgb25seSB3aGVuIHRoZSBjb21wb25lbnQgYXR0YWNoaW5nXG4gICAgICAgIC8vICAgICAgICAgICAgICAgICAgICAgICAgICAgdG8gYSBub2RlIGZvciB0aGUgZmlyc3QgdGltZVxuICAgICAgICAvLyAgICB1cmw6IGNjLlRleHR1cmUyRCwgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHR5cGVvZiBkZWZhdWx0XG4gICAgICAgIC8vICAgIHNlcmlhbGl6YWJsZTogdHJ1ZSwgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgdHJ1ZVxuICAgICAgICAvLyAgICB2aXNpYmxlOiB0cnVlLCAgICAgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHRydWVcbiAgICAgICAgLy8gICAgZGlzcGxheU5hbWU6ICdGb28nLCAvLyBvcHRpb25hbFxuICAgICAgICAvLyAgICByZWFkb25seTogZmFsc2UsICAgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIGZhbHNlXG4gICAgICAgIC8vIH0sXG4gICAgICAgIC8vIC4uLlxuICAgICAgICBoYW1tZXI6IGNjLk5vZGUsXG4gICAgICAgIGVnZzogY2MuTm9kZSxcblxuICAgICAgICB3aW5MYXllcjogY2MuTm9kZSxcbiAgICAgICAgbG9zdExheWVyOiBjYy5Ob2RlLFxuICAgICAgICBpbmZvTGF5ZXI6IGNjLk5vZGUsXG4gICAgICAgIG1zZ0xheWVyOiBjYy5Ob2RlLFxuICAgICAgICBzaGFyZUxheWVyOiBjYy5Ob2RlLFxuICAgICAgICByZXdhcmRMYXllcjogY2MuTm9kZSxcblxuICAgICAgICBlZ2dQYXJlbnQ6IGNjLk5vZGUsXG5cbiAgICAgICAgaXRlbURlc2M6IGNjLkxhYmVsLFxuXG4gICAgICAgIGNvdW50TGFiZWw6IGNjLkxhYmVsLFxuICAgICAgICByZXdhcmRQYXJlbnQ6IGNjLk5vZGUsXG5cbiAgICAgICAgZnJhbWVUb3A6IFtjYy5TcHJpdGVGcmFtZV0sXG4gICAgICAgIGZyYW1lRG93bjogW2NjLlNwcml0ZUZyYW1lXVxuICAgIH0sXG5cbiAgICAvLyB1c2UgdGhpcyBmb3IgaW5pdGlhbGl6YXRpb25cbiAgICBvbkxvYWQ6IGZ1bmN0aW9uIG9uTG9hZCgpIHtcbiAgICAgICAgdGhpcy5pbmZvTGF5ZXIuYWN0aXZlID0gZmFsc2U7XG4gICAgICAgIHRoaXMubG9zdExheWVyLmFjdGl2ZSA9IGZhbHNlO1xuICAgICAgICB0aGlzLndpbkxheWVyLmFjdGl2ZSA9IGZhbHNlO1xuICAgICAgICB0aGlzLnNoYXJlTGF5ZXIuYWN0aXZlID0gZmFsc2U7XG4gICAgICAgIHRoaXMubXNnTGF5ZXIuYWN0aXZlID0gZmFsc2U7XG4gICAgICAgIHRoaXMucmV3YXJkTGF5ZXIuYWN0aXZlID0gZmFsc2U7XG5cbiAgICAgICAgdGhpcy5oYW1tZXIuekluZGV4ID0gMTtcbiAgICAgICAgdGhpcy5oYW1tZXJBbmkgPSB0aGlzLmhhbW1lci5nZXRDb21wb25lbnQoY2MuQW5pbWF0aW9uKTtcblxuICAgICAgICB0aGlzLmhhbW1lckFuaS5vbignZmluaXNoZWQnLCB0aGlzLl9vblBsYXksIHRoaXMpO1xuICAgICAgICB0aGlzLmhhbW1lci5hY3RpdmUgPSBmYWxzZTtcbiAgICAgICAgdGhpcy5lZ2cuYWN0aXZlID0gZmFsc2U7XG5cbiAgICAgICAgdGhpcy5yZXdhcmRzID0gW107XG4gICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgMTI7IGkrKykge1xuICAgICAgICAgICAgdmFyIHJlID0gdGhpcy5yZXdhcmRQYXJlbnQuZ2V0Q2hpbGRCeU5hbWUoJ3AnICsgKGkgKyAxKSk7XG4gICAgICAgICAgICByZS5sYWJlbCA9IHJlLmdldENoaWxkQnlOYW1lKCdjJykuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKTtcbiAgICAgICAgICAgIHRoaXMucmV3YXJkcy5wdXNoKHJlKTtcbiAgICAgICAgfVxuXG4gICAgICAgIHdpbmRvdy5wbGF5ID0gdGhpcztcbiAgICAgICAgdGhpcy5fdXBkYXRlTGFiZWwoKTtcblxuICAgICAgICAvLyDpq5jkuq7mi6XmnInnmoTlpZblk4FcbiAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCAxMjsgaSsrKSB7XG4gICAgICAgICAgICB2YXIgcmUgPSB0aGlzLnJld2FyZHNbaV07XG4gICAgICAgICAgICBpZiAoaSA8IHdpbmRvdy5kYXRhLnJld2FyZHMubGVuZ3RoKSB7XG4gICAgICAgICAgICAgICAgaWYgKHdpbmRvdy5kYXRhLnVzZXJpbmZvLnJld2FyZHNbaV0pIHtcbiAgICAgICAgICAgICAgICAgICAgcmUuY29sb3IgPSBuZXcgY2MuQ29sb3IoMjU1LCAyNTUsIDI1NSk7XG4gICAgICAgICAgICAgICAgICAgIHJlLmxhYmVsLnN0cmluZyA9IDE7XG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgcmUuY29sb3IgPSBuZXcgY2MuQ29sb3IoMTI0LCAxMjQsIDEyNCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICByZS5hY3RpdmUgPSBmYWxzZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH0sXG5cbiAgICBfdXBkYXRlTGFiZWw6IGZ1bmN0aW9uIF91cGRhdGVMYWJlbCgpIHtcbiAgICAgICAgaWYgKHdpbmRvdy5kYXRhKSB0aGlzLmNvdW50TGFiZWwuc3RyaW5nID0gJ+S9oOi/mOWJqScgKyB3aW5kb3cuZGF0YS51c2VyaW5mby5jb3VudCArICfmrKHmnLrkvJonO1xuICAgIH0sXG5cbiAgICBzaG93TXNnOiBmdW5jdGlvbiBzaG93TXNnKG1zZykge1xuICAgICAgICB0aGlzLm1zZ0xheWVyLmFjdGl2ZSA9IHRydWU7XG4gICAgICAgIHRoaXMubXNnTGF5ZXIuZ2V0Q2hpbGRCeU5hbWUoJ0xhYmVsJykuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKS5zdHJpbmcgPSBtc2c7XG4gICAgfSxcblxuICAgIF9zaG93ZHVpSmlhbmc6IGZ1bmN0aW9uIF9zaG93ZHVpSmlhbmcocmV3YXJkSW5kZXgpIHtcbiAgICAgICAgdGhpcy5yZXdhcmRMYXllci5hY3RpdmUgPSB0cnVlO1xuICAgICAgICB2YXIgaW5mbyA9IHdpbmRvdy5kYXRhLnJld2FyZHNbcmV3YXJkSW5kZXhdO1xuICAgICAgICB0aGlzLnJld2FyZExheWVyLmdldENoaWxkQnlOYW1lKCduYW1lJykuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKS5zdHJpbmcgPSBpbmZvLm5hbWU7XG4gICAgICAgIHRoaXMucmV3YXJkTGF5ZXIuZ2V0Q2hpbGRCeU5hbWUoJ3N0bXAnKS5hY3RpdmUgPSB3aW5kb3cuZGF0YS51c2VyaW5mby5yZXdhcmRJbmRleCA9PSByZXdhcmRJbmRleDtcblxuICAgICAgICB0aGlzLml0ZW1EZXNjLnN0cmluZyA9IGluZm8uZGVzYyB8fCBcIuayoeacieivtOaYjlwiO1xuICAgICAgICB0aGlzLnJld2FyZExheWVyLnJld2FyZEluZGV4ID0gcmV3YXJkSW5kZXg7XG4gICAgfSxcblxuICAgIHJlcXVlc3Q6IGZ1bmN0aW9uIHJlcXVlc3QocmVxLCBhcmcsIGYpIHtcbiAgICAgICAgdmFyIGNiID0gZi5iaW5kKHRoaXMpO1xuICAgICAgICB0aGlzLmxvYWRpbmcgPSB0cnVlO1xuICAgICAgICAkLmFqYXgoe1xuICAgICAgICAgICAgdHlwZTogJ0dFVCcsXG4gICAgICAgICAgICB1cmw6IHJlcSxcbiAgICAgICAgICAgIGRhdGFUeXBlOiBcImpzb25cIixcbiAgICAgICAgICAgIGRhdGE6IGFyZyB8fCB7fSxcbiAgICAgICAgICAgIHN1Y2Nlc3M6IGZ1bmN0aW9uIHN1Y2Nlc3MoZGF0YSkge1xuICAgICAgICAgICAgICAgIHRoaXMubG9hZGluZyA9IGZhbHNlO1xuICAgICAgICAgICAgICAgIGNiKGRhdGEpO1xuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIGVycm9yOiBmdW5jdGlvbiBlcnJvcihkYXRhKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5sb2FkaW5nID0gZmFsc2U7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgIH0sXG5cbiAgICBidG5TaGVuZ3FpbjogZnVuY3Rpb24gYnRuU2hlbmdxaW4oZXZ0KSB7XG4gICAgICAgIHRoaXMucmVxdWVzdCgncmVxdWVzdFJld2FyZCcsIHtcbiAgICAgICAgICAgIHJld2FyZEluZGV4OiB0aGlzLnJld2FyZExheWVyLnJld2FyZEluZGV4XG4gICAgICAgIH0sIGZ1bmN0aW9uIChkYXRhKSB7XG4gICAgICAgICAgICB3aW5kb3cuZGF0YS51c2VyaW5mby5yZXdhcmRJbmRleCA9IHRoaXMucmV3YXJkTGF5ZXIucmV3YXJkSW5kZXg7XG4gICAgICAgICAgICB0aGlzLnJld2FyZExheWVyLmdldENoaWxkQnlOYW1lKCdzdG1wJykuYWN0aXZlID0gdHJ1ZTtcbiAgICAgICAgfSk7XG4gICAgfSxcblxuICAgIGJ0bkd1YW5CaUR1aUppYW5nOiBmdW5jdGlvbiBidG5HdWFuQmlEdWlKaWFuZygpIHtcbiAgICAgICAgdGhpcy5yZXdhcmRMYXllci5hY3RpdmUgPSBmYWxzZTtcbiAgICB9LFxuXG4gICAgb25TaGFyZTogZnVuY3Rpb24gb25TaGFyZSgpIHtcbiAgICAgICAgdGhpcy5yZXF1ZXN0KCd1c2VyU2hhcmVkJywge30sIGZ1bmN0aW9uIChkYXRhKSB7XG4gICAgICAgICAgICAvLyDliIbkuqvmiJDlip9cbiAgICAgICAgICAgIHdpbmRvdy5kYXRhLnVzZXJpbmZvLmNvdW50ID0gZGF0YS5hZGRjb3VudDtcbiAgICAgICAgICAgIHRoaXouX3VwZGF0ZUxhYmVsKCk7XG4gICAgICAgICAgICB0aGl6LnNoYXJlTGF5ZXIuYWN0aXZlID0gZmFsc2U7XG4gICAgICAgICAgICB0aGl6LnNob3dNc2coXCLliIbkuqvmiJDlip9cIik7XG4gICAgICAgIH0pO1xuICAgIH0sXG5cbiAgICByZXdhcmRQcmVzczogZnVuY3Rpb24gcmV3YXJkUHJlc3MoZXZ0KSB7XG4gICAgICAgIHZhciBuYW1lID0gZXZ0LnRhcmdldC5uYW1lO1xuICAgICAgICB2YXIgaWR4ID0gcGFyc2VJbnQobmFtZS5zdWJzdHJpbmcoMSkpIC0gMTtcblxuICAgICAgICBpZiAoIXdpbmRvdy5kYXRhKSByZXR1cm47XG5cbiAgICAgICAgaWYgKGV2dC50YXJnZXQuY29sb3IuciA9PSAxMjQpIHtcbiAgICAgICAgICAgIHRoaXMuc2hvd01zZyh3aW5kb3cuZGF0YS5yZXdhcmRzW2lkeF0ubmFtZSArIFwiIO+8iOacquiOt+W+l++8iVwiKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHRoaXMuX3Nob3dkdWlKaWFuZyhpZHgpO1xuICAgICAgICB9XG4gICAgfSxcblxuICAgIGVnZ1ByZXNzOiBmdW5jdGlvbiBlZ2dQcmVzcyhldnQpIHtcbiAgICAgICAgdGhpcy5oYW1tZXJBbmkuc3RvcCgpO1xuICAgICAgICB0aGlzLmhhbW1lci5hY3RpdmUgPSB0cnVlO1xuXG4gICAgICAgIHRoaXMuaGFtbWVyLnggPSBldnQudGFyZ2V0Lng7XG4gICAgICAgIHRoaXMuaGFtbWVyLnkgPSBldnQudGFyZ2V0Lnk7XG5cbiAgICAgICAgdGhpcy5oYW1tZXJBbmkucGxheSgpO1xuICAgICAgICB0aGlzLmhhbW1lci5nZXRDb21wb25lbnQoY2MuQXVkaW9Tb3VyY2UpLnBsYXkoKTtcblxuICAgICAgICB2YXIgdGhpeiA9IHRoaXM7XG4gICAgICAgIHZhciBlZ2dJbmRleCA9IHBhcnNlSW50KGV2dC50YXJnZXQubmFtZSkgLSAxO1xuXG4gICAgICAgIGlmICh0aGlzLmxvYWRpbmcgJiYgIXdpbmRvdy5kYXRhKSB7XG4gICAgICAgICAgICBjYy5sb2codGhpcy5sb2FkaW5nKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmICh3aW5kb3cuZGF0YS51c2VyaW5mby5jb3VudCA8PSAwKSB7XG4gICAgICAgICAgICAvLyDmrKHmlbDkuI3otrNcbiAgICAgICAgICAgIHRoaXMuc2hhcmVMYXllci5hY3RpdmUgPSB0cnVlO1xuXG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cblxuICAgICAgICB0aGlzLnJlcXVlc3QoJ2hpdEVnZycsIHtcbiAgICAgICAgICAgIGVnZ0luZGV4OiBlZ2dJbmRleFxuICAgICAgICB9LCBmdW5jdGlvbiAoZGF0YSkge1xuICAgICAgICAgICAgdGhpei5sb2FkaW5nID0gZmFsc2U7XG4gICAgICAgICAgICB3aW5kb3cuZGF0YS51c2VyaW5mby5jb3VudC0tO1xuICAgICAgICAgICAgdGhpei5fdXBkYXRlTGFiZWwoKTtcbiAgICAgICAgICAgIHRoaXouX2JyZWFrRWdnKGV2dCk7XG5cbiAgICAgICAgICAgIC8vIOagh+iusOm4oeibi+iiq+aJk+eijlxuICAgICAgICAgICAgd2luZG93LmRhdGEudXNlcmluZm8uZWdnc1tlZ2dJbmRleF0gPSB0cnVlO1xuXG4gICAgICAgICAgICB2YXIgcmV3YXJkSW5kZXggPSBkYXRhLnJld2FyZDtcbiAgICAgICAgICAgIGlmIChyZXdhcmRJbmRleCAhPSBudWxsIHx8IHJld2FyZEluZGV4ICE9IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgICAgIC8vIOmrmOS6ruWlluWTgVxuICAgICAgICAgICAgICAgIHRoaXoucmV3YXJkc1tyZXdhcmRJbmRleF0uY29sb3IgPSBuZXcgY2MuQ29sb3IoMjU1LCAyNTUsIDI1NSk7XG4gICAgICAgICAgICAgICAgd2luZG93LmRhdGEudXNlcmluZm8ucmV3YXJkID0gcmV3YXJkSW5kZXg7XG4gICAgICAgICAgICAgICAgdGhpei5yZXdhcmRzW3Jld2FyZEluZGV4XS5sYWJlbC5zdHJpbmcgPSAnMSc7XG5cbiAgICAgICAgICAgICAgICB0aGl6LndpbkxheWVyLmFjdGl2ZSA9IHRydWU7XG4gICAgICAgICAgICAgICAgdGhpei53aW5MYXllci5yZXdhcmRJbmRleCA9IHJld2FyZEluZGV4O1xuICAgICAgICAgICAgICAgIHRoaXoud2luTGF5ZXIuZ2V0Q2hpbGRCeU5hbWUoJ25hbWUnKS5nZXRDb21wb25lbnQoY2MuTGFiZWwpLnN0cmluZyA9IHdpbmRvdy5kYXRhLnJld2FyZHNbcmV3YXJkSW5kZXhdLm5hbWU7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIHRoaXoubG9zdExheWVyLmFjdGl2ZSA9IHRydWU7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgIH0sXG5cbiAgICBfc2V0RWdnQnJlYWs6IGZ1bmN0aW9uIF9zZXRFZ2dCcmVhayhpbmRleCkge1xuICAgICAgICB2YXIgb2xkX2VnZyA9IHRoaXMuZWdnUGFyZW50LmdldENoaWxkQnlOYW1lKCcnICsgKGluZGV4ICsgMSkpO1xuICAgICAgICBvbGRfZWdnLmFjdGl2ZSA9IGZhbHNlO1xuXG4gICAgICAgIHRoaXMuYnJlYWtlZEVHRyA9IG9sZF9lZ2c7XG5cbiAgICAgICAgdmFyIGVnZyA9IGNjLmluc3RhbnRpYXRlKHRoaXMuZWdnKTtcbiAgICAgICAgb2xkX2VnZy5icmVha2VyID0gZWdnO1xuXG4gICAgICAgIGVnZy5wYXJlbnQgPSB0aGlzLmVnZ1BhcmVudDtcbiAgICAgICAgZWdnLmFjdGl2ZSA9IHRydWU7XG4gICAgICAgIGVnZy5wb3NpdGlvbiA9IG9sZF9lZ2cucG9zaXRpb247XG5cbiAgICAgICAgZWdnLmdldENoaWxkQnlOYW1lKCd0b3AnKS5vcGFjaXR5ID0gMDtcbiAgICAgICAgZWdnLmdldENoaWxkQnlOYW1lKCd0b3AnKS5nZXRDb21wb25lbnQoY2MuU3ByaXRlKS5zcHJpdGVGcmFtZSA9IHRoaXMuZnJhbWVUb3BbaW5kZXhdO1xuICAgICAgICBlZ2cuZ2V0Q2hpbGRCeU5hbWUoJ2Rvd24nKS5nZXRDb21wb25lbnQoY2MuU3ByaXRlKS5zcHJpdGVGcmFtZSA9IHRoaXMuZnJhbWVEb3duW2luZGV4XTtcblxuICAgICAgICByZXR1cm4gZWdnO1xuICAgIH0sXG5cbiAgICBfYnJlYWtFZ2c6IGZ1bmN0aW9uIF9icmVha0VnZyhldnQpIHtcbiAgICAgICAgdmFyIGlkeCA9IHBhcnNlSW50KGV2dC50YXJnZXQubmFtZSkgLSAxO1xuICAgICAgICB2YXIgZWdnID0gdGhpcy5fc2V0RWdnQnJlYWsoaWR4KTtcbiAgICAgICAgZWdnLmdldENoaWxkQnlOYW1lKCd0b3AnKS5vcGFjaXR5ID0gMjU1O1xuICAgICAgICBlZ2cuZ2V0Q29tcG9uZW50KGNjLkFuaW1hdGlvbikucGxheSgpO1xuICAgIH0sXG5cbiAgICByZXN0b3JlRWdnczogZnVuY3Rpb24gcmVzdG9yZUVnZ3MoKSB7XG4gICAgICAgIGlmICghdGhpcy5icmVha2VkRUdHKSByZXR1cm47XG4gICAgICAgIHRoaXMuYnJlYWtlZEVHRy5hY3RpdmUgPSB0cnVlO1xuICAgICAgICB0aGlzLmJyZWFrZWRFR0cuYnJlYWtlci5wYXJlbnQgPSBudWxsO1xuICAgICAgICB0aGlzLmJyZWFrZWRFR0cgPSBudWxsO1xuICAgIH0sXG5cbiAgICBfb25QbGF5OiBmdW5jdGlvbiBfb25QbGF5KCkge1xuICAgICAgICB0aGlzLmhhbW1lci5hY3RpdmUgPSBmYWxzZTtcbiAgICB9LFxuXG4gICAgYnRuSW5mbzogZnVuY3Rpb24gYnRuSW5mbygpIHtcbiAgICAgICAgdGhpcy5pbmZvTGF5ZXIuYWN0aXZlID0gdHJ1ZTtcbiAgICB9LFxuXG4gICAgYnRuQ2hlY2tJbmZvOiBmdW5jdGlvbiBidG5DaGVja0luZm8oKSB7XG4gICAgICAgIHRoaXMud2luTGF5ZXIuYWN0aXZlID0gZmFsc2U7XG4gICAgICAgIHRoaXMucmVzdG9yZUVnZ3MoKTtcbiAgICAgICAgdGhpcy5fc2hvd2R1aUppYW5nKHRoaXMud2luTGF5ZXIucmV3YXJkSW5kZXgpO1xuICAgIH0sXG5cbiAgICBidG5Db250aW51ZUdhbWU6IGZ1bmN0aW9uIGJ0bkNvbnRpbnVlR2FtZSgpIHtcbiAgICAgICAgdGhpcy5yZXN0b3JlRWdncygpO1xuICAgICAgICB0aGlzLndpbkxheWVyLmFjdGl2ZSA9IGZhbHNlO1xuICAgIH0sXG5cbiAgICBidG5Db250aW51ZUdhbWVNc2c6IGZ1bmN0aW9uIGJ0bkNvbnRpbnVlR2FtZU1zZygpIHtcbiAgICAgICAgdGhpcy5tc2dMYXllci5hY3RpdmUgPSBmYWxzZTtcbiAgICB9LFxuXG4gICAgYnRuQWdhaW46IGZ1bmN0aW9uIGJ0bkFnYWluKCkge1xuICAgICAgICB0aGlzLnJlc3RvcmVFZ2dzKCk7XG4gICAgICAgIHRoaXMubG9zdExheWVyLmFjdGl2ZSA9IGZhbHNlO1xuICAgIH0sXG5cbiAgICBidG5CYWNrOiBmdW5jdGlvbiBidG5CYWNrKCkge1xuICAgICAgICBjYy5kaXJlY3Rvci5sb2FkU2NlbmUoJ21lbnVTY2VuZScpO1xuICAgIH1cblxufSk7XG4vLyBjYWxsZWQgZXZlcnkgZnJhbWUsIHVuY29tbWVudCB0aGlzIGZ1bmN0aW9uIHRvIGFjdGl2YXRlIHVwZGF0ZSBjYWxsYmFja1xuLy8gdXBkYXRlOiBmdW5jdGlvbiAoZHQpIHtcblxuLy8gfSxcblxuY2MuX1JGcG9wKCk7Il19
