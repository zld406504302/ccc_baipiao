
function appendLine(name) {

}

function applay(input) {
    var td = input.parent("td");
    var inputText = input.val();//这个地方不能用text(),而是用val()
    td.empty();
    //4.将保存的文本内容填充到td中去
    td.html(inputText);
    //5.让td重新拥有点击事件
    td.dblclick(tdClick);
}

function tdClick(){
     //1.取出当前td里面的文本内容
     var td = $(this);
     if (td.attr('name') == 'path')
        return
     var tdText = td.text();
    //2.清空td里面的文本内容
     td.html(""); //也可以使用td.empty();
    //3.建立一个输入框，也就是input标签
    var input = $("<input>");
    // input.width(td.width())
    //4.将输入框的内容设为刚才保存的td里面的文本内容
      input.attr("value",tdText);
     //4.5.让文本框能够响应键盘按下的keyup事件，主要是用于处理回车确认
       input.keyup(function(event){
           //1.获取当前用户按下的键值
              //解决不同浏览器获得事件对象的差异,
             // IE用自动提供window.event，而其他浏览器必须显示的提供，即在方法参数中加上event
           var myEvent = event || window.event;
           var keyCode = myEvent.keyCode;
           //2.判断是否是回车按下
           if(keyCode == 13){
               //2.保存当前输入框的内容
                var input = $(this);
                applay(input)
           }
       });
       input.blur(function() {
            applay($(this))
       })
    //5.将输入框加到td中
      td.append(input);  //也可以用input.appendTo(td);
    //5.5 让文本框中的文字被高亮选中
    //需要将jquery对象转化为DOM对象
     var inputDom = input.get(0);
     inputDom.select();
    //6.需要移除td上的点击事件
    td.unbind("click");
};

function parseTR(arr, tr) {
    var tds = $(tr).find('td')
    var info = {}
    for (var j = 1; j < tds.length; j++) {
        var td = $(tds[j])
        var name = td.attr('name')
        var text = td.text();
        if (name == 'path') {
            // info[name] = td.find('input').val()
        } else {
            info[name] = td.text()
        }
    }

    if (info.name == '' || info.name == null) {
      return false
    } else {
      arr.push(info)
    }
    return true;
}

function getTableValue() {
    var trs = $('#items').find('tr')

    var arr = []
    for (var i = 1; i < trs.length; i++) {
        if (!parseTR(arr, trs[i])) {
          break;
        }
    } 
    
    return arr
}

function saveTableValue(json) {
  var trs = $('#items').find('tr')

  for (var i = 1; i < json.length + 1; i++) {
    var tds = $(trs[i]).find('td')
    var cfg = json[i-1]
    for (var j = 1; j < tds.length; j++) {
      var td = $(tds[j])
      var name = td.attr('name')
      if (name != 'path')
        td.text(cfg[name])
    }
  } 
}

function update() {
  $.ajax({
      type: 'GET',
      url: "options" ,
      dataType: "json",
      data: {
          get : '2',
      },
      success: function(ret) {
          $("#enable input:radio[value="+(ret.enable?1:0)+"]").attr("checked", true);
          $('#help').val(ret.help)
          $('#share-reward').val(ret.shared_reward)
          $('#default-reward').val(ret.default_count)
          saveTableValue(ret.rewards)
          window.data = ret;
      },
      error : function(data) {
      }
  });
}

function save() {
    var rewards = getTableValue()
    var isEnable = parseInt($('#enable input:radio:checked').val()) == 1
    var helpText = $('#help').val()
    var shared_reward = parseInt($('#share-reward').val())
    var default_count = parseInt($('#default-reward').val())

    $.ajax({
        type: 'POST',
        url: "setting" ,
        dataType: "json",
        data: {
            rewards : rewards,
            enable : isEnable,
            help : helpText,
            shared_reward : shared_reward,
            default_count : default_count,
        },
        success: function(ret) {
            setTimeout(update, 0.3)
            if (ret.ok) {
              alert('成功')
            } else {
              alert('失败' + ret)
            }
        },
        error : function(data) {
            alert('失败' + data)
        }
    });
}

function getRName(idx) {
  var v = window.data.rewards[idx]
  if (v == null || v == undefined)
    return '错误id  ' + idx
  return v.name
}

function appendUser(u) {
  var str = '<tr>' +
            '<td width="10%">' + u.realName + '</td>' + 
            '<td>' + u.phone + '</td>' +
            '<td>' + getRName(u.rewardIndex) + '</td>' +
            '</tr>'

  $("#users").append(str);
}

function appendList(data) {
  $("#users").empty();
  var str = '<tr>' +
          '<td width="10%">实名</td>' + 
          '<td>手机</td>' +
          '<td>奖品</td>' +
          '</tr>'
  $("#users").append(str);

  for (var i = 0; i < data.length; i++) {
    appendUser(data[i])
  }
}

function getList(status) {
  console.log('getList')
  $.ajax({
      type: 'GET',
      url: "options" ,
      dataType: "json",
      data: {
          get : '3',
          status : status, 
      },
      success: function(ret) {
        console.log('data', ret)
          appendList(ret)
      },
      error : function(data) {
        console.log(data)
      }
  });
}

$(document).ready(function() {

    for (var i = 0; i < 12; i++) {
        var str = '<tr id="td'+i+'">' +
                  '<td width="10%">奖品' + (i+1) + '</td>'+
                  '<td name="name" width="20%"></td>'+
                  '<td name="chance" width="20%"></td>' +
                  '<td name="desc"></td>' +
                // + '<td name="path"><input type="file" name="file"></td></tr>'
                  // '<td name="path"></td>' +
                  '</tr>'

        $("#items").append(str);
    }
    $("#items td").dblclick(tdClick);
    $('#items').prepend(
      '<tr>' +
      '<td></td>'+
      '<td>名字</td>'+
      '<td>概率</td>' +
      '<td>说明</td>'+
      // '<td>图片替换</td>'+
      '</tr>')

    $('#save').click(save)
    $('#getlist1').click(function() { getList(1) })
    $('#getlist2').click(function() { getList(2) })

    update()
});