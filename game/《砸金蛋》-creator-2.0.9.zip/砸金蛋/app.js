
/**
 * Module dependencies.
 */

require('./DBMgr');


var fs = require("fs")

var express = require('express');
var session = require('express-session');
var cookieParser = require('cookie-parser');

var routes = require('./routes');
var upload = require('jquery-file-upload-middleware');

var http = require('http');
var path = require('path');
var ejs = require('ejs');

var app = express();

// all environments
app.set('port', process.env.PORT || 3000);

// app.set('views', path.join(__dirname, 'views'));
// app.set('view engine', 'jade');
app.engine('html', ejs.__express);
app.set('view engine', 'html');
// app.use(express.static(__dirname + '/views'));

app.use(cookieParser());
app.use(session({
  secret: 'session_secret', // 建议使用 128 个字符的随机字符串
  cookie: { maxAge: 60 * 1000 }
}));

app.use(express.favicon());//网站图标
// app.use(express.logger('dev'));
app.use(express.json());
app.use(express.urlencoded());
app.use(express.methodOverride());
app.use(app.router);
app.use(express.static(path.join(__dirname, 'public')));

upload.configure({
        uploadDir: __dirname + '/public/uploads',
        uploadUrl: '/uploads',
        imageVersions: {
            thumbnail: {
                width: 80,
                height: 80
            }
        }
    });

app.configure(function() {
    app.use('/upload', upload.fileHandler());
    app.use(express.bodyParser());
})

global.config = JSON.parse(fs.readFileSync("config.json"));

// development only
if ('development' == app.get('env')) {
  app.use(express.errorHandler());
}

var user = require('./routes/user');
app.get('/game/web-mobile/getInfo', user.getInfo);
app.get('/game/web-mobile/hitEgg', user.hitEgg);
app.get('/game/web-mobile/userShared', user.userShared);
app.get('/game/web-mobile/setPhone', user.setPhone);
app.get('/game/web-mobile/getReward', user.getReward);
app.get('/game/web-mobile/requestReward', user.requestReward);

app.get('/login', function(req, res){
  res.send("请登录")
});

app.get('/options', function(req, res) {
  if (req.query.get == '1') {
    res.render('options')
  } else if (req.query.get == '2') {
    res.send(global.config)
  } else if (req.query.get == '3') {
    DBMgr.getList(req.query.status, (d)=>{
      res.send(d)
    })
  }
})

app.post('/setting', function(req, res) {
  var config = {
      rewards : [],
      help : req.body.help,
      shared_reward : parseInt(req.body.shared_reward),
      default_count : parseInt(req.body.default_count),
      enable : (req.body.enable == 'true' ? true : false)
  }


  for (var item of req.body.rewards) {
    if (!item.name) {
      break;
    } else {
      config.rewards.push({
        name : item.name,
        dsec : item.desc,
        chance : parseFloat(item.chance),
      })
    }
  }
  fs.writeFile(path.join(__dirname, 'config.json'),  
      JSON.stringify(global.config), 
      function (err) {
          if (err) {
            res.send({ok:false, msg:err})
          } else {
            global.config = config
            res.send({ok:true})
          }
      });
})

//上传文件路由
// app.post('/upload', upload.upload);

http.createServer(app).listen(app.get('port'), function(){
  console.log('Express server listening on port ' + app.get('port'));
});
