cc.Class({
    extends: cc.Component,

    properties: {
        infoLayer : cc.Node,
        inputLayer : cc.Node,

        nameEdit : cc.EditBox,
        phoneEdit : cc.EditBox,
    },

    // use this for initialization
    onLoad: function () {
        this.infoLayer.active = false;
        this.inputLayer.active = false;
        this.doReq();
    },

    _gotoGame : function() {
        if (this.phone && this.realName) {
            cc.director.loadScene('playScene');
        } else {
            this.inputLayer.active = true;
        }
    } ,

    btnDoStart : function () {
        if (this.nameEdit.string == "" || this.phoneEdit.string == "") {
            cc.log('kong')
        } else {
            this.phone = this.phoneEdit.string;
            this.realName = this.nameEdit.string;
            cc.log(this.phone, this.realName)
            var thiz = this;
            $.ajax({
                    type: 'GET',
                    url: "setPhone" ,
                    dataType: "json",
                    data: {
                        phone : this.phone,
                        realName : this.realName,
                    },
                    success: function(ret) {
                        cc.log(ret)
                        if (ret.ok)
                            thiz.inputLayer.active = false;
                    },
                    error : function(data) {
                    }
                });
        }
    },

    doReq : function() {
        if (this.loading) return;
        this.loading = true;
        var thiz = this;
        $.ajax({
                type: 'GET',
                url: "getInfo" ,
                dataType: "json",
                data: {
                    userid : "test1",
                },
                success: function(ret) {
                    window.data = ret;
                    thiz.loading = false;
                    console.log(ret)
                    if (!ret.enable) {
                        cc.director.loadScene('close');
                    } else {
                        if (ret.userinfo.phone != null && ret.userinfo.phone != undefined)
                            thiz.phone = ret.userinfo.phone
                        if (ret.userinfo.realName != null && ret.userinfo.realName != undefined)
                            thiz.realName = ret.userinfo.realName

                        if (thiz.action == 'game')
                            thiz._gotoGame();
                        else if (thiz.action == 'help')
                            thiz.infoLayer.active = true;
                    }
                },
                error : function(data) {
                    thiz.loading = false;
                }
            });
    },

    btnStart : function() {
        this.action = 'game'

        if (!this.loading)
            this._gotoGame();
    },
    btnInfo : function() {
        this.action = 'help'
        if (!this.loading)
            this.infoLayer.active = true;
    }
});
