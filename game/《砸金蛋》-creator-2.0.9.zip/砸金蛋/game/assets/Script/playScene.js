cc.Class({
    extends: cc.Component,

    properties: {
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...
        hammer : cc.Node,
        egg : cc.Node,

        winLayer : cc.Node,
        lostLayer : cc.Node,
        infoLayer : cc.Node,
        msgLayer : cc.Node,
        shareLayer : cc.Node,
        rewardLayer : cc.Node,
        
        eggParent : cc.Node,

        itemDesc : cc.Label,

        countLabel : cc.Label,
        rewardParent : cc.Node,


        
        frameTop : [cc.SpriteFrame],
        frameDown : [cc.SpriteFrame],
    },

    // use this for initialization
    onLoad: function () {
        this.infoLayer.active = false;
        this.lostLayer.active = false;
        this.winLayer.active = false;
        this.shareLayer.active = false;
        this.msgLayer.active = false;
        this.rewardLayer.active = false;


        this.hammer.zIndex = 1;
        this.hammerAni = this.hammer.getComponent(cc.Animation)
        
        this.hammerAni.on('finished', this._onPlay, this);
        this.hammer.active = false;
        this.egg.active = false;
        
        this.rewards = []
        for (let i = 0; i < 12; i ++) {
            let re = this.rewardParent.getChildByName('p'+(i+1));
            re.label = re.getChildByName('c').getComponent(cc.Label)
            this.rewards.push(re)
        }

        window.play = this;
        this._updateLabel();

        // 高亮拥有的奖品
        for (let i = 0; i < 12; i++) {
            let re = this.rewards[i]
            if (i < window.data.rewards.length) {
                if (window.data.userinfo.rewards[i]) {
                    re.color = new cc.Color(255, 255, 255)
                    re.label.string = 1
                } else {
                    re.color = new cc.Color(124, 124, 124)
                }
            } else {
                re.active = false;
            }
        }
    },

    _updateLabel : function() {
        if (window.data)
            this.countLabel.string = '你还剩'+window.data.userinfo.count+'次机会'
    },

    showMsg : function(msg) {
        this.msgLayer.active = true;
        this.msgLayer.getChildByName('Label').getComponent(cc.Label).string = msg
    },

    _showduiJiang : function(rewardIndex) {
        this.rewardLayer.active = true;
        let info = window.data.rewards[rewardIndex]
        this.rewardLayer.getChildByName('name').getComponent(cc.Label).string = info.name;
        this.rewardLayer.getChildByName('stmp').active = (window.data.userinfo.rewardIndex == rewardIndex)
        
        this.itemDesc.string = info.desc || "没有说明"
        this.rewardLayer.rewardIndex = rewardIndex;
    },

    request : function(req, arg, f) {
        let cb = f.bind(this)
        this.loading = true
        $.ajax({
            type: 'GET',
            url: req,
            dataType: "json",
            data: arg || {},
            success: function(data) {
                this.loading = false
                cb(data)
            },
            error : function(data) {
                this.loading = false
            }
        });
    },

    btnShengqin: function(evt) {
        this.request('requestReward', {
            rewardIndex : this.rewardLayer.rewardIndex
        }, function(data) {
            window.data.userinfo.rewardIndex = this.rewardLayer.rewardIndex
            this.rewardLayer.getChildByName('stmp').active = true;
        })
    },

    btnGuanBiDuiJiang : function() {
        this.rewardLayer.active = false;
    },

    onShare : function() {
        this.request('userShared', {

        }, function(data) {
            // 分享成功
            window.data.userinfo.count = data.addcount
            thiz._updateLabel();
            thiz.shareLayer.active = false;
            thiz.showMsg("分享成功")
        })
    },

    rewardPress : function(evt) {
        let name = evt.target.name
        let idx = parseInt(name.substring(1)) - 1

        if (!window.data) return;

        if (evt.target.color.r == 124) {
            this.showMsg(window.data.rewards[idx].name + " （未获得）")
        } else {
            this._showduiJiang(idx)
        }
    },

    eggPress : function(evt) {
        this.hammerAni.stop()
        this.hammer.active = true;

        this.hammer.x = evt.target.x;
        this.hammer.y = evt.target.y;
        
        this.hammerAni.play()
        this.hammer.getComponent(cc.AudioSource).play()

        var thiz = this;
        var eggIndex = parseInt(evt.target.name) - 1

        if (this.loading && !window.data) {
            cc.log(this.loading)
            return;
        }

        if (window.data.userinfo.count <= 0) {
            // 次数不足
            this.shareLayer.active = true;
            
            return;
        }

        this.request('hitEgg', {
            eggIndex : eggIndex
        }, function(data) {
            thiz.loading = false
            window.data.userinfo.count--
            thiz._updateLabel();
            thiz._breakEgg(evt)

            // 标记鸡蛋被打碎
            window.data.userinfo.eggs[eggIndex] = true;

            let rewardIndex = data.reward
            if (rewardIndex != null || rewardIndex != undefined) {
                // 高亮奖品
                thiz.rewards[rewardIndex].color = new cc.Color(255, 255, 255)
                window.data.userinfo.reward = rewardIndex
                thiz.rewards[rewardIndex].label.string = '1'

                thiz.winLayer.active = true;
                thiz.winLayer.rewardIndex = rewardIndex
                thiz.winLayer.getChildByName('name').getComponent(cc.Label).string = window.data.rewards[rewardIndex].name;
            } else {
                thiz.lostLayer.active = true;
            }
        })
    },
    
    _setEggBreak(index) {
        let old_egg = this.eggParent.getChildByName(''+(index+1))
        old_egg.active = false;

        this.breakedEGG = old_egg;

        let egg = cc.instantiate(this.egg)
        old_egg.breaker = egg;

        egg.parent = this.eggParent
        egg.active = true;
        egg.position = old_egg.position

        egg.getChildByName('top').opacity = 0
        egg.getChildByName('top').getComponent(cc.Sprite).spriteFrame = this.frameTop[index]
        egg.getChildByName('down').getComponent(cc.Sprite).spriteFrame = this.frameDown[index]

        return egg;
    },

    _breakEgg(evt) {
        var idx = parseInt(evt.target.name) - 1
        var egg = this._setEggBreak(idx)
        egg.getChildByName('top').opacity = 255
        egg.getComponent(cc.Animation).play()
    },
    
    restoreEggs() {
        if (!this.breakedEGG) return;
        this.breakedEGG.active = true;
        this.breakedEGG.breaker.parent = null
        this.breakedEGG = null
    },

    _onPlay : function() {
        this.hammer.active = false;
    },

    btnInfo : function() {
        this.infoLayer.active = true;
    },

    btnCheckInfo : function() {
        this.winLayer.active = false;
        this.restoreEggs();
        this._showduiJiang(this.winLayer.rewardIndex);
    },

    btnContinueGame : function() {
        this.restoreEggs();
        this.winLayer.active = false;
    },

    btnContinueGameMsg : function() {
        this.msgLayer.active = false;
    },

    btnAgain : function() {
        this.restoreEggs();
        this.lostLayer.active = false;
    },

    btnBack : function() {
        cc.director.loadScene('menuScene')
    },

    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});
