'use strict'


var randomIdx = function(mark) {
    let arr = [];
    let v = 0;
    let cfg = global.config.rewards

    for (let i = 0; i < cfg.length; i++) {
        if (!mark[i]) {
            v += cfg[i].chance
            arr.push({index:i, chance:v});
        }
    }

    let randNum = Math.random();
    for (var i = 0; i < arr.length; i++) {
        let info = arr[i];
        if (randNum < info.chance) {
            return info.index;
        }
    }
}

class UserHandler {

    //获取用户信息
    getInfo(req, res){ 
        var userid = req.query.userid;
        if (!userid) {
            res.redirect('/login')
            return
        }

        req.session.userid = userid

        DBMgr.getUser(userid, function(err, doc) {
            if (err) {
                console.log("DBMgr.getPlayerInfo error")
            } else {
                delete doc._id
                delete doc._userid
                req.session.userinfo = doc

                res.send({
                    enable  : global.config.enable,
                    help    : global.config.help,
                    rewards :　global.config.rewards,
                    userinfo : doc
                })
            }
        })
    };

    //打击一个蛋后
    hitEgg(req, res) {
        var uf = req.session.userinfo
        var userid = req.session.userid
        if (!userid) {
            res.redirect('/login')
            return
        }

        var eggIndex = parseInt(req.query.eggIndex)
        if (eggIndex == null || eggIndex == undefined) {
            res.send({errorid : 1})
            return
        }

        if (uf.count <= 0) {
            res.send({errorid : 2})
            return
        }

        if (!global.config.enable) {
            res.send({errorid : 3})
            return
        }

        let rewardIndex = randomIdx(uf.rewards);
        
        uf.count -- ;
        uf.eggs[eggIndex] = true
        uf.rewards[rewardIndex] = true

        DBMgr.setEggBreak(userid, rewardIndex, eggIndex, uf.count,
            (err, resule)=>{
                // rewardIndex == null or undefined 说明没中奖
                res.send({reward : rewardIndex})
            })
    }

    // 设置手机号和真实名
    setPhone (req, res) {

        var uf = req.session.userinfo
        var userid = req.session.userid;

        DBMgr.setPhone(userid, req.query.realName, req.query.phone,
            (err, resule)=>{
                res.send({ok : true})
            })
    }

    // 请求奖品编号
    requestReward(req, res) {
        var uf = req.session.userinfo
        var userid = req.session.userid;

        if (uf.isGot) {
            res.send({code : 1})//已经领取过了
        } else {
            uf.status = 1;
            
            DBMgr.setKey(userid, {
                'rewardIndex' : parseInt(req.query.rewardIndex),
                'status' : 1,//标记为已经请求
             }, (err, resule)=> {
                    res.send({code : 0})//
                })
        }
    }

    //领奖品接口
    getReward (req, res) {

        var uf = req.session.userinfo
        var userid = req.session.userid;

        if (uf.status == 0) {
            res.send({code : 0})//没有请求奖品
        } else if (uf.status == 2) {
            res.send({code : 1})//已经领取过了
        } else if (uf.status == 1) {
            uf.status = 2;

            DBMgr.setKey(userid, {
                'status' : 2,//标记为已经领取
                'isGot': true,
            }, (err, resule)=> {
                    res.send({code : 0})//
                })
        }
    }

    //用户分享成功 给与抽奖次数奖励
    userShared(req, res) {
        var uf = req.session.userinfo
        var userid = req.session.userid;
        if (!userid) {
            res.redirect('/login')
            return
        }

        uf.count += global.config.shared_reward

        DBMgr.addShareReward(userid, uf.count,
            (err, resule)=>{
                // 刷新内存
                res.send({addcount : global.config.shared_reward})
            })
    }

}

module.exports = new UserHandler