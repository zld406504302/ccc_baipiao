'use strict'
var MongoClient = require('mongodb').MongoClient

var url = process.env.MONGODBURL || 'mongodb://localhost/game';
var collection

var dump = function(userid) {
    collection.findOne({ userid: userid },
            function(err, doc) {
                console.log(doc)
            })
}

class DBManager {
    constructor() {
        MongoClient.connect(url, (err, db) => {
            if (err) {
                console.log("no db found.");
            } else {
                console.log("Connected db server successfully");
                collection = db.collection('game');
            }
        })
    }

    getUser(userid, cb) {
        collection.findOne({ userid: userid },
            function(err, doc) {

                if (doc) {
                    cb(null, doc)
                    return;
                }

                doc = {
                    userid : userid, 
                    rewards: [],
                    eggs   : [],
                    rewardIndex : null,//想领取的奖品编号
                    status : 0, // 0,表示什么都没，1已经请求，2已经领取
                    count  : global.config.default_count,//抽奖次数
                }

                console.log('new_user:', userid)
                collection.insert(doc, function(err, resule) {
                    cb(null, doc)
                })
            })
        
    }

    setEggBreak(userid, rewardIndex, eggIndex, leftcount, cb) {

        var set = {
            count : leftcount,
            ["eggs." + eggIndex]: true,
        }

        if (rewardIndex != null && rewardIndex != undefined) {
            set["rewards." + rewardIndex] = true
        }

        collection.updateOne({ userid: userid },
            { $set: set },
            function(err, resule) {
                cb(err, resule)
            }
        )
    }

    addShareReward(userid, leftcount, cb) {
        collection.updateOne({ userid: userid },
            { 
                $set: { count : leftcount }
            },
            function(err, resule) {
                cb(err, resule)
            }
        )
    }

    setPhone (userid, realName, phone, cb) {
        collection.updateOne({ userid: userid },
            { 
                $set: { 
                    realName : realName,
                    phone : phone 
                }
            },
            function(err, resule) {
                cb(err, resule)
            }
        )
    }

    setKey(userid, info, cb) {
        collection.updateOne({ userid: userid },
            { 
                $set: info
            },
            function(err, resule) {
                cb(err, resule)
            }
        )
    }

    //获取中奖列表
    getList(status, cb) {

        let iter = collection.find({ status: parseInt(status) }, 
            function(err, resule) {

                resule.toArray(function(err, docs) {
                    var ret = []

                    for (var i = 0; i < docs.length; i++) {
                        ret.push({
                            realName : docs[i].realName,
                            status : docs[i].status,
                            phone : docs[i].phone,
                            rewardIndex : docs[i].rewardIndex,
                            
                        })
                    }

                    cb(ret)
                })
        })
    }
}

global.DBMgr = new DBManager
