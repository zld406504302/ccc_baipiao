"use strict";
cc._RF.push(module, '81bc2x7ngxFVZXb64p0B0ZQ', 'LevelBtn');
// Script/Home/LevelBtn.js

'use strict';

var Global = require("Global");

cc.Class({
    extends: cc.Component,

    properties: {},
    // 关卡按钮点击
    btnClick: function btnClick(e) {
        // console.log(e.target.dataNum);
        if (Global.gameInfo.saveLevel < e.target.dataNum) {
            // console.log(`需要玩过第：${e.target.dataNum} 关解锁`);
            Global.home.bar.getChildByName('text').getComponent(cc.Label).string = '\u9700\u8981\u73A9\u8FC7\u7B2C\uFF1A' + e.target.dataNum + ' \u5173\u89E3\u9501';
            if (Global.home.isClick) return;
            Global.home.isClick = true;
            var h = Global.home.bar.height;
            var show = cc.moveBy(0.3, cc.p(0, -h));
            Global.home.bar.runAction(show);
            if (Global.home.timer) clearTimeout(Global.home.timer);
            Global.home.timer = setTimeout(function () {
                // cc.log('执行');
                var hide = cc.moveBy(0.3, cc.p(0, h));
                Global.home.bar.runAction(hide);
                Global.home.isClick = false;
            }, 3000);
            // console.log('定时器：', Global.home.timer);
        } else {
            Global.gameInfo.level = e.target.dataNum;
            cc.director.loadScene('Game');
            if (Global.home.timer) clearTimeout(Global.home.timer);
        }
    },

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start: function start() {}
}

// update (dt) {},
);

cc._RF.pop();