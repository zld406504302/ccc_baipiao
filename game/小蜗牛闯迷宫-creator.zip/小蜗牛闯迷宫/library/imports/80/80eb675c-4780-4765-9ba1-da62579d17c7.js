"use strict";
cc._RF.push(module, '80eb6dcR4BHZZuh2mJXnRfH', 'Rank');
// Script/Rank/Rank.js

'use strict';

var Global = require("Global");

cc.Class({
    extends: cc.Component,

    properties: {},
    openGame: function openGame() {
        cc.director.loadScene('Game');
    },
    openHome: function openHome() {
        cc.director.loadScene('Home');
    },

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start: function start() {}
}

// update (dt) {},
);

cc._RF.pop();