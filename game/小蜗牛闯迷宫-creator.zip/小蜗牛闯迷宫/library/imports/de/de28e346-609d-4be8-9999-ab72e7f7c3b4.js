"use strict";
cc._RF.push(module, 'de28eNGYJ1L6JmZq3Ln98O0', 'Map');
// Script/Game/Map.js

'use strict';

var _Global = require('Global');

var _Global2 = _interopRequireDefault(_Global);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

cc.Class({
    extends: cc.Component,

    properties: {
        // 资源
        prefab: {
            default: null,
            type: cc.Prefab
        }
    },
    createMap: function createMap() {
        var _this = this;

        // 坐标
        var location = { x: 0, y: 0 };
        // 上一个管道方向
        var after_d = '';
        /**
         * 单个生成管道
         * @param {nunber} distance 距离
         * @param {string} direction 方向
         * @param {nunber} index 管道位置
         * @param {string} mark 管道标记 last & first
         */
        var single = function single(distance, direction, mark) {
            // 创建色块
            var sprite = cc.instantiate(_this.prefab);
            // 碰撞墙的集合
            var wall = {
                top: sprite.getChildByName('wall-top'),
                bottom: sprite.getChildByName('wall-bottom'),
                left: sprite.getChildByName('wall-left'),
                right: sprite.getChildByName('wall-right')
            };
            // 箭头道具（这里的箭头道具要放在下一条管道上，因为下一条会覆盖当前的管道）
            var arrow = sprite.getChildByName('arrow'),
                arrow_off = sprite.getChildByName('arrow-off');
            // 终点旗帜
            var end = sprite.getChildByName('end');
            // 终点旗帜长宽比值
            var value = 5;
            // 碰撞墙和轨道的间距（碰撞物体宽度的一半）
            var spacing = 50;
            // 设置颜色
            sprite.color = new cc.Color({ r: 255, g: 255, b: 255 });
            switch (direction) {
                case 'top':
                    sprite.width = _Global2.default.gameInfo.conduitWidth;
                    sprite.height = distance;
                    sprite.x = location.x;
                    sprite.y = location.y + distance / 2 - _Global2.default.gameInfo.conduitWidth / 2;
                    // 碰撞墙包围显示
                    wall.left.active = wall.right.active = wall.bottom.active = true;
                    // 第一条特殊处理
                    if (mark === 'first') {
                        arrow.active = arrow_off.active = wall.bottom.active = false;
                    } else {
                        // 在尾部设置上一个方向
                        arrow.dataDirection = 'top';
                        arrow.rotation = arrow_off.rotation = 0;
                        arrow.y = arrow_off.y = -(distance - _Global2.default.gameInfo.conduitWidth) / 2;
                    }
                    // 左边碰撞条
                    wall.left.height = wall.left.getComponent(cc.BoxCollider).size.height = distance - _Global2.default.gameInfo.conduitWidth - spacing;
                    wall.left.x = -(_Global2.default.gameInfo.conduitWidth / 2 + spacing);
                    wall.left.y = -(_Global2.default.gameInfo.conduitWidth / 2 + spacing);
                    // 右边碰撞条
                    wall.right.height = wall.right.getComponent(cc.BoxCollider).size.height = distance - _Global2.default.gameInfo.conduitWidth - spacing;
                    wall.right.x = _Global2.default.gameInfo.conduitWidth / 2 + spacing;
                    wall.right.y = -(_Global2.default.gameInfo.conduitWidth / 2 + spacing);
                    // 下边碰撞条
                    wall.bottom.width = wall.bottom.getComponent(cc.BoxCollider).size.width = _Global2.default.gameInfo.conduitWidth + spacing * 2;
                    wall.bottom.y = -(distance / 2 + spacing);
                    // 判断上一条的对接口
                    if (after_d === 'left') {
                        wall.right.height = wall.right.getComponent(cc.BoxCollider).size.height = distance - (_Global2.default.gameInfo.conduitWidth + spacing) * 2;
                        wall.right.y = 0;
                    } else if (after_d === 'right') {
                        wall.left.height = wall.left.getComponent(cc.BoxCollider).size.height = distance - (_Global2.default.gameInfo.conduitWidth + spacing) * 2;
                        wall.left.y = 0;
                    }
                    // 判断是否终点，添加终点碰撞
                    if (mark === 'last') {
                        end.active = true;
                        end.width = end.getComponent(cc.BoxCollider).size.width = _Global2.default.gameInfo.conduitWidth;
                        end.height = end.getComponent(cc.BoxCollider).size.height = end.width / value;
                        end.y = spacing;
                    }
                    // 更新一下坐标 & 上一个方向
                    location.y = location.y + distance - _Global2.default.gameInfo.conduitWidth;
                    after_d = direction;
                    break;
                case 'bottom':
                    sprite.width = _Global2.default.gameInfo.conduitWidth;
                    sprite.height = distance;
                    sprite.x = location.x;
                    sprite.y = location.y - distance / 2 + _Global2.default.gameInfo.conduitWidth / 2;
                    // 碰撞墙包围显示
                    wall.left.active = wall.right.active = wall.top.active = true;
                    // 在尾部设置上一个方向
                    arrow.dataDirection = 'down';
                    arrow.rotation = arrow_off.rotation = 180;
                    arrow.y = arrow_off.y = (distance - _Global2.default.gameInfo.conduitWidth) / 2;
                    // 左边碰撞条
                    wall.left.height = wall.left.getComponent(cc.BoxCollider).size.height = distance - _Global2.default.gameInfo.conduitWidth - spacing;
                    wall.left.x = -(_Global2.default.gameInfo.conduitWidth / 2 + spacing);
                    wall.left.y = _Global2.default.gameInfo.conduitWidth / 2 + spacing;
                    // 右边碰撞条
                    wall.right.height = wall.right.getComponent(cc.BoxCollider).size.height = distance - _Global2.default.gameInfo.conduitWidth - spacing;
                    wall.right.x = _Global2.default.gameInfo.conduitWidth / 2 + spacing;
                    wall.right.y = _Global2.default.gameInfo.conduitWidth / 2 + spacing;
                    // 上边碰撞条
                    wall.top.width = wall.top.getComponent(cc.BoxCollider).size.width = _Global2.default.gameInfo.conduitWidth + spacing * 2;
                    wall.top.y = distance / 2 + spacing;
                    // 判断上一条的对接口
                    if (after_d === 'left') {
                        wall.right.height = wall.right.getComponent(cc.BoxCollider).size.height = distance - (_Global2.default.gameInfo.conduitWidth + spacing) * 2;
                        wall.right.y = 0;
                    } else if (after_d === 'right') {
                        wall.left.height = wall.left.getComponent(cc.BoxCollider).size.height = distance - (_Global2.default.gameInfo.conduitWidth + spacing) * 2;
                        wall.left.y = 0;
                    }
                    // 判断是否终点，添加终点碰撞
                    if (mark === 'last') {
                        end.active = true;
                        end.width = end.getComponent(cc.BoxCollider).size.width = _Global2.default.gameInfo.conduitWidth;
                        end.height = end.getComponent(cc.BoxCollider).size.height = end.width / value;
                        end.y = -spacing;
                    }
                    // 更新一下坐标 & 上一个方向
                    location.y = location.y - distance + _Global2.default.gameInfo.conduitWidth;
                    after_d = direction;
                    break;
                case 'left':
                    sprite.width = distance;
                    sprite.height = _Global2.default.gameInfo.conduitWidth;
                    sprite.x = location.x - distance / 2 + _Global2.default.gameInfo.conduitWidth / 2;
                    sprite.y = location.y;
                    // 碰撞墙包围显示
                    wall.top.active = wall.bottom.active = wall.right.active = true;
                    // 在尾部设置上一个方向
                    arrow.dataDirection = 'left';
                    arrow.rotation = arrow_off.rotation = -90;
                    arrow.x = arrow_off.x = (distance - _Global2.default.gameInfo.conduitWidth) / 2;
                    // 上边碰撞条
                    wall.top.width = wall.top.getComponent(cc.BoxCollider).size.width = distance - _Global2.default.gameInfo.conduitWidth - spacing;
                    wall.top.x = _Global2.default.gameInfo.conduitWidth / 2 + spacing;
                    wall.top.y = _Global2.default.gameInfo.conduitWidth / 2 + spacing;
                    // 下边碰撞条
                    wall.bottom.width = wall.bottom.getComponent(cc.BoxCollider).size.width = distance - _Global2.default.gameInfo.conduitWidth - spacing;
                    wall.bottom.x = _Global2.default.gameInfo.conduitWidth / 2 + spacing;
                    wall.bottom.y = -(_Global2.default.gameInfo.conduitWidth / 2 + spacing);
                    // 右边碰撞条
                    wall.right.height = wall.right.getComponent(cc.BoxCollider).size.height = _Global2.default.gameInfo.conduitWidth + spacing * 2;
                    wall.right.x = distance / 2 + spacing;
                    // 判断上一条的对接口
                    if (after_d === 'top') {
                        wall.bottom.width = wall.bottom.getComponent(cc.BoxCollider).size.width = distance - (_Global2.default.gameInfo.conduitWidth + spacing) * 2;
                        wall.bottom.x = 0;
                    } else if (after_d === 'bottom') {
                        wall.top.width = wall.top.getComponent(cc.BoxCollider).size.width = distance - (_Global2.default.gameInfo.conduitWidth + spacing) * 2;
                        wall.top.x = 0;
                    }
                    // 判断是否终点，添加终点碰撞
                    if (mark === 'last') {
                        end.active = true;
                        end.width = end.getComponent(cc.BoxCollider).size.width = _Global2.default.gameInfo.conduitWidth;
                        end.height = end.getComponent(cc.BoxCollider).size.height = end.width / value;
                        end.x = -(end.width / 2 + spacing * 2);
                        end.rotation = -90;
                    }
                    // 更新一下坐标 & 上一个方向
                    location.x = location.x - distance + _Global2.default.gameInfo.conduitWidth;
                    after_d = direction;
                    break;
                case 'right':
                    sprite.width = distance;
                    sprite.height = _Global2.default.gameInfo.conduitWidth;
                    sprite.x = location.x + distance / 2 - _Global2.default.gameInfo.conduitWidth / 2;
                    sprite.y = location.y;
                    // 碰撞墙包围显示
                    wall.top.active = wall.bottom.active = wall.left.active = true;
                    // 在尾部设置上一个方向
                    arrow.dataDirection = 'right';
                    arrow.rotation = arrow_off.rotation = 90;
                    arrow.x = arrow_off.x = -(distance - _Global2.default.gameInfo.conduitWidth) / 2;
                    // 上边碰撞条
                    wall.top.width = wall.top.getComponent(cc.BoxCollider).size.width = distance - _Global2.default.gameInfo.conduitWidth - spacing;
                    wall.top.x = -(_Global2.default.gameInfo.conduitWidth / 2 + spacing);
                    wall.top.y = _Global2.default.gameInfo.conduitWidth / 2 + spacing;
                    // 下边碰撞条
                    wall.bottom.width = wall.bottom.getComponent(cc.BoxCollider).size.width = distance - _Global2.default.gameInfo.conduitWidth - spacing;
                    wall.bottom.x = -(_Global2.default.gameInfo.conduitWidth / 2 + spacing);
                    wall.bottom.y = -(_Global2.default.gameInfo.conduitWidth / 2 + spacing);
                    // 左边碰撞条
                    wall.left.height = wall.left.getComponent(cc.BoxCollider).size.height = _Global2.default.gameInfo.conduitWidth + spacing * 2;
                    wall.left.x = -(distance / 2 + spacing);
                    // 判断上一条的对接口
                    if (after_d === 'top') {
                        wall.bottom.width = wall.bottom.getComponent(cc.BoxCollider).size.width = distance - (_Global2.default.gameInfo.conduitWidth + spacing) * 2;
                        wall.bottom.x = 0;
                    } else if (after_d === 'bottom') {
                        wall.top.width = wall.top.getComponent(cc.BoxCollider).size.width = distance - (_Global2.default.gameInfo.conduitWidth + spacing) * 2;
                        wall.top.x = 0;
                    }
                    // 判断是否终点，添加终点碰撞
                    if (mark === 'last') {
                        end.active = true;
                        end.width = end.getComponent(cc.BoxCollider).size.width = _Global2.default.gameInfo.conduitWidth;
                        end.height = end.getComponent(cc.BoxCollider).size.height = end.width / value;
                        end.x = end.width / 2 + spacing * 2;
                        end.rotation = 90;
                    }
                    // 更新一下坐标 & 上一个方向
                    location.x = location.x + distance - _Global2.default.gameInfo.conduitWidth;
                    after_d = direction;
                    break;
            }
            // 输出到对应容器
            sprite.parent = _this.node;
        };
        var list = _Global2.default.levels[_Global2.default.gameInfo.level].list;
        // 修改对应的关卡速度
        _Global2.default.gameInfo.speed = _Global2.default.levels[_Global2.default.gameInfo.level].speed;
        // 修改对应的关卡旋转
        _Global2.default.gameInfo.rotate = _Global2.default.levels[_Global2.default.gameInfo.level].rotate;
        // 重置下初始化方向
        _Global2.default.game.direction = list[0].str;
        _Global2.default.game.move_direction = list[1].str;
        // 生成轨道
        for (var i = 0; i < list.length; i++) {
            if (i == 0) {
                single(list[i].num, list[i].str, 'first');
            } else if (i == list.length - 1) {
                single(list[i].num, list[i].str, 'last');
            } else {
                single(list[i].num, list[i].str);
            }
        }
    },

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start: function start() {
        this.createMap();
    }
}

// update (dt) {},
); // const Global = require("Global")

cc._RF.pop();